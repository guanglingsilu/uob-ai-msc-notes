# 模块地图、项目连接与综合

## Core Idea
本单元围绕以下页面建立学习路径：第 24 页、第 25 页、第 26 页、第 27 页。

## Page-by-page Learning Notes
### 第 24 页：One question, four areas, eleven weeks

- Source ID: `src-ba38b47b419c-pdf_page-00024`
- Core: 这一页给模块结构。第 1-3 周建立人和智能交互的概念基础；第 4-7 周转向工程与系统构建；第 8-11 周看身体、空间、能动性、依赖、评估和部署。中心问题始终是智能能力如何有意义地参与互动。
- Extension: 复习时可把每周内容放回主问题：这周帮助我回答 design、build 还是 evaluate？它处理的是人、工程、身体空间，还是部署责任？

#### Key Concepts
- **Module map / 模块地图**：课程主题与周次的结构化安排。
- **Meaningful participation / 有意义参与**：智能能力不是装饰，而是在互动中实际改变任务、决策或体验。
- **Evaluation and deployment / 评估与部署**：后期关注系统是否有效、可靠、可被依赖并适合真实环境。

### 第 25 页：Phase 1 begins now: choose an area by its shift

- Source ID: `src-ba38b47b419c-pdf_page-00025`
- Core: 这一页把课程框架接到项目。选题不要先想“做什么应用”，而要问它依赖哪类智能能力：规则对话、GUI/直接操控、推荐学习、感知深度学习、LLM/agents。不同 shift 会决定文献、评估指标和证据类型。
- Extension: 写 proposal 时建议用一句话定位：My project depends primarily on Shift X because... Then evidence should include... 这样能把技术、交互变量和文献类型连起来。

#### Key Concepts
- **Phase 1 / 阶段 1**：第 1-4 周的项目阶段，聚焦问题、文献、研究空白和贡献。
- **Research gap / 研究空白**：现有文献或系统尚未充分解决的问题。
- **Contribution / 贡献**：你的项目相对已有工作的新增价值，可以是设计、实现、评估或实证发现。

### 第 26 页：What changed each time

- Source ID: `src-ba38b47b419c-pdf_page-00026`
- Core: 这是总结页，也是最该记住的一页。AI 系统越强，越要主动设计用户的可见性和可撤销性。课程不是反对系统推断或主动行动，而是要求在能力上升时重新设计控制、解释、确认和恢复机制。
- Extension: 这一页可变成项目评价准则：我的系统增加了哪些推断和主动权？我怎样把可见性和可撤销性设计回来？

#### Key Concepts
- **Design choice / 设计选择**：某种交互品质不是技术自然产物，而是设计者通过界面、流程、反馈和约束主动实现的。
- **Designing back in / 重新设计回来**：在现代智能系统中重新引入 GUI 时代强调的可见性和可撤销性。
- **Human control / 人的控制**：用户理解、批准、修正、撤销和监督系统行动的能力。

### 第 27 页：References and further reading

- Source ID: `src-ba38b47b419c-pdf_page-00027`
- Core: 这一页给整讲的学术出处。它把本讲的几条线索连起来：James 和 Levin 支持广义智能定义；Turing 和 Weizenbaum 支持早期 AI 与交互讨论；Sutherland、Shneiderman 支持直接操控与 human-centered AI；GroupLens、Amazon、ImageNet、Transformers、GPT-3 支持五次能力迁移中的技术节点。
- Extension: 优先精读 Shneiderman 1983、Shneiderman 2022 第 1 章、Weizenbaum 1966/1976、Brown 2020 和 Levin 2022。做项目时，再按自己的 shift 选择 GroupLens/Amazon、ImageNet 或 Transformer/LLM 方向。

#### Key Concepts
- **Primary source / 一手来源**：概念或技术首次提出或经典发表的文献，例如 Turing 1950、Weizenbaum 1966、Shneiderman 1983。
- **Further reading / 延伸阅读**：用于加深理解但不一定在课件正文详讲的文献。
- **Citation lineage / 引文脉络**：一讲课中概念、案例和理论的来源网络。
