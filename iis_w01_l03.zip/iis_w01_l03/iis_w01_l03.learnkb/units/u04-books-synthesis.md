# 书目、综合与参考

## Page-by-page Notes

### 第 21 页：Three books, and how the module reads them

Source ID: `src-b91e955ebdec-pdf_page-00021`

这页告诉你如何用书：不是泛读，而是按 lecture anchor 读。每本书支撑不同部分：HCAI、日常设计心理学、XR。

#### Concepts
- **Chapter anchor / 章节锚点**：每讲指定的阅读定位，用于支撑当前设计问题。

### 第 22 页：Who is it for, and what does that commit us to?

Source ID: `src-b91e955ebdec-pdf_page-00022`

总结页把本讲压缩成项目原则：先问为谁设计，再用指南和主动权规则保证人在系统推断与行动中仍保留控制。

#### Concepts
- **Gap sentence / 研究空白句**：用一句话说明现有工作没有解决什么，以及你的项目切入点。

### 第 23 页：References and further reading

Source ID: `src-b91e955ebdec-pdf_page-00023`

参考页把每个概念的学术来源对应起来。复习时按主题读：HCAI 看 Shneiderman，日常设计看 Norman，指南看 Amershi，主动权看 Horvitz，期待鸿沟看 Luger & Sellen。

#### Concepts
- **Citation mapping / 引文映射**：把课程概念与支撑文献一一对应，便于复习和项目引用。
