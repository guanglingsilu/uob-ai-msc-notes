# 自测题

## 第 1 页：Ingredients of an Intelligent Interactive Systems
- p001-q1 中文：第 1 页的核心设计问题是什么？
  - 答案：这一页给出本讲目标：从第 1 讲的用户体验框架转向系统内部结构。你要学会把一个智能交互系统拆成层次，并在系统出错时定位是哪一层导致失败。
  - English: What is the core design issue on page 1?
  - Answer: This opening slide shifts from user-facing interaction to the system's internal ingredients. The lecture teaches students to apply the working definition and trace failures through layers.
- p001-q2 中文：本页最重要的概念是什么？
  - 答案：Conceptual spine / 概念脊柱：一个逐层分析系统的检查表，用来追踪人、感知、上下文、模型、行动、反馈和适应之间的关系。
  - English: What is the most important concept on this page?
  - Answer: Conceptual spine: 一个逐层分析系统的检查表，用来追踪人、感知、上下文、模型、行动、反馈和适应之间的关系。
## 第 2 页：The mis-cropped page
- p002-q1 中文：第 2 页的核心设计问题是什么？
  - 答案：这页用手机扫描裁剪错误作为贯穿案例。重点不是马上猜“AI 错了”，而是把症状追踪到具体层：是传感输入模糊、上下文假设错、模型边缘检测错，还是用户无法修正反馈。
  - English: What is the core design issue on page 2?
  - Answer: The mis-cropped scan is a concrete diagnostic case. The lecture will return to it after giving a layer-by-layer method for locating the cause of failure.
- p002-q2 中文：本页最重要的概念是什么？
  - 答案：Failure diagnosis / 失败诊断：先描述症状，再定位到系统层次，最后选择修复方案。不同层出错需要不同修复。
  - English: What is the most important concept on this page?
  - Answer: Failure diagnosis: 先描述症状，再定位到系统层次，最后选择修复方案。不同层出错需要不同修复。
## 第 3 页：From the frame to the box
- p003-q1 中文：第 3 页的核心设计问题是什么？
  - 答案：第 1 讲是外部评价：系统如何改变用户。第 2 讲是内部分析：系统由哪些层组成，智能放在哪里，失败如何穿过层传播。
  - English: What is the core design issue on page 3?
  - Answer: Lecture 01 described effects on the person; Lecture 02 opens the box and asks what components must be present for a system to be both intelligent and interactive.
- p003-q2 中文：本页最重要的概念是什么？
  - 答案：Initiative, inference, visibility, reversibility / 主动权、推断、可见性、可撤销性：第 1 讲的用户侧框架，在第 2 讲中会与系统内部层次连接起来。
  - English: What is the most important concept on this page?
  - Answer: Initiative, inference, visibility, reversibility: 第 1 讲的用户侧框架，在第 2 讲中会与系统内部层次连接起来。
## 第 4 页：The working definition
- p004-q1 中文：第 4 页的核心设计问题是什么？
  - 答案：这一页给出本课对智能交互系统的工作定义。关键是 loop：系统不是离线做预测，而是在人的情境中感知、解释、行动、适应。模型输出永远是可错的推断。
  - English: What is the core design issue on page 4?
  - Answer: The working definition treats intelligence as part of an interaction loop. The system senses, interprets, acts, and adapts with a person and context, while model accuracy is only one part of quality.
- p004-q2 中文：本页最重要的概念是什么？
  - 答案：Inference / 推断：系统对信号作出的最佳解释，例如用户意图、当前状态或偏好；它不是事实本身，可能错误。
  - English: What is the most important concept on this page?
  - Answer: Inference: 系统对信号作出的最佳解释，例如用户意图、当前状态或偏好；它不是事实本身，可能错误。
## 第 5 页：Four properties, all required
- p005-q1 中文：第 5 页的核心设计问题是什么？
  - 答案：这是本讲最核心的定义页。只有感知、解释、行动、闭环同时存在，才算智能交互系统。单纯自动化、单次预测或没有人类反馈的流水线都不完整。
  - English: What is the core design issue on page 5?
  - Answer: The four required properties are sensing, interpretation under uncertainty, action through an output channel, and a closed human loop. They must hold together.
- p005-q2 中文：本页最重要的概念是什么？
  - 答案：Closed loop / 闭环：系统输出影响人，人的反应又影响系统下一步行为。没有这个回路，系统只是 pipeline。
  - English: What is the most important concept on this page?
  - Answer: Closed loop: 系统输出影响人，人的反应又影响系统下一步行为。没有这个回路，系统只是 pipeline。
## 第 6 页：The conceptual spine at a glance
- p006-q1 中文：第 6 页的核心设计问题是什么？
  - 答案：概念脊柱不是必须每层都复杂，而是让你知道要查哪里。某层为空不是失败，而是分析结果：例如没有记忆、没有适应、没有工具，都说明系统边界。
  - English: What is the core design issue on page 6?
  - Answer: The spine is a checklist for inspecting the system. It covers human involvement, sensing, context, memory, knowledge, model, planning, tools, action, environment, feedback, and adaptation.
- p006-q2 中文：本页最重要的概念是什么？
  - 答案：Empty layer / 空层：某一层不存在或只是占位，同样是有意义的系统分析发现。
  - English: What is the most important concept on this page?
  - Answer: Empty layer: 某一层不存在或只是占位，同样是有意义的系统分析发现。
## 第 7 页：Layers 1 and 2: the human and sensing
- p007-q1 中文：第 7 页的核心设计问题是什么？
  - 答案：这页把 scanner 的前两层展开。人带着目标和心理模型进入系统；系统通过相机、运动传感器、方向传感器和触摸收集信号。这里的智能不是用户明确命令，而是系统从信号中看出“页面”。
  - English: What is the core design issue on page 7?
  - Answer: The scanner begins with the person's goal and available signals. Sensing goes beyond explicit commands because the system detects a page without the user saying so.
- p007-q2 中文：本页最重要的概念是什么？
  - 答案：Sensing beyond commands / 超越命令的感知：系统收集环境、身体或行为信号，而不只是执行用户显式指令。
  - English: What is the most important concept on this page?
  - Answer: Sensing beyond commands: 系统收集环境、身体或行为信号，而不只是执行用户显式指令。
## 第 8 页：Layers 3 to 5: context, memory and knowledge
- p008-q1 中文：第 8 页的核心设计问题是什么？
  - 答案：同一张图像不只由像素决定。上下文告诉系统当前情况，记忆给出个人历史，知识提供一般规则。三者都会影响扫描器如何解释边界、方向和文字。
  - English: What is the core design issue on page 8?
  - Answer: Context, memory, and knowledge add information beyond the current frame. They shape how the scanner interprets page size, orientation, filtering, and text recognition.
- p008-q2 中文：本页最重要的概念是什么？
  - 答案：Context / 上下文：当前任务和环境条件，例如第几页、方向、光照。
  - English: What is the most important concept on this page?
  - Answer: Context: 当前任务和环境条件，例如第几页、方向、光照。
## 第 9 页：Layer 6: the model
- p009-q1 中文：第 9 页的核心设计问题是什么？
  - 答案：模型层负责把传感数据变成判断：哪里是纸张边界、如何校正透视、文字是什么。每个判断都是概率性的，不是绝对真相，所以后续界面需要让用户检查和修正。
  - English: What is the core design issue on page 9?
  - Answer: The model turns signals into claims: edges, quadrilaterals, perspective transforms, and recognized text. Each claim is uncertain and can be wrong.
- p009-q2 中文：本页最重要的概念是什么？
  - 答案：Edge detection / 边缘检测：识别图像中强烈变化的边界，用于找页面轮廓。
  - English: What is the most important concept on this page?
  - Answer: Edge detection: 识别图像中强烈变化的边界，用于找页面轮廓。
## 第 10 页：Layers 7 and 8: planning and action
- p010-q1 中文：第 10 页的核心设计问题是什么？
  - 答案：模型只是提出解释，规划层决定怎么处理解释，行动层真正改变状态。扫描器可以等一等、自动拍摄、提示用户或直接裁剪。不同选择会改变用户控制感和错误成本。
  - English: What is the core design issue on page 10?
  - Answer: Planning chooses the next step and action executes it. The scanner may capture, wait, ask, assume, crop, rotate, recognize, save, or share through different output channels.
- p010-q2 中文：本页最重要的概念是什么？
  - 答案：Planning / 规划：根据目标、不确定性和上下文选择下一步。
  - English: What is the most important concept on this page?
  - Answer: Planning: 根据目标、不确定性和上下文选择下一步。
## 第 11 页：Layers 9 to 11: closing the loop
- p011-q1 中文：第 11 页的核心设计问题是什么？
  - 答案：闭环意味着用户不是最后的旁观者，而是能改变系统下一步。即时反馈是拖角、重拍、接受；长期适应是系统把偏好变成默认。
  - English: What is the core design issue on page 11?
  - Answer: The loop closes when the person's response changes what happens next. Immediate feedback supports re-cropping; adaptation changes defaults over time.
- p011-q2 中文：本页最重要的概念是什么？
  - 答案：Feedback / 反馈：系统让人看到结果并允许回应。
  - English: What is the most important concept on this page?
  - Answer: Feedback: 系统让人看到结果并允许回应。
## 第 12 页：Tracing the mis-crop to its layer
- p012-q1 中文：第 12 页的核心设计问题是什么？
  - 答案：同一个错误表象可以来自不同层，修复也完全不同。不要把所有问题归咎于模型。用户无法修正、系统过早行动、反馈控件太小，都可能被误认为“AI 错了”。
  - English: What is the core design issue on page 12?
  - Answer: The same visible symptom can come from sensing, context, model, action, or feedback. The fix depends on the diagnosed layer.
- p012-q2 中文：本页最重要的概念是什么？
  - 答案：Symptom vs cause / 症状与原因：看到的错误只是表象，真正原因需要沿层追踪证据。
  - English: What is the most important concept on this page?
  - Answer: Symptom vs cause: 看到的错误只是表象，真正原因需要沿层追踪证据。
## 第 13 页：Intelligence can sit at any layer
- p013-q1 中文：第 13 页的核心设计问题是什么？
  - 答案：智能不总在模型层。它可以在记忆、适应、规划、工具使用中出现。判断时先问：系统到底在哪里推断了什么？单纯自动适应不一定满足智能交互定义。
  - English: What is the core design issue on page 13?
  - Answer: Inference can appear in different layers: model, memory, adaptation, planning, or tool use. Adaptation alone is not enough under the working definition.
- p013-q2 中文：本页最重要的概念是什么？
  - 答案：Locate the inference / 定位推断：分析系统时先找出哪一层在做不确定解释。
  - English: What is the most important concept on this page?
  - Answer: Locate the inference: 分析系统时先找出哪一层在做不确定解释。
## 第 14 页：One scale of autonomy
- p014-q1 中文：第 14 页的核心设计问题是什么？
  - 答案：自主性不是越高越好。简单系统、agentic system、多智能体系统代表不同复杂度。课程给出的设计原则是：先选择足够简单的结构，只有当额外自治和协调真的带来收益时再升级。
  - English: What is the core design issue on page 14?
  - Answer: The autonomy scale runs from simple systems to agentic systems to multi-agent systems. The lecture's design principle is to choose the simplest design that does the job.
- p014-q2 中文：本页最重要的概念是什么？
  - 答案：Agentic system / 智能体系统：能观察、决策、调用工具、检查结果并继续推进目标的系统。
  - English: What is the most important concept on this page?
  - Answer: Agentic system: 能观察、决策、调用工具、检查结果并继续推进目标的系统。
## 第 15 页：The scanner at three points on the scale
- p015-q1 中文：第 15 页的核心设计问题是什么？
  - 答案：这个例子说明多智能体不是高级默认答案。如果任务步骤强依赖、线性推进，把它拆成多个 agent 可能只增加交接和故障点。
  - English: What is the core design issue on page 15?
  - Answer: The scanner example shows that multi-agent design is not automatically better. If steps are sequential and dependent, extra loops add hand-offs without benefit.
- p015-q2 中文：本页最重要的概念是什么？
  - 答案：Smallest sufficient design / 最小充分设计：能完成任务且复杂度最低的设计。
  - English: What is the most important concept on this page?
  - Answer: Smallest sufficient design: 能完成任务且复杂度最低的设计。
## 第 16 页：What moves along the scale
- p016-q1 中文：第 16 页的核心设计问题是什么？
  - 答案：自主性提升会把 L01 的四变量再次拉出来：主动权、推断上升，但可见性、可撤销性下降。设计者必须补上检查、日志、预览和恢复路径。
  - English: What is the core design issue on page 16?
  - Answer: As autonomy increases, initiative and inference rise while visibility and reversibility tend to fall. Inspection and recovery become more demanding.
- p016-q2 中文：本页最重要的概念是什么？
  - 答案：Inspection work / 检查工作：用户或开发者为了理解系统行为必须阅读轨迹、日志、状态或证据。
  - English: What is the most important concept on this page?
  - Answer: Inspection work: 用户或开发者为了理解系统行为必须阅读轨迹、日志、状态或证据。
## 第 17 页：Your turn: place three systems
- p017-q1 中文：第 17 页的核心设计问题是什么？
  - 答案：这页是把自主性尺度应用到真实系统。重点是分类后还要问：更简单的设计是否足够？例如 C 看似多智能体，但也许一个 agent 加工具就够。
  - English: What is the core design issue on page 17?
  - Answer: The activity asks students to classify systems on the autonomy scale and defend the smallest sufficient design.
- p017-q2 中文：本页最重要的概念是什么？
  - 答案：Classification by autonomy / 按自主性分类：根据系统是否单次推断、是否持续行动、是否协调多个循环来分类。
  - English: What is the most important concept on this page?
  - Answer: Classification by autonomy: 根据系统是否单次推断、是否持续行动、是否协调多个循环来分类。
## 第 18 页：Every inference is a bet
- p018-q1 中文：第 18 页的核心设计问题是什么？
  - 答案：系统输出经常看起来确定，但内部其实是在多个候选中选择。设计不能只展示最终答案，还要考虑置信度、备选、纠错入口和失败后的用户行动。
  - English: What is the core design issue on page 18?
  - Answer: Inference is a bet among alternatives. Users often see only the chosen interpretation, so designers must expose what people can see and do when it fails.
- p018-q2 中文：本页最重要的概念是什么？
  - 答案：Uncertainty / 不确定性：推断不是确定事实，而是在多个可能解释中选择。
  - English: What is the most important concept on this page?
  - Answer: Uncertainty: 推断不是确定事实，而是在多个可能解释中选择。
## 第 19 页：Each layer's story for being wrong
- p019-q1 中文：第 19 页的核心设计问题是什么？
  - 答案：这页把不确定性变成设计清单：不同层出错时，用户需要不同信息和控制。修复不是统一的“加解释”，而是要匹配层次。
  - English: What is the core design issue on page 19?
  - Answer: Each layer needs a visible route from error to correction. The appropriate control depends on whether the error is in sensing, inference, planning, action, feedback, or adaptation.
- p019-q2 中文：本页最重要的概念是什么？
  - 答案：Confidence / 置信度：系统对某个推断的把握程度。
  - English: What is the most important concept on this page?
  - Answer: Confidence: 系统对某个推断的把握程度。
## 第 20 页：Reliable, safe, trustworthy: where this goes
- p020-q1 中文：第 20 页的核心设计问题是什么？
  - 答案：这页连接 Lecture 03。好的系统不是自动化越高越好，而是在可靠、安全、可信上有证据，并同时提高自动化与人的控制。
  - English: What is the core design issue on page 20?
  - Answer: Reliable, safe, and trustworthy interaction requires evidence, bounded failure costs, and enough visibility for calibrated reliance. Shneiderman's framework separates automation from human control.
- p020-q2 中文：本页最重要的概念是什么？
  - 答案：Calibrated reliance / 校准后的依赖：用户根据系统实际可靠性决定依赖程度，既不过度信任也不过度不用。
  - English: What is the most important concept on this page?
  - Answer: Calibrated reliance: 用户根据系统实际可靠性决定依赖程度，既不过度信任也不过度不用。
## 第 21 页：The twenty questions, shown once
- p021-q1 中文：第 21 页的核心设计问题是什么？
  - 答案：这是项目和考试都很有用的检查表。它把概念脊柱、人的控制、证据、安全、隐私和最小充分设计统一成 20 个问题。特别注意第 20 个问题最后问，因为要先理解系统再判断是否过度设计。
  - English: What is the core design issue on page 21?
  - Answer: The twenty questions operationalize the spine as an analysis checklist. They cover problem, intelligence, layers, control, uncertainty, evidence, safety, privacy, evaluation, and simplicity.
- p021-q2 中文：本页最重要的概念是什么？
  - 答案：Release checklist / 发布检查表：系统上线前用来确认问题、层次、控制、证据和风险的清单。
  - English: What is the most important concept on this page?
  - Answer: Release checklist: 系统上线前用来确认问题、层次、控制、证据和风险的清单。
## 第 22 页：Your project: draft its spine
- p022-q1 中文：第 22 页的核心设计问题是什么？
  - 答案：项目要求你把系统结构讲清楚：哪些层是真的，哪些是模拟占位；智能在哪里；用户通过什么通道看到什么。这样可以避免项目只停留在“我要做一个 AI app”。
  - English: What is the core design issue on page 22?
  - Answer: The project task asks students to make the interaction explicit by marking spine layers, stubs, intelligence location, output channel, and what the user sees.
- p022-q2 中文：本页最重要的概念是什么？
  - 答案：Stub / 占位组件：原型中暂时模拟而非完整实现的组件。
  - English: What is the most important concept on this page?
  - Answer: Stub: 原型中暂时模拟而非完整实现的组件。
## 第 23 页：What must be present, and how to look inside
- p023-q1 中文：第 23 页的核心设计问题是什么？
  - 答案：总结页：四属性回答“是不是智能交互系统”，概念脊柱回答“如何分析它”。最终评价仍回到人类活动，而不是只看模型技术。
  - English: What is the core design issue on page 23?
  - Answer: The synthesis combines the four properties with the spine. A system is judged by the interaction's effect on human activity, not only by technical performance.
- p023-q2 中文：本页最重要的概念是什么？
  - 答案：Human activity / 人类活动：用户真正要完成的工作、理解、控制和恢复过程。
  - English: What is the most important concept on this page?
  - Answer: Human activity: 用户真正要完成的工作、理解、控制和恢复过程。
## 第 24 页：References and further reading
- p024-q1 中文：第 24 页的核心设计问题是什么？
  - 答案：参考页显示本讲的三个来源群：HCAI 与可靠/安全/可信，智能体结构与自主性，扫描器案例中的边缘检测和 OCR。项目写作时可按主题选读。
  - English: What is the core design issue on page 24?
  - Answer: The references connect the lecture to human-centered AI, agents, mixed initiative, human-AI guidelines, edge detection, and OCR.
- p024-q2 中文：本页最重要的概念是什么？
  - 答案：Evidence anchor / 证据锚点：课件主张背后的文献来源，可用于项目和复习时追溯。
  - English: What is the most important concept on this page?
  - Answer: Evidence anchor: 课件主张背后的文献来源，可用于项目和复习时追溯。
## 第 25 页：Optional viewing: agents acting alone
- p025-q1 中文：第 25 页的核心设计问题是什么？
  - 答案：可选观看把本讲概念扩展到更强的 agents。重点不是视频本身，而是用概念脊柱追踪观察、上下文、记忆、工具、行动和人类控制。
  - English: What is the core design issue on page 25?
  - Answer: The optional viewing extends the spine to agents acting beyond answer generation. Students should inspect observation, planning, tool use, action, control, and feedback.
- p025-q2 中文：本页最重要的概念是什么？
  - 答案：Agent acting alone / 独立行动的智能体：能够持续观察、规划和调用工具的系统，需要特别设计人类可见性与停止/纠错能力。
  - English: What is the most important concept on this page?
  - Answer: Agent acting alone: 能够持续观察、规划和调用工具的系统，需要特别设计人类可见性与停止/纠错能力。