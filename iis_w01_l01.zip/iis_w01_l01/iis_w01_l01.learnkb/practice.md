# 自检题库索引

## 第 1 页：From Calculators to Copilots: A History of Intelligent Interaction
- p001-q1 CN: 这讲课的中心对象是 AI 技术本身，还是人与智能系统的互动？
  - 答案：中心对象是互动。技术史只是背景，真正要看的是系统能力如何改变人的可见性、主动权和可撤销性。
  - EN: Is the lecture mainly about AI technology itself or interaction between people and intelligent systems?
  - Answer: It is mainly about interaction. The technology history matters because it changes what people can see, control, and undo.
- p001-q2 CN: 为什么标题用 calculators 到 copilots？
  - 答案：它压缩了从“机器执行明确计算”到“系统参与复杂任务并提出行动”的历史变化。
  - EN: Why does the title move from calculators to copilots?
  - Answer: It compresses the move from machines that compute explicit operations to systems that participate in complex tasks and propose actions.
## 第 2 页：What we usually mean by 'intelligence'
- p002-q1 CN: 这一页指出的两个隐藏假设是什么？
  - 答案：以人类为中心和以大脑为中心。前者把人类当单一尺度顶点，后者假定智能必须在大脑中。
  - EN: What are the two hidden assumptions on this slide?
  - Answer: Anthropocentrism and brain-centrism: treating humans as the top of one scale and assuming intelligence must live in a brain.
- p002-q2 CN: 为什么这些假设会影响交互设计？
  - 答案：因为它们会让设计者只看系统是否像人，而忽略用户能否看见、控制和撤销系统行为。
  - EN: Why do these assumptions matter for interaction design?
  - Answer: They can make designers focus on human-likeness instead of whether users can see, control, and undo system behavior.
## 第 3 页：Intelligence as goal-directed navigation
- p003-q1 CN: 本页建议把“它有多智能”换成哪两个问题？
  - 答案：它在导航哪个空间？它导航得有多好？
  - EN: Which two questions replace 'how intelligent is it?'
  - Answer: Which space is it navigating, and how well is it navigating it?
- p003-q2 CN: 为什么这个定义能用于细胞？
  - 答案：因为它不要求大脑，只要求系统能朝理想区域调整行为或状态。
  - EN: Why can this definition apply to a cell?
  - Answer: Because it does not require a brain; it only requires competence in moving states toward desirable regions.
## 第 4 页：Different spaces, different intelligences
- p004-q1 CN: 蝾螈再生例子说明什么？
  - 答案：智能可被理解为在形态发生空间中朝正确身体形状导航，不一定涉及人类式思考。
  - EN: What does the salamander example show?
  - Answer: It shows intelligence as navigation in morphogenetic space toward a correct bodily form, not necessarily human-like thought.
- p004-q2 CN: 人的系统和数字系统的关系是什么？
  - 答案：人跨越物理、概念、社会空间；系统在数字空间中导航，并与人共同完成任务。
  - EN: How do human and digital-system spaces relate?
  - Answer: Humans span physical, conceptual, and social spaces; systems navigate digital spaces alongside a person.
## 第 5 页：Two conversations, fifty-nine years apart
- p005-q1 CN: ELIZA 和 2025 编码助手的关键差别是什么？
  - 答案：ELIZA 只回复文本；编码助手可以提出、运行并提交代码修改，因此错误后果更大。
  - EN: What is the key difference between ELIZA and a 2025 coding assistant?
  - Answer: ELIZA only replies with text; the coding assistant can propose, run, and commit code changes.
- p005-q2 CN: 为什么屏幕上看起来相似仍然不够？
  - 答案：因为交互评价要看系统能力和后果，而不只是看输入输出形式。
  - EN: Why is visual similarity on screen not enough?
  - Answer: Because interaction evaluation must consider system capability and consequences, not only input-output format.
## 第 6 页：What changed for the person, each time?
- p006-q1 CN: 本模块为什么不以“机器有多智能”为中心？
  - 答案：因为它不能直接推出设计决策；设计更需要知道互动如何影响人的行动、理解和控制。
  - EN: Why does the module avoid centering 'how intelligent is the machine?'
  - Answer: Because that answer does not directly imply design decisions; design needs to know how interaction affects people.
- p006-q2 CN: 四个阅读变量是什么？
  - 答案：主动权、推断、可见性、可撤销性。
  - EN: What are the four reading variables?
  - Answer: Initiative, inference, visibility, and reversibility.
## 第 7 页：The idea most of us arrive with
- p007-q1 CN: 为什么聊天框不是 AI 交互的全部？
  - 答案：因为很多智能功能以建议、排序、检测、追踪和补全的形式出现，不需要对话界面。
  - EN: Why is a chat box not the whole of AI interaction?
  - Answer: Because many intelligent functions appear as suggestions, rankings, detection, tracking, and completion without dialogue.
- p007-q2 CN: 历史在这里有什么作用？
  - 答案：历史拓宽定义，避免把 AI 交互误定义成聊天机器人交互。
  - EN: What is the role of history here?
  - Answer: History widens the definition so AI interaction is not accidentally defined as chatbot interaction.
## 第 8 页：Five capability shifts, 1950 to today
- p008-q1 CN: 五次迁移的边界为什么不是事实本身？
  - 答案：因为它们是为分析交互变化而划分的解释性框架。
  - EN: Why are the boundaries between shifts not facts themselves?
  - Answer: They are interpretive boundaries used to analyze interactional change.
- p008-q2 CN: 阅读每次迁移时应看什么？
  - 答案：看它对人改变了什么，而不只是看技术新增了什么。
  - EN: What should we read for in each shift?
  - Answer: What changed for the person, not only what changed in the technology.
## 第 9 页：Shift 1: symbolic rules and ELIZA (1966)
- p009-q1 CN: ELIZA 实际推断了什么？
  - 答案：它只推断句子形状和关键词模式，没有推断真实世界或用户心理。
  - EN: What did ELIZA actually infer?
  - Answer: It inferred sentence shape and keyword patterns, not the world or the user's mind.
- p009-q2 CN: 四变量中哪一项稍微移动了？
  - 答案：主动权稍微移动，因为机器获得了对话回合。
  - EN: Which variable moved slightly?
  - Answer: Initiative moved slightly because the machine gained a conversational turn.
## 第 10 页：Shift 2: direct manipulation and the GUI
- p010-q1 CN: 直接操控的三个特征是什么？
  - 答案：连续表示、用物理动作替代命令、可撤销操作。
  - EN: What are the three features of direct manipulation?
  - Answer: Continuous representation, physical actions rather than commands, and reversible operations.
- p010-q2 CN: 为什么 GUI 迁移很特殊？
  - 答案：因为可见性和可撤销性在这里被有意设计进去，之后的智能迁移没有自动保持它们。
  - EN: Why is the GUI shift special?
  - Answer: Visibility and reversibility were deliberately designed in, and later intelligent shifts did not automatically preserve them.
## 第 11 页：Shift 3: learning and recommendation
- p011-q1 CN: 推荐系统让哪两个变量上升或移动？
  - 答案：推断增强，主动权向系统移动。
  - EN: Which variables increase or move in recommendation systems?
  - Answer: Inference increases and initiative moves toward the system.
- p011-q2 CN: 为什么可见性下降？
  - 答案：因为用户通常只能看到推荐结果，而看不到背后的相似用户、物品关系和权重。
  - EN: Why does visibility go down?
  - Answer: Users usually see the recommendation output, not the evidence, similar users, item relations, or weights behind it.
## 第 12 页：Shift 4: deep learning and perception
- p012-q1 CN: 2012 年 ImageNet 例子说明了什么？
  - 答案：学习得到的特征在视觉识别中胜过人工构造特征，推动感知能力进入普通界面。
  - EN: What does the 2012 ImageNet example show?
  - Answer: Learned features outperformed hand-built features in vision, helping perception enter ordinary interfaces.
- p012-q2 CN: 这次迁移对交互的后果是什么？
  - 答案：系统开始推断世界中的语音、人脸、场景和手势，而不只是用户输入的文字。
  - EN: What was the interactional consequence?
  - Answer: Systems began inferring speech, faces, scenes, and gestures in the world, not only typed text.
## 第 13 页：Shift 5: large language models and agents
- p013-q1 CN: 为什么 LLM 加工具会让可撤销性变成开放问题？
  - 答案：因为系统不只是生成文本，还可能改变外部世界或用户资产，撤销成本不再固定。
  - EN: Why do LLMs with tools make reversibility an open problem?
  - Answer: Because they may change external state or user assets, so undo costs are no longer simple or fixed.
- p013-q2 CN: Few-shot prompting 是什么？
  - 答案：在提示中给几个示例，让模型在没有专门训练的情况下执行新任务。
  - EN: What is few-shot prompting?
  - Answer: Giving a few examples in the prompt so the model can perform a new task without task-specific training.
## 第 14 页：The reading frame: four interaction variables
- p014-q1 CN: 可见性问的是什么？
  - 答案：人能看见多少系统状态和推理。
  - EN: What does visibility ask?
  - Answer: How much of the system's state and reasoning the person can actually see.
- p014-q2 CN: 可撤销性只问有没有 undo 按钮吗？
  - 答案：不是，还要问后果是否真的能恢复，以及撤销成本有多高。
  - EN: Is reversibility only about having an undo button?
  - Answer: No. It asks whether the consequence can really be undone and how costly undoing is.
## 第 15 页：Five shifts scored on four variables
- p015-q1 CN: 本页总结的总体模式是什么？
  - 答案：主动权和推断向系统移动；可见性和可撤销性在 GUI 达峰后下降。
  - EN: What is the overall pattern?
  - Answer: Initiative and inference move toward the system; visibility and reversibility peak with the GUI and then decline.
- p015-q2 CN: 核心设计问题是什么？
  - 答案：系统能做什么与用户能看见或撤销什么之间的距离。
  - EN: What is the core design problem?
  - Answer: The distance between what the system can do and what the person can see or undo.
## 第 16 页：1) the predictive keyboard
- p016-q1 CN: 预测键盘的主动权体现在哪里？
  - 答案：它在用户未完成输入前主动提出候选词。
  - EN: Where is initiative in a predictive keyboard?
  - Answer: It proposes candidate words before the user has finished typing.
- p016-q2 CN: 为什么 autocorrect 比候选词风险更高？
  - 答案：因为它已经替用户执行替换，用户可能在注意到之前把错误发出去。
  - EN: Why is autocorrect riskier than word candidates?
  - Answer: It has already acted on the user's text, so the user may send the wrong replacement before noticing.
## 第 17 页：2) navigation that reroutes
- p017-q1 CN: 导航重规划用什么证据推断拥堵？
  - 答案：许多其他手机的移动情况。
  - EN: What evidence is used to infer congestion?
  - Answer: The movement of many other phones.
- p017-q2 CN: 用户看到什么，又看不到什么？
  - 答案：看到节省时间，看不到背后证据的细节。
  - EN: What does the user see and not see?
  - Answer: They see a time saving, not the detailed evidence behind it.
## 第 18 页：3) a coding copilot
- p018-q1 CN: Copilot 从哪些线索推断用户意图？
  - 答案：代码、注释和命名。
  - EN: What clues does a copilot use to infer intent?
  - Answer: Code, comments, and naming.
- p018-q2 CN: 为什么按 Tab 后风险改变？
  - 答案：因为建议变成实际编辑，进入用户自己的工作成果和责任范围。
  - EN: Why does risk change after pressing Tab?
  - Answer: The suggestion becomes an actual edit within the user's work and responsibility.
## 第 19 页：Your turn: score the automatic captions
- p019-q1 CN: 自动字幕应从哪四个变量评分？
  - 答案：主动权、推断、可见性和可撤销性。
  - EN: Which four variables should automatic captions be scored on?
  - Answer: Initiative, inference, visibility, and reversibility.
- p019-q2 CN: 举一个你需要看见才会信任字幕的东西。
  - 答案：例如置信度、对应音频片段、时间戳或可编辑修订历史。
  - EN: Name one thing you might need to see to trust captions.
  - Answer: For example confidence, the matching audio segment, timestamps, or editable revision history.
## 第 20 页：ELIZA and a copilot, side by side
- p020-q1 CN: ELIZA 和 Copilot 都像在哪里？
  - 答案：都使用打字语言交换轮次，屏幕表面相似。
  - EN: Where do ELIZA and Copilot look similar?
  - Answer: Both exchange typed language turns and look similar on screen.
- p020-q2 CN: 它们出错成本为何不同？
  - 答案：ELIZA 只能产生奇怪回复；Copilot 能编辑、运行、提交，可能损害代码库。
  - EN: Why are their error costs different?
  - Answer: ELIZA can only produce a strange reply; Copilot can edit, run, and commit, potentially damaging a codebase.
## 第 21 页：The ELIZA effect
- p021-q1 CN: ELIZA effect 的机制是什么？
  - 答案：人把语言流畅性读作理解，并由自己补足其余意义。
  - EN: What is the mechanism of the ELIZA effect?
  - Answer: People read fluency as understanding and supply the rest themselves.
- p021-q2 CN: 设计上的直接后果是什么？
  - 答案：要展示系统实际做了什么，而不只是展示它说了什么。
  - EN: What is the direct design consequence?
  - Answer: Show what the system actually did, not just what it said.
## 第 22 页：Turing's question versus the design question
- p022-q1 CN: Turing 的问题和本课问题分别关注什么？
  - 答案：Turing 关注机器；本课关注人和人的任务。
  - EN: What do Turing's question and this module's question focus on?
  - Answer: Turing's focuses on the machine; this module's focuses on the person and their task.
- p022-q2 CN: 为什么通过图灵测试不等于好用？
  - 答案：因为它不说明系统是否支持用户任务、是否可见、可控、可撤销。
  - EN: Why does passing the Turing Test not mean a system is useful?
  - Answer: It says nothing about whether the system supports the user's task or is visible, controllable, and reversible.
## 第 23 页：You bring the last generation's model with you
- p023-q1 CN: 什么是心理模型？
  - 答案：用户对系统如何工作、能做什么、结果如何产生的内在理解。
  - EN: What is a mental model?
  - Answer: A user's internal understanding of how a system works, what it can do, and how consequences happen.
- p023-q2 CN: 为什么从文档带来的撤销期待危险？
  - 答案：因为会采取真实行动的系统可能无法像文档编辑一样轻松撤销。
  - EN: Why are undo expectations from documents dangerous?
  - Answer: Systems that take real actions may not be undoable like document edits.
## 第 24 页：One question, four areas, eleven weeks
- p024-q1 CN: 贯穿模块的中心问题是什么？
  - 答案：如何设计、构建和评估让智能能力有意义参与人机互动的交互系统。
  - EN: What is the central module question?
  - Answer: How to design, build, and evaluate interactive systems in which intelligent capabilities meaningfully participate in interaction with people.
- p024-q2 CN: 第 6 周和第 11 周分别是什么？
  - 答案：第 6 周是阅读周；第 11 周是复习和项目提交。
  - EN: What are Weeks 6 and 11?
  - Answer: Week 6 is reading week; Week 11 is review and project submission.
## 第 25 页：Phase 1 begins now: choose an area by its shift
- p025-q1 CN: 项目选区应先问什么？
  - 答案：我的问题依赖五次能力迁移中的哪一次。
  - EN: What should you ask first when choosing a project area?
  - Answer: Which of the five capability shifts the problem depends on.
- p025-q2 CN: Phase 1 包括哪些内容？
  - 答案：问题、文献、空白和贡献。
  - EN: What does Phase 1 include?
  - Answer: Problem, literature, gap, and contribution.
## 第 26 页：What changed each time
- p026-q1 CN: 可见性和可撤销性为什么不是进步的礼物？
  - 答案：因为技术能力上升不会自动带来它们；GUI 中它们高，是因为被有意设计进去。
  - EN: Why are visibility and reversibility not gifts of progress?
  - Answer: Because technological capability does not automatically produce them; they were high in the GUI because they were deliberately designed in.
- p026-q2 CN: 本模块训练你做什么？
  - 答案：在智能能力上升时，把可见性和可撤销性重新设计回来。
  - EN: What does the module train you to do?
  - Answer: To design visibility and reversibility back in as intelligent capability rises.
## 第 27 页：References and further reading
- p027-q1 CN: 哪篇文献对应 Direct Manipulation？
  - 答案：Shneiderman, B. (1983), Direct Manipulation: A Step Beyond Programming Languages.
  - EN: Which reference corresponds to Direct Manipulation?
  - Answer: Shneiderman, B. (1983), Direct Manipulation: A Step Beyond Programming Languages.
- p027-q2 CN: 如果项目偏 LLM 和 agents，参考页上哪些文献最直接相关？
  - 答案：Vaswani 等 2017 的 Transformer 与 Brown 等 2020 的 GPT-3/few-shot learning。
  - EN: If a project focuses on LLMs and agents, which references are most directly relevant?
  - Answer: Vaswani et al. 2017 on Transformers and Brown et al. 2020 on GPT-3 and few-shot learning.