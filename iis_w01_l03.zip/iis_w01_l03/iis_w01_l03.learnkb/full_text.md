# 来源：W01_L03_Human_Centred_Intelligent_Interaction_and_the_Shape_of_the_Module_v5_novideo.pdf

<!-- SOURCE: W01_L03_Human_Centred_Intelligent_Interaction_and_the_Shape_of_the_Module_v5_novideo.pdf -->

<!-- PDF 页 1 -->

Human-Centred Intelligent 
Interaction and the Shape of 
the Module

Intelligent Interactive Systems  ·  Week 1  ·  Lecture 03
University of Birmingham

Human-centred design gives us criteria for judging 
intelligent interaction.

• We will turn human-centred into three commitments that you 

After Shneiderman (2022).

can test against a design.

• We will connect the two-dimensional framework, eighteen 
guidelines, mixed initiative and the expectation gulf to your 
project.

<!-- PDF 页 2 -->

Two inbox assistants, one tagline

Lecture 03 · Hook

The difference is the control the person keeps.

• Both hypothetical assistants say “designed 

around you” and save the same time, but A acts 
while you are away and reports afterwards.

• B proposes and you decide; every accepted 

change can be undone.

• For Interaction 1, write one sentence explaining 
which is human-centred and exactly what makes 
the difference.

Hypothetical inbox assistants.

<!-- PDF 页 3 -->

'Human-centred' as three commitments

Lecture 03 · Central question

Human-centred design makes three testable commitments.

• Accountability: when a person cannot use the 

system successfully, examine the design 
(Norman, 2013).

• Two dimensions: automation and human control 

are separate; design for high levels of both 
(Shneiderman, 2022).

• Initiative: who acts next is an explicit, testable 

rule (Horvitz, 1999; Amershi et al., 2019).

• Central question: who is this system for, and 

what does ‘human-centred’ commit us to when it 
can infer and act?

Norman (2013); Shneiderman (2022); Horvitz (1999); Amershi et al. (2019).

<!-- PDF 页 4 -->

Shneiderman's two-dimensional framework

Lecture 03 · The framework

A design can increase automation and human control together.

• Shneiderman’s two-dimensional framework 

(2022) places computer automation on one axis 
and human control on the other; together they 
form a plane.

• The aim is high on both: reliable, safe and 

trustworthy systems that do useful work while 
people retain control.

• Excessive automation can remove oversight; 

excessive control can burden people with work 
the machine could do. The illustrated placements 
are the lecturer’s examples.

After Shneiderman (2022); lecturer’s placements.

<!-- PDF 页 5 -->

Moving a design on the plane

Lecture 03 · The framework

A proposal, review and undo can add control without changing the model.

• In this example, Assistants A and B use the 
same model at the same level of automation.

• B adds a proposal step, review and 

reversibility, moving the design upward on the 
human-control axis.

• The design challenge is to avoid excessive 

automation and excessive control: keep useful 
automation while giving the person a workable 
way to supervise it.

After Shneiderman (2022); illustrative comparison.

<!-- PDF 页 6 -->

Eighteen guidelines in four phases

Lecture 03 · The guidelines

The eighteen guidelines cover four phases of interaction.

• Initially and during interaction, address 

• When wrong and over time, support recovery, 

capabilities, reliability, timing, relevance, social 
norms and bias.

explanations, cautious learning, feedback, visible 
consequences, controls and change notifications.

Amershi et al. (2019).

<!-- PDF 页 7 -->

Initially and during: G1 to G6

Lecture 03 · The guidelines

G1–G6 make the system’s limits and situation visible.

• G1–G2 reveal the capability envelope—what the 

system can do—and reliability; G3–G4 add timing 
and relevance.

• G5–G6 address social norms and bias: match the 
expected register and test across accents, names 
and dialects.

Amershi et al. (2019); course examples.

<!-- PDF 页 8 -->

When wrong and over time: G7 to G18

Lecture 03 · The guidelines

Being wrong is a normal phase that the interface must support.

• G7–G11 make invocation, dismissal and 

• G12–G18 support memory, cautious learning, 

correction efficient; narrow the scope when 
uncertain and explain actions.

granular feedback, visible consequences, global 
controls and change notifications.

After Amershi et al. (2019); course examples.

<!-- PDF 页 9 -->

Who moves next is a design decision

Lecture 03 · Mixed initiative

Mixed initiative makes the next move a shared design decision.

• In the manual example, the person creates the 
meeting; in the automatic example, the system 
creates it before the person reviews it.

• With mixed initiative, the system proposes a 
meeting and the person decides. Both can 
contribute to progressing the task.

• Horvitz (1999) links this decision to uncertainty, 
attention and the cost of a poor guess, using 
dialogue to resolve important uncertainties.

After Horvitz (1999); illustrative meeting.

<!-- PDF 页 10 -->

Act, ask or wait

Lecture 03 · Mixed initiative

Choose whether to act, ask or wait by considering the consequences.

• Consider confidence that the person wants 

the action and the cost of being wrong
together.

• In this qualitative rule, act when confidence is 

high and error costs are low; ask when 
uncertainty or costs warrant it; otherwise wait.

• Attention changes the decision: an appropriate 
action at 08:10 may be an interruption during a 
meeting. Document, test and defend the rule.

After Horvitz (1999); qualitative illustration.

<!-- PDF 页 11 -->

The gulf between expectation and experience

Lecture 03 · The expectation gulf

The expectation gulf concerns what people expect the system to understand.

• The lecture contrasts “like having a PA” with 
Luger and Sellen’s (2016) study title, “like 
having a really bad PA”.

• Interviewees reported simple-task reliability, 

unexplained failures and unclear capabilities, 
then developed workarounds or used the 
system less.

• The design interpretation is a mismatch 

between expectation and experience: 
presentation shapes what people believe the 
assistant can do.

Luger and Sellen (2016); course interpretation.

<!-- PDF 页 12 -->

The gulf is a mental-model mismatch

Lecture 03 · The expectation gulf

Make the system’s limits visible so people can revise their mental model.

• A mental model is the person’s understanding of 

how a system works, shaped by previous 
experience and how the assistant presents itself.

• When the capability envelope remains hidden, 
that understanding cannot be corrected against 
what the system actually does reliably.

• Saying what it can do and how well (G1, G2)

communicates capability and reliability; scoping 
when in doubt and explaining why (G10, G11)
narrow uncertain services and explain behaviour. 
These design moves reduce the mismatch.

Course illustration; Amershi et al. (2019).

<!-- PDF 页 13 -->

Your turn: name the guideline, then the fix

Lecture 03 · Interaction 2

Diagnose the broken guideline, then propose a concrete repair.

• A repeats “Sorry, I didn't get that” four times and 
stops. B sends a smart reply after an accidental 
thumb brush, with no recall.

• C silently rewrites a music profile after someone 

else plays a child’s songs for one afternoon.

• Take two minutes to name the guideline, the fix 
and the broken commitment: accountability, two 
dimensions or an explicit initiative rule.

<!-- PDF 页 14 -->

The recommender, initially

Lecture 03 · Worked example

Explain what the recommender uses and where it may be unreliable.

• Say what it can do (G1): it recommends from 

what you play and save, and never buys, shares 
or posts.

• Say how well (G2): it works better for familiar 

genres than new ones, and labels lower-
confidence recommendations.

• Show where the model of you lives and how to 
inspect it. Missing these explanations makes 
later recommendations harder to understand and 
trust.

Amershi et al. (2019); hypothetical interface.

<!-- PDF 页 15 -->

The recommender, during interaction

Lecture 03 · Worked example

Timing, relevance and reasons make a recommendation checkable.

• Timing (G3): a commute mix at 08:10 on a 

weekday, and quiet during a call.

• Relevance (G4): three tiles that fit the current 

situation, so the person can see why they matter 
now.

• Explain why (G11): “because you saved Night 

Drive yesterday”. The person can challenge that 
inference and learn what information the system 
uses.

Amershi et al. (2019); hypothetical interface.

<!-- PDF 页 16 -->

The recommender, when wrong

Lecture 03 · Worked example

A correction should address the mistaken profile update, not only the tile.

• After someone borrows the phone for one 

afternoon, its home page becomes nursery 
rhymes. Easy dismissal (G8) hides the tile; 
easy correction (G9) lets “that was someone 
else” fix the cause.

EO1

• Scoping when in doubt (G10) treats an unusual 
day as uncertainty and limits what the system 
changes.

• The silent update also breaks cautious 

adaptation (G14), notifying users of changes 
(G18) and global controls (G17).

Amershi et al. (2019).

<!-- PDF 页 17 -->

Slide 16

EO1 

Are these references to future lectures? If so, nobody will remember them. Maybe it's better to relate them to a concept rather 
than a number.
Eyal Ofek, 2026-09-23T15:36:24.424

DG1 0 

They are points of a paper
Daniele Giunchi (Computer Scien, 2026-09-24T12:26:19.244

<!-- PDF 页 18 -->

The recommender, over time: the fix

Lecture 03 · Worked example

Make profile changes cautious, visible and controllable.

• Adapt cautiously (G14): update the profile from 
repeated behaviour over days, and hold unusual 
days apart for review.

• Notify changes (G18): explain “your 

recommendations changed because…” and 
show the evidence with a choice.

• Global controls (G17): a guest session, pause 
learning, reset and a view of what is used. The 
recommender keeps its accuracy; the person 
gains control.

Amershi et al. (2019).

<!-- PDF 页 19 -->

The project is a compact research paper

Lecture 03 · Project connection

The project develops a question, a system and evidence about it.

• Phase 1, Weeks 1–4 (5%), establishes the 
problem, related work, gap, question and 
contribution, with an illustrated document of 
about 700 words and a video of about five 
minutes.

• Phase 2, Weeks 5–9 (10%), develops the 

prototype with documented AI use; Week 6 is 
reading week.

• Phase 3, Weeks 10–11 (5%), presents evidence 

and a poster. The project is continuous 
assessment, 20% of the module; the final exam
is 80%.

<!-- PDF 页 20 -->

Eleven weeks, three phases, one final exam

Lecture 03 · Project connection

Three project phases make up 20% of the module; the final exam makes up 80%.

• Project (20%): Phase 1 5%, Weeks 1–4; Phase 2 

• Final exam (80%) in the exam period. Weekly 

10%, Weeks 5–9; Phase 3 5%, Weeks 10–11.

Canvas quizzes are formative: no score.

Submission dates are published on Canvas.

<!-- PDF 页 21 -->

Three books, and how the module reads them

Lecture 03 · The books

Read each lecture’s chapter anchor with its design question in mind.

• Shneiderman, Human-Centered AI (2022)

supports the design stance, human control and 
governance.

• Norman, The Design of Everyday Things 
(2013) explains action, error, feedback and 
mental models: how people understand and 
operate a system.

• LaValle, Virtual Reality (2017) covers sensing, 
rendering and evaluation for extended reality 
(XR). Read the named chapter anchor rather 
than the whole book at once.

Shneiderman (2022); Norman (2013); LaValle (2017).

<!-- PDF 页 22 -->

Who is it for, and what does that commit us to?

Lecture 03 · Synthesis and bridge

Human-centred systems keep people in control as the system infers and acts.

• Design for the person whose activity changes, 
aiming for high automation and human control 
together.

• Use the eighteen guidelines and an explicit 

initiative rule; this stance returns in Lectures 07, 
13 and 28 (the Week 11 self-audit).

• In Lab 1, use AI tools to search the literature and 

verify five sources; you leave with one-line 
notes, a prompt log and a first gap sentence.

<!-- PDF 页 23 -->

References and further reading

Lecture 03 · References

Read the sources according to the design claim they 
support.

Shneiderman, B. (2022). Human-Centered AI. Oxford University Press. Part 1 (chapters 3–4) and Part 2 (the two-
dimensional human-centred AI (HCAI) framework and design guidelines).

Norman, D. A. (2013). The Design of Everyday Things (revised and expanded edition). Basic Books. Chapter 1, The 
Psychopathology of Everyday Things.

Amershi, S., Weld, D., Vorvoreanu, M., Fourney, A., Nushi, B., Collisson, P., Suh, J., Iqbal, S., Bennett, P. N., Inkpen, 
K., Teevan, J., Kikin-Gil, R., & Horvitz, E. (2019). Guidelines for Human-AI Interaction. CHI 2019, Paper 3.

Horvitz, E. (1999). Principles of Mixed-Initiative User Interfaces. CHI 1999, 159–166.

Luger, E., & Sellen, A. (2016). 'Like Having a Really Bad PA': The Gulf between User Expectation and Experience of 
Conversational Agents. CHI 2016, 5286–5297.

LaValle, S. M. (2017). Virtual Reality. Cambridge University Press; free online at lavalle.pl/vr. Named today; used 
mainly in Weeks 7–9.

Assessment details and submission dates: module handbook and Canvas.

• Shneiderman and Norman establish 
the design stance; Amershi et al. 
and Horvitz support guidelines and 
initiative decisions.

• Luger and Sellen examine the 

expectation gulf; LaValle supports the 
extended reality (XR) weeks.
