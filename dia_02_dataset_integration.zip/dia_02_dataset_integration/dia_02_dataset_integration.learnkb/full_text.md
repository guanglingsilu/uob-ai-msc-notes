# 来源：2. Dataset_selection_and_integration_-_Lecture_Notes.pdf

<!-- SOURCE: 2. Dataset_selection_and_integration_-_Lecture_Notes.pdf -->

<!-- PDF 页 1 -->

Dataset selection and integration

Prof. Paolo Missier
School of Computer Science
University of Birmingham, UK

Data-intensive AI
2026/27 Sem 1

<!-- PDF 页 2 -->

In this lecture: Dataset selection and integration

We dive into the TAXI dataset example to illustrate the “Bronze” part of data preparation

Overall goal: 

I am a taxi fleet operator. I want to position my fleet at any point in time to maximise revenues 

A real data lake would contain hundreds of raw datasets

1. Dataset selection:
- Which datasets should I use to create a training set?

2. Dataset integration:

- how do I consolidate the selected tables into a viable “Bronze” starting point to create 
my training set?

<!-- PDF 页 3 -->

Bronze medallion: TAXI dataset example

Network 
analysis

Most popular pick up / drop off points, most profitable routes
Are these time-dependent? What else determines profitability?

Choice of Yellow vs Green datasets, or both
- What do I need to know about these datasets?

- How does each of them contribute to the learning task?

- What else do I need?

- Eg zone_lookup reference table

Reference notebook:
data_load_to_Delta_Tables
[Loading and integrate the TAXI datasets into Delta Tables]

<!-- PDF 页 4 -->

Inspecting the available data

Source

Yellow Taxi trips

Green Taxi trips

Taxi Zone Lookup

Format

Parquet

Parquet

CSV

Scale

~3M rows/month --> 36 M rows/year

~70K rows/month

265 zones

https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page

- How similar/different are the Yellow and Green datasets?
-
-
- How much data do I need?  (1 month --> 10 years??) 

Is there value in trying to create a unified view that includes both?
Is this technically feasible?

<!-- PDF 页 5 -->

Step 1: loading data and metadata

Refer to these notebooks:

0. databricks_taxi_read-into_DBFS

Load raw data into DataBricks File System (DBFS)

1. data_load_to_Delta_Tables

Load and integrate the TAXI datasets into Delta Tables

TLC 
site

DBFS

Add metadata 
to Catalog

Load data into 
Delta Table

<!-- PDF 页 6 -->

Schema inspection

Analyse incompatibilities before attempting a union

Months to download : ['2024-01', '2024-02', '2024-03']

Green rows loaded: 167,585

Yellow rows loaded: 9,554,778

<!-- PDF 页 7 -->

Schema compatibility analysis

renaming timestamp columns

-
- adding null-filled columns for missing fields
- casting types

See harmonize_yellow() and harmonize_green() in notebook  data_load_to_Delta_Tables()

<!-- PDF 页 8 -->

Creating an integrated view

1. Union yellow_trips with green_trips (harmonized)
2.

Join the result with the zone_lookup table

Schema
mapping

yellow

yellow_h

union

join

green

green_h

zones

unionByName to 
combine Yellow 
and Green safely

Join with the zone CSV 
for borough names

Integrated
trips

Partitioned Parquet output

pickup_month, taxi_type

for efficient downstream reads

<!-- PDF 页 9 -->

Integration pitfalls: structure and semantics

Two datasets can be structurally incompatible even when they describe the same real-world entities

Schema-level heterogeneity: same concept, different names
 - tpep_pickup_datetime vs lpep_pickup_datetime, different types (DoubleType vs IntegerType)

Instance-level heterogeneity:
- same schema, different value conventions ("credit_card" vs 1 vs "CC").

Semantic heterogeneity: columns with the same name but different meaning (e.g., total_amount 
including or excluding tolls depending on the operator)

Reference: Rahm, E. & Bernstein, P.A. (2001).
A survey of approaches to automatic schema matching, The VLDB Journal, 10(4), 334–350.
https://doi.org/10.1007/s007780100057

<!-- PDF 页 10 -->

Example: unsafe union 

Plot fare distribution against distance for Yellow taxi 2019-Q1 ∪ 2020-Q2  

- The union is schema-valid: it is just Yellow taxi over different time periods
- But you find that the fare distribution is bimodal:

<!-- PDF 页 11 -->

Example: unsafe union (cont.)

WHY is this happening? Hint: 2020-Q2 is during COVID

--> Cost of taxi rides per mile in this period is not directly comparable with “normal” cost of taxi rides

Property
Monthly trip volume
Median trip distance
Median fare
Most common pickup borough Manhattan (92%)
Short trips < 0.5 miles

2019-Q1 (normal)
~8.5 M
1.7 miles
$10.50

18% of all trips

2020-Q2 (lockdown)
~1.0 M (−88%)
3.2 miles (+88%)
$14.80 (+41%)
Manhattan (61%)
3% of all trips

<!-- PDF 页 12 -->

Example: unsafe join

Suppose we want to associate Census data to taxi pickup/dropoff zones (zone_ lookup)
- Census data is public and contains location geo_id
-

This joins “correctly” with pickup_location_id

However, the resulting view is wrong because Census and Taxi use 
the same codes purely by coincidence

<!-- PDF 页 13 -->

Integration pitfalls: Data fusion, unbalancing 

Multiple sources may provide conflicting values for the same attribute
- e.g., two data providers reporting different trip distances (or other attribute values) for 

what appears to be the same trip

- how do you decide which one is correct?

Integration can be technically correct but the resulting training set is unbalanced
Example:
The Yellow+Green union produces a training set where
- ~98% of rows are Yellow taxi trips (Manhattan-heavy)
- ~2% are Green (outer borough-heavy)

This strong bias will reflect in a fare prediction model trained on this raw union
- Expect the model to overfit on Green fares predictions

Reference: Dong, X.L. & Srivastava, D. (2015). Big Data Integration, Morgan & Claypool. (Synthesis Lectures on Data 
Management, Vol. 7, No. 1)
https://doi.org/10.2200/S00578ED1V01Y201404DTM040

<!-- PDF 页 14 -->

Summary

We introduced the following concepts:

Moving data from ”raw” to “Bronze” entails
- Selecting datasets from the lakehouse
- Harmonising their schema
-

Integrating, using union and join when appropriate

However: 
The blind application of these steps may lead to very wrong results!

- Both union and join look superficially correct, but are semantically wrong
- when the integrated dataset is used as a training set, the resulting model will be poor
