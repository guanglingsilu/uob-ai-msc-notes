# IIS W01 L03 - Human-Centred Intelligent Interaction and the Shape of the Module

逐页完整翻译与复习笔记。

## 第 1 页：Human-Centred Intelligent Interaction and the Shape of the Module

Source ID: `src-b91e955ebdec-pdf_page-00001`

![PDF page 1](../assets/pages/page_001.png)

### 原文
```text
Human-Centred Intelligent 
Interaction and the Shape of 
the Module

Intelligent Interactive Systems  ·  Week 1  ·  Lecture 03
University of Birmingham

Human-centred design gives us criteria for judging 
intelligent interaction.

• We will turn human-centred into three commitments that you 

After Shneiderman (2022).

can test against a design.

• We will connect the two-dimensional framework, eighteen 
guidelines, mixed initiative and the expectation gulf to your 
project.
```

### 完整中文翻译
以人为中心的智能交互与模块形状。

智能交互系统 - 第 1 周 - 第 3 讲。伯明翰大学。

以人为中心的设计给了我们判断智能交互的标准。

- 我们会把 human-centred 转化为三个可以用来测试设计的承诺。
- 我们会把二维框架、十八条指南、混合主动权和期待鸿沟连接到你的项目。

根据 Shneiderman（2022）。

### 中文释义
本讲把“以人为中心”从口号变成可检验标准：用户是否保留控制、系统是否清楚地表达能力与边界、主动权规则是否可说明。

### English Explanation
The lecture turns human-centred design into testable commitments for intelligent systems.

### 概念解析
- **Human-centred design / 以人为中心设计**：把人的活动、控制、理解、恢复和责任放在系统设计中心。

### 自测问题
**Q1 中文：** 第 1 页最重要的设计判断是什么？
**答：** 本讲把“以人为中心”从口号变成可检验标准：用户是否保留控制、系统是否清楚地表达能力与边界、主动权规则是否可说明。
**Q1 English:** What is the key design judgement on page 1?
**Answer:** The lecture turns human-centred design into testable commitments for intelligent systems.

**Q2 中文：** 解释本页概念：Human-centred design / 以人为中心设计
**答：** 把人的活动、控制、理解、恢复和责任放在系统设计中心。
**Q2 English:** Explain this concept: Human-centred design / 以人为中心设计
**Answer:** 把人的活动、控制、理解、恢复和责任放在系统设计中心。

## 第 2 页：Two inbox assistants, one tagline

Source ID: `src-b91e955ebdec-pdf_page-00002`

![PDF page 2](../assets/pages/page_002.png)

### 原文
```text
Two inbox assistants, one tagline

Lecture 03 · Hook

The difference is the control the person keeps.

• Both hypothetical assistants say “designed 

around you” and save the same time, but A acts 
while you are away and reports afterwards.

• B proposes and you decide; every accepted 

change can be undone.

• For Interaction 1, write one sentence explaining 
which is human-centred and exactly what makes 
the difference.

Hypothetical inbox assistants.
```

### 完整中文翻译
两个收件箱助手，一个宣传语。

第 3 讲 - 引入。

差别在于人保留了多少控制。

- 两个假想助手都说“围绕你而设计”，也节省相同时间，但 A 在你离开时行动，事后报告。
- B 先提出建议，由你决定；每个被接受的改动都可以撤销。
- 互动 1：写一句话说明哪个是以人为中心的，并准确说出差别在哪里。

假想收件箱助手。

### 中文释义
这一页说明 human-centred 不是看宣传语，而是看控制结构。B 更接近以人为中心，因为它保留了审批和撤销。

### English Explanation
The difference between the two assistants is not productivity but retained human control.

### 概念解析
- **Human control / 人类控制**：人在系统行动前后保留审核、批准、撤销和纠错能力。

### 自测问题
**Q1 中文：** 第 2 页最重要的设计判断是什么？
**答：** 这一页说明 human-centred 不是看宣传语，而是看控制结构。B 更接近以人为中心，因为它保留了审批和撤销。
**Q1 English:** What is the key design judgement on page 2?
**Answer:** The difference between the two assistants is not productivity but retained human control.

**Q2 中文：** 解释本页概念：Human control / 人类控制
**答：** 人在系统行动前后保留审核、批准、撤销和纠错能力。
**Q2 English:** Explain this concept: Human control / 人类控制
**Answer:** 人在系统行动前后保留审核、批准、撤销和纠错能力。

## 第 3 页：'Human-centred' as three commitments

Source ID: `src-b91e955ebdec-pdf_page-00003`

![PDF page 3](../assets/pages/page_003.png)

### 原文
```text
'Human-centred' as three commitments

Lecture 03 · Central question

Human-centred design makes three testable commitments.

• Accountability: when a person cannot use the 

system successfully, examine the design 
(Norman, 2013).

• Two dimensions: automation and human control 

are separate; design for high levels of both 
(Shneiderman, 2022).

• Initiative: who acts next is an explicit, testable 

rule (Horvitz, 1999; Amershi et al., 2019).

• Central question: who is this system for, and 

what does ‘human-centred’ commit us to when it 
can infer and act?

Norman (2013); Shneiderman (2022); Horvitz (1999); Amershi et al. (2019).
```

### 完整中文翻译
“以人为中心”作为三个承诺。

第 3 讲 - 中心问题。

以人为中心设计提出三个可测试承诺。

- 问责：当一个人无法成功使用系统时，检查设计（Norman，2013）。
- 两个维度：自动化和人类控制是分开的；要设计两者都高的系统（Shneiderman，2022）。
- 主动权：谁接下来行动是一条明确、可测试的规则（Horvitz，1999；Amershi 等，2019）。
- 中心问题：这个系统为谁而设计？当它能推断和行动时，“以人为中心”要求我们承担什么？

### 中文释义
三个承诺是本讲骨架：错误先问设计责任；自动化不必牺牲控制；系统何时行动必须有规则。

### English Explanation
The three commitments are accountability, two independent dimensions, and explicit initiative rules.

### 概念解析
- **Accountability / 问责**：用户失败时先检查设计，而不是把责任推给用户。
- **Initiative rule / 主动权规则**：说明在什么条件下人或系统采取下一步行动。

### 自测问题
**Q1 中文：** 第 3 页最重要的设计判断是什么？
**答：** 三个承诺是本讲骨架：错误先问设计责任；自动化不必牺牲控制；系统何时行动必须有规则。
**Q1 English:** What is the key design judgement on page 3?
**Answer:** The three commitments are accountability, two independent dimensions, and explicit initiative rules.

**Q2 中文：** 解释本页概念：Accountability / 问责
**答：** 用户失败时先检查设计，而不是把责任推给用户。
**Q2 English:** Explain this concept: Accountability / 问责
**Answer:** 用户失败时先检查设计，而不是把责任推给用户。

## 第 4 页：Shneiderman's two-dimensional framework

Source ID: `src-b91e955ebdec-pdf_page-00004`

![PDF page 4](../assets/pages/page_004.png)

### 原文
```text
Shneiderman's two-dimensional framework

Lecture 03 · The framework

A design can increase automation and human control together.

• Shneiderman’s two-dimensional framework 

(2022) places computer automation on one axis 
and human control on the other; together they 
form a plane.

• The aim is high on both: reliable, safe and 

trustworthy systems that do useful work while 
people retain control.

• Excessive automation can remove oversight; 

excessive control can burden people with work 
the machine could do. The illustrated placements 
are the lecturer’s examples.

After Shneiderman (2022); lecturer’s placements.
```

### 完整中文翻译
Shneiderman 的二维框架。

第 3 讲 - 框架。

一个设计可以同时提高自动化和人类控制。

- Shneiderman（2022）的二维框架把计算机自动化放在一条轴上，把人类控制放在另一条轴上；两者形成一个平面。
- 目标是在两者上都高：系统可靠、安全、可信，能做有用工作，同时人仍保留控制。
- 过度自动化会移除监督；过度控制会让人承担机器本可完成的工作。图中位置是讲师示例。

### 中文释义
核心误区是把自动化和控制当成此消彼长。Shneiderman 框架要求我们寻找“高自动化 + 高控制”的设计。

### English Explanation
Shneiderman's framework separates automation from human control so a design can aim to be high on both.

### 概念解析
- **Two-dimensional HCAI framework / 二维 HCAI 框架**：用自动化和人类控制两条独立轴评估系统，而不是只问自动化高低。

### 自测问题
**Q1 中文：** 第 4 页最重要的设计判断是什么？
**答：** 核心误区是把自动化和控制当成此消彼长。Shneiderman 框架要求我们寻找“高自动化 + 高控制”的设计。
**Q1 English:** What is the key design judgement on page 4?
**Answer:** Shneiderman's framework separates automation from human control so a design can aim to be high on both.

**Q2 中文：** 解释本页概念：Two-dimensional HCAI framework / 二维 HCAI 框架
**答：** 用自动化和人类控制两条独立轴评估系统，而不是只问自动化高低。
**Q2 English:** Explain this concept: Two-dimensional HCAI framework / 二维 HCAI 框架
**Answer:** 用自动化和人类控制两条独立轴评估系统，而不是只问自动化高低。

## 第 5 页：Moving a design on the plane

Source ID: `src-b91e955ebdec-pdf_page-00005`

![PDF page 5](../assets/pages/page_005.png)

### 原文
```text
Moving a design on the plane

Lecture 03 · The framework

A proposal, review and undo can add control without changing the model.

• In this example, Assistants A and B use the 
same model at the same level of automation.

• B adds a proposal step, review and 

reversibility, moving the design upward on the 
human-control axis.

• The design challenge is to avoid excessive 

automation and excessive control: keep useful 
automation while giving the person a workable 
way to supervise it.

After Shneiderman (2022); illustrative comparison.
```

### 完整中文翻译
在平面上移动一个设计。

第 3 讲 - 框架。

提议、审查和撤销可以在不改变模型的情况下增加控制。

- 在这个例子中，助手 A 和 B 使用同一个模型，自动化水平也相同。
- B 增加提议步骤、审查和可撤销性，使设计沿人类控制轴向上移动。
- 设计挑战是避免过度自动化和过度控制：保留有用自动化，同时给人一种可执行的监督方式。

### 中文释义
这页很实用：你不一定要换模型才能改善人本性。只要加 proposal、review、undo，就能增加控制。

### English Explanation
A design can gain human control through proposal, review, and undo without changing the underlying model.

### 概念解析
- **Proposal-review-undo / 提议-审查-撤销**：让系统先建议，人再批准，并提供撤销路径的控制模式。

### 自测问题
**Q1 中文：** 第 5 页最重要的设计判断是什么？
**答：** 这页很实用：你不一定要换模型才能改善人本性。只要加 proposal、review、undo，就能增加控制。
**Q1 English:** What is the key design judgement on page 5?
**Answer:** A design can gain human control through proposal, review, and undo without changing the underlying model.

**Q2 中文：** 解释本页概念：Proposal-review-undo / 提议-审查-撤销
**答：** 让系统先建议，人再批准，并提供撤销路径的控制模式。
**Q2 English:** Explain this concept: Proposal-review-undo / 提议-审查-撤销
**Answer:** 让系统先建议，人再批准，并提供撤销路径的控制模式。

## 第 6 页：Eighteen guidelines in four phases

Source ID: `src-b91e955ebdec-pdf_page-00006`

![PDF page 6](../assets/pages/page_006.png)

### 原文
```text
Eighteen guidelines in four phases

Lecture 03 · The guidelines

The eighteen guidelines cover four phases of interaction.

• Initially and during interaction, address 

• When wrong and over time, support recovery, 

capabilities, reliability, timing, relevance, social 
norms and bias.

explanations, cautious learning, feedback, visible 
consequences, controls and change notifications.

Amershi et al. (2019).
```

### 完整中文翻译
四个阶段中的十八条指南。

第 3 讲 - 指南。

十八条指南覆盖互动的四个阶段。

- 在互动开始和互动过程中，要处理能力、可靠性、时机、相关性、社会规范和偏见。
- 当系统出错以及随着时间推移，要支持恢复、解释、谨慎学习、反馈、可见后果、控制和变更通知。

Amershi 等（2019）。

### 中文释义
Amershi 指南把人机 AI 互动拆成生命周期：开始、过程中、出错时、长期使用中。每个阶段都有不同设计责任。

### English Explanation
The eighteen guidelines cover the lifecycle of human-AI interaction: initially, during interaction, when wrong, and over time.

### 概念解析
- **Guidelines for Human-AI Interaction / 人机 AI 交互指南**：Amershi 等提出的 18 条设计指南，用于改善 AI 系统可理解、可控和可恢复性。

### 自测问题
**Q1 中文：** 第 6 页最重要的设计判断是什么？
**答：** Amershi 指南把人机 AI 互动拆成生命周期：开始、过程中、出错时、长期使用中。每个阶段都有不同设计责任。
**Q1 English:** What is the key design judgement on page 6?
**Answer:** The eighteen guidelines cover the lifecycle of human-AI interaction: initially, during interaction, when wrong, and over time.

**Q2 中文：** 解释本页概念：Guidelines for Human-AI Interaction / 人机 AI 交互指南
**答：** Amershi 等提出的 18 条设计指南，用于改善 AI 系统可理解、可控和可恢复性。
**Q2 English:** Explain this concept: Guidelines for Human-AI Interaction / 人机 AI 交互指南
**Answer:** Amershi 等提出的 18 条设计指南，用于改善 AI 系统可理解、可控和可恢复性。

## 第 7 页：Initially and during: G1 to G6

Source ID: `src-b91e955ebdec-pdf_page-00007`

![PDF page 7](../assets/pages/page_007.png)

### 原文
```text
Initially and during: G1 to G6

Lecture 03 · The guidelines

G1–G6 make the system’s limits and situation visible.

• G1–G2 reveal the capability envelope—what the 

system can do—and reliability; G3–G4 add timing 
and relevance.

• G5–G6 address social norms and bias: match the 
expected register and test across accents, names 
and dialects.

Amershi et al. (2019); course examples.
```

### 完整中文翻译
开始时和互动中：G1 到 G6。

第 3 讲 - 指南。

G1-G6 让系统限制和情境变得可见。

- G1-G2 显示 capability envelope，也就是系统能做什么，以及可靠性；G3-G4 加入时机和相关性。
- G5-G6 处理社会规范和偏见：匹配预期语气，并跨口音、姓名和方言测试。

### 中文释义
前六条关心用户一开始如何理解系统：它能做什么、做得多可靠、什么时候出现、是否相关、是否符合社会场景且不带偏见。

### English Explanation
G1-G6 make capability, reliability, timing, relevance, social norms, and bias visible.

### 概念解析
- **Capability envelope / 能力边界**：系统能可靠完成和不能完成的范围。

### 自测问题
**Q1 中文：** 第 7 页最重要的设计判断是什么？
**答：** 前六条关心用户一开始如何理解系统：它能做什么、做得多可靠、什么时候出现、是否相关、是否符合社会场景且不带偏见。
**Q1 English:** What is the key design judgement on page 7?
**Answer:** G1-G6 make capability, reliability, timing, relevance, social norms, and bias visible.

**Q2 中文：** 解释本页概念：Capability envelope / 能力边界
**答：** 系统能可靠完成和不能完成的范围。
**Q2 English:** Explain this concept: Capability envelope / 能力边界
**Answer:** 系统能可靠完成和不能完成的范围。

## 第 8 页：When wrong and over time: G7 to G18

Source ID: `src-b91e955ebdec-pdf_page-00008`

![PDF page 8](../assets/pages/page_008.png)

### 原文
```text
When wrong and over time: G7 to G18

Lecture 03 · The guidelines

Being wrong is a normal phase that the interface must support.

• G7–G11 make invocation, dismissal and 

• G12–G18 support memory, cautious learning, 

correction efficient; narrow the scope when 
uncertain and explain actions.

granular feedback, visible consequences, global 
controls and change notifications.

After Amershi et al. (2019); course examples.
```

### 完整中文翻译
出错时和长期使用中：G7 到 G18。

第 3 讲 - 指南。

出错是一个正常阶段，界面必须支持它。

- G7-G11 让调用、忽略和纠正更高效；在不确定时缩小范围并解释行动。
- G12-G18 支持记忆、谨慎学习、细粒度反馈、可见后果、全局控制和变更通知。

### 中文释义
后十二条承认 AI 会错，所以要设计恢复和长期学习控制。重点不是让系统永不出错，而是错了之后人能看见、理解和修正。

### English Explanation
G7-G18 address invocation, dismissal, correction, scoped uncertainty, explanation, memory, cautious learning, feedback, consequences, controls, and change notifications.

### 概念解析
- **Cautious learning / 谨慎学习**：系统从用户行为中学习时不要过度推广，应让用户知道并能控制。

### 自测问题
**Q1 中文：** 第 8 页最重要的设计判断是什么？
**答：** 后十二条承认 AI 会错，所以要设计恢复和长期学习控制。重点不是让系统永不出错，而是错了之后人能看见、理解和修正。
**Q1 English:** What is the key design judgement on page 8?
**Answer:** G7-G18 address invocation, dismissal, correction, scoped uncertainty, explanation, memory, cautious learning, feedback, consequences, controls, and change notifications.

**Q2 中文：** 解释本页概念：Cautious learning / 谨慎学习
**答：** 系统从用户行为中学习时不要过度推广，应让用户知道并能控制。
**Q2 English:** Explain this concept: Cautious learning / 谨慎学习
**Answer:** 系统从用户行为中学习时不要过度推广，应让用户知道并能控制。

## 第 9 页：Who moves next is a design decision

Source ID: `src-b91e955ebdec-pdf_page-00009`

![PDF page 9](../assets/pages/page_009.png)

### 原文
```text
Who moves next is a design decision

Lecture 03 · Mixed initiative

Mixed initiative makes the next move a shared design decision.

• In the manual example, the person creates the 
meeting; in the automatic example, the system 
creates it before the person reviews it.

• With mixed initiative, the system proposes a 
meeting and the person decides. Both can 
contribute to progressing the task.

• Horvitz (1999) links this decision to uncertainty, 
attention and the cost of a poor guess, using 
dialogue to resolve important uncertainties.

After Horvitz (1999); illustrative meeting.
```

### 完整中文翻译
谁下一步行动，是一个设计决策。

第 3 讲 - 混合主动权。

混合主动权把下一步行动变成共享的设计决策。

- 在手动例子中，人创建会议；在自动例子中，系统在人审查之前创建会议。
- 在混合主动权中，系统提出会议，人来决定。双方都能推进任务。
- Horvitz（1999）把这个决定连接到不确定性、注意力和错误猜测的成本，并用对话解决重要不确定性。

### 中文释义
Mixed initiative 的本质是分配下一步行动权：人做、系统做，还是系统建议人决定。选择取决于置信度、注意力和错误成本。

### English Explanation
Mixed initiative treats the next move as a shared design decision based on uncertainty, attention, and cost.

### 概念解析
- **Mixed initiative / 混合主动权**：人和系统都可以推动任务，但谁行动由明确规则决定。

### 自测问题
**Q1 中文：** 第 9 页最重要的设计判断是什么？
**答：** Mixed initiative 的本质是分配下一步行动权：人做、系统做，还是系统建议人决定。选择取决于置信度、注意力和错误成本。
**Q1 English:** What is the key design judgement on page 9?
**Answer:** Mixed initiative treats the next move as a shared design decision based on uncertainty, attention, and cost.

**Q2 中文：** 解释本页概念：Mixed initiative / 混合主动权
**答：** 人和系统都可以推动任务，但谁行动由明确规则决定。
**Q2 English:** Explain this concept: Mixed initiative / 混合主动权
**Answer:** 人和系统都可以推动任务，但谁行动由明确规则决定。

## 第 10 页：Act, ask or wait

Source ID: `src-b91e955ebdec-pdf_page-00010`

![PDF page 10](../assets/pages/page_010.png)

### 原文
```text
Act, ask or wait

Lecture 03 · Mixed initiative

Choose whether to act, ask or wait by considering the consequences.

• Consider confidence that the person wants 

the action and the cost of being wrong
together.

• In this qualitative rule, act when confidence is 

high and error costs are low; ask when 
uncertainty or costs warrant it; otherwise wait.

• Attention changes the decision: an appropriate 
action at 08:10 may be an interruption during a 
meeting. Document, test and defend the rule.

After Horvitz (1999); qualitative illustration.
```

### 完整中文翻译
行动、询问或等待。

第 3 讲 - 混合主动权。

根据后果选择行动、询问或等待。

- 同时考虑系统对人想要该行动的置信度和出错成本。
- 在这个定性规则中，置信度高且错误成本低时行动；不确定或成本值得关注时询问；否则等待。
- 注意力会改变决策：08:10 合适的行动，在会议中可能变成打扰。记录、测试并为规则辩护。

### 中文释义
这是主动权规则的简洁公式。系统何时自动行动不应凭感觉，而要把置信度、错误成本和用户注意状态写成可测试规则。

### English Explanation
Act, ask, or wait should be chosen by considering confidence, error cost, and attention.

### 概念解析
- **Act-ask-wait rule / 行动-询问-等待规则**：高置信低成本就行动；有不确定或成本就询问；否则等待。

### 自测问题
**Q1 中文：** 第 10 页最重要的设计判断是什么？
**答：** 这是主动权规则的简洁公式。系统何时自动行动不应凭感觉，而要把置信度、错误成本和用户注意状态写成可测试规则。
**Q1 English:** What is the key design judgement on page 10?
**Answer:** Act, ask, or wait should be chosen by considering confidence, error cost, and attention.

**Q2 中文：** 解释本页概念：Act-ask-wait rule / 行动-询问-等待规则
**答：** 高置信低成本就行动；有不确定或成本就询问；否则等待。
**Q2 English:** Explain this concept: Act-ask-wait rule / 行动-询问-等待规则
**Answer:** 高置信低成本就行动；有不确定或成本就询问；否则等待。

## 第 11 页：The gulf between expectation and experience

Source ID: `src-b91e955ebdec-pdf_page-00011`

![PDF page 11](../assets/pages/page_011.png)

### 原文
```text
The gulf between expectation and experience

Lecture 03 · The expectation gulf

The expectation gulf concerns what people expect the system to understand.

• The lecture contrasts “like having a PA” with 
Luger and Sellen’s (2016) study title, “like 
having a really bad PA”.

• Interviewees reported simple-task reliability, 

unexplained failures and unclear capabilities, 
then developed workarounds or used the 
system less.

• The design interpretation is a mismatch 

between expectation and experience: 
presentation shapes what people believe the 
assistant can do.

Luger and Sellen (2016); course interpretation.
```

### 完整中文翻译
期待与体验之间的鸿沟。

第 3 讲 - 期待鸿沟。

期待鸿沟关心人们期待系统理解什么。

- 本讲把“像有一个私人助理”与 Luger 和 Sellen（2016）的研究题目“像有一个非常糟糕的私人助理”进行对比。
- 受访者报告了简单任务可靠性、无法解释的失败和能力不清，随后发展出变通办法或更少使用系统。
- 设计解释是期待与体验不匹配：呈现方式塑造人们相信助手能做什么。

### 中文释义
宣传和界面会塑造用户期待。如果系统看起来像真人助理，用户会期待它理解更多；实际能力不足就形成 expectation gulf。

### English Explanation
The expectation gulf is a mismatch between what people expect an assistant to understand and what it reliably does.

### 概念解析
- **Expectation gulf / 期待鸿沟**：系统呈现出的能力形象与真实体验之间的差距。

### 自测问题
**Q1 中文：** 第 11 页最重要的设计判断是什么？
**答：** 宣传和界面会塑造用户期待。如果系统看起来像真人助理，用户会期待它理解更多；实际能力不足就形成 expectation gulf。
**Q1 English:** What is the key design judgement on page 11?
**Answer:** The expectation gulf is a mismatch between what people expect an assistant to understand and what it reliably does.

**Q2 中文：** 解释本页概念：Expectation gulf / 期待鸿沟
**答：** 系统呈现出的能力形象与真实体验之间的差距。
**Q2 English:** Explain this concept: Expectation gulf / 期待鸿沟
**Answer:** 系统呈现出的能力形象与真实体验之间的差距。

## 第 12 页：The gulf is a mental-model mismatch

Source ID: `src-b91e955ebdec-pdf_page-00012`

![PDF page 12](../assets/pages/page_012.png)

### 原文
```text
The gulf is a mental-model mismatch

Lecture 03 · The expectation gulf

Make the system’s limits visible so people can revise their mental model.

• A mental model is the person’s understanding of 

how a system works, shaped by previous 
experience and how the assistant presents itself.

• When the capability envelope remains hidden, 
that understanding cannot be corrected against 
what the system actually does reliably.

• Saying what it can do and how well (G1, G2)

communicates capability and reliability; scoping 
when in doubt and explaining why (G10, G11)
narrow uncertain services and explain behaviour. 
These design moves reduce the mismatch.

Course illustration; Amershi et al. (2019).
```

### 完整中文翻译
这个鸿沟是一种心理模型错配。

第 3 讲 - 期待鸿沟。

让系统限制可见，使人能修正自己的心理模型。

- 心理模型是人对系统如何工作的理解，由过去经验和助手如何呈现自己共同塑造。
- 当能力边界保持隐藏时，这种理解无法根据系统实际可靠行为得到纠正。
- 说明它能做什么以及做得多好（G1、G2）传达能力和可靠性；在不确定时限定范围并解释原因（G10、G11）缩小不确定服务并解释行为。这些设计动作会减少错配。

### 中文释义
期待鸿沟不是单纯用户误会，而是系统没有给足证据让用户校准心理模型。能力边界、可靠性、范围限定和解释都是校准工具。

### English Explanation
The gulf can be reduced by making limits, reliability, uncertainty, and explanations visible so users can revise their mental models.

### 概念解析
- **Mental-model mismatch / 心理模型错配**：用户以为系统怎样工作，与系统实际可靠能力不一致。

### 自测问题
**Q1 中文：** 第 12 页最重要的设计判断是什么？
**答：** 期待鸿沟不是单纯用户误会，而是系统没有给足证据让用户校准心理模型。能力边界、可靠性、范围限定和解释都是校准工具。
**Q1 English:** What is the key design judgement on page 12?
**Answer:** The gulf can be reduced by making limits, reliability, uncertainty, and explanations visible so users can revise their mental models.

**Q2 中文：** 解释本页概念：Mental-model mismatch / 心理模型错配
**答：** 用户以为系统怎样工作，与系统实际可靠能力不一致。
**Q2 English:** Explain this concept: Mental-model mismatch / 心理模型错配
**Answer:** 用户以为系统怎样工作，与系统实际可靠能力不一致。

## 第 13 页：Your turn: name the guideline, then the fix

Source ID: `src-b91e955ebdec-pdf_page-00013`

![PDF page 13](../assets/pages/page_013.png)

### 原文
```text
Your turn: name the guideline, then the fix

Lecture 03 · Interaction 2

Diagnose the broken guideline, then propose a concrete repair.

• A repeats “Sorry, I didn't get that” four times and 
stops. B sends a smart reply after an accidental 
thumb brush, with no recall.

• C silently rewrites a music profile after someone 

else plays a child’s songs for one afternoon.

• Take two minutes to name the guideline, the fix 
and the broken commitment: accountability, two 
dimensions or an explicit initiative rule.
```

### 完整中文翻译
轮到你：说出指南，再提出修复。

第 3 讲 - 互动 2。

诊断被破坏的指南，再提出具体修复。

- A 连续四次重复“抱歉，我没听懂”然后停止。B 因一次误触拇指滑动就发送智能回复，且无法召回。
- C 在别人用你的手机播放一下午儿童歌曲后，悄悄重写音乐档案。
- 用两分钟说出指南、修复，以及被破坏的承诺：问责、两个维度，或明确主动权规则。

### 中文释义
练习要求你不要只说“体验差”，而要把问题映射到具体指南和三个承诺。例如误触发送破坏主动权与可撤销性，静默改档案破坏谨慎学习与通知。

### English Explanation
The activity trains diagnosis: name the broken guideline, propose a repair, and link it to one of the commitments.

### 概念解析
- **Guideline diagnosis / 指南诊断**：把交互失败映射到具体人机 AI 指南，再提出修复。

### 自测问题
**Q1 中文：** 第 13 页最重要的设计判断是什么？
**答：** 练习要求你不要只说“体验差”，而要把问题映射到具体指南和三个承诺。例如误触发送破坏主动权与可撤销性，静默改档案破坏谨慎学习与通知。
**Q1 English:** What is the key design judgement on page 13?
**Answer:** The activity trains diagnosis: name the broken guideline, propose a repair, and link it to one of the commitments.

**Q2 中文：** 解释本页概念：Guideline diagnosis / 指南诊断
**答：** 把交互失败映射到具体人机 AI 指南，再提出修复。
**Q2 English:** Explain this concept: Guideline diagnosis / 指南诊断
**Answer:** 把交互失败映射到具体人机 AI 指南，再提出修复。

## 第 14 页：The recommender, initially

Source ID: `src-b91e955ebdec-pdf_page-00014`

![PDF page 14](../assets/pages/page_014.png)

### 原文
```text
The recommender, initially

Lecture 03 · Worked example

Explain what the recommender uses and where it may be unreliable.

• Say what it can do (G1): it recommends from 

what you play and save, and never buys, shares 
or posts.

• Say how well (G2): it works better for familiar 

genres than new ones, and labels lower-
confidence recommendations.

• Show where the model of you lives and how to 
inspect it. Missing these explanations makes 
later recommendations harder to understand and 
trust.

Amershi et al. (2019); hypothetical interface.
```

### 完整中文翻译
推荐器：初始阶段。

第 3 讲 - worked example。

解释推荐器使用什么，以及在哪里可能不可靠。

- 说明它能做什么（G1）：它根据你播放和保存的内容推荐；它绝不会购买、分享或发布。
- 说明它做得多好（G2）：熟悉类型上更好，新类型上较弱，并标注低置信推荐。
- 显示关于你的模型在哪里以及如何检查。缺少这些解释会让后来的推荐更难理解和信任。

### 中文释义
推荐系统一开始就要亮明能力边界、可靠性和用户模型位置。这样用户才知道推荐来自哪里，也知道它不会越权。

### English Explanation
The recommender should initially reveal capability, reliability, confidence, and where the user model can be inspected.

### 概念解析
- **User model / 用户模型**：系统保存的关于用户偏好、历史和推断的表示。

### 自测问题
**Q1 中文：** 第 14 页最重要的设计判断是什么？
**答：** 推荐系统一开始就要亮明能力边界、可靠性和用户模型位置。这样用户才知道推荐来自哪里，也知道它不会越权。
**Q1 English:** What is the key design judgement on page 14?
**Answer:** The recommender should initially reveal capability, reliability, confidence, and where the user model can be inspected.

**Q2 中文：** 解释本页概念：User model / 用户模型
**答：** 系统保存的关于用户偏好、历史和推断的表示。
**Q2 English:** Explain this concept: User model / 用户模型
**Answer:** 系统保存的关于用户偏好、历史和推断的表示。

## 第 15 页：The recommender, during interaction

Source ID: `src-b91e955ebdec-pdf_page-00015`

![PDF page 15](../assets/pages/page_015.png)

### 原文
```text
The recommender, during interaction

Lecture 03 · Worked example

Timing, relevance and reasons make a recommendation checkable.

• Timing (G3): a commute mix at 08:10 on a 

weekday, and quiet during a call.

• Relevance (G4): three tiles that fit the current 

situation, so the person can see why they matter 
now.

• Explain why (G11): “because you saved Night 

Drive yesterday”. The person can challenge that 
inference and learn what information the system 
uses.

Amershi et al. (2019); hypothetical interface.
```

### 完整中文翻译
推荐器：互动过程中。

第 3 讲 - worked example。

时机、相关性和理由让推荐可检查。

- 时机（G3）：工作日 08:10 的通勤歌单，在通话中保持安静。
- 相关性（G4）：三个符合当前情境的卡片，让用户看到为什么现在重要。
- 解释原因（G11）：“因为你昨天保存了 Night Drive”。用户可以挑战这个推断，并了解系统使用了什么信息。

### 中文释义
推荐不是只给结果，还要让用户检查“为什么现在推荐这个”。时机、情境相关性和简短理由能增强可见性。

### English Explanation
During interaction, timing, relevance, and reasons make recommendations checkable.

### 概念解析
- **Reason-giving / 给出理由**：用简短证据说明推荐为何出现，帮助用户挑战或校准系统推断。

### 自测问题
**Q1 中文：** 第 15 页最重要的设计判断是什么？
**答：** 推荐不是只给结果，还要让用户检查“为什么现在推荐这个”。时机、情境相关性和简短理由能增强可见性。
**Q1 English:** What is the key design judgement on page 15?
**Answer:** During interaction, timing, relevance, and reasons make recommendations checkable.

**Q2 中文：** 解释本页概念：Reason-giving / 给出理由
**答：** 用简短证据说明推荐为何出现，帮助用户挑战或校准系统推断。
**Q2 English:** Explain this concept: Reason-giving / 给出理由
**Answer:** 用简短证据说明推荐为何出现，帮助用户挑战或校准系统推断。

## 第 16 页：The recommender, when wrong

Source ID: `src-b91e955ebdec-pdf_page-00016`

![PDF page 16](../assets/pages/page_016.png)

### 原文
```text
The recommender, when wrong

Lecture 03 · Worked example

A correction should address the mistaken profile update, not only the tile.

• After someone borrows the phone for one 

afternoon, its home page becomes nursery 
rhymes. Easy dismissal (G8) hides the tile; 
easy correction (G9) lets “that was someone 
else” fix the cause.

EO1

• Scoping when in doubt (G10) treats an unusual 
day as uncertainty and limits what the system 
changes.

• The silent update also breaks cautious 

adaptation (G14), notifying users of changes 
(G18) and global controls (G17).

Amershi et al. (2019).
```

### 完整中文翻译
推荐器：出错时。

第 3 讲 - worked example。

纠正应该处理错误的档案更新，而不只是隐藏卡片。

- 有人借你的手机一下午后，首页变成儿歌。轻松忽略（G8）只能隐藏卡片；轻松纠正（G9）允许“那是别人”修复原因。
- 不确定时缩小范围（G10）把异常一天视为不确定，并限制系统改变的内容。
- 静默更新还破坏谨慎适应（G14）、通知用户变化（G18）和全局控制（G17）。

### 中文释义
真正修复推荐错误要改原因，而不是只删结果。系统需要识别异常行为、暂停学习或让用户标记“不是我”。

### English Explanation
When a recommender is wrong, correction should address the mistaken profile update, not only dismiss the visible tile.

### 概念解析
- **Cause-level correction / 原因层修正**：修正导致错误输出的用户模型或学习记录，而不是只隐藏表面结果。

### 自测问题
**Q1 中文：** 第 16 页最重要的设计判断是什么？
**答：** 真正修复推荐错误要改原因，而不是只删结果。系统需要识别异常行为、暂停学习或让用户标记“不是我”。
**Q1 English:** What is the key design judgement on page 16?
**Answer:** When a recommender is wrong, correction should address the mistaken profile update, not only dismiss the visible tile.

**Q2 中文：** 解释本页概念：Cause-level correction / 原因层修正
**答：** 修正导致错误输出的用户模型或学习记录，而不是只隐藏表面结果。
**Q2 English:** Explain this concept: Cause-level correction / 原因层修正
**Answer:** 修正导致错误输出的用户模型或学习记录，而不是只隐藏表面结果。

## 第 17 页：Slide 16 comments

Source ID: `src-b91e955ebdec-pdf_page-00017`

![PDF page 17](../assets/pages/page_017.png)

### 原文
```text
Slide 16

EO1 

Are these references to future lectures? If so, nobody will remember them. Maybe it's better to relate them to a concept rather 
than a number.
Eyal Ofek, 2026-09-23T15:36:24.424

DG1 0 

They are points of a paper
Daniele Giunchi (Computer Scien, 2026-09-24T12:26:19.244
```

### 完整中文翻译
第 16 页评论。

EO1：这些是指向未来讲座的引用吗？如果是，没人会记得。也许最好把它们关联到一个概念，而不是一个数字。

DG1：它们是论文中的点。

Eyal Ofek，2026-09-23；Daniele Giunchi，2026-09-24。

### 中文释义
这一页是课件批注，不是正式授课内容。它提醒我们：引用或编号如果不自明，会增加理解负担；更好的做法是把引用连接到概念。

### English Explanation
This page contains review comments rather than lecture content. It highlights that references should be concept-linked rather than opaque numbers.

### 概念解析
- **Review comment / 课件批注**：课件制作过程中的反馈，不应和正式课程主张混淆。

### 自测问题
**Q1 中文：** 第 17 页最重要的设计判断是什么？
**答：** 这一页是课件批注，不是正式授课内容。它提醒我们：引用或编号如果不自明，会增加理解负担；更好的做法是把引用连接到概念。
**Q1 English:** What is the key design judgement on page 17?
**Answer:** This page contains review comments rather than lecture content. It highlights that references should be concept-linked rather than opaque numbers.

**Q2 中文：** 解释本页概念：Review comment / 课件批注
**答：** 课件制作过程中的反馈，不应和正式课程主张混淆。
**Q2 English:** Explain this concept: Review comment / 课件批注
**Answer:** 课件制作过程中的反馈，不应和正式课程主张混淆。

## 第 18 页：The recommender, over time: the fix

Source ID: `src-b91e955ebdec-pdf_page-00018`

![PDF page 18](../assets/pages/page_018.png)

### 原文
```text
The recommender, over time: the fix

Lecture 03 · Worked example

Make profile changes cautious, visible and controllable.

• Adapt cautiously (G14): update the profile from 
repeated behaviour over days, and hold unusual 
days apart for review.

• Notify changes (G18): explain “your 

recommendations changed because…” and 
show the evidence with a choice.

• Global controls (G17): a guest session, pause 
learning, reset and a view of what is used. The 
recommender keeps its accuracy; the person 
gains control.

Amershi et al. (2019).
```

### 完整中文翻译
推荐器：长期使用中的修复。

第 3 讲 - worked example。

让档案变化谨慎、可见、可控。

- 谨慎适应（G14）：根据多日重复行为更新档案，并把异常日期单独保留以供审查。
- 变化通知（G18）：解释“你的推荐发生变化，因为……”并显示证据和选择。
- 全局控制（G17）：访客会话、暂停学习、重置，以及查看使用了什么。推荐器保留准确性，人获得控制。

### 中文释义
这页给出推荐器长期学习的好设计：不要因为一天异常就改用户模型；要通知变化、显示证据，并提供全局控制。

### English Explanation
The fix is cautious, visible, controllable adaptation: repeated evidence, change notifications, and global controls.

### 概念解析
- **Guest session / 访客会话**：允许他人使用设备而不污染主用户模型的模式。

### 自测问题
**Q1 中文：** 第 18 页最重要的设计判断是什么？
**答：** 这页给出推荐器长期学习的好设计：不要因为一天异常就改用户模型；要通知变化、显示证据，并提供全局控制。
**Q1 English:** What is the key design judgement on page 18?
**Answer:** The fix is cautious, visible, controllable adaptation: repeated evidence, change notifications, and global controls.

**Q2 中文：** 解释本页概念：Guest session / 访客会话
**答：** 允许他人使用设备而不污染主用户模型的模式。
**Q2 English:** Explain this concept: Guest session / 访客会话
**Answer:** 允许他人使用设备而不污染主用户模型的模式。

## 第 19 页：The project is a compact research paper

Source ID: `src-b91e955ebdec-pdf_page-00019`

![PDF page 19](../assets/pages/page_019.png)

### 原文
```text
The project is a compact research paper

Lecture 03 · Project connection

The project develops a question, a system and evidence about it.

• Phase 1, Weeks 1–4 (5%), establishes the 
problem, related work, gap, question and 
contribution, with an illustrated document of 
about 700 words and a video of about five 
minutes.

• Phase 2, Weeks 5–9 (10%), develops the 

prototype with documented AI use; Week 6 is 
reading week.

• Phase 3, Weeks 10–11 (5%), presents evidence 

and a poster. The project is continuous 
assessment, 20% of the module; the final exam
is 80%.
```

### 完整中文翻译
项目是一篇紧凑的研究论文。

第 3 讲 - 项目连接。

项目要发展一个问题、一个系统和关于它的证据。

- 阶段 1，第 1-4 周（5%）：建立问题、相关工作、空白、问题和贡献，提交约 700 字图文文档和约 5 分钟视频。
- 阶段 2，第 5-9 周（10%）：开发原型并记录 AI 使用；第 6 周是阅读周。
- 阶段 3，第 10-11 周（5%）：呈现证据和海报。项目是连续评估，占模块 20%；期末考试占 80%。

### 中文释义
项目不是单纯做 demo，而是小型研究：问题、文献、空白、贡献、原型和证据必须连起来。

### English Explanation
The project is framed as a compact research paper: question, system, evidence, and contribution.

### 概念解析
- **Research contribution / 研究贡献**：项目相对已有工作的新增价值，可以体现在问题、设计、实现或评估证据上。

### 自测问题
**Q1 中文：** 第 19 页最重要的设计判断是什么？
**答：** 项目不是单纯做 demo，而是小型研究：问题、文献、空白、贡献、原型和证据必须连起来。
**Q1 English:** What is the key design judgement on page 19?
**Answer:** The project is framed as a compact research paper: question, system, evidence, and contribution.

**Q2 中文：** 解释本页概念：Research contribution / 研究贡献
**答：** 项目相对已有工作的新增价值，可以体现在问题、设计、实现或评估证据上。
**Q2 English:** Explain this concept: Research contribution / 研究贡献
**Answer:** 项目相对已有工作的新增价值，可以体现在问题、设计、实现或评估证据上。

## 第 20 页：Eleven weeks, three phases, one final exam

Source ID: `src-b91e955ebdec-pdf_page-00020`

![PDF page 20](../assets/pages/page_020.png)

### 原文
```text
Eleven weeks, three phases, one final exam

Lecture 03 · Project connection

Three project phases make up 20% of the module; the final exam makes up 80%.

• Project (20%): Phase 1 5%, Weeks 1–4; Phase 2 

• Final exam (80%) in the exam period. Weekly 

10%, Weeks 5–9; Phase 3 5%, Weeks 10–11.

Canvas quizzes are formative: no score.

Submission dates are published on Canvas.
```

### 完整中文翻译
十一周，三个阶段，一场期末考试。

第 3 讲 - 项目连接。

三个项目阶段构成模块 20%；期末考试构成 80%。

- 项目（20%）：阶段 1 占 5%，第 1-4 周；阶段 2 占 10%，第 5-9 周；阶段 3 占 5%，第 10-11 周。
- 期末考试（80%）在考试期进行。每周 Canvas quizzes 是 formative，也就是形成性练习，不计分。

提交日期发布在 Canvas。

### 中文释义
这页是 assessment 结构。重要的是项目三阶段持续推进，Canvas quiz 用于练习，不计入成绩。

### English Explanation
The assessment structure is 20% project across three phases and 80% final exam; weekly quizzes are formative.

### 概念解析
- **Formative assessment / 形成性评估**：用于学习反馈但不计入最终成绩的练习。

### 自测问题
**Q1 中文：** 第 20 页最重要的设计判断是什么？
**答：** 这页是 assessment 结构。重要的是项目三阶段持续推进，Canvas quiz 用于练习，不计入成绩。
**Q1 English:** What is the key design judgement on page 20?
**Answer:** The assessment structure is 20% project across three phases and 80% final exam; weekly quizzes are formative.

**Q2 中文：** 解释本页概念：Formative assessment / 形成性评估
**答：** 用于学习反馈但不计入最终成绩的练习。
**Q2 English:** Explain this concept: Formative assessment / 形成性评估
**Answer:** 用于学习反馈但不计入最终成绩的练习。

## 第 21 页：Three books, and how the module reads them

Source ID: `src-b91e955ebdec-pdf_page-00021`

![PDF page 21](../assets/pages/page_021.png)

### 原文
```text
Three books, and how the module reads them

Lecture 03 · The books

Read each lecture’s chapter anchor with its design question in mind.

• Shneiderman, Human-Centered AI (2022)

supports the design stance, human control and 
governance.

• Norman, The Design of Everyday Things 
(2013) explains action, error, feedback and 
mental models: how people understand and 
operate a system.

• LaValle, Virtual Reality (2017) covers sensing, 
rendering and evaluation for extended reality 
(XR). Read the named chapter anchor rather 
than the whole book at once.

Shneiderman (2022); Norman (2013); LaValle (2017).
```

### 完整中文翻译
三本书，以及模块如何阅读它们。

第 3 讲 - 书目。

带着每讲的设计问题阅读对应章节锚点。

- Shneiderman《Human-Centered AI》（2022）支持设计立场、人类控制和治理。
- Norman《The Design of Everyday Things》（2013）解释行动、错误、反馈和心理模型：人如何理解并操作系统。
- LaValle《Virtual Reality》（2017）覆盖扩展现实（XR）的感知、渲染和评估。阅读指定章节锚点，而不是一次读完整本书。

### 中文释义
这页告诉你如何用书：不是泛读，而是按 lecture anchor 读。每本书支撑不同部分：HCAI、日常设计心理学、XR。

### English Explanation
The module uses three books as chapter anchors, not as whole-book reading assignments.

### 概念解析
- **Chapter anchor / 章节锚点**：每讲指定的阅读定位，用于支撑当前设计问题。

### 自测问题
**Q1 中文：** 第 21 页最重要的设计判断是什么？
**答：** 这页告诉你如何用书：不是泛读，而是按 lecture anchor 读。每本书支撑不同部分：HCAI、日常设计心理学、XR。
**Q1 English:** What is the key design judgement on page 21?
**Answer:** The module uses three books as chapter anchors, not as whole-book reading assignments.

**Q2 中文：** 解释本页概念：Chapter anchor / 章节锚点
**答：** 每讲指定的阅读定位，用于支撑当前设计问题。
**Q2 English:** Explain this concept: Chapter anchor / 章节锚点
**Answer:** 每讲指定的阅读定位，用于支撑当前设计问题。

## 第 22 页：Who is it for, and what does that commit us to?

Source ID: `src-b91e955ebdec-pdf_page-00022`

![PDF page 22](../assets/pages/page_022.png)

### 原文
```text
Who is it for, and what does that commit us to?

Lecture 03 · Synthesis and bridge

Human-centred systems keep people in control as the system infers and acts.

• Design for the person whose activity changes, 
aiming for high automation and human control 
together.

• Use the eighteen guidelines and an explicit 

initiative rule; this stance returns in Lectures 07, 
13 and 28 (the Week 11 self-audit).

• In Lab 1, use AI tools to search the literature and 

verify five sources; you leave with one-line 
notes, a prompt log and a first gap sentence.
```

### 完整中文翻译
它是为谁而设计？这要求我们承担什么？

第 3 讲 - 综合与过渡。

以人为中心的系统在人推断和行动时仍让人保持控制。

- 为活动被改变的人设计，目标是同时获得高自动化和高人类控制。
- 使用十八条指南和明确的主动权规则；这个立场会在第 7、13 和 28 讲（第 11 周自我审计）回归。
- 在实验 1 中，使用 AI 工具搜索文献并验证五个来源；你会得到一句话笔记、prompt log 和第一句 gap sentence。

### 中文释义
总结页把本讲压缩成项目原则：先问为谁设计，再用指南和主动权规则保证人在系统推断与行动中仍保留控制。

### English Explanation
The synthesis connects human-centred commitments to project work and later module checkpoints.

### 概念解析
- **Gap sentence / 研究空白句**：用一句话说明现有工作没有解决什么，以及你的项目切入点。

### 自测问题
**Q1 中文：** 第 22 页最重要的设计判断是什么？
**答：** 总结页把本讲压缩成项目原则：先问为谁设计，再用指南和主动权规则保证人在系统推断与行动中仍保留控制。
**Q1 English:** What is the key design judgement on page 22?
**Answer:** The synthesis connects human-centred commitments to project work and later module checkpoints.

**Q2 中文：** 解释本页概念：Gap sentence / 研究空白句
**答：** 用一句话说明现有工作没有解决什么，以及你的项目切入点。
**Q2 English:** Explain this concept: Gap sentence / 研究空白句
**Answer:** 用一句话说明现有工作没有解决什么，以及你的项目切入点。

## 第 23 页：References and further reading

Source ID: `src-b91e955ebdec-pdf_page-00023`

![PDF page 23](../assets/pages/page_023.png)

### 原文
```text
References and further reading

Lecture 03 · References

Read the sources according to the design claim they 
support.

Shneiderman, B. (2022). Human-Centered AI. Oxford University Press. Part 1 (chapters 3–4) and Part 2 (the two-
dimensional human-centred AI (HCAI) framework and design guidelines).

Norman, D. A. (2013). The Design of Everyday Things (revised and expanded edition). Basic Books. Chapter 1, The 
Psychopathology of Everyday Things.

Amershi, S., Weld, D., Vorvoreanu, M., Fourney, A., Nushi, B., Collisson, P., Suh, J., Iqbal, S., Bennett, P. N., Inkpen, 
K., Teevan, J., Kikin-Gil, R., & Horvitz, E. (2019). Guidelines for Human-AI Interaction. CHI 2019, Paper 3.

Horvitz, E. (1999). Principles of Mixed-Initiative User Interfaces. CHI 1999, 159–166.

Luger, E., & Sellen, A. (2016). 'Like Having a Really Bad PA': The Gulf between User Expectation and Experience of 
Conversational Agents. CHI 2016, 5286–5297.

LaValle, S. M. (2017). Virtual Reality. Cambridge University Press; free online at lavalle.pl/vr. Named today; used 
mainly in Weeks 7–9.

Assessment details and submission dates: module handbook and Canvas.

• Shneiderman and Norman establish 
the design stance; Amershi et al. 
and Horvitz support guidelines and 
initiative decisions.

• Luger and Sellen examine the 

expectation gulf; LaValle supports the 
extended reality (XR) weeks.
```

### 完整中文翻译
参考文献与延伸阅读。

第 3 讲 - 参考文献。

按设计主张阅读来源。

Shneiderman（2022）《Human-Centered AI》：第 1 部分第 3-4 章，以及第 2 部分的二维 HCAI 框架和设计指南。

Norman（2013）《The Design of Everyday Things》修订扩展版：第 1 章，The Psychopathology of Everyday Things。

Amershi 等（2019）《Guidelines for Human-AI Interaction》。CHI 2019, Paper 3。

Horvitz（1999）《Principles of Mixed-Initiative User Interfaces》。CHI 1999，159-166。

Luger 与 Sellen（2016）《Like Having a Really Bad PA: The Gulf between User Expectation and Experience of Conversational Agents》。CHI 2016，5286-5297。

LaValle（2017）《Virtual Reality》。Cambridge University Press；可在 lavalle.pl/vr 免费在线阅读。今天点名，主要用于第 7-9 周。

评估细节和提交日期见 module handbook 与 Canvas。

- Shneiderman 和 Norman 建立设计立场；Amershi 等与 Horvitz 支持指南和主动权决策。
- Luger 与 Sellen 研究期待鸿沟；LaValle 支持 XR 周内容。

### 中文释义
参考页把每个概念的学术来源对应起来。复习时按主题读：HCAI 看 Shneiderman，日常设计看 Norman，指南看 Amershi，主动权看 Horvitz，期待鸿沟看 Luger & Sellen。

### English Explanation
The references map each design claim to its supporting literature.

### 概念解析
- **Citation mapping / 引文映射**：把课程概念与支撑文献一一对应，便于复习和项目引用。

### 自测问题
**Q1 中文：** 第 23 页最重要的设计判断是什么？
**答：** 参考页把每个概念的学术来源对应起来。复习时按主题读：HCAI 看 Shneiderman，日常设计看 Norman，指南看 Amershi，主动权看 Horvitz，期待鸿沟看 Luger & Sellen。
**Q1 English:** What is the key design judgement on page 23?
**Answer:** The references map each design claim to its supporting literature.

**Q2 中文：** 解释本页概念：Citation mapping / 引文映射
**答：** 把课程概念与支撑文献一一对应，便于复习和项目引用。
**Q2 English:** Explain this concept: Citation mapping / 引文映射
**Answer:** 把课程概念与支撑文献一一对应，便于复习和项目引用。
