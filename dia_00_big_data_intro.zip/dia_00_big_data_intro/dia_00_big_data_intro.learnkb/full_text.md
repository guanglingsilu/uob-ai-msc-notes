# 来源：0. Introduction to Big Data engineering - Lecture Notes-1.pdf

<!-- SOURCE: 0. Introduction to Big Data engineering - Lecture Notes-1.pdf -->

<!-- PDF 页 1 -->

Data-intensive AI:
Introduction to Big Data Engineering

Prof. Paolo Missier
School of Computer Science
University of Birmingham, UK

Data-intensive AI
2026/27 Sem 1

<!-- PDF 页 2 -->

The data-to-inference value chain

Training-ready 
datasets

Model

Source
datasets

Dataset
- Selection
- Integration

Source data quality
Task-agnostic

- Supervised / 
Unsupervised    Machine 
Learning
- Deep Learning
- Transformers --> LLMs

Inference
Prediction
Generation
Emergent structure

<!-- PDF 页 3 -->

Data-centric AI

D

M

D

M’

(

(

,

,

D

)

)

M

Optimise M

Improve D

(

(

,

,

D’

M

)

)

Zha, D., et al. (2023). "Data-centric Artificial Intelligence: A Survey." arXiv preprint arXiv:2303.10158

Prerna Singh, Systematic review of data-centric approaches in artificial intelligence and machine 
learning, Data Science and Management, (6,3), 2023, https://doi.org/10.1016/j.dsm.2023.06.001.

Bhatt, N., Bhatt, N., Prajapati, P. et al. A Data-Centric Approach to improve performance of deep learning 
models. Sci Rep 14, 22329 (2024). https://doi.org/10.1038/s41598-024-73643-x

<!-- PDF 页 4 -->

4

Big Data

<!-- PDF 页 5 -->

Data growth

 106B Megabyte
 109B Gigabyte
 1012B Terabyte
 1015B Petabyte
 1018B Exabyte
 1021B Zettabyte

90% of world's data:

 generated over last two years

<!-- PDF 页 6 -->

Big Data for AI

Domain

Volume

Variety

Velocity

Model purpose

NLP / LLMs

~12–20T tokens
(PB-scale corpora)

Web text, books,
code, image/video

~1000× growth
since 2019

General-purpose
generation

Particle physics 
/ CERN LHC

~10,000 EB/yr raw →
tens of PB/yr stored

High-dimensional
detector readings

~4 TB/s raw;
μs-level filtering

Real-time ML triggers
selecting events

Genomics /
UK Biobank

30+ PB total
(27.5 PB genomic)

Genomes, imaging,
EHR, biomarkers

Streaming /
Netflix

Logs from 100s of
millions of users

Clicks, watch time,
pauses, searches

1,000s 
genomes/mo;
15+ yr 
longitudinal

Continuous,
per-session 
updates

Disease-risk
prediction (MILTON)

Ranking & 
recommendation

<!-- PDF 页 7 -->

Big Data for AI

Domain

Volume

Variety

Velocity

Purpose

Google Search: 
PageRank at 
Web Scale

billions of pages, 
tens of billions of 
edges

Pure link structure 
(URLs)

Continuous re-
crawling

Rank pages / linear 
algebra

Collaborative 
Filtering
Netflix, 
Amazon…

Purchase/rating 
histories. hundreds 
of millions of users 
and items

user–item and 
item–item 
interaction 
matrices

Recomputed 
continuously

Matrix factorisation & 
item-item similarity 

Link Prediction 
in graphs
Linkedin

~1 billion member 
nodes
billions of 
connection edges

Graph structure 
plus profile, activity, 
and mutual-
connection signals

Recomputed 
continuously 

Heuristic/statistical 
link prediction 
(triangle-closing)

<!-- PDF 页 8 -->

Data analytics and machine learning

2. Predictive Analytics

Data → Model → Predictions

Supervised learning:

• Decision trees
• Random forests
• Support Vector Machines
• …

Unsupervised learning:

Training
set

Model
training 

New Data
instances

Model 

Predictions

Data points
In space

clustering

Natural data
aggregations

• K-means
• Topic modelling
• …
Ex. Anomaly detection in network traffic

Analysis of graph structures
Ex. Social media graphs
- people’s connections

Ex. Analysis of co-occurrences 
networks

User / item analysis
Ex. Product recommendations

Time series analysis
Ex. Current best routes → predicted best routes

8

<!-- PDF 页 9 -->

Big Data processing: technology

• Most examples above require similar underlying large-scale data processing capability

What sort of processing?

- Selecting and Ingesting: which data sources? Load into “data lakes” for efficient processing

- Cleaning: deduplication, missing data imputation, outlier detection

- Integrating joining, transforming

<!-- PDF 页 10 -->

Data Engineering + Data Science technology stack

-
-

Exploratory Data analytics
Predictive modelling

Machine Learning
Deep Learning
Visual analytics

Data wrangling 
Data Quality processes

Distributed data 
processing

Data acquisition and storage

NoSQL, Graph DBMS
Distributed File Systems
Data Lakes

People

Markets

Cities

Machines

Streaming data

Static data

<!-- PDF 页 11 -->

Big Data Architecture: Azure and Databricks

Source:
https://techcommunity.microsoft.com/t5/analytics-on-azure/how-to-reduce-infrastructure-costs-by-up-to-80-with-azure/ba-p/1820280
