# Data Warehouse, Data Lake, Lakehouse 知识库索引

来源：1. Datalake and lakehouse architecture_Lecture_Notes-1.pdf

- [第 1-12 页](units/u01-pages-001-012.md)
- [第 13-24 页](units/u02-pages-013-024.md)
- [第 25-27 页](units/u03-pages-025-027.md)