# 推荐器案例与项目结构

## Page-by-page Notes

### 第 14 页：The recommender, initially

Source ID: `src-b91e955ebdec-pdf_page-00014`

推荐系统一开始就要亮明能力边界、可靠性和用户模型位置。这样用户才知道推荐来自哪里，也知道它不会越权。

#### Concepts
- **User model / 用户模型**：系统保存的关于用户偏好、历史和推断的表示。

### 第 15 页：The recommender, during interaction

Source ID: `src-b91e955ebdec-pdf_page-00015`

推荐不是只给结果，还要让用户检查“为什么现在推荐这个”。时机、情境相关性和简短理由能增强可见性。

#### Concepts
- **Reason-giving / 给出理由**：用简短证据说明推荐为何出现，帮助用户挑战或校准系统推断。

### 第 16 页：The recommender, when wrong

Source ID: `src-b91e955ebdec-pdf_page-00016`

真正修复推荐错误要改原因，而不是只删结果。系统需要识别异常行为、暂停学习或让用户标记“不是我”。

#### Concepts
- **Cause-level correction / 原因层修正**：修正导致错误输出的用户模型或学习记录，而不是只隐藏表面结果。

### 第 17 页：Slide 16 comments

Source ID: `src-b91e955ebdec-pdf_page-00017`

这一页是课件批注，不是正式授课内容。它提醒我们：引用或编号如果不自明，会增加理解负担；更好的做法是把引用连接到概念。

#### Concepts
- **Review comment / 课件批注**：课件制作过程中的反馈，不应和正式课程主张混淆。

### 第 18 页：The recommender, over time: the fix

Source ID: `src-b91e955ebdec-pdf_page-00018`

这页给出推荐器长期学习的好设计：不要因为一天异常就改用户模型；要通知变化、显示证据，并提供全局控制。

#### Concepts
- **Guest session / 访客会话**：允许他人使用设备而不污染主用户模型的模式。

### 第 19 页：The project is a compact research paper

Source ID: `src-b91e955ebdec-pdf_page-00019`

项目不是单纯做 demo，而是小型研究：问题、文献、空白、贡献、原型和证据必须连起来。

#### Concepts
- **Research contribution / 研究贡献**：项目相对已有工作的新增价值，可以体现在问题、设计、实现或评估证据上。

### 第 20 页：Eleven weeks, three phases, one final exam

Source ID: `src-b91e955ebdec-pdf_page-00020`

这页是 assessment 结构。重要的是项目三阶段持续推进，Canvas quiz 用于练习，不计入成绩。

#### Concepts
- **Formative assessment / 形成性评估**：用于学习反馈但不计入最终成绩的练习。
