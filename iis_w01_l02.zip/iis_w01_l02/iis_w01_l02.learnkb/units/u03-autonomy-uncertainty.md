# 自主性、不确定性与恢复

## Page-by-page Notes

### 第 13 页：Intelligence can sit at any layer

Source ID: `src-a5decf9f86a2-pdf_page-00013`

智能不总在模型层。它可以在记忆、适应、规划、工具使用中出现。判断时先问：系统到底在哪里推断了什么？单纯自动适应不一定满足智能交互定义。

#### Concepts
- **Locate the inference / 定位推断**：分析系统时先找出哪一层在做不确定解释。
- **Adaptation alone / 单独适应**：系统改变行为但没有解释意图或任务，不一定构成智能交互。

### 第 14 页：One scale of autonomy

Source ID: `src-a5decf9f86a2-pdf_page-00014`

自主性不是越高越好。简单系统、agentic system、多智能体系统代表不同复杂度。课程给出的设计原则是：先选择足够简单的结构，只有当额外自治和协调真的带来收益时再升级。

#### Concepts
- **Agentic system / 智能体系统**：能观察、决策、调用工具、检查结果并继续推进目标的系统。
- **Multi-agent system / 多智能体系统**：多个智能体循环之间需要协调的系统。

### 第 15 页：The scanner at three points on the scale

Source ID: `src-a5decf9f86a2-pdf_page-00015`

这个例子说明多智能体不是高级默认答案。如果任务步骤强依赖、线性推进，把它拆成多个 agent 可能只增加交接和故障点。

#### Concepts
- **Smallest sufficient design / 最小充分设计**：能完成任务且复杂度最低的设计。
- **Hand-off cost / 交接成本**：多个循环之间传递状态和责任带来的额外复杂度。

### 第 16 页：What moves along the scale

Source ID: `src-a5decf9f86a2-pdf_page-00016`

自主性提升会把 L01 的四变量再次拉出来：主动权、推断上升，但可见性、可撤销性下降。设计者必须补上检查、日志、预览和恢复路径。

#### Concepts
- **Inspection work / 检查工作**：用户或开发者为了理解系统行为必须阅读轨迹、日志、状态或证据。
- **Recovery work / 恢复工作**：系统出错后恢复正确状态所需的步骤和成本。

### 第 17 页：Your turn: place three systems

Source ID: `src-a5decf9f86a2-pdf_page-00017`

这页是把自主性尺度应用到真实系统。重点是分类后还要问：更简单的设计是否足够？例如 C 看似多智能体，但也许一个 agent 加工具就够。

#### Concepts
- **Classification by autonomy / 按自主性分类**：根据系统是否单次推断、是否持续行动、是否协调多个循环来分类。

### 第 18 页：Every inference is a bet

Source ID: `src-a5decf9f86a2-pdf_page-00018`

系统输出经常看起来确定，但内部其实是在多个候选中选择。设计不能只展示最终答案，还要考虑置信度、备选、纠错入口和失败后的用户行动。

#### Concepts
- **Uncertainty / 不确定性**：推断不是确定事实，而是在多个可能解释中选择。
- **Candidate distribution / 候选分布**：模型对多个可能结果的相对支持程度。

### 第 19 页：Each layer's story for being wrong

Source ID: `src-a5decf9f86a2-pdf_page-00019`

这页把不确定性变成设计清单：不同层出错时，用户需要不同信息和控制。修复不是统一的“加解释”，而是要匹配层次。

#### Concepts
- **Confidence / 置信度**：系统对某个推断的把握程度。
- **Global controls / 全局控制**：用户控制系统长期学习、默认设置和记忆的总开关或管理界面。

### 第 20 页：Reliable, safe, trustworthy: where this goes

Source ID: `src-a5decf9f86a2-pdf_page-00020`

这页连接 Lecture 03。好的系统不是自动化越高越好，而是在可靠、安全、可信上有证据，并同时提高自动化与人的控制。

#### Concepts
- **Calibrated reliance / 校准后的依赖**：用户根据系统实际可靠性决定依赖程度，既不过度信任也不过度不用。
- **Human control / 人类控制**：用户监督、批准、纠正和撤销系统行为的能力。
