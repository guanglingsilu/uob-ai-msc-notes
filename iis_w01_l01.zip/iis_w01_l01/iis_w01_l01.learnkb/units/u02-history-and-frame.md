# 历史引入与四变量阅读框架

## Core Idea
本单元围绕以下页面建立学习路径：第 5 页、第 6 页、第 7 页、第 8 页。

## Page-by-page Learning Notes
### 第 5 页：Two conversations, fifty-nine years apart

- Source ID: `src-ba38b47b419c-pdf_page-00005`
- Core: 这一页用 ELIZA 和现代 coding assistant 做强对比。两者都是文本交互，但能力和风险完全不同：ELIZA 只是语言表面改写；现代助手能修改、运行、提交代码。课件想让你意识到：不能只看界面形式，要看系统行为后果。
- Extension: 交互分析中常犯错是“界面同形就风险同形”。实际设计要问：系统能否行动？行动范围多大？失败成本由谁承担？

#### Key Concepts
- **ELIZA**：1966 年 Weizenbaum 的早期聊天程序，使用关键词匹配和模板改写，常被用来说明人会把流畅回应误读为理解。
- **Surface similarity / 表面相似性**：界面看起来相似不代表交互后果相似。文本框可以承载完全不同的系统能力。
- **Consequential action / 有后果的行动**：系统行为会改变外部状态，例如修改代码、提交仓库或触发真实流程。

### 第 6 页：What changed for the person, each time?

- Source ID: `src-ba38b47b419c-pdf_page-00006`
- Core: 这一页是整门课的工具页。四个问题分别对应 initiative、inference、visibility、reversibility。它们把抽象的“智能程度”变成可以设计、评估和批判的交互变量。之后每个系统都可以用这四项打分。
- Extension: 这四个变量可直接用于论文阅读、项目选题和实验分析。写作时可以把它们当作统一小标题，比较不同智能系统。

#### Key Concepts
- **Initiative / 主动权**：谁先发起下一步互动，是人要求系统做事，还是系统主动打断、建议、补全或行动。
- **Inference / 推断**：系统从用户输入、环境、历史或他人行为中得出什么额外结论。
- **Visibility / 可见性**：用户能看见多少系统状态、理由、证据或置信度。
- **Reversibility / 可撤销性**：系统造成的结果能否撤销，以及撤销成本有多高。

### 第 7 页：The idea most of us arrive with

- Source ID: `src-ba38b47b419c-pdf_page-00007`
- Core: 这一页解释为什么课程从历史开始：如果只从 ChatGPT 的聊天界面出发，我们会把 AI 误定义为“会聊天的盒子”。但智能交互已经存在于键盘建议、地图、搜索排序、视觉识别、手势输入等大量非聊天场景中。
- Extension: 项目选题不要局限于 chatbot。推荐、搜索、自动字幕、相机识别、智能家居、医疗分诊、代码补全都可以是 IIS 主题。

#### Key Concepts
- **Chat box bias / 聊天框偏见**：把 AI 误认为主要是问答聊天，从而忽视嵌入式、预测式、感知式智能。
- **Embedded intelligence / 嵌入式智能**：智能功能嵌入在普通界面流程中，不一定以对话形式出现。
- **Text completion / 文本补全**：系统根据上下文预测接下来可能输入的文本，是常见的非聊天智能交互。

### 第 8 页：Five capability shifts, 1950 to today

- Source ID: `src-ba38b47b419c-pdf_page-00008`
- Core: 这一页预告后面五个 shift。重要的是边界是 interpretive：不是自然界固定分期，而是为了帮助我们看清交互变化而做的解释框架。读每一段技术史时，都要把注意力放回“对用户改变了什么”。
- Extension: 论文写作中可以借用这种方式：不要只列技术发展，而要解释每个发展如何改变用户任务、责任、风险或信任。

#### Key Concepts
- **Capability shift / 能力迁移**：机器获得新能力后，互动结构发生变化的历史节点。
- **Interpretive boundary / 解释性边界**：分期边界是为了分析而划定，不是客观世界中绝对存在的线。
- **User-centered historical reading / 以用户为中心的历史阅读**：读技术史时关注技术让人能做什么、看见什么、撤销什么。
