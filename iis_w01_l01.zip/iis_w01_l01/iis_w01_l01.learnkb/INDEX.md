# IIS Week 1 Lecture 1 知识库索引

来源材料：W01_L01_From_Calculators_to_Copilots_A_History_of_Intelligent_Interaction_v5_novideo.pdf

本知识库由 learn-from-materials 抽取结果和逐页人工审校笔记生成。每一页均保留原文、完整中文翻译、概念释义、拓展说明与自测题。

## 单元
- [智能定义与目标导向导航](units/u01-framing-intelligence.md)：PDF 页 1-4
- [历史引入与四变量阅读框架](units/u02-history-and-frame.md)：PDF 页 5-8
- [五次能力迁移](units/u03-five-capability-shifts.md)：PDF 页 9-15
- [三类日常智能系统练习](units/u04-everyday-systems.md)：PDF 页 16-20
- [ELIZA 效应、设计问题与心理模型](units/u05-psychology-and-reframing.md)：PDF 页 21-23
- [模块地图、项目连接与综合](units/u06-module-project-synthesis.md)：PDF 页 24-27