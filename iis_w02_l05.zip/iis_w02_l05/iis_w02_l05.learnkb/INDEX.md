# Memory, Mental Models and Cognitive Load 知识库索引

来源材料：W02_L05_Memory_Mental_Models_and_Cognitive_Load.pdf

- [第 1-6 页](units/u01-pages-01-06.md)
- [第 7-12 页](units/u02-pages-07-12.md)
- [第 13-18 页](units/u03-pages-13-18.md)
- [第 19-24 页](units/u04-pages-19-24.md)