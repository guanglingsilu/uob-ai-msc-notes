# Perception, Attention and Feedback

逐页完整翻译与复习笔记。

## 第 1 页：Perception, Attention and Feedback

Source ID: `src-760c4a1613ea-pdf_page-00001`

![PDF page 1](../assets/pages/page_001.png)

### 原文
```text
Perception, Attention and 
Feedback

Intelligent Interactive Systems  ·  Week 2  ·  Lecture 04
University of Birmingham

Feedback works only when a person can notice and 
interpret it.

• We will examine how perception and attention shape what 

people notice when an intelligent system communicates.

• We will use signal detection, cue integration and feedback 

timing to choose a cue, a channel and a response.

Course-own diagram. Five cues competing for one 
person.
```

### 完整中文翻译
感知、注意力与反馈。

智能交互系统 - 第 2 周 - 第 4 讲。伯明翰大学。

只有当人能够注意到并解释反馈时，反馈才真正起作用。

- 我们会考察感知和注意力如何塑造人在智能系统沟通时会注意到什么。
- 我们会使用信号检测、线索整合和反馈时机来选择线索、通道和回应。

课程自绘图：五个线索竞争同一个人的注意。

### 中文释义
本讲把“系统给了反馈”拆成“人是否注意到、是否能解释、是否及时收到”。智能系统沟通不是把消息放到界面上就结束，而要匹配人的任务、感官通道和注意资源。

### English Explanation
This lecture asks whether feedback actually reaches and can be interpreted by a person who is already doing something.

### 概念解析
- **Feedback / 反馈**：系统向用户传达状态、结果或确认的信号；只有被注意并解释后才有效。

### 自测问题
**Q1 中文：** 第 1 页的核心复习点是什么？
**答：** 本讲把“系统给了反馈”拆成“人是否注意到、是否能解释、是否及时收到”。智能系统沟通不是把消息放到界面上就结束，而要匹配人的任务、感官通道和注意资源。
**Q1 English:** What is the key revision point on page 1?
**Answer:** This lecture asks whether feedback actually reaches and can be interpreted by a person who is already doing something.

**Q2 中文：** 解释本页概念：Feedback / 反馈
**答：** 系统向用户传达状态、结果或确认的信号；只有被注意并解释后才有效。
**Q2 English:** Explain this concept: Feedback / 反馈
**Answer:** 系统向用户传达状态、结果或确认的信号；只有被注意并解释后才有效。

## 第 2 页：Watch the video

Source ID: `src-760c4a1613ea-pdf_page-00002`

![PDF page 2](../assets/pages/page_002.png)

### 原文
```text
Watch the video.

Follow the counting task while you watch.

• Count the passes made by 

the team in white.

• Keep your answer to yourself until the video 
ends, then follow the lecturer’s discussion.
```

### 完整中文翻译
观看视频。

观看时跟随计数任务。

- 计算白衣队伍传球的次数。
- 在视频结束前先不要说出答案，然后跟随讲师讨论。

### 中文释义
这一页设置了经典注意力实验。任务要求你专注于计数，为后面解释“可见事件也可能被错过”做铺垫。

### English Explanation
The video primes students for inattentional blindness by giving them a counting task that consumes attention.

### 概念解析
- **Counting task / 计数任务**：用一个明确目标占用注意力，从而显示未被关注事件如何被漏看。

### 自测问题
**Q1 中文：** 第 2 页的核心复习点是什么？
**答：** 这一页设置了经典注意力实验。任务要求你专注于计数，为后面解释“可见事件也可能被错过”做铺垫。
**Q1 English:** What is the key revision point on page 2?
**Answer:** The video primes students for inattentional blindness by giving them a counting task that consumes attention.

**Q2 中文：** 解释本页概念：Counting task / 计数任务
**答：** 用一个明确目标占用注意力，从而显示未被关注事件如何被漏看。
**Q2 English:** Explain this concept: Counting task / 计数任务
**Answer:** 用一个明确目标占用注意力，从而显示未被关注事件如何被漏看。

## 第 3 页：Count the passes

Source ID: `src-760c4a1613ea-pdf_page-00003`

![PDF page 3](../assets/pages/page_003.png)

### 原文
```text
Count the passes

Lecture 04 · Hook

A visible event can be missed when 
attention is elsewhere.

• In Simons and Chabris (1999), observers 
counted passes while an unexpected event 
occurred. Roughly half missed it across the 
study’s conditions.

• This is sustained inattentional blindness: an 
unexpected, visible event can escape notice 
during another task.

• For Interaction 1, predict what fraction of drivers 
notice a dashboard icon at a busy junction. Write 
a number; revisit it in five minutes.

After Simons and Chabris (1999). Original film frame retained: ©1999 Daniel J. Simons; adjacent 
schematic is course-created.
```

### 完整中文翻译
数传球次数。

第 4 讲 - 引入。

当注意力在别处时，一个可见事件也可能被错过。

- 在 Simons 和 Chabris（1999）中，观察者一边数传球，一边发生意外事件。研究多个条件下大约一半人错过了它。
- 这就是持续性非注意盲视：在执行另一个任务时，一个意外且可见的事件可能逃过注意。
- 互动 1：预测司机在繁忙路口注意到仪表盘图标的比例。写下一个数字，五分钟后再回看。

根据 Simons 和 Chabris（1999）。原始影片帧保留版权；旁边示意图为课程自制。

### 中文释义
关键概念是 inattentional blindness：看见不等于注意到。对设计来说，静态图标或颜色变化即使“在屏幕上”，也可能在高负荷任务中完全失败。

### English Explanation
A visible event can still be missed when attention is committed elsewhere; this creates a design risk for passive cues.

### 概念解析
- **Inattentional blindness / 非注意盲视**：人在专注于一个任务时，可能漏掉明显可见但未被期待的事件。

### 自测问题
**Q1 中文：** 第 3 页的核心复习点是什么？
**答：** 关键概念是 inattentional blindness：看见不等于注意到。对设计来说，静态图标或颜色变化即使“在屏幕上”，也可能在高负荷任务中完全失败。
**Q1 English:** What is the key revision point on page 3?
**Answer:** A visible event can still be missed when attention is committed elsewhere; this creates a design risk for passive cues.

**Q2 中文：** 解释本页概念：Inattentional blindness / 非注意盲视
**答：** 人在专注于一个任务时，可能漏掉明显可见但未被期待的事件。
**Q2 English:** Explain this concept: Inattentional blindness / 非注意盲视
**Answer:** 人在专注于一个任务时，可能漏掉明显可见但未被期待的事件。

## 第 4 页：The feedback arrow, taken seriously

Source ID: `src-760c4a1613ea-pdf_page-00004`

![PDF page 4](../assets/pages/page_004.png)

### 原文
```text
The feedback arrow, taken seriously

Lecture 04 · Central question

The feedback arrow must reach a person who is already doing something.

• Lecture 02’s feedback arrow connects a 

system’s message to a person. Today we ask 
what makes that message arrive.

• Ask whether the cue will be noticed, compete 

with the task, or be wrong, and how it combines 
with other senses.

• Then ask how quickly and precisely people can 

perceive it, and when and how to acknowledge
their actions.

Course-own diagram. The reduced loop and the six questions the lecture answers.
```

### 完整中文翻译
认真对待反馈箭头。

第 4 讲 - 中心问题。

反馈箭头必须到达一个已经在做事的人。

- 第 2 讲的反馈箭头把系统消息连接到人。今天我们问：什么让这条消息真正抵达？
- 问这个线索是否会被注意到、是否与当前任务竞争、是否可能错误，以及它如何与其他感官结合。
- 然后问人能多快、多精确地感知它，以及何时、如何确认人的行动。

课程自绘图：简化循环和本讲回答的六个问题。

### 中文释义
这页给出本讲总问题：反馈不是一条抽象箭头，而要穿过注意、竞争、不确定性、感官整合、速度和确认机制。

### English Explanation
The central question is what makes a system message arrive, compete appropriately, and support action acknowledgement.

### 概念解析
- **Feedback arrow / 反馈箭头**：从系统消息到人的感知和解释之间的设计路径。

### 自测问题
**Q1 中文：** 第 4 页的核心复习点是什么？
**答：** 这页给出本讲总问题：反馈不是一条抽象箭头，而要穿过注意、竞争、不确定性、感官整合、速度和确认机制。
**Q1 English:** What is the key revision point on page 4?
**Answer:** The central question is what makes a system message arrive, compete appropriately, and support action acknowledgement.

**Q2 中文：** 解释本页概念：Feedback arrow / 反馈箭头
**答：** 从系统消息到人的感知和解释之间的设计路径。
**Q2 English:** Explain this concept: Feedback arrow / 反馈箭头
**Answer:** 从系统消息到人的感知和解释之间的设计路径。

## 第 5 页：Selective attention: one narrow channel

Source ID: `src-760c4a1613ea-pdf_page-00005`

![PDF page 5](../assets/pages/page_005.png)

### 原文
```text
Selective attention: one narrow channel

Lecture 04 · Attention

Selective attention limits which inputs receive sustained processing.

• Selective attention means prioritising some 
inputs over others. Broadbent’s filter model 
(1958) pictured many inputs competing for a 
narrow processing channel.

• Later work revised that model: some unattended 
information can still be processed, so the filter is 
a teaching simplification.

• For design, ask whether a cue reaches the 

person’s current attention or captures it at an 
acceptable disruption cost.

Course-own diagram after Broadbent (1958).
```

### 完整中文翻译
选择性注意：一条狭窄通道。

第 4 讲 - 注意力。

选择性注意限制哪些输入能得到持续处理。

- 选择性注意意味着优先处理某些输入而不是另一些。Broadbent 的过滤模型（1958）把许多输入想象成竞争一条狭窄处理通道。
- 后续研究修正了该模型：一些未被注意的信息仍然能被处理，因此过滤器只是教学简化。
- 对设计来说，要问线索是否到达人的当前注意，或者是否以可接受的打断成本捕获注意。

课程自绘图，基于 Broadbent（1958）。

### 中文释义
选择性注意告诉我们：人的处理能力有限，线索必须进入注意通道。强行捕获注意可能有效，但代价是打断当前任务。

### English Explanation
Selective attention limits sustained processing, so designers must decide whether a cue fits current attention or justifiably interrupts it.

### 概念解析
- **Selective attention / 选择性注意**：人在多个输入中优先处理某些输入的机制。

### 自测问题
**Q1 中文：** 第 5 页的核心复习点是什么？
**答：** 选择性注意告诉我们：人的处理能力有限，线索必须进入注意通道。强行捕获注意可能有效，但代价是打断当前任务。
**Q1 English:** What is the key revision point on page 5?
**Answer:** Selective attention limits sustained processing, so designers must decide whether a cue fits current attention or justifiably interrupts it.

**Q2 中文：** 解释本页概念：Selective attention / 选择性注意
**答：** 人在多个输入中优先处理某些输入的机制。
**Q2 English:** Explain this concept: Selective attention / 选择性注意
**Answer:** 人在多个输入中优先处理某些输入的机制。

## 第 6 页：Inattentional blindness as a design problem

Source ID: `src-760c4a1613ea-pdf_page-00006`

![PDF page 6](../assets/pages/page_006.png)

### 原文
```text
Inattentional blindness as a design problem

Lecture 04 · Attention

Design for the person’s current task, not visibility alone.

• Inattentional blindness helps explain why a 
static dashboard icon or peripheral colour 
change can be missed during demanding work.

• Abrupt onset, motion, changes in the attended 

channel, and meaningful cues can attract 
attention, but they also interrupt the task.

• Revisit your prediction: a sound may also 

compete with speech. Treat the icon as a design 
risk, not a measured detection rate.

Course-own table. The prediction from the hook, revisited.
```

### 完整中文翻译
非注意盲视作为设计问题。

第 4 讲 - 注意力。

要为人的当前任务设计，而不是只为可见性设计。

- 非注意盲视帮助解释为什么静态仪表盘图标或外围颜色变化会在高要求工作中被错过。
- 突然出现、运动、被关注通道中的变化和有意义线索能吸引注意，但它们也会打断任务。
- 回看你的预测：声音也可能与语音竞争。把这个图标当作设计风险，而不是已经测量出的检测率。

课程自制表格：回到引入中的预测。

### 中文释义
这页把心理学实验转成设计判断：线索是否会被注意取决于任务环境。设计师要权衡注意捕获与打断成本。

### English Explanation
Visibility alone is not enough. A cue must be designed for the person's current task and disruption tolerance.

### 概念解析
- **Disruption cost / 打断成本**：线索捕获注意时对当前任务造成的干扰。

### 自测问题
**Q1 中文：** 第 6 页的核心复习点是什么？
**答：** 这页把心理学实验转成设计判断：线索是否会被注意取决于任务环境。设计师要权衡注意捕获与打断成本。
**Q1 English:** What is the key revision point on page 6?
**Answer:** Visibility alone is not enough. A cue must be designed for the person's current task and disruption tolerance.

**Q2 中文：** 解释本页概念：Disruption cost / 打断成本
**答：** 线索捕获注意时对当前任务造成的干扰。
**Q2 English:** Explain this concept: Disruption cost / 打断成本
**Answer:** 线索捕获注意时对当前任务造成的干扰。

## 第 7 页：Multiple resources: use a free channel

Source ID: `src-760c4a1613ea-pdf_page-00007`

![PDF page 7](../assets/pages/page_007.png)

### 原文
```text
Multiple resources: use a free channel

Lecture 04 · Attention

Tasks interfere less when they draw on different resources.

• Multiple-resource theory distinguishes 

modality, code and processing stage (Wickens, 
2002). In plain terms, tasks can compete for 
different kinds of attention.

• Driving and a dashboard map both demand 

visual and spatial resources. Spoken 
directions use auditory and verbal resources, 
which can reduce interference.

• A different channel still has a cost: typing code 
and hearing speech can compete for verbal 
resources.

After Wickens (2002); simplified teaching model. Current links: sensing Week 7, XR Weeks 8–9.
```

### 完整中文翻译
多资源理论：使用空闲通道。

第 4 讲 - 注意力。

当任务使用不同资源时，干扰较少。

- 多资源理论区分模态、编码和处理阶段（Wickens，2002）。通俗地说，任务会竞争不同类型的注意力。
- 驾驶和仪表盘地图都要求视觉和空间资源。语音导航使用听觉和语言资源，因此能减少干扰。
- 不同通道仍有成本：写代码和听语音可能都会竞争语言资源。

根据 Wickens（2002）的简化教学模型。

### 中文释义
如果当前任务占用视觉空间资源，就不要再用视觉地图塞给用户；可以考虑听觉语言。但通道不同不等于零成本。

### English Explanation
Multiple-resource theory helps choose a less competing channel, while reminding us that every channel still has costs.

### 概念解析
- **Multiple-resource theory / 多资源理论**：不同任务会占用不同模态、编码和处理阶段资源；资源重叠越多，干扰越大。

### 自测问题
**Q1 中文：** 第 7 页的核心复习点是什么？
**答：** 如果当前任务占用视觉空间资源，就不要再用视觉地图塞给用户；可以考虑听觉语言。但通道不同不等于零成本。
**Q1 English:** What is the key revision point on page 7?
**Answer:** Multiple-resource theory helps choose a less competing channel, while reminding us that every channel still has costs.

**Q2 中文：** 解释本页概念：Multiple-resource theory / 多资源理论
**答：** 不同任务会占用不同模态、编码和处理阶段资源；资源重叠越多，干扰越大。
**Q2 English:** Explain this concept: Multiple-resource theory / 多资源理论
**Answer:** 不同任务会占用不同模态、编码和处理阶段资源；资源重叠越多，干扰越大。

## 第 8 页：Three perceptual limits every system runs into

Source ID: `src-760c4a1613ea-pdf_page-00008`

![PDF page 8](../assets/pages/page_008.png)

### 原文
```text
Three perceptual limits every system runs into

Lecture 04 · Perceptual limits

Perceptual limits create concrete constraints for interface design.

• Latency is the delay between an action and its 
visible effect. Short delays matter especially in 
head-mounted displays (LaValle, 2017).

• Resolution falls away from the fovea, the small 
region of sharp central vision. Fine detail and 
subtle colour differences are harder to see 
peripherally.

• Change blindness means missing a change 

across a visual disruption, as the flicker paradigm 
demonstrates (Rensink, O’Regan and Clark, 
1997).

LaValle (2017), chapters 5–6; Rensink, O’Regan and Clark (1997). Current XR teaching is Week 8; the 
original image says Week 7.
```

### 完整中文翻译
每个系统都会遇到的三种感知限制。

第 4 讲 - 感知限制。

感知限制为界面设计创造具体约束。

- 延迟是动作和可见效果之间的间隔。短延迟在头戴显示器中特别重要（LaValle，2017）。
- 分辨率会从中央凹向外下降；中央凹是清晰中央视觉的小区域。细节和微妙颜色差异在周边更难看见。
- 变化盲视意味着人在视觉中断期间漏掉变化，flicker paradigm 展示了这一点（Rensink、O'Regan 和 Clark，1997）。

### 中文释义
三条设计约束：反馈要快；细节要放在用户看得到的地方；变化不能只靠用户自己发现。XR 和智能界面尤其受延迟影响。

### English Explanation
Latency, foveal resolution, and change blindness create concrete constraints for feedback and interface design.

### 概念解析
- **Latency / 延迟**：用户动作和系统反馈之间的时间差。
- **Change blindness / 变化盲视**：人在视觉中断或注意不足时漏掉变化。

### 自测问题
**Q1 中文：** 第 8 页的核心复习点是什么？
**答：** 三条设计约束：反馈要快；细节要放在用户看得到的地方；变化不能只靠用户自己发现。XR 和智能界面尤其受延迟影响。
**Q1 English:** What is the key revision point on page 8?
**Answer:** Latency, foveal resolution, and change blindness create concrete constraints for feedback and interface design.

**Q2 中文：** 解释本页概念：Latency / 延迟
**答：** 用户动作和系统反馈之间的时间差。
**Q2 English:** Explain this concept: Latency / 延迟
**Answer:** 用户动作和系统反馈之间的时间差。

## 第 9 页：Change blindness

Source ID: `src-760c4a1613ea-pdf_page-00009`

![PDF page 9](../assets/pages/page_009.png)

### 原文
```text
Change blindness

Watch the room closely for anything that changes.

• List each change you spot; 

• Afterwards, what you missed is change 

keep it to yourself.

blindness (Rensink et al., 1997).
```

### 完整中文翻译
变化盲视。

仔细观察房间，看有什么发生变化。

- 列出你发现的每一个变化；
- 先不要说出来。

之后，你漏掉的内容就是变化盲视（Rensink 等，1997）。

### 中文释义
这是课堂活动页，用来让学生亲身体验变化盲视。设计含义是：如果系统状态变化很重要，就不要只依赖细微视觉变化。

### English Explanation
This activity makes change blindness experiential: students list noticed changes and then compare with what they missed.

### 概念解析
- **Flicker paradigm / 闪烁范式**：通过视觉中断展示人对变化的感知依赖注意力。

### 自测问题
**Q1 中文：** 第 9 页的核心复习点是什么？
**答：** 这是课堂活动页，用来让学生亲身体验变化盲视。设计含义是：如果系统状态变化很重要，就不要只依赖细微视觉变化。
**Q1 English:** What is the key revision point on page 9?
**Answer:** This activity makes change blindness experiential: students list noticed changes and then compare with what they missed.

**Q2 中文：** 解释本页概念：Flicker paradigm / 闪烁范式
**答：** 通过视觉中断展示人对变化的感知依赖注意力。
**Q2 English:** Explain this concept: Flicker paradigm / 闪烁范式
**Answer:** 通过视觉中断展示人对变化的感知依赖注意力。

## 第 10 页：Signal detection: four outcomes, two quantities

Source ID: `src-760c4a1613ea-pdf_page-00010`

![PDF page 10](../assets/pages/page_010.png)

### 原文
```text
Signal detection: four outcomes, two quantities

Lecture 04 · Signal detection

Separate the quality of the evidence from the decision to warn.

• Signal detection theory distinguishes hit, miss, 
false alarm and correct rejection: compare the 
warning decision with whether a hazard exists 
(Green and Swets, 1966).

• Sensitivity (d′) describes how well the evidence 
separates hazard from no hazard. Sensor and 
model performance can affect that separation.

• The criterion is the decision threshold. With 

sensitivity fixed, moving it trades misses against 
false alarms rather than reducing both.

Course-own diagram after Green and Swets (1966).
```

### 完整中文翻译
信号检测：四种结果，两个量。

第 4 讲 - 信号检测。

把证据质量和是否发出警告的决定分开。

- 信号检测理论区分命中、漏报、误报和正确拒绝：把警告决策与危险是否真实存在进行比较（Green 和 Swets，1966）。
- 敏感度 d' 描述证据区分危险与非危险的能力。传感器和模型性能会影响这种分离。
- 判据是决策阈值。在敏感度固定时，移动阈值是在漏报与误报之间权衡，而不是同时减少二者。

课程自绘图，基于 Green 和 Swets（1966）。

### 中文释义
这一页非常重要：模型证据质量和报警阈值是两件事。调低阈值可以减少漏报，但会增加误报；不是免费提升。

### English Explanation
Signal detection separates evidence quality from warning criterion, making error trade-offs explicit.

### 概念解析
- **Signal detection theory / 信号检测理论**：分析系统在信号存在/不存在时做出警告/不警告决定的框架。
- **Criterion / 判据**：决定证据是否足够触发警告的阈值。

### 自测问题
**Q1 中文：** 第 10 页的核心复习点是什么？
**答：** 这一页非常重要：模型证据质量和报警阈值是两件事。调低阈值可以减少漏报，但会增加误报；不是免费提升。
**Q1 English:** What is the key revision point on page 10?
**Answer:** Signal detection separates evidence quality from warning criterion, making error trade-offs explicit.

**Q2 中文：** 解释本页概念：Signal detection theory / 信号检测理论
**答：** 分析系统在信号存在/不存在时做出警告/不警告决定的框架。
**Q2 English:** Explain this concept: Signal detection theory / 信号检测理论
**Answer:** 分析系统在信号存在/不存在时做出警告/不警告决定的框架。

## 第 11 页：The same evidence, two criteria

Source ID: `src-760c4a1613ea-pdf_page-00011`

![PDF page 11](../assets/pages/page_011.png)

### 原文
```text
The same evidence, two criteria

Lecture 04 · Signal detection

Changing the criterion changes the errors, not the underlying evidence.

• The same overlapping hazard and no-hazard 

distributions appear in both panels. Their shape 
is illustrative, not measured.

• A cautious criterion gives fewer false alarms 

but more misses. An eager criterion gives fewer 
misses but more false alarms.

• Improving the sensor or model can improve 
sensitivity. Moving the decision line alone 
cannot separate the distributions.

Course-own schematic; the curves are illustrative, not measured.
```

### 完整中文翻译
同样的证据，两种判据。

第 4 讲 - 信号检测。

改变判据会改变错误，而不是改变底层证据。

- 两个图中都有相同的危险和非危险重叠分布。形状是示意，不是实测。
- 谨慎判据会产生更少误报但更多漏报。积极判据会产生更少漏报但更多误报。
- 改善传感器或模型能改善敏感度。只移动决策线不能把分布分开。

课程自绘示意图；曲线为示意，不是实测。

### 中文释义
这页防止一个常见误解：阈值调节不能让模型更懂世界，只能改变错误类型。真正提高证据质量要改善传感器或模型。

### English Explanation
Moving the criterion changes the balance of misses and false alarms; improving sensitivity requires better evidence.

### 概念解析
- **Sensitivity / 敏感度**：证据区分有危险与无危险的能力。

### 自测问题
**Q1 中文：** 第 11 页的核心复习点是什么？
**答：** 这页防止一个常见误解：阈值调节不能让模型更懂世界，只能改变错误类型。真正提高证据质量要改善传感器或模型。
**Q1 English:** What is the key revision point on page 11?
**Answer:** Moving the criterion changes the balance of misses and false alarms; improving sensitivity requires better evidence.

**Q2 中文：** 解释本页概念：Sensitivity / 敏感度
**答：** 证据区分有危险与无危险的能力。
**Q2 English:** Explain this concept: Sensitivity / 敏感度
**Answer:** 证据区分有危险与无危险的能力。

## 第 12 页：A collision warning at three criteria

Source ID: `src-760c4a1613ea-pdf_page-00012`

![PDF page 12](../assets/pages/page_012.png)

### 原文
```text
A collision warning at three criteria

Lecture 04 · Worked example

A higher hit rate can bring a costly increase in false alarms.

• These invented teaching numbers use the 

same sensor at cautious, balanced and eager 
criteria. They are not observations of a real 
warning system.

• Moving from cautious to eager gains 18 hits per 
100 hazards while false alarms rise from 2 to 60 
per 100 driving hours, a thirtyfold increase.

• Judge both error costs: frequent false alarms can 
make drivers less willing to respond, reducing the 
warning’s practical benefit.

Invented teaching data; the behavioural interpretations are hypotheses, not measured outcomes.
```

### 完整中文翻译
三个判据下的碰撞警告。

第 4 讲 - worked example。

更高命中率可能带来代价高昂的误报增加。

- 这些虚构教学数字使用同一个传感器，在谨慎、平衡和积极三个判据下比较。它们不是实际警告系统观测数据。
- 从谨慎到积极，每 100 个危险多得到 18 次命中，但误报从每 100 小时驾驶 2 次上升到 60 次，增加 30 倍。
- 要同时判断两种错误成本：频繁误报会降低司机响应意愿，从而减少警告的实际收益。

虚构教学数据；行为解释是假设，不是实测结果。

### 中文释义
碰撞警告不能只追求 hit rate。误报过多会使用户习惯性忽略警告，最终损害系统有效性。

### English Explanation
Higher hit rates can come with many more false alarms, which may reduce practical benefit by changing user response.

### 概念解析
- **False alarm cost / 误报成本**：不该警告时警告造成的打扰、信任下降或行为疲劳。

### 自测问题
**Q1 中文：** 第 12 页的核心复习点是什么？
**答：** 碰撞警告不能只追求 hit rate。误报过多会使用户习惯性忽略警告，最终损害系统有效性。
**Q1 English:** What is the key revision point on page 12?
**Answer:** Higher hit rates can come with many more false alarms, which may reduce practical benefit by changing user response.

**Q2 中文：** 解释本页概念：False alarm cost / 误报成本
**答：** 不该警告时警告造成的打扰、信任下降或行为疲劳。
**Q2 English:** Explain this concept: False alarm cost / 误报成本
**Answer:** 不该警告时警告造成的打扰、信任下降或行为疲劳。

## 第 13 页：Cry wolf: what false alarms do over time

Source ID: `src-760c4a1613ea-pdf_page-00013`

![PDF page 13](../assets/pages/page_013.png)

### 原文
```text
Cry wolf: what false alarms do over time

Lecture 04 · Worked example

Repeated false alarms can weaken responses to later warnings.

• The cry-wolf effect describes reduced 

responsiveness when alarms prove unreliable 
(Breznitz, 1984). People learn what a warning is 
worth attending to.

• The two curves show a qualitative tendency, 
not measured data or a guaranteed decrease 
after every false alarm.

• Evaluate the system’s hit rate alongside 

people’s responses over time. A false alarm 
can affect the usefulness of future warnings.

After Breznitz (1984). Qualitative schematic, not data or a deterministic response law.
```

### 完整中文翻译
狼来了：误报随时间造成什么。

第 4 讲 - worked example。

重复误报会削弱人们对后续警告的反应。

- cry-wolf effect 描述当警报被证明不可靠时，人们响应性下降（Breznitz，1984）。人会学习一个警告值不值得注意。
- 两条曲线显示定性趋势，不是实测数据，也不是每次误报后必然下降的规律。
- 评估系统时，要把命中率和人随时间的反应一起看。一次误报会影响未来警告的有用性。

根据 Breznitz（1984）。定性示意图，不是数据或确定性反应规律。

### 中文释义
误报是长期交互问题，不只是一次错误。它会改变用户对未来警告的信任和响应。

### English Explanation
False alarms can train people to ignore later warnings, so evaluation must include responses over time.

### 概念解析
- **Cry-wolf effect / 狼来了效应**：警报频繁不可靠后，用户对后续警报响应降低。

### 自测问题
**Q1 中文：** 第 13 页的核心复习点是什么？
**答：** 误报是长期交互问题，不只是一次错误。它会改变用户对未来警告的信任和响应。
**Q1 English:** What is the key revision point on page 13?
**Answer:** False alarms can train people to ignore later warnings, so evaluation must include responses over time.

**Q2 中文：** 解释本页概念：Cry-wolf effect / 狼来了效应
**答：** 警报频繁不可靠后，用户对后续警报响应降低。
**Q2 English:** Explain this concept: Cry-wolf effect / 狼来了效应
**Answer:** 警报频繁不可靠后，用户对后续警报响应降低。

## 第 14 页：Every threshold is a criterion

Source ID: `src-760c4a1613ea-pdf_page-00014`

![PDF page 14](../assets/pages/page_014.png)

### 原文
```text
Every threshold is a criterion

Lecture 04 · Application

A threshold makes a decision whose errors have human costs.

• Wake words, classifier confidence cut-offs 
and retrieval scores all determine whether 
evidence is sufficient for a response.

• Planning/action adds act, ask or wait; feedback
adds warn or stay quiet. Define the event being 
detected before naming a miss or false alarm.

• For each threshold, distinguish sensitivity from 
criterion and explain whose costs justify the 
setting, as you will in sensing and evaluation.

Course applications: define the detected event before classifying errors. Current links: sensing Week 7; 
evaluation Week 10.
```

### 完整中文翻译
每个阈值都是一个判据。

第 4 讲 - 应用。

阈值会做出决策，而这些错误具有人的成本。

- 唤醒词、分类器置信度截断和检索分数都决定证据是否足以触发回应。
- 规划/行动层加入行动、询问或等待；反馈层加入警告或保持安静。在命名漏报或误报前，先定义被检测的事件。
- 对每个阈值，都要区分敏感度和判据，并解释谁的成本证明这个设置合理。

### 中文释义
阈值不只是技术参数，而是人机互动决策。必须先定义要检测什么，再讨论 miss/false alarm，并说明成本由谁承担。

### English Explanation
Every threshold is a criterion with human costs, whether in wake words, classifiers, retrieval, planning, or feedback.

### 概念解析
- **Threshold / 阈值**：系统把连续证据转化为行动或不行动的决策边界。

### 自测问题
**Q1 中文：** 第 14 页的核心复习点是什么？
**答：** 阈值不只是技术参数，而是人机互动决策。必须先定义要检测什么，再讨论 miss/false alarm，并说明成本由谁承担。
**Q1 English:** What is the key revision point on page 14?
**Answer:** Every threshold is a criterion with human costs, whether in wake words, classifiers, retrieval, planning, or feedback.

**Q2 中文：** 解释本页概念：Threshold / 阈值
**答：** 系统把连续证据转化为行动或不行动的决策边界。
**Q2 English:** Explain this concept: Threshold / 阈值
**Answer:** 系统把连续证据转化为行动或不行动的决策边界。

## 第 15 页：Your turn: set the criterion for three systems

Source ID: `src-760c4a1613ea-pdf_page-00015`

![PDF page 15](../assets/pages/page_015.png)

### 原文
```text
Your turn: set the criterion for three systems

Lecture 04 · Interaction 2

Set each criterion by comparing the cost of both errors.

• For A, a smoke alarm in a student kitchen, 

compare a missed fire with nuisance alarms and 
their consequences.

• For B, a spelling suggestion, compare an 

unnoticed typo with an unnecessary underline. 
For C, consider an agent asking ‘are you sure?’
before a risky email.

• Take two minutes to place A, B and C on the 

cautious-to-eager scale. Write one sentence per 
system justifying the two costs.

Course-own worksheet.
```

### 完整中文翻译
轮到你：为三个系统设置判据。

第 4 讲 - 互动 2。

通过比较两种错误成本来设置每个判据。

- A 是学生厨房里的烟雾报警器，比较漏掉火灾与烦人警报及其后果。
- B 是拼写建议，比较未被注意的拼写错误与不必要下划线。C 是智能体在发送高风险邮件前询问“你确定吗？”。
- 用两分钟把 A、B、C 放到谨慎到积极的尺度上。每个系统写一句话解释两种成本。

课程自制 worksheet。

### 中文释义
练习要求你把 criterion 变成设计论证。不同系统错误成本不同，所以阈值也应该不同。

### English Explanation
The activity asks students to justify criteria by comparing the cost of misses and false alarms.

### 概念解析
- **Cost-based criterion setting / 基于成本的判据设置**：根据漏报和误报的相对代价选择阈值。

### 自测问题
**Q1 中文：** 第 15 页的核心复习点是什么？
**答：** 练习要求你把 criterion 变成设计论证。不同系统错误成本不同，所以阈值也应该不同。
**Q1 English:** What is the key revision point on page 15?
**Answer:** The activity asks students to justify criteria by comparing the cost of misses and false alarms.

**Q2 中文：** 解释本页概念：Cost-based criterion setting / 基于成本的判据设置
**答：** 根据漏报和误报的相对代价选择阈值。
**Q2 English:** Explain this concept: Cost-based criterion setting / 基于成本的判据设置
**Answer:** 根据漏报和误报的相对代价选择阈值。

## 第 16 页：Cue integration: weighting by reliability

Source ID: `src-760c4a1613ea-pdf_page-00016`

![PDF page 16](../assets/pages/page_016.png)

### 原文
```text
Cue integration: weighting by reliability

Lecture 04 · Cue integration

In cue integration, more reliable evidence can receive more weight.

• Cue integration means combining sensory 

estimates. Ernst and Banks (2002) found near-
optimal weighting when people judged ridge 
height using sight and touch.

EO1

• In their experiment, the more reliable cue
received more weight, and the combined 
estimate was more precise than either cue alone.

• This connects to sensor fusion. Applying the 

idea to trust in warnings is a design analogy, not 
a universal formula established by that 
experiment.

After Ernst and Banks (2002). Warning-trust extension is an analogy. Sensor fusion is in Week 7; the 
original image says Week 6.
```

### 完整中文翻译
线索整合：按可靠性加权。

第 4 讲 - 线索整合。

在线索整合中，更可靠的证据可以获得更高权重。

- 线索整合意味着合并感官估计。Ernst 和 Banks（2002）发现，人们在使用视觉和触觉判断凸起高度时接近最优加权。
- 在他们的实验中，更可靠的线索获得更多权重，合并估计比任一单独线索更精确。
- 这连接到传感器融合。把这个想法应用到对警告的信任是一种设计类比，不是该实验确立的通用公式。

根据 Ernst 和 Banks（2002）。警告信任扩展是类比。

### 中文释义
人会综合多个线索，并倾向依赖更可靠的线索。设计中可以借用这个思想，但不要把实验结果直接当作所有信任判断公式。

### English Explanation
Cue integration combines estimates and can weight more reliable cues more heavily; applying it to trust is an analogy.

### 概念解析
- **Cue integration / 线索整合**：把多个感官或信息线索组合成一个估计。
- **Sensor fusion / 传感器融合**：将多个传感器来源组合以获得更可靠估计。

### 自测问题
**Q1 中文：** 第 16 页的核心复习点是什么？
**答：** 人会综合多个线索，并倾向依赖更可靠的线索。设计中可以借用这个思想，但不要把实验结果直接当作所有信任判断公式。
**Q1 English:** What is the key revision point on page 16?
**Answer:** Cue integration combines estimates and can weight more reliable cues more heavily; applying it to trust is an analogy.

**Q2 中文：** 解释本页概念：Cue integration / 线索整合
**答：** 把多个感官或信息线索组合成一个估计。
**Q2 English:** Explain this concept: Cue integration / 线索整合
**Answer:** 把多个感官或信息线索组合成一个估计。

## 第 17 页：Slide 16 comment

Source ID: `src-760c4a1613ea-pdf_page-00017`

![PDF page 17](../assets/pages/page_017.png)

### 原文
```text
Slide 16

EO1 

You can mention much of our Haptics research, where Visual input is used to modify the haptic rendering.
Eyal Ofek, 2026-09-23T15:42:22.914
```

### 完整中文翻译
第 16 页批注。

EO1：你可以提到我们的许多触觉研究，其中视觉输入被用来修改触觉渲染。

Eyal Ofek，2026-09-23。

### 中文释义
这是课件批注，不是正式知识点。它提示 cue integration 与触觉研究有关，尤其是视觉如何改变触觉渲染。

### English Explanation
This is a review comment noting that haptics research can illustrate visual influence on haptic rendering.

### 概念解析
- **Haptic rendering / 触觉渲染**：通过设备生成触觉反馈，让用户感到接触、纹理或力。

### 自测问题
**Q1 中文：** 第 17 页的核心复习点是什么？
**答：** 这是课件批注，不是正式知识点。它提示 cue integration 与触觉研究有关，尤其是视觉如何改变触觉渲染。
**Q1 English:** What is the key revision point on page 17?
**Answer:** This is a review comment noting that haptics research can illustrate visual influence on haptic rendering.

**Q2 中文：** 解释本页概念：Haptic rendering / 触觉渲染
**答：** 通过设备生成触觉反馈，让用户感到接触、纹理或力。
**Q2 English:** Explain this concept: Haptic rendering / 触觉渲染
**Answer:** 通过设备生成触觉反馈，让用户感到接触、纹理或力。

## 第 18 页：Feedback timing: three thresholds

Source ID: `src-760c4a1613ea-pdf_page-00018`

![PDF page 18](../assets/pages/page_018.png)

### 原文
```text
Feedback timing: three thresholds

Lecture 04 · Feedback

Acknowledge the action before a slow response leaves people uncertain.

• The approximate 0.1 s, 1 s and 10 s guidelines
describe immediate response, continued flow 
and the limit of sustained attention (Miller, 1968; 
Nielsen, 1993).

• If a model call takes longer, show ‘working on 

it’, a typing indicator or a partial result before the 
final answer.

• Feedback tells people what their action caused 

(Norman, 2013). Silence or a late 
acknowledgement can leave them uncertain or 
attending elsewhere.

Approximate response-time guidelines: Miller (1968); Nielsen (1993). Feedback: Norman (2013).
```

### 完整中文翻译
反馈时机：三个阈值。

第 4 讲 - 反馈。

在慢响应让人不确定之前，先确认动作已被接收。

- 约 0.1 秒、1 秒和 10 秒指南分别描述即时响应、持续流畅和持续注意的上限（Miller，1968；Nielsen，1993）。
- 如果模型调用需要更久，在最终答案前显示“正在处理”、输入指示器或部分结果。
- 反馈告诉人们他们的行动造成了什么（Norman，2013）。沉默或迟到确认会让人不确定，或把注意力转向别处。

响应时间指南：Miller（1968）；Nielsen（1993）。反馈：Norman（2013）。

### 中文释义
速度本身就是反馈设计。即使最终结果很慢，也要先让用户知道系统听到了、正在做、下一步是什么。

### English Explanation
Prompt acknowledgement prevents uncertainty while slower processing continues.

### 概念解析
- **Response-time thresholds / 响应时间阈值**：0.1s、1s、10s 等大致时间界限，用于判断反馈是否及时。

### 自测问题
**Q1 中文：** 第 18 页的核心复习点是什么？
**答：** 速度本身就是反馈设计。即使最终结果很慢，也要先让用户知道系统听到了、正在做、下一步是什么。
**Q1 English:** What is the key revision point on page 18?
**Answer:** Prompt acknowledgement prevents uncertainty while slower processing continues.

**Q2 中文：** 解释本页概念：Response-time thresholds / 响应时间阈值
**答：** 0.1s、1s、10s 等大致时间界限，用于判断反馈是否及时。
**Q2 English:** Explain this concept: Response-time thresholds / 响应时间阈值
**Answer:** 0.1s、1s、10s 等大致时间界限，用于判断反馈是否及时。

## 第 19 页：Feedback modality: which channel?

Source ID: `src-760c4a1613ea-pdf_page-00019`

![PDF page 19](../assets/pages/page_019.png)

### 原文
```text
Feedback modality: which channel?

Lecture 04 · Feedback

Choose a feedback modality that fits the task and the person.

• Foveal visual feedback carries detail where 
people are looking. Peripheral changes can 
attract attention, but small static cues are easier 
to miss.

• Non-speech sound can acknowledge quickly 

but competes with other sounds. Speech carries 
meaning and competes with verbal tasks.

• Haptic feedback uses touch for discreet 

confirmation when the device is in contact. 
Combine channel choice with error costs and 
timely feedback (Norman, 2013).

Course-own table. Multiple resources, signal detection and timing combined into a channel choice.
```

### 完整中文翻译
反馈模态：哪个通道？

第 4 讲 - 反馈。

选择适合任务和人的反馈模态。

- 中央视觉反馈能在人正在看的地方承载细节。周边变化能吸引注意，但小型静态线索更容易漏掉。
- 非语音声音能快速确认，但会与其他声音竞争。语音承载意义，也会与语言任务竞争。
- 触觉反馈在设备接触身体时能离散确认。把通道选择与错误成本和及时反馈结合起来（Norman，2013）。

课程自制表格：多资源、信号检测和时机共同决定通道选择。

### 中文释义
反馈通道要根据任务资源选择：视觉适合细节，声音适合快速提醒，触觉适合低调确认。但每个通道都有竞争成本。

### English Explanation
Modality choice combines attention resources, error costs, and timing requirements.

### 概念解析
- **Feedback modality / 反馈模态**：视觉、声音、语音、触觉等反馈通道。

### 自测问题
**Q1 中文：** 第 19 页的核心复习点是什么？
**答：** 反馈通道要根据任务资源选择：视觉适合细节，声音适合快速提醒，触觉适合低调确认。但每个通道都有竞争成本。
**Q1 English:** What is the key revision point on page 19?
**Answer:** Modality choice combines attention resources, error costs, and timing requirements.

**Q2 中文：** 解释本页概念：Feedback modality / 反馈模态
**答：** 视觉、声音、语音、触觉等反馈通道。
**Q2 English:** Explain this concept: Feedback modality / 反馈模态
**Answer:** 视觉、声音、语音、触觉等反馈通道。

## 第 20 页：The cost of a late or missing acknowledgement

Source ID: `src-760c4a1613ea-pdf_page-00020`

![PDF page 20](../assets/pages/page_020.png)

### 原文
```text
The cost of a late or missing acknowledgement

Lecture 04 · Feedback

Prompt acknowledgement can reduce uncertainty and repeated requests.

• In this hypothetical receipt-filing example, one 
route acknowledges within a second; the other 
remains silent for six seconds.

• During silence, the person wonders ‘did it hear 

me?’, repeats the request and receives a 
duplicate filing. The model’s answer was not the 
cause.

• An early acknowledgement can reduce that risk. 
It does not, by itself, guarantee that the system 
prevents every duplicate action.

Hypothetical timelines. Original plotted positions conflict with the stated timings; the replacement 
follows the narration.
```

### 完整中文翻译
迟到或缺失确认的成本。

第 4 讲 - 反馈。

及时确认能减少不确定性和重复请求。

- 在假想收据归档例子中，一条路径在一秒内确认；另一条沉默六秒。
- 沉默期间，用户会想“它听到了吗？”，重复请求，结果产生重复归档。模型答案本身不是原因。
- 早期确认可以降低这种风险。但它本身不能保证系统阻止每一次重复操作。

假想时间线。原始绘图位置与文字时间冲突；替换版本遵循叙述。

### 中文释义
这页说明很多错误不是模型错，而是反馈晚造成用户重复行动。确认消息能减少不确定性。

### English Explanation
Late acknowledgement can cause repeated requests and duplicate actions even when the model's final answer is fine.

### 概念解析
- **Acknowledgement / 确认反馈**：系统及时告知用户行动已被接收或正在处理。

### 自测问题
**Q1 中文：** 第 20 页的核心复习点是什么？
**答：** 这页说明很多错误不是模型错，而是反馈晚造成用户重复行动。确认消息能减少不确定性。
**Q1 English:** What is the key revision point on page 20?
**Answer:** Late acknowledgement can cause repeated requests and duplicate actions even when the model's final answer is fine.

**Q2 中文：** 解释本页概念：Acknowledgement / 确认反馈
**答：** 系统及时告知用户行动已被接收或正在处理。
**Q2 English:** Explain this concept: Acknowledgement / 确认反馈
**Answer:** 系统及时告知用户行动已被接收或正在处理。

## 第 21 页：Phase 1: your channel and the cost of a miss

Source ID: `src-760c4a1613ea-pdf_page-00021`

![PDF page 21](../assets/pages/page_021.png)

### 原文
```text
Phase 1: your channel and the cost of a miss

Lecture 04 · Project connection

Specify one important cue and justify how it reaches the user.

• Write six lines: name the message and channel, 
then describe the person’s current task and the 
resources it uses.

• Describe the cost of a miss and the cost of a 

false alarm. Then choose cautious, balanced or 
eager and explain why.

• Spend ten minutes on this unmarked task and 
bring it to Lab 2. It develops Phase 1’s ‘user 
experiences’ slot and your feedback layer.

Six-line unmarked task, ten-minute target. Bring the completed worksheet to Lab 2.
```

### 完整中文翻译
阶段 1：你的通道和漏报成本。

第 4 讲 - 项目连接。

指定一个重要线索，并说明它如何到达用户。

- 写六行：命名消息和通道，然后描述人的当前任务以及它使用的资源。
- 描述漏报成本和误报成本。然后选择谨慎、平衡或积极，并解释原因。
- 花十分钟完成这个不计分任务，并带到实验 2。它会发展阶段 1 的“用户体验”部分和你的反馈层。

六行不计分任务，目标十分钟。把完成的 worksheet 带到 Lab 2。

### 中文释义
项目任务把本讲工具落地：你必须为一个 cue 说明通道、用户当前任务、资源竞争、漏报/误报成本和判据选择。

### English Explanation
The project task asks students to justify one cue and channel using current task resources and error costs.

### 概念解析
- **Cue-channel justification / 线索-通道论证**：说明某个消息为什么通过某个通道传达，并如何权衡错误成本。

### 自测问题
**Q1 中文：** 第 21 页的核心复习点是什么？
**答：** 项目任务把本讲工具落地：你必须为一个 cue 说明通道、用户当前任务、资源竞争、漏报/误报成本和判据选择。
**Q1 English:** What is the key revision point on page 21?
**Answer:** The project task asks students to justify one cue and channel using current task resources and error costs.

**Q2 中文：** 解释本页概念：Cue-channel justification / 线索-通道论证
**答：** 说明某个消息为什么通过某个通道传达，并如何权衡错误成本。
**Q2 English:** Explain this concept: Cue-channel justification / 线索-通道论证
**Answer:** 说明某个消息为什么通过某个通道传达，并如何权衡错误成本。

## 第 22 页：What a person can notice, and how fast

Source ID: `src-760c4a1613ea-pdf_page-00022`

![PDF page 22](../assets/pages/page_022.png)

### 原文
```text
What a person can notice, and how fast

Lecture 04 · Synthesis and bridge

A useful cue must reach attention, support judgement and arrive in time.

• Attention and resources determine whether a 
cue is noticed and how much it competes with 
the current task.

• Detection and integration connect error costs 
with the reliability of the available evidence. 
Repeated false alarms can change responses.

• Give timely feedback, then ask what the person 
can hold in mind. Lecture 05 follows with working 
memory, cognitive load and mental models.

Five principles, followed by Lecture 05. Current warnings/evaluation links are L25/L26, replacing the 
original L31/L32.
```

### 完整中文翻译
人能注意到什么，以及多快。

第 4 讲 - 综合与过渡。

有用线索必须到达注意力、支持判断，并及时抵达。

- 注意力和资源决定线索是否被注意到，以及它与当前任务竞争多少。
- 检测和整合把错误成本与可用证据的可靠性连接起来。重复误报会改变反应。
- 及时给出反馈，然后问人能在脑中保持什么。第 5 讲会接着讲工作记忆、认知负荷和心理模型。

五条原则，随后进入第 5 讲。

### 中文释义
总结页把本讲三个部分连起来：注意力决定能否注意，信号检测决定何时警告，反馈时机决定是否及时解除不确定。

### English Explanation
The synthesis links attention, detection, integration, false alarms over time, and timely feedback.

### 概念解析
- **Attention-resource-feedback chain / 注意-资源-反馈链**：线索设计必须同时考虑注意、资源竞争、证据可靠性和反馈时机。

### 自测问题
**Q1 中文：** 第 22 页的核心复习点是什么？
**答：** 总结页把本讲三个部分连起来：注意力决定能否注意，信号检测决定何时警告，反馈时机决定是否及时解除不确定。
**Q1 English:** What is the key revision point on page 22?
**Answer:** The synthesis links attention, detection, integration, false alarms over time, and timely feedback.

**Q2 中文：** 解释本页概念：Attention-resource-feedback chain / 注意-资源-反馈链
**答：** 线索设计必须同时考虑注意、资源竞争、证据可靠性和反馈时机。
**Q2 English:** Explain this concept: Attention-resource-feedback chain / 注意-资源-反馈链
**Answer:** 线索设计必须同时考虑注意、资源竞争、证据可靠性和反馈时机。

## 第 23 页：References and further reading

Source ID: `src-760c4a1613ea-pdf_page-00023`

![PDF page 23](../assets/pages/page_023.png)

### 原文
```text
References and further reading

Lecture 04 · References

Broadbent, D. E. (1958). Perception and Communication. Pergamon Press.

Simons, D. J., & Chabris, C. F. (1999). Gorillas in our midst: sustained inattentional blindness for dynamic events. 
Perception, 28(9), 1059–1074.

Wickens, C. D. (2002). Multiple resources and performance prediction. Theoretical Issues in Ergonomics Science, 3(2), 
159–177.

Green, D. M., & Swets, J. A. (1966). Signal Detection Theory and Psychophysics. Wiley.

Breznitz, S. (1984). Cry Wolf: The Psychology of False Alarms. Lawrence Erlbaum.

Ernst, M. O., & Banks, M. S. (2002). Humans integrate visual and haptic information in a statistically optimal fashion. 
Nature, 415, 429–433.

Rensink, R. A., O'Regan, J. K., & Clark, J. J. (1997). To see or not to see: the need for attention to perceive changes in 
scenes. Psychological Science, 8(5), 368–373.

Miller, R. B. (1968). Response time in man-computer conversational transactions. AFIPS Fall Joint Computer 
Conference, 267–277.   ·   Nielsen, J. (1993). Usability Engineering. Academic Press.

Norman, D. A. (2013). The Design of Everyday Things (revised and expanded edition). Basic Books, chapter 2.   ·   
LaValle, S. M. (2017). Virtual Reality, chapters 5–6 (previewed).

Full list with verification notes: W02_L04_references.md

Course-own diagram. The sources grouped by what they support.

Use the primary sources to examine the mechanisms 
behind each design rule.

• Start with Simons and Chabris 

(1999) and an introduction to signal 
detection theory.

• The bibliography retains the lecture’s 
sources. W02_L04_references.md
records the verification notes.
```

### 完整中文翻译
参考文献与延伸阅读。

第 4 讲 - 参考文献。

Broadbent（1958）《Perception and Communication》。

Simons 与 Chabris（1999）《Gorillas in our midst: sustained inattentional blindness for dynamic events》。Perception, 28(9), 1059-1074。

Wickens（2002）《Multiple resources and performance prediction》。Theoretical Issues in Ergonomics Science, 3(2), 159-177。

Green 与 Swets（1966）《Signal Detection Theory and Psychophysics》。Wiley。

Breznitz（1984）《Cry Wolf: The Psychology of False Alarms》。Lawrence Erlbaum。

Ernst 与 Banks（2002）《Humans integrate visual and haptic information in a statistically optimal fashion》。Nature, 415, 429-433。

Rensink、O'Regan 与 Clark（1997）《To see or not to see: the need for attention to perceive changes in scenes》。Psychological Science, 8(5), 368-373。

Miller（1968）《Response time in man-computer conversational transactions》。AFIPS Fall Joint Computer Conference, 267-277。Nielsen（1993）《Usability Engineering》。Academic Press。

Norman（2013）《The Design of Everyday Things》第 2 章。LaValle（2017）《Virtual Reality》第 5-6 章预告。

完整列表与核验注释：W02_L04_references.md。

课程自绘图：来源按支持内容分组。使用一手来源检查每条设计规则背后的机制。

### 中文释义
参考页把本讲机制对应到来源：注意力、非注意盲视、多资源、信号检测、误报心理、线索整合、变化盲视、反馈时机和 Norman 反馈理论。

### English Explanation
The references anchor the mechanisms behind the design rules: attention, signal detection, cue integration, timing, and feedback.

### 概念解析
- **Primary mechanism source / 机制一手来源**：用于追溯设计原则背后心理或感知机制的原始研究。

### 自测问题
**Q1 中文：** 第 23 页的核心复习点是什么？
**答：** 参考页把本讲机制对应到来源：注意力、非注意盲视、多资源、信号检测、误报心理、线索整合、变化盲视、反馈时机和 Norman 反馈理论。
**Q1 English:** What is the key revision point on page 23?
**Answer:** The references anchor the mechanisms behind the design rules: attention, signal detection, cue integration, timing, and feedback.

**Q2 中文：** 解释本页概念：Primary mechanism source / 机制一手来源
**答：** 用于追溯设计原则背后心理或感知机制的原始研究。
**Q2 English:** Explain this concept: Primary mechanism source / 机制一手来源
**Answer:** 用于追溯设计原则背后心理或感知机制的原始研究。
