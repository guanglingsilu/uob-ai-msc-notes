# 来源：W01_L01_From_Calculators_to_Copilots_A_History_of_Intelligent_Interaction_v5_novideo.pdf

<!-- SOURCE: W01_L01_From_Calculators_to_Copilots_A_History_of_Intelligent_Interaction_v5_novideo.pdf -->

<!-- PDF 页 1 -->

From Calculators to 
Copilots: A History of 
Intelligent Interaction

Intelligent Interactive Systems  ·  Week 1  ·  Lecture 01
University of Birmingham

<!-- PDF 页 2 -->

What we usually mean by 'intelligence'

Lecture 01 · Framing

Ask a room to define intelligence and you get the 
same list every time — and two hidden assumptions 
come with it.

The list is usually reasoning, problem solving, flexibility, 
intuition and learning, and it is the one most of us arrive 
with.

The first assumption is anthropocentric: humans at the top 
of a single scale, everything else measured by how close it 
gets to us.

The second is brain-centric: that intelligence has to live in a 
brain. Both will shape how you judge every system in this 
module.

<!-- PDF 页 3 -->

Intelligence as goal-directed navigation

Lecture 01 · Framing

A definition that mentions neither brains nor humans: 
holding a goal fixed while varying the means of 
reaching it.

William James (1890) called it the pursuit of 'fixed ends with 
varying means'. Block one route and an intelligent system 
finds another.

Levin (2022) generalises this to competency at navigating 
a space toward desirable regions — a definition that fits a 
cell as well as a person.

So the question changes. Instead of 'how intelligent is it?', we 
ask which space is it navigating, and how well?

<!-- PDF 页 4 -->

Different spaces, different intelligences

Lecture 01 · Framing

Once intelligence means navigating a space, you can 
see it working at scales that have nothing to do with 
thinking.

Cells navigate anatomical (morphogenetic) space and 
organs navigate physiological space: a salamander regrows 
a limb and stops when the shape is right.

Some animals outperform us inside a narrow space: a 
young chimpanzee beat untrained adults at numeral recall 
(2007), but practised humans matched him (2009).

Humans range across physical, conceptual and social 
space. Your systems navigate a digital one, alongside a 
person.

<!-- PDF 页 5 -->

Two conversations, fifty-nine years apart

Lecture 01 · Hook (Interaction 1)

Two typed conversations that look almost identical on 
screen, and could hardly differ more in what they can 
do to you.

1966: ELIZA answers a troubled user by turning their 
sentence back into a question. It understands nothing; it 
matches keywords.

2025: a coding assistant proposes a change, runs it, and 
offers to commit it to your repository.

The typed surface is the same. The consequences are not
— and that gap is what this lecture is about.

<!-- PDF 页 6 -->

What changed for the person, each time?

Lecture 01 · Central question

This module never asks how intelligent the machine 
is. It asks what the interaction did to the person.

'How intelligent is the machine?' is the wrong question here, 
because no design decision follows from the answer.

Ours is: who starts the turn, what does the system infer, 
what can the person see, and what can be undone?

Those four questions are a reading frame we reuse every 
week. Today we read five capability shifts through it.

<!-- PDF 页 7 -->

The idea most of us arrive with

Lecture 01 · Why history

Most people picture AI as a chat box — but almost 
none of the intelligence you used today had one.

The mental image is a box that answers questions, 
because that is the form that became famous in 2022.

In practice you met suggestions, reroutes, rankings, scene 
detection, hand tracking and text completion, none of 
which involve a conversation.

History widens the picture before we define anything, so 
our definition is not accidentally a definition of chatbots.

<!-- PDF 页 8 -->

Five capability shifts, 1950 to today

Lecture 01 · Timeline

Five moments where a new capability arrived and the interaction changed shape with it.

Each shift added a capability to the machine and moved something in the interaction; the boundaries between them are interpretive, not facts.

As we go, read the last line of each band: it says what changed for the person, not what changed in the technology.

<!-- PDF 页 9 -->

Shift 1: symbolic rules and ELIZA (1966)

Lecture 01 · Shift 1

The first shift gave the machine a turn in the 
conversation — and nothing else.

ELIZA works by keyword spotting, decomposition and 
reassembly rules: it finds a pattern in your sentence and 
rebuilds it as a question.

The machine takes a turn, but the person supplies all the 
meaning. Nothing is inferred about the world, only about the 
shape of the sentence.

In frame terms: initiative moved a little; inference and 
visibility barely moved at all.

<!-- PDF 页 10 -->

Shift 2: direct manipulation and the GUI

Lecture 01 · Shift 2

The second shift made the system's state visible and 
its actions reversible — and both were deliberate 
design choices.

Sketchpad (1963) and Sutherland's Ultimate Display (1965)
imagined it; the Alto (1973), Star (1981), Lisa (1983) and 
Macintosh (1984) delivered it.

Shneiderman named the principle in 1983 as Direct 
Manipulation: continuous representation, physical actions 
rather than commands, and reversible operations.

This is the one shift where visibility and reversibility were 
designed in on purpose. Notice that it never happens again 
by accident.

Xerox Star (1981)

Xerox Alto (1973)

Photos: Alto and Star, source and licence to be confirmed; Lisa, © Auction Team Breker.

Apple Lisa (1983)

<!-- PDF 页 11 -->

Shift 3: learning and recommendation

Lecture 01 · Shift 3

The third shift let systems infer what you want from 
what other people did — and the reasoning left the 
screen.

GroupLens (Resnick et al., 1994) predicted what you would 
like from people who rated things the way you do: 
Collaborative Filtering.

Amazon's item-to-item filtering (Linden et al., 2003) scaled 
that to millions of items and made it ordinary.

The system now infers preferences you never stated. 
Initiative moved towards the system, and visibility went 
down.

<!-- PDF 页 12 -->

Shift 4: deep learning and perception

Lecture 01 · Shift 4

The fourth shift let inference reach past the keyboard 
and into the world.

In 2012 Krizhevsky, Sutskever and Hinton showed learned 
features beat hand-built ones on ImageNet: 15.3% top-5 
error against 26.2%.

Within a few years speech, faces, scenes and gestures 
became usable inputs to ordinary interfaces.

The consequence for interaction: the system now infers 
things about the world, not only about what you typed.

<!-- PDF 页 13 -->

Shift 5: large language models and agents

Lecture 01 · Shift 5

The fifth shift made systems fluent in any typed task 
— and then let them act, which is where reversibility 
broke.

Transformers (Vaswani et al., 2017) and GPT-3 (Brown et 
al., 2020) led to Copilot and ChatGPT in 2022.

They also generalise: a few examples in the prompt are 
enough for a new task (Brown et al., 2020).

Put them in agentic loops with tools and they act rather 
than only answer — and reversing a real action is now 
the open design problem.

<!-- PDF 页 14 -->

The reading frame: four interaction variables

Lecture 01 · The frame

Four questions you can ask of any intelligent system, 
and will ask of your own project.

Initiative — who starts the turn, the person or the system?  
Inference — what does the system conclude beyond your 
words or clicks?

Visibility — how much of the system's state and reasoning 
can the person actually see?

Reversibility — can a consequence be undone, and how 
easily?

<!-- PDF 页 15 -->

Five shifts scored on four variables

Lecture 01 · The pattern

Initiative and inference moved to the system; visibility and 
reversibility peaked with the GUI and have fallen since.

Systems started more turns and inferred more at each 
shift — except under direct manipulation, where the 
person held the initiative.

Visibility and reversibility peaked with the GUI, where 
they were designed in, and fell at each later shift.

The distance between what a system can do and what 
a person can see or undo is the design problem we 
keep returning to.

<!-- PDF 页 16 -->

1) the predictive keyboard

Lecture 01 · Three systems

An intelligent system most of you used before 
breakfast, with no chat box anywhere.

Initiative: the system proposes a word before you have 
finished typing it.

Inference: your next word, predicted from general language 
patterns and your own typing history.

Visibility and reversibility: you see three candidates and 
no reasons, and correcting takes one tap — unless 
autocorrect already acted.

<!-- PDF 页 17 -->

2) navigation that reroutes

Lecture 01 · Three systems

Here the system interrupts you mid-task, using 
evidence you cannot inspect.

Initiative: the map interrupts your journey to offer a faster 
route.

Inference: congestion ahead, estimated from the 
movement of many other phones.

Visibility and reversibility: you are shown a time saving, 
not the evidence behind it, and you have seconds to accept 
or dismiss.

<!-- PDF 页 18 -->

3) a coding copilot

Lecture 01 · Three systems

The same pattern again, but now the consequences 
land in your own work.

Initiative: ghost text appears as you type, unasked.

Inference: what it thinks you meant, read from your code, 
your comments and your naming.

Visibility and reversibility: the suggestion is shown but the 
reasoning is not, and once you press Tab the edits are 
yours.

<!-- PDF 页 19 -->

Your turn: score the automatic captions

Lecture 01 · Interaction 2

Lecture capture is writing captions while I speak. 
Score it.

Score all four variables — initiative, inference, visibility 
and reversibility — from low to high.

Then name one thing you would need to be able to see in 
order to trust it.

Two minutes, then three answers from the room.

<!-- PDF 页 20 -->

ELIZA and a copilot, side by side

Lecture 01 · Worked example

Two systems that take typed turns, separated by what 
happens when they are wrong.

Both exchange turns in typed language, and on screen 
they look alike.

But one infers the shape of a sentence; the other infers a 
plan — and then carries it out.

ELIZA can only reply. A copilot can edit, run and commit.
One mistake costs a strange question; the other can cost a 
codebase.

<!-- PDF 页 21 -->

The ELIZA effect

Lecture 01 · The ELIZA effect

People read fluency as understanding — and they did 
it with a keyword matcher in 1966.

Weizenbaum's own users confided in ELIZA, knowing it 
was a program. Hofstadter (1995) popularised the name 
ELIZA effect.

The mechanism is simple: fluency is read as 
understanding, and the reader supplies the rest.

It scales with fluency, which has never been higher. The 
design consequence is blunt: show what the system 
actually did, not just what it said.

Source: Wikimedia Commons, 'ELIZA conversation' (2005 re-implementation by N. Landsteiner), 
public domain.

<!-- PDF 页 22 -->

Turing's question versus the design question

Lecture 01 · Reframing

Turing's question is about the machine. Ours is about 
the person — and that changes what counts as 
success.

Turing (1950) replaced 'can machines think?' with an 
imitation game, because the original question was not 
answerable.

But the game judges the machine and says nothing about 
the person's task. A system can pass it and still be useless 
to work with.

Our question is what the interaction lets a person do, see 
and undo — the reframing Shneiderman (2022, ch. 1)
builds human-centred AI on.

<!-- PDF 页 23 -->

You bring the last generation's model with you

Lecture 01 · Psychology, informally

Every one of you is running an out-of-date model of 
what these systems are — and so are your users.

People type search-engine keywords into a chat, and aim 
conversational requests at a database.

More dangerously, they carry undo expectations from 
documents into systems that take real actions.

This is your first, informal meeting with the idea of a mental 
model. No theory today — just notice it in yourself this 
week.

<!-- PDF 页 24 -->

One question, four areas, eleven weeks

Lecture 01 · The module map

One question runs through the module: how do we 
design, build and evaluate interactive systems in 
which intelligent capabilities meaningfully take part in 
interaction with people?

Area I (Weeks 1–3): humans and intelligent interaction —
what intelligence is, and who is on the other side of it.

Area II (Weeks 4–5 and 7): engineering intelligent systems 
— context, models, knowledge, tools, agents and sensing.

Areas III and IV (Weeks 8–9, then 10–11): bodies and 
space; then agency, reliance, evaluation and deployment. 
Week 6 is reading week; Week 11 is review and project 
submission.

<!-- PDF 页 25 -->

Phase 1 begins now: choose an area by its shift

Lecture 01 · Project connection

Pick your project area by asking which capability shift 
your problem actually depends on.

Ask: which of the five shifts does my problem rely on?
That answer points at your area.

The shift also tells you what evidence you will need, 
which is why choosing early saves you weeks later.

Phase 1 (Weeks 1–4) is problem, literature, gap and 
contribution — and Lab 1 this week starts the literature 
search with AI tools.

<!-- PDF 页 26 -->

What changed each time

Lecture 01 · Synthesis

Initiative and inference moved to the system; visibility 
and reversibility were high only where somebody 
designed them.

From recommendation onward, what the system starts and 
what it infers kept rising. Direct manipulation was the 
exception: it handed both back to the person.

Visibility and reversibility are design choices, not gifts of 
progress — they peaked with the GUI, where they were 
deliberately built in (Shneiderman, 1983).

Since then they have fallen as capability rose. Designing 
them back in is the job, and it is what this module trains you 
to do.

<!-- PDF 页 27 -->

References and further reading

Lecture 01 · References

James, W. (1890). The Principles of Psychology. Henry Holt.

Turing, A. M. (1950). Computing Machinery and Intelligence. Mind, 59(236), 433–460.

Weizenbaum, J. (1966). ELIZA — A Computer Program for the Study of Natural Language 
Communication between Man and Machine. Communications of the ACM, 9(1), 36–45.

Weizenbaum, J. (1976). Computer Power and Human Reason. W. H. Freeman.

Sutherland, I. E. (1965). The Ultimate Display. Proceedings of IFIP Congress, 506–508.

Shneiderman, B. (1983). Direct Manipulation: A Step Beyond Programming Languages. IEEE 
Computer, 16(8), 57–69.

Resnick, P., Iacovou, N., Suchak, M., Bergstrom, P., & Riedl, J. (1994). GroupLens: An Open 
Architecture for Collaborative Filtering of Netnews. CSCW 1994.

Linden, G., Smith, B., & York, J. (2003). Amazon.com Recommendations: Item-to-Item 
Collaborative Filtering. IEEE Internet Computing, 7(1), 76–80.
Inoue, S., & Matsuzawa, T. (2007). Working memory of numerals in chimpanzees. Current 
Biology, 17(23), R1004–R1005.
Silberberg, A., & Kearns, D. (2009). Memory for the order of briefly presented numerals in 
humans as a function of practice. Animal Cognition, 12(2), 405–407.
Krizhevsky, A., Sutskever, I., & Hinton, G. E. (2012). ImageNet Classification with Deep 
Convolutional Neural Networks. NeurIPS 25.
Hinton, G. et al. (2012). Deep Neural Networks for Acoustic Modeling in Speech Recognition. 
IEEE Signal Processing Magazine, 29(6), 82–97.
Vaswani, A. et al. (2017). Attention Is All You Need. NeurIPS 30.   ·   Brown, T. et al. (2020). 
Language Models are Few-Shot Learners. NeurIPS 33.
Hofstadter, D. R. (1995). Fluid Concepts and Creative Analogies. Basic Books (preface: the 
'ELIZA effect').
Levin, M. (2022). Technological Approach to Mind Everywhere: An Experimentally-Grounded 
Framework for Understanding Diverse Bodies and Minds. Frontiers in Systems Neuroscience, 
16, 768201.
Shneiderman, B. (2022). Human-Centered AI. Oxford University Press. Start with Part 1, ch. 1.
