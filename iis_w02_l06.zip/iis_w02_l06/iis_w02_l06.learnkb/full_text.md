# 来源：W02_L06_Action_Error_Agency_and_Decision.pdf

<!-- SOURCE: W02_L06_Action_Error_Agency_and_Decision.pdf -->

<!-- PDF 页 1 -->

Action, Error, Agency 
and Decision

Intelligent Interactive Systems  ·  Week 2  ·  Lecture 06
University of Birmingham

Course-own diagram. A thermostat that learns, and the five ideas of the 
lecture.

<!-- PDF 页 2 -->

A door that needs a sign

Lecture 06 · Hook

A plate says "push" and a handle says 
"pull"; a signifier tells us which affordance 
is available.

Interaction 1: give one word for what the plate 
invites and one for what the handle invites.

An assistant that can send email but shows 
no sign has the same design problem: 
capability without a visible signifier; a 
thermostat that changes with no visible cause 
removes the handle as well.

<!-- PDF 页 3 -->

Acting through a system, and being acted for

Lecture 06 · Central question

Lecture 04 asked whether a 
cue arrives; Lecture 05 
asked what the person holds 
and which model forms.

Today asks how people act, 
why they err, and what 
changes when a system acts 
on their behalf.

We connect signifiers, gulfs, 
errors, agency, decision, and 
automation through the 
person's cue-built model of 
action.

<!-- PDF 页 4 -->

Affordance, signifier, mapping

Lecture 06 · Action

An affordance is what an object or system 
allows this person to do, whether or not it 
is visible.

A signifier is the perceivable cue that 
communicates the affordance; it is the part 
design can control.

Mapping links controls to effects: Norman's 
stove works because knob positions mirror 
burner positions, so labels are unnecessary.

Course-own diagram after Norman (2013), chapter 1.

<!-- PDF 页 5 -->

What tells you what a system can do?

Lecture 06 · Action

A microphone icon signifies speech, but it 
does not say which phrases or capabilities 
the system supports.

Suggestion chips are strong signifiers 
because they expose capabilities the person 
can recognise.

"Ask me anything" is a false signifier: a 
learning thermostat that silently overrides its 
dial also signals a control it does not honour.

Course-own mock-ups of six signifiers; none is a screenshot.

<!-- PDF 页 6 -->

The two gulfs

Lecture 06 · Action

Norman's seven stages move from goal, 
plan, and specification to performance, 
then perception, interpretation, and 
comparison.

The gulf of execution asks how to act; the gulf 
of evaluation asks what happened and 
whether it matches the goal.

Signifiers narrow execution, while feedback 
and a runnable mental model narrow 
evaluation.

Course-own diagram after Norman (1986; 2013, chapter 2).

<!-- PDF 页 7 -->

A thermostat that learns

Lecture 06 · Worked example

You set 21, but the 
thermostat drops to 19 at 
ten and warms again on 
Thursday; the system has 
acted on an inferred 
pattern.

Comfort improves and the 
bill falls, yet neither the 
person nor the system 
makes the cause visible.

When the gulf of evaluation 
widens, the person feels less 
able to say "I acted".

<!-- PDF 页 8 -->

Where the gulfs sit on the spine

Lecture 06 · Application

Prompting can narrow the gulf of 
execution while opening a new question: 
did the system understand me?

Agents can widen evaluation because many 
hidden steps separate a request from visible 
results.

Observability narrows evaluation again by 
showing what happened, why, and what 
comes next; assistance and embodiment also 
shape agency.

Course-own diagram. The Lecture 02 spine with both gulfs marked and four later lectures placed on 
them.

<!-- PDF 页 9 -->

Slips versus mistakes

Lecture 06 · Error

A slip preserves the right intention but 
executes the wrong action; a mistake 
begins with a wrong intention, rule, or 
guess (Reason, 1990).

Slips need constraints, confirmation, or undo; 
mistakes need a better model and clearer 
feedback.

Diagnose the error before redesigning, 
because the wrong remedy can irritate users 
or fail.

Course-own diagram after Reason (1990) and Norman (2013), chapter 5.

<!-- PDF 页 10 -->

Three kinds of error in one voice assistant

Lecture 06 · Error

"Call Sam" dialling Samantha is a system 
recognition error: the system inferred the 
wrong target.

"Call Sam" when you meant to text is a user 
slip; setting an alarm believing it repeats daily 
is a user mistake.

Each needs a different remedy: show what 
was heard, confirm risky actions, and expose 
the system's model.

Course-own table; the assistant is generic.

<!-- PDF 页 11 -->

Your turn: slip, mistake, or system inference?

Lecture 06 · Interaction 2

Classify five failures—
wrong-window send, lane 
assistant, photo tag, two 
listeners, and a deleting 
agent—as slip, mistake, 
or system inference.

Name the remedy in three 
words, and mark cases that 
need two labels because 
human and system errors 
interact.

Take two minutes, then 
defend the agent case.

<!-- PDF 页 12 -->

The sense of agency

Lecture 06 · Agency

The sense of agency is a computed feeling 
built from intention, action, predicted 
outcome, and comparison (Haggard, 2017).

It is strongest when an intended action is 
followed promptly by the predicted result.

Delay, mismatched outcomes, and actions not 
one's own weaken agency; perceived control 
extends the same feeling over time.

Course-own diagram after Haggard (2017).

<!-- PDF 页 13 -->

The thermostat, redesigned for agency

Lecture 06 · Agency

"Set to 21 by you, 18:40" 
and "lowered by schedule, 
22:00" make the cause of 
each change visible.

An override should persist 
until the person releases it, 
and the interface should say 
that it will.

"What I have learned about 
your week" should be 
editable, with changes 
announced before they 
happen; learning can remain 
while agency is restored.

<!-- PDF 页 14 -->

Who feels they acted?

Lecture 06 · Agency

In a simple assistant, the person acts and 
the system proposes, so agency remains 
clear.

In an agentic system, the person initiates a 
multi-step process and the system acts; 
agency becomes shared and potentially 
unclear.

When the system decides without the 
person's intention, the person becomes an 
observer; co-agency requires initiation and a 
visible veto.

Course-own diagram. The Lecture 02 autonomy scale annotated for agency.

<!-- PDF 页 15 -->

Bounded rationality: people satisfice

Lecture 06 · Decision

Simon (1955) describes 
bounded rationality: people 
search until an option is good 
enough, constrained by 
attention, memory, and time.

Joachims et al. (2005) swapped 
the top two search results and 
found that people still clicked 
the first.

Whatever the system ranks first 
becomes a decision made on 
the person's behalf, whether or 
not it is labelled as one.

<!-- PDF 页 16 -->

Heuristics and biases: anchoring

Lecture 06 · Decision

In an anchoring 
demonstration, a random 
wheel landing on 10 or 65 
shifted median estimates to 
25 or 45 (Tversky and 
Kahneman, 1974).

Anchoring, availability, and 
representativeness are 
heuristics through which a 
bounded mind makes 
decisions.

An assistant's first draft 
anchors the edit, so generating 
a draft is already a decision.

<!-- PDF 页 17 -->

Automation bias: introduced and parked

Lecture 06 · Decision

Parasuraman and Riley (1997) distinguish 
use, misuse, disuse, and abuse of 
automation.

An aid that was usually right but sometimes 
wrong led people to make both omission and 
commission errors (Skitka et al., 1999).

Parked means introduced now but not 
revisited in a scheduled lecture; optional 
material extends it, so agents are never 
taught without their human cost.

EO1

Course-own diagram after Parasuraman and Riley (1997) and Skitka, Mosier and Burdick (1999).

<!-- PDF 页 18 -->

Slide 17

EO1 

Not clear. What is parked - are u going to return to it by week 10?
Eyal Ofek, 2026-09-23T15:51:57.628

<!-- PDF 页 19 -->

Phase 1: mark your storyboard

Lecture 06 · Project connection

For Phase 1 of your project, mark five 
storyboard frames: the goal, the person's 
action, the system's inference and action, 
the result, and recovery.

For each frame, record who acts (P, S, or 
both), which gulf is involved, and which 
signifier is shown.

A frame with S and no visible cause is the 
thermostat problem; bring the marked 
storyboard to Lab 2.

EO1

Course-own worksheet. Phase 2 storyboards are assessed; this draft is not.

<!-- PDF 页 20 -->

Slide 18

EO1 

Is this the beginning of the project? Maybe it requires a title and a slide to announce it?
Eyal Ofek, 2026-09-23T15:53:40.419

<!-- PDF 页 21 -->

The week's theories, and where each returns

Lecture 06 · Synthesis and bridge

Lecture 04 supplied 
attention, detection, 
integration, limits, and 
feedback timing; Lecture 05 
added working memory, 
recognition, load, mental 
models, and explanations.

Today adds signifiers, the two 
gulfs, slips and mistakes, 
agency, decision, and 
automation.

For Lab 2, storyboard your 
problem and mark every frame 
with today's concepts.

<!-- PDF 页 22 -->

References and further reading

Lecture 06 · References

Norman, D. A. (2013). The Design of Everyday Things (revised and expanded edition). Basic Books. Chapters 
1–2 and 5.

Norman, D. A. (1986). Cognitive engineering. In D. A. Norman & S. W. Draper (Eds.), User Centered System Design 
(pp. 31–61). Lawrence Erlbaum.

Reason, J. (1990). Human Error. Cambridge University Press.

Haggard, P. (2017). Sense of agency in the human brain. Nature Reviews Neuroscience, 18(4), 196–207.

Simon, H. A. (1955). A behavioral model of rational choice. Quarterly Journal of Economics, 69(1), 99–118.

Tversky, A., & Kahneman, D. (1974). Judgment under uncertainty: heuristics and biases. Science, 185(4157), 1124–
1131.

Joachims, T., Granka, L., Pan, B., Hembrooke, H., & Gay, G. (2005). Accurately interpreting clickthrough data as 
implicit feedback. SIGIR 2005, 154–161.

Parasuraman, R., & Riley, V. (1997). Humans and automation: use, misuse, disuse, abuse. Human Factors, 39(2), 
230–253.

Skitka, L. J., Mosier, K. L., & Burdick, M. (1999). Does automation bias decision-making? International Journal of 
Human-Computer Studies, 51(5), 991–1006.

Shneiderman, B. (2022). Human-Centered AI. Oxford University Press; the control-centre design metaphor, previewed.   
·   Full list with verification notes: W02_L06_references.md

Course-own diagram. The sources grouped by what they support.

<!-- PDF 页 23 -->

Watch the first 90 seconds clip of Wargames (1983)

Gulf of evaluation: the humans can see missile tracks, but they cannot 
tell whether those tracks correspond to real missiles or a simulation. 

Mental model / signifier problem: the interface presents the information 
exactly as though it were real. There is essentially no signifier 
distinguishing simulation from reality. 

System inference/error: the displayed state is wrong from the operators’ 
perspective, but it arrives with strong authority — “confidence is high.” 

Automation bias: because the system is normally trusted, people start 
acting on its output instead of independently checking the world. 
Bounded rationality: under extreme time pressure, the operators cannot 
inspect everything; they act on the first apparently credible interpretation. 

Agency: the interesting question becomes who is actually making the 
decision? The general technically decides, but the computer has framed 
the situation and recommended the action. 
Ranking/default effect: WOPR recommends a full retaliatory strike. That 
recommendation itself becomes a powerful anchor for the human 
decision. 

Error diagnosis: is this a human mistake, a system inference problem, 
or an interface/feedback failure? It is actually a combination—which 
makes it excellent for discussion.

https://youtu.be/9RRGvAB4HF8?si=iVceCeyGYdRvguXY
