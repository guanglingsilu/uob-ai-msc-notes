# 18 条指南与混合主动权

## Page-by-page Notes

### 第 6 页：Eighteen guidelines in four phases

Source ID: `src-b91e955ebdec-pdf_page-00006`

Amershi 指南把人机 AI 互动拆成生命周期：开始、过程中、出错时、长期使用中。每个阶段都有不同设计责任。

#### Concepts
- **Guidelines for Human-AI Interaction / 人机 AI 交互指南**：Amershi 等提出的 18 条设计指南，用于改善 AI 系统可理解、可控和可恢复性。

### 第 7 页：Initially and during: G1 to G6

Source ID: `src-b91e955ebdec-pdf_page-00007`

前六条关心用户一开始如何理解系统：它能做什么、做得多可靠、什么时候出现、是否相关、是否符合社会场景且不带偏见。

#### Concepts
- **Capability envelope / 能力边界**：系统能可靠完成和不能完成的范围。

### 第 8 页：When wrong and over time: G7 to G18

Source ID: `src-b91e955ebdec-pdf_page-00008`

后十二条承认 AI 会错，所以要设计恢复和长期学习控制。重点不是让系统永不出错，而是错了之后人能看见、理解和修正。

#### Concepts
- **Cautious learning / 谨慎学习**：系统从用户行为中学习时不要过度推广，应让用户知道并能控制。

### 第 9 页：Who moves next is a design decision

Source ID: `src-b91e955ebdec-pdf_page-00009`

Mixed initiative 的本质是分配下一步行动权：人做、系统做，还是系统建议人决定。选择取决于置信度、注意力和错误成本。

#### Concepts
- **Mixed initiative / 混合主动权**：人和系统都可以推动任务，但谁行动由明确规则决定。

### 第 10 页：Act, ask or wait

Source ID: `src-b91e955ebdec-pdf_page-00010`

这是主动权规则的简洁公式。系统何时自动行动不应凭感觉，而要把置信度、错误成本和用户注意状态写成可测试规则。

#### Concepts
- **Act-ask-wait rule / 行动-询问-等待规则**：高置信低成本就行动；有不确定或成本就询问；否则等待。

### 第 11 页：The gulf between expectation and experience

Source ID: `src-b91e955ebdec-pdf_page-00011`

宣传和界面会塑造用户期待。如果系统看起来像真人助理，用户会期待它理解更多；实际能力不足就形成 expectation gulf。

#### Concepts
- **Expectation gulf / 期待鸿沟**：系统呈现出的能力形象与真实体验之间的差距。

### 第 12 页：The gulf is a mental-model mismatch

Source ID: `src-b91e955ebdec-pdf_page-00012`

期待鸿沟不是单纯用户误会，而是系统没有给足证据让用户校准心理模型。能力边界、可靠性、范围限定和解释都是校准工具。

#### Concepts
- **Mental-model mismatch / 心理模型错配**：用户以为系统怎样工作，与系统实际可靠能力不一致。

### 第 13 页：Your turn: name the guideline, then the fix

Source ID: `src-b91e955ebdec-pdf_page-00013`

练习要求你不要只说“体验差”，而要把问题映射到具体指南和三个承诺。例如误触发送破坏主动权与可撤销性，静默改档案破坏谨慎学习与通知。

#### Concepts
- **Guideline diagnosis / 指南诊断**：把交互失败映射到具体人机 AI 指南，再提出修复。
