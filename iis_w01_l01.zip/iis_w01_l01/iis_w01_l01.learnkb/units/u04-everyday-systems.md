# 三类日常智能系统练习

## Core Idea
本单元围绕以下页面建立学习路径：第 16 页、第 17 页、第 18 页、第 19 页、第 20 页。

## Page-by-page Learning Notes
### 第 16 页：1) the predictive keyboard

- Source ID: `src-ba38b47b419c-pdf_page-00016`
- Core: 预测键盘是低风险、日常化的智能交互例子。它主动建议、根据模式推断、只显示候选不显示理由。可撤销性通常还不错，但 autocorrect 一旦替你行动，就可能产生误发、误写等小型后果。
- Extension: 同一个系统里“建议”和“自动执行”差别很大。设计上，suggestion 通常比 automatic action 更容易撤销、更少打断用户。

#### Key Concepts
- **Predictive keyboard / 预测键盘**：根据上下文和用户历史预测下一个词或短语。
- **Autocorrect / 自动更正**：系统不只建议，而是直接替换文本，主动权和后果都更强。
- **Candidate visibility / 候选可见性**：用户看到若干结果，但看不到模型理由或证据。

### 第 17 页：2) navigation that reroutes

- Source ID: `src-ba38b47b419c-pdf_page-00017`
- Core: 地图重规划比预测键盘更强，因为它在你执行任务时打断并改变计划。它的推断基于群体移动数据，用户通常看不到证据。设计难点是：在驾驶压力下如何让用户迅速但合理地信任或拒绝建议。
- Extension: 地图类系统可以通过显示拥堵来源、时间估计不确定性、路线差异和撤回方式来增强可见性与可控性。

#### Key Concepts
- **Rerouting / 路线重规划**：系统根据新的交通信息改变建议路径。
- **Interruptive initiative / 打断式主动权**：系统在用户任务进行中主动介入。
- **Evidence opacity / 证据不透明**：系统显示结论或收益，但不显示足够证据让用户判断。

### 第 18 页：3) a coding copilot

- Source ID: `src-ba38b47b419c-pdf_page-00018`
- Core: 编码 Copilot 是本讲与学生项目最相关的例子。系统主动提供 ghost text，从局部上下文推断意图。用户能看到代码建议，但看不到推断过程、训练来源或风险。接受后，责任和后果转移到用户代码库中。
- Extension: 评估 Copilot 不只看节省时间，还要看错误检测、可解释性、测试覆盖、许可证风险和用户是否过度依赖。

#### Key Concepts
- **Ghost text / 幽灵文本**：编辑器中半透明或灰色显示的预测补全，等待用户接受。
- **Intent inference / 意图推断**：系统根据代码、注释、命名和上下文猜测用户想做什么。
- **Ownership transfer / 责任转移**：用户接受建议后，代码成为用户工作的一部分，错误也由用户承担。

### 第 19 页：Your turn: score the automatic captions

- Source ID: `src-ba38b47b419c-pdf_page-00019`
- Core: 这是课堂练习页。自动字幕是感知型智能系统：它从语音推断文本，通常主动生成结果。你要用四变量分析它，而不是只说“准不准”。信任需要可见证据，例如置信度、可回放音频、时间戳、谁说话、可编辑记录等。
- Extension: 自动字幕的设计可以加入低置信高亮、可回放片段、说话人分离、术语词典和人工修订流程，以提升可见性和可撤销性。

#### Key Concepts
- **Automatic captions / 自动字幕**：系统把语音实时或近实时转写成文字。
- **Trust evidence / 信任证据**：用户判断是否相信系统输出所需的信息，如置信度、原音频、时间戳或可编辑性。
- **Scoring frame / 评分框架**：用同一组变量比较不同系统，而不是只凭直觉评价。

### 第 20 页：ELIZA and a copilot, side by side

- Source ID: `src-ba38b47b419c-pdf_page-00020`
- Core: 这页把第 5 页的对比讲透：同样是 typed turns，系统推断对象和行动能力完全不同。ELIZA 错了只是回答怪；Copilot 错了可能改变代码库。出错成本是评价智能交互的重要维度。
- Extension: 设计评估时可以把系统按 action scope 分层：只显示、建议但不执行、执行可撤销操作、执行难撤销操作。层级越高，越需要可见性和确认机制。

#### Key Concepts
- **Inference target / 推断对象**：系统到底在推断什么：句法模式、用户偏好、世界状态、任务计划等。
- **Action scope / 行动范围**：系统能影响的外部范围，例如只回复文本，或能编辑和提交代码。
- **Error cost / 错误成本**：系统判断错误后造成的损失、修复难度和责任影响。
