# Data Quality II: Anomaly Detection

课程：Data-Intensive Artificial Intelligence

## 第 1 页：数据质量第二部分:

Source ID: `src-652be139ad4c-pdf_page-00001`

![PDF page 1](../assets/pages/page_001.jpg)

### 原文 / Original Text

```text
Data Quality II:
Anomaly Detection

Prof. Paolo Missier
School of Computer Science
University of Birmingham, UK

Data-intensive AI
2026/27 Sem 1
```

### 完整中文翻译

数据质量第二部分:
异常检测
教授 Paolo Missier
计算机科学学院
伯明翰大学, UK
数据密集型人工智能
2026/27 Sem 1

### 中文释义

本页围绕“Data Quality II:”展开。课件中的关键信息包括：数据质量第二部分:；异常检测；教授 Paolo Missier；计算机科学学院。复习时先抓住检测：同时判断目标类别与位置，通常输出边界框。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data Quality II:'. The slide includes: Data Quality II:; Anomaly Detection; Prof. Paolo Missier; School of Computer Science. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。

拓展复习：把“Data Quality II:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 1 页的核心主题是什么？
**答：** 本页围绕“Data Quality II:”展开。课件中的关键信息包括：数据质量第二部分:；异常检测；教授 Paolo Missier；计算机科学学院。复习时先抓住检测：同时判断目标类别与位置，通常输出边界框。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 1?
**Answer:** This page presents 'Data Quality II:'. The slide includes: Data Quality II:; Anomaly Detection; Prof. Paolo Missier; School of Computer Science. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：检测 / detection
**答：** 同时判断目标类别与位置，通常输出边界框。
**Q2 English:** Explain the concept on this page: detection
**Answer:** The page focuses on detection. This page presents 'Data Quality II:'. The slide includes: Data Quality II:; Anomaly Detection; Prof. Paolo Missier; School of Computer Science. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

## 第 2 页：检测单变量离群点: Z 分数

Source ID: `src-652be139ad4c-pdf_page-00002`

![PDF page 2](../assets/pages/page_002.jpg)

### 原文 / Original Text

```text
Detecting Univariate outliers: Z-score

Given a set 𝐱 = 𝑥1 … 𝑥𝑛  of points, the z-score 𝑧𝑖 of 𝑥𝑖 is defined as:

Rule of thumb:  Flag 𝑥𝑖 a point as anomalous when |𝑧𝑖 > 𝜏

This heuristics for detecting anomalies works well
when 𝒙 is approximately normally distributed

In this case, 𝜏 = 3 is a reasonable choice, because only about only ≈0.3% of points have |𝑧𝑖 >
3
```

### 完整中文翻译

检测单变量离群点: Z 分数
Given a set 𝐱 = 𝑥1 … 𝑥𝑛 of points, the Z 分数 𝑧𝑖 of 𝑥𝑖 is defined as:
经验规则: Flag 𝑥𝑖 a point as anomalous when |𝑧𝑖 > 𝜏
This heuristics for detecting anomalies works well
when 𝒙 is 近似服从正态分布
In this case, 𝜏 = 3 is a reasonable choice, because only about only ≈0.3% of points have |𝑧𝑖 >
3

### 中文释义

本页围绕“Detecting Univariate outliers: Z-score”展开。课件中的关键信息包括：检测单变量离群点: Z 分数；Given a set 𝐱 = 𝑥1 … 𝑥𝑛 of points, the Z 分数 𝑧𝑖 of 𝑥𝑖 is defined as:；经验规则: Flag 𝑥𝑖 a point as anomalous when |𝑧𝑖 > 𝜏；This heuristics for detecting anomalies works well。复习时先抓住Z 分数：用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Detecting Univariate outliers: Z-score'. The slide includes: Detecting Univariate outliers: Z-score; Given a set 𝐱 = 𝑥1 … 𝑥𝑛  of points, the z-score 𝑧𝑖 of 𝑥𝑖 is defined as:; Rule of thumb:  Flag 𝑥𝑖 a point as anomalous when |𝑧𝑖 > 𝜏; This heuristics for detecting anomalies works well. The revision focus is Z-score; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Z-score / Z 分数**：用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。

拓展复习：把“Detecting Univariate outliers: Z-score”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 2 页的核心主题是什么？
**答：** 本页围绕“Detecting Univariate outliers: Z-score”展开。课件中的关键信息包括：检测单变量离群点: Z 分数；Given a set 𝐱 = 𝑥1 … 𝑥𝑛 of points, the Z 分数 𝑧𝑖 of 𝑥𝑖 is defined as:；经验规则: Flag 𝑥𝑖 a point as anomalous when |𝑧𝑖 > 𝜏；This heuristics for detecting anomalies works well。复习时先抓住Z 分数：用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 2?
**Answer:** This page presents 'Detecting Univariate outliers: Z-score'. The slide includes: Detecting Univariate outliers: Z-score; Given a set 𝐱 = 𝑥1 … 𝑥𝑛  of points, the z-score 𝑧𝑖 of 𝑥𝑖 is defined as:; Rule of thumb:  Flag 𝑥𝑖 a point as anomalous when |𝑧𝑖 > 𝜏; This heuristics for detecting anomalies works well. The revision focus is Z-score; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：Z 分数 / Z-score
**答：** 用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。
**Q2 English:** Explain the concept on this page: Z-score
**Answer:** The page focuses on Z-score. This page presents 'Detecting Univariate outliers: Z-score'. The slide includes: Detecting Univariate outliers: Z-score; Given a set 𝐱 = 𝑥1 … 𝑥𝑛  of points, the z-score 𝑧𝑖 of 𝑥𝑖 is defined as:; Rule of thumb:  Flag 𝑥𝑖 a point as anomalous when |𝑧𝑖 > 𝜏; This heuristics for detecting anomalies works well. The revision focus is Z-score; connect its definition, evidence, and use to the examples on the page.

## 第 3 页：Z 分数的局限性

Source ID: `src-652be139ad4c-pdf_page-00003`

![PDF page 3](../assets/pages/page_003.jpg)

### 原文 / Original Text

```text
Z-score: limitations

The average is not a robust estimator for the true mean of the distribution

Example:

Consider 𝐱 = 6.27,6.34,6.25,6.31,6.28

Suppose a single point is entered incorrectly:
𝐱’ = 6.27,6.34,6.25,63.1,6.28

Why is this point not flagged as 
outlier”?

the outlier inflates both the mean and the std
This drags the outlier's own score back down toward "normal."

x

6.27

6.34

6.25

6.31

6.28

x

6.27

6.34

6.25

63.1

6.28

Z

−0.566

+1.414

−1.131

+0.566

−0.283

Z

−0.448

−0.445

−0.449

+1.789

−0.447

mean = 6.29
std = 0.035

No outliers

mean = 17.6480
std = 25.4085
```

### 完整中文翻译

Z 分数的局限性
平均值不是稳健估计量 for the true mean of the distribution
Example:
Consider 𝐱 = 6.27,6.34,6.25,6.31,6.28
Suppose a single point is entered incorrectly:
𝐱’ = 6.27,6.34,6.25,63.1,6.28
Why is this point not flagged as
离群点”?
the 离群点 inflates both the mean and the std
This drags the 离群点's own score back down toward "normal."
x
6.27
6.34
6.25
6.31
6.28
x
6.27
6.34
6.25
63.1
6.28
Z
−0.566
+1.414
−1.131
+0.566
−0.283
Z
−0.448
−0.445
−0.449
+1.789
−0.447
mean = 6.29
std = 0.035
No outliers
mean = 17.6480
std = 25.4085

### 中文释义

本页围绕“Z-score: limitations”展开。课件中的关键信息包括：Z 分数的局限性；平均值不是稳健估计量 for the true mean of the distribution；Example:；Consider 𝐱 = 6.27,6.34,6.25,6.31,6.28。复习时先抓住Z 分数：用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Z-score: limitations'. The slide includes: Z-score: limitations; The average is not a robust estimator for the true mean of the distribution; Example:; Consider 𝐱 = 6.27,6.34,6.25,6.31,6.28. The revision focus is Z-score; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Z-score / Z 分数**：用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。

拓展复习：把“Z-score: limitations”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 3 页的核心主题是什么？
**答：** 本页围绕“Z-score: limitations”展开。课件中的关键信息包括：Z 分数的局限性；平均值不是稳健估计量 for the true mean of the distribution；Example:；Consider 𝐱 = 6.27,6.34,6.25,6.31,6.28。复习时先抓住Z 分数：用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 3?
**Answer:** This page presents 'Z-score: limitations'. The slide includes: Z-score: limitations; The average is not a robust estimator for the true mean of the distribution; Example:; Consider 𝐱 = 6.27,6.34,6.25,6.31,6.28. The revision focus is Z-score; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：Z 分数 / Z-score
**答：** 用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。
**Q2 English:** Explain the concept on this page: Z-score
**Answer:** The page focuses on Z-score. This page presents 'Z-score: limitations'. The slide includes: Z-score: limitations; The average is not a robust estimator for the true mean of the distribution; Example:; Consider 𝐱 = 6.27,6.34,6.25,6.31,6.28. The revision focus is Z-score; connect its definition, evidence, and use to the examples on the page.

## 第 4 页：Z 分数 in Code: trip_distance

Source ID: `src-652be139ad4c-pdf_page-00004`

![PDF page 4](../assets/pages/page_004.jpg)

### 原文 / Original Text

```text
Z-score in Code: trip_distance

dist_stats = trips.agg(

F.mean("trip_distance").alias("mean_dist"),

F.stddev("trip_distance").alias("std_dist"),

).collect()[0]

trips = trips.withColumn(

"distance_zscore",
(F.col("trip_distance") - mean_dist) / std_dist

).withColumn(

"distance_anomaly_z",

F.when(F.abs(F.col("distance_zscore")) > 3, 1).otherwise(0)

)

• One Spark job computes mean_dist and std_dist as two driver-side scalars.

• Every row's distance_zscore and the boolean distance_anomaly_z flag are then computed 

column-wise, in parallel, with no further driver round-trip.
```

### 完整中文翻译

Z 分数 in Code: trip_distance
dist_stats = trips.agg(
F.mean("trip_distance").alias("mean_dist"),
F.stddev("trip_distance").alias("std_dist"),
).collect()[0]
trips = trips.withColumn(
"distance_zscore",
(F.col("trip_distance") - mean_dist) / std_dist
).withColumn(
"distance_anomaly_z",
F.when(F.abs(F.col("distance_zscore")) > 3, 1).otherwise(0)
)
• One Spark job computes mean_dist and std_dist as two driver-side scalars.
• Every row's distance_zscore and the boolean distance_anomaly_z flag are then computed
column-wise, in parallel, with no further driver round-trip.

### 中文释义

本页围绕“Z-score in Code: trip_distance”展开。课件中的关键信息包括：Z 分数 in Code: trip_distance；dist_stats = trips.agg(；F.mean("trip_distance").alias("mean_dist"),；F.stddev("trip_distance").alias("std_dist"),。复习时先抓住Z 分数：用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Z-score in Code: trip_distance'. The slide includes: Z-score in Code: trip_distance; dist_stats = trips.agg(; F.mean("trip_distance").alias("mean_dist"),; F.stddev("trip_distance").alias("std_dist"),. The revision focus is Z-score; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Z-score / Z 分数**：用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。

拓展复习：把“Z-score in Code: trip_distance”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 4 页的核心主题是什么？
**答：** 本页围绕“Z-score in Code: trip_distance”展开。课件中的关键信息包括：Z 分数 in Code: trip_distance；dist_stats = trips.agg(；F.mean("trip_distance").alias("mean_dist"),；F.stddev("trip_distance").alias("std_dist"),。复习时先抓住Z 分数：用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 4?
**Answer:** This page presents 'Z-score in Code: trip_distance'. The slide includes: Z-score in Code: trip_distance; dist_stats = trips.agg(; F.mean("trip_distance").alias("mean_dist"),; F.stddev("trip_distance").alias("std_dist"),. The revision focus is Z-score; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：Z 分数 / Z-score
**答：** 用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。
**Q2 English:** Explain the concept on this page: Z-score
**Answer:** The page focuses on Z-score. This page presents 'Z-score in Code: trip_distance'. The slide includes: Z-score in Code: trip_distance; dist_stats = trips.agg(; F.mean("trip_distance").alias("mean_dist"),; F.stddev("trip_distance").alias("std_dist"),. The revision focus is Z-score; connect its definition, evidence, and use to the examples on the page.

## 第 5 页：中位数绝对偏差: A more robust estimator

Source ID: `src-652be139ad4c-pdf_page-00005`

![PDF page 5](../assets/pages/page_005.jpg)

### 原文 / Original Text

```text
MAD: A more robust estimator

Median: the mid value when the data points are sorted

MAD: Median of all Absolute Deviations from the median:

(1.483 is a correction factor that makes the MAD unbiased)

Note that for the two example sets of data points, both median and MAD are the same:

X = {6.25, 6.27, 6.28, 6.31, 6.34}

X’ = {6.25, 6.27, 6.28, 6.34, 63.1}

median = 6.28, MAD = 0.044
```

### 完整中文翻译

中位数绝对偏差: A more robust estimator
Median: the mid value when the data points are sorted
中位数绝对偏差: Median of all Absolute Deviations from the median:
(1.483 is a correction factor that makes the 中位数绝对偏差 unbiased)
Note that for the two example sets of data points, both median and 中位数绝对偏差 are the same:
X = {6.25, 6.27, 6.28, 6.31, 6.34}
X’ = {6.25, 6.27, 6.28, 6.34, 63.1}
median = 6.28, 中位数绝对偏差 = 0.044

### 中文释义

本页围绕“MAD: A more robust estimator”展开。课件中的关键信息包括：中位数绝对偏差: A more robust estimator；Median: the mid value when the data points are sorted；中位数绝对偏差: Median of all Absolute Deviations from the median:；(1.483 is a correction factor that makes the 中位数绝对偏差 unbiased)。复习时先抓住中位数绝对偏差：用中位数和绝对偏差中位数构建稳健离群检测，比均值/标准差更不怕极端值。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'MAD: A more robust estimator'. The slide includes: MAD: A more robust estimator; Median: the mid value when the data points are sorted; MAD: Median of all Absolute Deviations from the median:; (1.483 is a correction factor that makes the MAD unbiased). The revision focus is MAD; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **MAD / 中位数绝对偏差**：用中位数和绝对偏差中位数构建稳健离群检测，比均值/标准差更不怕极端值。

拓展复习：把“MAD: A more robust estimator”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 5 页的核心主题是什么？
**答：** 本页围绕“MAD: A more robust estimator”展开。课件中的关键信息包括：中位数绝对偏差: A more robust estimator；Median: the mid value when the data points are sorted；中位数绝对偏差: Median of all Absolute Deviations from the median:；(1.483 is a correction factor that makes the 中位数绝对偏差 unbiased)。复习时先抓住中位数绝对偏差：用中位数和绝对偏差中位数构建稳健离群检测，比均值/标准差更不怕极端值。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 5?
**Answer:** This page presents 'MAD: A more robust estimator'. The slide includes: MAD: A more robust estimator; Median: the mid value when the data points are sorted; MAD: Median of all Absolute Deviations from the median:; (1.483 is a correction factor that makes the MAD unbiased). The revision focus is MAD; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：中位数绝对偏差 / MAD
**答：** 用中位数和绝对偏差中位数构建稳健离群检测，比均值/标准差更不怕极端值。
**Q2 English:** Explain the concept on this page: MAD
**Answer:** The page focuses on MAD. This page presents 'MAD: A more robust estimator'. The slide includes: MAD: A more robust estimator; Median: the mid value when the data points are sorted; MAD: Median of all Absolute Deviations from the median:; (1.483 is a correction factor that makes the MAD unbiased). The revision focus is MAD; connect its definition, evidence, and use to the examples on the page.

## 第 6 页：Replacing Z 分数 with 中位数绝对偏差

Source ID: `src-652be139ad4c-pdf_page-00006`

![PDF page 6](../assets/pages/page_006.jpg)

### 原文 / Original Text

```text
Replacing z-score with MAD

If we replace average with median and standard deviation with MAD in the z-score equation:

The new scores for X’ = {6.27, 6.34, 6.25, 63.1, 6.28} become:  

−0.22, 1.35, −0.67, 1277.5, 0.0 

where now the outlier is clearly identified 

•
The median and MAD stay stable even if up to half the data is extreme
• A few very large values can't drag the median the way they drag the mean
```

### 完整中文翻译

Replacing Z 分数 with 中位数绝对偏差
If we replace average with median and standard deviation with 中位数绝对偏差 in the Z 分数 equation:
The new scores for X’ = {6.27, 6.34, 6.25, 63.1, 6.28} become:
−0.22, 1.35, −0.67, 1277.5, 0.0
where now the 离群点 is clearly identified
•
The median and 中位数绝对偏差 stay stable even if up to half the data is extreme
• A few very large values can't drag the median the way they drag the mean

### 中文释义

本页围绕“Replacing z-score with MAD”展开。课件中的关键信息包括：Replacing Z 分数 with 中位数绝对偏差；If we replace average with median and standard deviation with 中位数绝对偏差 in the Z 分数 equation:；The new scores for X’ = {6.27, 6.34, 6.25, 63.1, 6.28} become:；−0.22, 1.35, −0.67, 1277.5, 0.0。复习时先抓住Z 分数：用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Replacing z-score with MAD'. The slide includes: Replacing z-score with MAD; If we replace average with median and standard deviation with MAD in the z-score equation:; The new scores for X’ = {6.27, 6.34, 6.25, 63.1, 6.28} become:; −0.22, 1.35, −0.67, 1277.5, 0.0. The revision focus is Z-score; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Z-score / Z 分数**：用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。
- **MAD / 中位数绝对偏差**：用中位数和绝对偏差中位数构建稳健离群检测，比均值/标准差更不怕极端值。

拓展复习：把“Replacing z-score with MAD”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 6 页的核心主题是什么？
**答：** 本页围绕“Replacing z-score with MAD”展开。课件中的关键信息包括：Replacing Z 分数 with 中位数绝对偏差；If we replace average with median and standard deviation with 中位数绝对偏差 in the Z 分数 equation:；The new scores for X’ = {6.27, 6.34, 6.25, 63.1, 6.28} become:；−0.22, 1.35, −0.67, 1277.5, 0.0。复习时先抓住Z 分数：用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 6?
**Answer:** This page presents 'Replacing z-score with MAD'. The slide includes: Replacing z-score with MAD; If we replace average with median and standard deviation with MAD in the z-score equation:; The new scores for X’ = {6.27, 6.34, 6.25, 63.1, 6.28} become:; −0.22, 1.35, −0.67, 1277.5, 0.0. The revision focus is Z-score; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：Z 分数 / Z-score
**答：** 用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。
**Q2 English:** Explain the concept on this page: Z-score
**Answer:** The page focuses on Z-score. This page presents 'Replacing z-score with MAD'. The slide includes: Replacing z-score with MAD; If we replace average with median and standard deviation with MAD in the z-score equation:; The new scores for X’ = {6.27, 6.34, 6.25, 63.1, 6.28} become:; −0.22, 1.35, −0.67, 1277.5, 0.0. The revision focus is Z-score; connect its definition, evidence, and use to the examples on the page.

## 第 7 页：中位数绝对偏差 in Code: fare_amount

Source ID: `src-652be139ad4c-pdf_page-00007`

![PDF page 7](../assets/pages/page_007.jpg)

### 原文 / Original Text

```text
MAD in Code: fare_amount

fare_median = trips.approxQuantile("fare_amount", [0.5], 0.001)[0]

trips = trips.withColumn("fare_abs_dev",

F.abs(F.col("fare_amount") - fare_median))

mad = trips.approxQuantile("fare_abs_dev", [0.5], 0.001)[0]

MODIFIED_Z_THRESHOLD = 3.5
trips = trips.withColumn(

"fare_modified_z",
F.lit(0.6745) * (F.col("fare_amount") - fare_median) / F.lit(mad)

).withColumn(

"fare_anomaly_mad",

F.when(F.abs(F.col("fare_modified_z")) > MODIFIED_Z_THRESHOLD, 1).otherwise(0))

Two lightweight Spark scans: one approxQuantile() call for the median of fare_amount, a second for 
the median of the absolute deviations

Both stay on the workers; only two scalars return to the driver.
```

### 完整中文翻译

中位数绝对偏差 in Code: fare_amount
fare_median = trips.approxQuantile("fare_amount", [0.5], 0.001)[0]
trips = trips.withColumn("fare_abs_dev",
F.abs(F.col("fare_amount") - fare_median))
中位数绝对偏差 = trips.approxQuantile("fare_abs_dev", [0.5], 0.001)[0]
MODIFIED_Z_THRESHOLD = 3.5
trips = trips.withColumn(
"fare_modified_z",
F.lit(0.6745) * (F.col("fare_amount") - fare_median) / F.lit(中位数绝对偏差)
).withColumn(
"fare_anomaly_中位数绝对偏差",
F.when(F.abs(F.col("fare_modified_z")) > MODIFIED_Z_THRESHOLD, 1).otherwise(0))
Two lightweight Spark scans: one approxQuantile() call for the median of fare_amount, a second for
the median of the absolute deviations
Both stay on the workers; only two scalars return to the driver.

### 中文释义

本页围绕“MAD in Code: fare_amount”展开。课件中的关键信息包括：中位数绝对偏差 in Code: fare_amount；fare_median = trips.approxQuantile("fare_amount", [0.5], 0.001)[0]；trips = trips.withColumn("fare_abs_dev",；F.abs(F.col("fare_amount") - fare_median))。复习时先抓住中位数绝对偏差：用中位数和绝对偏差中位数构建稳健离群检测，比均值/标准差更不怕极端值。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'MAD in Code: fare_amount'. The slide includes: MAD in Code: fare_amount; fare_median = trips.approxQuantile("fare_amount", [0.5], 0.001)[0]; trips = trips.withColumn("fare_abs_dev",; F.abs(F.col("fare_amount") - fare_median)). The revision focus is MAD; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **MAD / 中位数绝对偏差**：用中位数和绝对偏差中位数构建稳健离群检测，比均值/标准差更不怕极端值。

拓展复习：把“MAD in Code: fare_amount”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 7 页的核心主题是什么？
**答：** 本页围绕“MAD in Code: fare_amount”展开。课件中的关键信息包括：中位数绝对偏差 in Code: fare_amount；fare_median = trips.approxQuantile("fare_amount", [0.5], 0.001)[0]；trips = trips.withColumn("fare_abs_dev",；F.abs(F.col("fare_amount") - fare_median))。复习时先抓住中位数绝对偏差：用中位数和绝对偏差中位数构建稳健离群检测，比均值/标准差更不怕极端值。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 7?
**Answer:** This page presents 'MAD in Code: fare_amount'. The slide includes: MAD in Code: fare_amount; fare_median = trips.approxQuantile("fare_amount", [0.5], 0.001)[0]; trips = trips.withColumn("fare_abs_dev",; F.abs(F.col("fare_amount") - fare_median)). The revision focus is MAD; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：中位数绝对偏差 / MAD
**答：** 用中位数和绝对偏差中位数构建稳健离群检测，比均值/标准差更不怕极端值。
**Q2 English:** Explain the concept on this page: MAD
**Answer:** The page focuses on MAD. This page presents 'MAD in Code: fare_amount'. The slide includes: MAD in Code: fare_amount; fare_median = trips.approxQuantile("fare_amount", [0.5], 0.001)[0]; trips = trips.withColumn("fare_abs_dev",; F.abs(F.col("fare_amount") - fare_median)). The revision focus is MAD; connect its definition, evidence, and use to the examples on the page.

## 第 8 页：异常检测: 孤立森林

Source ID: `src-652be139ad4c-pdf_page-00008`

![PDF page 8](../assets/pages/page_008.jpg)

### 原文 / Original Text

```text
Anomaly Detection: Isolation Forest

How it Works

Key Advantage: Multivariate

• Builds an ensemble of random binary trees

• Catches implausible combinations of features, not just extreme single values

• At each node, a random feature and split value are chosen

• Anomalies sit in sparse regions of feature space, so they get isolated (reach a 

leaf) after very few splits

score = 2^(−mean path length / c(n))

score → 1: likely anomaly.  score → 0.5: normal.

• Example: 0.5-mile trip + $40 fare + 90-minute duration — each figure is 

individually plausible, but the combination is anomalous (e.g. metered while 
stuck in traffic, or fraud)

• Z-score and MAD would never flag this, since each column looks normal on its 

own

Limitation: scikit-learn's IsolationForest does not run natively on Spark workers — it needs the train → broadcast → score pattern shown on the next slide.
```

### 完整中文翻译

异常检测: 孤立森林
How it Works
Key Advantage: Multivariate
• Builds an ensemble of random binary trees
• Catches implausible combinations of features, not just extreme single values
• At each node, a random 特征 and split value are chosen
• Anomalies sit in sparse regions of 特征 space, so they get isolated (reach a
leaf) after very few splits
score = 2^(−mean path length / c(n))
score → 1: likely anomaly. score → 0.5: normal.
• Example: 0.5-mile trip + $40 fare + 90-minute duration — each figure is
individually plausible, but the combination is anomalous (e.g. metered while
stuck in traffic, or fraud)
• Z 分数 and 中位数绝对偏差 would never flag this, since each column looks normal on its
own
Limitation: scikit-learn's IsolationForest does not run natively on Spark workers — it needs the train → broadcast → score pattern shown on the next slide.

### 中文释义

本页围绕“Anomaly Detection: Isolation Forest”展开。课件中的关键信息包括：异常检测: 孤立森林；How it Works；Key Advantage: Multivariate；• Builds an ensemble of random binary trees。复习时先抓住Z 分数：用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Anomaly Detection: Isolation Forest'. The slide includes: Anomaly Detection: Isolation Forest; How it Works; Key Advantage: Multivariate; • Builds an ensemble of random binary trees. The revision focus is Z-score; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Z-score / Z 分数**：用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。
- **MAD / 中位数绝对偏差**：用中位数和绝对偏差中位数构建稳健离群检测，比均值/标准差更不怕极端值。
- **Isolation Forest / 孤立森林**：用随机树更快隔离稀疏区域样本，适合多变量异常组合检测。
- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。

拓展复习：把“Anomaly Detection: Isolation Forest”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 8 页的核心主题是什么？
**答：** 本页围绕“Anomaly Detection: Isolation Forest”展开。课件中的关键信息包括：异常检测: 孤立森林；How it Works；Key Advantage: Multivariate；• Builds an ensemble of random binary trees。复习时先抓住Z 分数：用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 8?
**Answer:** This page presents 'Anomaly Detection: Isolation Forest'. The slide includes: Anomaly Detection: Isolation Forest; How it Works; Key Advantage: Multivariate; • Builds an ensemble of random binary trees. The revision focus is Z-score; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：Z 分数 / Z-score
**答：** 用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。
**Q2 English:** Explain the concept on this page: Z-score
**Answer:** The page focuses on Z-score. This page presents 'Anomaly Detection: Isolation Forest'. The slide includes: Anomaly Detection: Isolation Forest; How it Works; Key Advantage: Multivariate; • Builds an ensemble of random binary trees. The revision focus is Z-score; connect its definition, evidence, and use to the examples on the page.

## 第 9 页：孤立森林

Source ID: `src-652be139ad4c-pdf_page-00009`

![PDF page 9](../assets/pages/page_009.jpg)

### 原文 / Original Text

```text
Isolation Forest

build a random tree, where
- at each node, a random feature and split 

value are chosen

Repeat until we have a forest of random trees

The average path length to a leaf is used as a 
measure of normality

Insight: Anomalies sit in sparse regions of 
feature space, so they reach a leaf after very 
few splits 
- use the length of a path to a sample to flag 
likely outliers

Key reference: F. T. Liu, K. M. Ting and Z. Zhou, "Isolation Forest," 2008 Eighth IEEE International Conference on 
Data Mining, 2008, pp. 413-422, doi: 10.1109/ICDM.2008.17.
```

### 完整中文翻译

孤立森林
build a random tree, where
- at each node, a random 特征 and split
value are chosen
Repeat until we have a forest of random trees
The average path length to a leaf is used as a
measure of normality
Insight: Anomalies sit in sparse regions of
特征 space, so they reach a leaf after very
few splits
- use the length of a path to a sample to flag
likely outliers
Key reference: F. T. Liu, K. M. Ting and Z. Zhou, "孤立森林," 2008 Eighth IEEE International Conference on
Data Mining, 2008, pp. 413-422, doi: 10.1109/ICDM.2008.17.

### 中文释义

本页围绕“Isolation Forest”展开。课件中的关键信息包括：孤立森林；build a random tree, where；- at each node, a random 特征 and split；value are chosen。复习时先抓住孤立森林：用随机树更快隔离稀疏区域样本，适合多变量异常组合检测。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Isolation Forest'. The slide includes: Isolation Forest; build a random tree, where; - at each node, a random feature and split; value are chosen. The revision focus is Isolation Forest; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Isolation Forest / 孤立森林**：用随机树更快隔离稀疏区域样本，适合多变量异常组合检测。

拓展复习：把“Isolation Forest”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 9 页的核心主题是什么？
**答：** 本页围绕“Isolation Forest”展开。课件中的关键信息包括：孤立森林；build a random tree, where；- at each node, a random 特征 and split；value are chosen。复习时先抓住孤立森林：用随机树更快隔离稀疏区域样本，适合多变量异常组合检测。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 9?
**Answer:** This page presents 'Isolation Forest'. The slide includes: Isolation Forest; build a random tree, where; - at each node, a random feature and split; value are chosen. The revision focus is Isolation Forest; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：孤立森林 / Isolation Forest
**答：** 用随机树更快隔离稀疏区域样本，适合多变量异常组合检测。
**Q2 English:** Explain the concept on this page: Isolation Forest
**Answer:** The page focuses on Isolation Forest. This page presents 'Isolation Forest'. The slide includes: Isolation Forest; build a random tree, where; - at each node, a random feature and split; value are chosen. The revision focus is Isolation Forest; connect its definition, evidence, and use to the examples on the page.
