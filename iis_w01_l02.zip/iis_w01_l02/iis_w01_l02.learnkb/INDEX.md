# IIS W01 L02 知识库索引

来源材料：W01_L02_Ingredients_of_an_Intelligent_Interactive_System_v5_novideo.pdf

- [工作定义与四属性](units/u01-definition.md)
- [概念脊柱与扫描器案例](units/u02-spine-scanner.md)
- [自主性、不确定性与恢复](units/u03-autonomy-uncertainty.md)
- [二十问、项目连接与参考](units/u04-checklist-project.md)