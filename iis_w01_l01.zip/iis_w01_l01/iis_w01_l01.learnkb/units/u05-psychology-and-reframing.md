# ELIZA 效应、设计问题与心理模型

## Core Idea
本单元围绕以下页面建立学习路径：第 21 页、第 22 页、第 23 页。

## Page-by-page Learning Notes
### 第 21 页：The ELIZA effect

- Source ID: `src-ba38b47b419c-pdf_page-00021`
- Core: ELIZA effect 是理解现代 LLM 的核心心理机制。人会自然把语言流畅等同于理解、意图或能力。系统越会说，用户越可能高估它。设计上的回应不是禁止流畅，而是显示行动、证据、限制和真实能力。
- Extension: LLM 产品常见风险是“语气可信但事实错误”。缓解方式包括来源引用、过程日志、可验证输出、明确不确定性、任务边界和人工确认。

#### Key Concepts
- **ELIZA effect / ELIZA 效应**：用户把系统的语言流畅性误读为理解、同理心或能力。
- **Fluency / 流畅性**：输出看起来连贯自然，但不等于真实理解、正确性或可靠性。
- **Attribution / 归因**：用户把意义、意图或知识归给系统的心理过程。

### 第 22 页：Turing's question versus the design question

- Source ID: `src-ba38b47b419c-pdf_page-00022`
- Core: 本页把 AI 哲学问题转成设计问题。Turing Test 问机器是否能表现得像人；IIS 问系统是否让人的任务变好。一个会骗过人的系统不一定有用、安全或可控。因此课程采用 human-centered AI 的视角。
- Extension: 在项目评估中，不要只问模型是否像人或准确率是否高，还要测量任务完成、错误恢复、用户理解、信任校准和工作流整合。

#### Key Concepts
- **Turing Test / 图灵测试**：通过模仿游戏判断机器是否能在对话中表现得像人。
- **Design question / 设计问题**：互动让人能做什么、看见什么、撤销什么。
- **Human-centered AI / 以人为中心的 AI**：把人的能力、控制、理解、责任和社会影响放在 AI 系统设计中心。

### 第 23 页：You bring the last generation's model with you

- Source ID: `src-ba38b47b419c-pdf_page-00023`
- Core: 心理模型是用户对系统如何工作的内在理解。新系统出现时，用户会带着旧系统经验来使用它：把 chat 当 search，用自然语言问数据库，或以为所有系统都像文档编辑器一样能撤销。错配的心理模型会导致误用和过度信任。
- Extension: 设计新智能系统时，需要通过界面信号、反馈、确认和教育帮助用户建立正确心理模型，而不是假设用户自然理解系统边界。

#### Key Concepts
- **Mental model / 心理模型**：用户心中关于系统是什么、如何工作、会产生什么后果的内在模型。
- **Model mismatch / 模型错配**：用户用旧系统规则理解新系统，导致错误操作或错误期待。
- **Undo expectation / 撤销期待**：用户默认操作可以像文档编辑一样撤销，但真实行动系统未必如此。
