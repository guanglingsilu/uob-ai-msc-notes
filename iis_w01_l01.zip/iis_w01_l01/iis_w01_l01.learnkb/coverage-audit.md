# 覆盖审计

所有 27 个 PDF 页块均已映射到逐页翻译、解释、概念拓展与自测题。

- PDF 页 1：covered - src-ba38b47b419c-pdf_page-00001
- PDF 页 2：covered - src-ba38b47b419c-pdf_page-00002
- PDF 页 3：covered - src-ba38b47b419c-pdf_page-00003
- PDF 页 4：covered - src-ba38b47b419c-pdf_page-00004
- PDF 页 5：covered - src-ba38b47b419c-pdf_page-00005
- PDF 页 6：covered - src-ba38b47b419c-pdf_page-00006
- PDF 页 7：covered - src-ba38b47b419c-pdf_page-00007
- PDF 页 8：covered - src-ba38b47b419c-pdf_page-00008
- PDF 页 9：covered - src-ba38b47b419c-pdf_page-00009
- PDF 页 10：covered - src-ba38b47b419c-pdf_page-00010
- PDF 页 11：covered - src-ba38b47b419c-pdf_page-00011
- PDF 页 12：covered - src-ba38b47b419c-pdf_page-00012
- PDF 页 13：covered - src-ba38b47b419c-pdf_page-00013
- PDF 页 14：covered - src-ba38b47b419c-pdf_page-00014
- PDF 页 15：covered - src-ba38b47b419c-pdf_page-00015
- PDF 页 16：covered - src-ba38b47b419c-pdf_page-00016
- PDF 页 17：covered - src-ba38b47b419c-pdf_page-00017
- PDF 页 18：covered - src-ba38b47b419c-pdf_page-00018
- PDF 页 19：covered - src-ba38b47b419c-pdf_page-00019
- PDF 页 20：covered - src-ba38b47b419c-pdf_page-00020
- PDF 页 21：covered - src-ba38b47b419c-pdf_page-00021
- PDF 页 22：covered - src-ba38b47b419c-pdf_page-00022
- PDF 页 23：covered - src-ba38b47b419c-pdf_page-00023
- PDF 页 24：covered - src-ba38b47b419c-pdf_page-00024
- PDF 页 25：covered - src-ba38b47b419c-pdf_page-00025
- PDF 页 26：covered - src-ba38b47b419c-pdf_page-00026
- PDF 页 27：covered - src-ba38b47b419c-pdf_page-00027