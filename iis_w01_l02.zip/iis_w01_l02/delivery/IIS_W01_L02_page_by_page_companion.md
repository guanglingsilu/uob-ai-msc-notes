# IIS W01 L02 - Ingredients of an Intelligent Interactive System

逐页完整翻译与复习笔记。

## 第 1 页：Ingredients of an Intelligent Interactive Systems

Source ID: `src-a5decf9f86a2-pdf_page-00001`

![PDF page 1](../assets/pages/page_001.png)

### 原文
```text
Ingredients of an 
Intelligent Interactive 
Systems

Intelligent Interactive Systems  ·  Week 1  ·  Lecture 02
University of Birmingham

We will open the system and follow its interaction 
with a person.

• Apply the working definition to a system.

• Walk the spine to trace a failure to its layer.
```

### 完整中文翻译
智能交互系统的组成要素。

智能交互系统 - 第 1 周 - 第 2 讲。

伯明翰大学。

本讲会打开系统内部，跟踪它与人的互动过程。

- 把工作定义应用到一个具体系统上。
- 沿着概念脊柱追踪一次失败，定位它属于哪一层。

### 中文释义
这一页给出本讲目标：从第 1 讲的用户体验框架转向系统内部结构。你要学会把一个智能交互系统拆成层次，并在系统出错时定位是哪一层导致失败。

### English Explanation
This opening slide shifts from user-facing interaction to the system's internal ingredients. The lecture teaches students to apply the working definition and trace failures through layers.

### 概念解析
- **Conceptual spine / 概念脊柱**：一个逐层分析系统的检查表，用来追踪人、感知、上下文、模型、行动、反馈和适应之间的关系。

### 自测问题
**Q1 中文：** 第 1 页的核心设计问题是什么？
**答：** 这一页给出本讲目标：从第 1 讲的用户体验框架转向系统内部结构。你要学会把一个智能交互系统拆成层次，并在系统出错时定位是哪一层导致失败。
**Q1 English:** What is the core design issue on page 1?
**Answer:** This opening slide shifts from user-facing interaction to the system's internal ingredients. The lecture teaches students to apply the working definition and trace failures through layers.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Conceptual spine / 概念脊柱：一个逐层分析系统的检查表，用来追踪人、感知、上下文、模型、行动、反馈和适应之间的关系。
**Q2 English:** What is the most important concept on this page?
**Answer:** Conceptual spine: 一个逐层分析系统的检查表，用来追踪人、感知、上下文、模型、行动、反馈和适应之间的关系。

## 第 2 页：The mis-cropped page

Source ID: `src-a5decf9f86a2-pdf_page-00002`

![PDF page 2](../assets/pages/page_002.png)

### 原文
```text
The mis-cropped page

Lecture 02 · Hook

A bad crop gives us a concrete failure to investigate.

• Your phone finds a page and crops it, but this 
scan includes a strip of table along one edge.

• For Interaction 1, vote for the layer responsible: 

sensing, context, model, action or feedback.

• Keep your first answer: we will return to this page 

with a method for diagnosing the mistake.
```

### 完整中文翻译
裁剪错误的页面。

第 2 讲 - 引入。

一次糟糕的裁剪给了我们一个可以调查的具体失败案例。

- 你的手机识别出一页纸并进行裁剪，但这次扫描在一侧包含了一条桌面边缘。
- 在互动 1 中，请投票判断负责出错的层：感知、上下文、模型、行动，还是反馈。
- 保留你的第一个答案：我们会带着一种诊断错误的方法回到这一页。

### 中文释义
这页用手机扫描裁剪错误作为贯穿案例。重点不是马上猜“AI 错了”，而是把症状追踪到具体层：是传感输入模糊、上下文假设错、模型边缘检测错，还是用户无法修正反馈。

### English Explanation
The mis-cropped scan is a concrete diagnostic case. The lecture will return to it after giving a layer-by-layer method for locating the cause of failure.

### 概念解析
- **Failure diagnosis / 失败诊断**：先描述症状，再定位到系统层次，最后选择修复方案。不同层出错需要不同修复。

### 自测问题
**Q1 中文：** 第 2 页的核心设计问题是什么？
**答：** 这页用手机扫描裁剪错误作为贯穿案例。重点不是马上猜“AI 错了”，而是把症状追踪到具体层：是传感输入模糊、上下文假设错、模型边缘检测错，还是用户无法修正反馈。
**Q1 English:** What is the core design issue on page 2?
**Answer:** The mis-cropped scan is a concrete diagnostic case. The lecture will return to it after giving a layer-by-layer method for locating the cause of failure.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Failure diagnosis / 失败诊断：先描述症状，再定位到系统层次，最后选择修复方案。不同层出错需要不同修复。
**Q2 English:** What is the most important concept on this page?
**Answer:** Failure diagnosis: 先描述症状，再定位到系统层次，最后选择修复方案。不同层出错需要不同修复。

## 第 3 页：From the frame to the box

Source ID: `src-a5decf9f86a2-pdf_page-00003`

![PDF page 3](../assets/pages/page_003.png)

### 原文
```text
From the frame to the box

Lecture 02 · Central question

Today we move from the user’s experience to the system’s ingredients.

• Lecture 01 used initiative, inference, visibility 
and reversibility to describe what a system 
does to a person.

• Central question: what must be present for a 

system to count as both intelligent and 
interactive, and how do we look inside one?

• The conceptual spine gives us a layer-by-layer 
checklist that you can apply now and defend 
later.
```

### 完整中文翻译
从框架到盒子内部。

第 2 讲 - 中心问题。

今天我们从用户体验移动到系统组成要素。

- 第 1 讲用主动权、推断、可见性和可撤销性描述系统对人做了什么。
- 中心问题：一个系统要同时算作智能并且交互式，必须具备什么？我们如何看进系统内部？
- 概念脊柱提供逐层检查表，你现在可以应用它，以后也可以为它辩护。

### 中文释义
第 1 讲是外部评价：系统如何改变用户。第 2 讲是内部分析：系统由哪些层组成，智能放在哪里，失败如何穿过层传播。

### English Explanation
Lecture 01 described effects on the person; Lecture 02 opens the box and asks what components must be present for a system to be both intelligent and interactive.

### 概念解析
- **Initiative, inference, visibility, reversibility / 主动权、推断、可见性、可撤销性**：第 1 讲的用户侧框架，在第 2 讲中会与系统内部层次连接起来。

### 自测问题
**Q1 中文：** 第 3 页的核心设计问题是什么？
**答：** 第 1 讲是外部评价：系统如何改变用户。第 2 讲是内部分析：系统由哪些层组成，智能放在哪里，失败如何穿过层传播。
**Q1 English:** What is the core design issue on page 3?
**Answer:** Lecture 01 described effects on the person; Lecture 02 opens the box and asks what components must be present for a system to be both intelligent and interactive.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Initiative, inference, visibility, reversibility / 主动权、推断、可见性、可撤销性：第 1 讲的用户侧框架，在第 2 讲中会与系统内部层次连接起来。
**Q2 English:** What is the most important concept on this page?
**Answer:** Initiative, inference, visibility, reversibility: 第 1 讲的用户侧框架，在第 2 讲中会与系统内部层次连接起来。

## 第 4 页：The working definition

Source ID: `src-a5decf9f86a2-pdf_page-00004`

![PDF page 4](../assets/pages/page_004.png)

### 原文
```text
The working definition

Lecture 02 · Definition

Intelligence must be designed into the interaction.

• The system senses, interprets, acts and 

adapts in a loop with a person and their context.

• Its model of intent, state or preference is an 

inference: it is a best interpretation of the signals, 
and it can be wrong.

• We judge quality by what the interaction does 
for human activity, alongside model accuracy.
```

### 完整中文翻译
工作定义。

第 2 讲 - 定义。

智能必须被设计进互动中。

- 系统在人及其情境的循环中进行感知、解释、行动和适应。
- 它关于意图、状态或偏好的模型是一种推断：它是对信号的最佳解释，并且可能出错。
- 我们评价质量时，不只看模型准确率，也看互动对人类活动产生了什么影响。

### 中文释义
这一页给出本课对智能交互系统的工作定义。关键是 loop：系统不是离线做预测，而是在人的情境中感知、解释、行动、适应。模型输出永远是可错的推断。

### English Explanation
The working definition treats intelligence as part of an interaction loop. The system senses, interprets, acts, and adapts with a person and context, while model accuracy is only one part of quality.

### 概念解析
- **Inference / 推断**：系统对信号作出的最佳解释，例如用户意图、当前状态或偏好；它不是事实本身，可能错误。

### 自测问题
**Q1 中文：** 第 4 页的核心设计问题是什么？
**答：** 这一页给出本课对智能交互系统的工作定义。关键是 loop：系统不是离线做预测，而是在人的情境中感知、解释、行动、适应。模型输出永远是可错的推断。
**Q1 English:** What is the core design issue on page 4?
**Answer:** The working definition treats intelligence as part of an interaction loop. The system senses, interprets, acts, and adapts with a person and context, while model accuracy is only one part of quality.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Inference / 推断：系统对信号作出的最佳解释，例如用户意图、当前状态或偏好；它不是事实本身，可能错误。
**Q2 English:** What is the most important concept on this page?
**Answer:** Inference: 系统对信号作出的最佳解释，例如用户意图、当前状态或偏好；它不是事实本身，可能错误。

## 第 5 页：Four properties, all required

Source ID: `src-a5decf9f86a2-pdf_page-00005`

![PDF page 5](../assets/pages/page_005.png)

### 原文
```text
Four properties, all required

Lecture 02 · Definition

An intelligent interactive system must satisfy all four properties.

• 1. Sensing gathers signals beyond explicit 

commands. 

• 2. Interpretation under uncertainty infers an 

intent, preference or situation that was not 
literally stated, and can be wrong.

• 3. Action through an output channel means 

the system changes its behaviour with the 
inference and reaches the person through an 
informational, spatial or physical channel.

• 4. A closed loop with a human means the 
person’s response changes what the system 
does next. All four properties must hold together.
```

### 完整中文翻译
四个属性，全部都必须具备。

第 2 讲 - 定义。

一个智能交互系统必须同时满足四个属性。

1. 感知：收集超出显式命令之外的信号。
2. 不确定性下的解释：推断一个没有被逐字说明的意图、偏好或情境，并且这种推断可能出错。
3. 通过输出通道行动：系统根据推断改变自身行为，并通过信息、空间或物理通道到达人。
4. 与人形成闭环：人的反应会改变系统接下来做什么。四个属性必须同时成立。

### 中文释义
这是本讲最核心的定义页。只有感知、解释、行动、闭环同时存在，才算智能交互系统。单纯自动化、单次预测或没有人类反馈的流水线都不完整。

### English Explanation
The four required properties are sensing, interpretation under uncertainty, action through an output channel, and a closed human loop. They must hold together.

### 概念解析
- **Closed loop / 闭环**：系统输出影响人，人的反应又影响系统下一步行为。没有这个回路，系统只是 pipeline。
- **Output channel / 输出通道**：系统把行动或信息传给人的方式，可以是信息、空间或物理通道。

### 自测问题
**Q1 中文：** 第 5 页的核心设计问题是什么？
**答：** 这是本讲最核心的定义页。只有感知、解释、行动、闭环同时存在，才算智能交互系统。单纯自动化、单次预测或没有人类反馈的流水线都不完整。
**Q1 English:** What is the core design issue on page 5?
**Answer:** The four required properties are sensing, interpretation under uncertainty, action through an output channel, and a closed human loop. They must hold together.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Closed loop / 闭环：系统输出影响人，人的反应又影响系统下一步行为。没有这个回路，系统只是 pipeline。
**Q2 English:** What is the most important concept on this page?
**Answer:** Closed loop: 系统输出影响人，人的反应又影响系统下一步行为。没有这个回路，系统只是 pipeline。

## 第 6 页：The conceptual spine at a glance

Source ID: `src-a5decf9f86a2-pdf_page-00006`

![PDF page 6](../assets/pages/page_006.png)

### 原文
```text
The conceptual spine at a glance

Lecture 02 · The spine

The conceptual spine is a checklist for investigating a system.

• Start with human, sensing, context, memory, 
knowledge and model: who is involved, what 
arrives, what is retained and what is inferred?

• Continue through planning, tools and action, 
environment, feedback and adaptation: what 
happens next, and how does the person’s 
response change it?

• At every connection, examine control, 

uncertainty, verification, safety, privacy and 
evaluation. Use this as an analysis tool; an 
empty layer is a meaningful finding.
```

### 完整中文翻译
概念脊柱一览。

第 2 讲 - 脊柱。

概念脊柱是调查系统的检查表。

- 从人、感知、上下文、记忆、知识和模型开始：谁参与其中？什么信号到达？什么被保留？什么被推断？
- 继续看规划、工具和行动、环境、反馈和适应：接下来发生什么？人的反应如何改变系统？
- 在每个连接处，检查控制、不确定性、验证、安全、隐私和评估。把它当分析工具；空层也是有意义的发现。

### 中文释义
概念脊柱不是必须每层都复杂，而是让你知道要查哪里。某层为空不是失败，而是分析结果：例如没有记忆、没有适应、没有工具，都说明系统边界。

### English Explanation
The spine is a checklist for inspecting the system. It covers human involvement, sensing, context, memory, knowledge, model, planning, tools, action, environment, feedback, and adaptation.

### 概念解析
- **Empty layer / 空层**：某一层不存在或只是占位，同样是有意义的系统分析发现。
- **Verification / 验证**：检查系统推断或行动是否有证据支持、是否可被用户或设计者确认。

### 自测问题
**Q1 中文：** 第 6 页的核心设计问题是什么？
**答：** 概念脊柱不是必须每层都复杂，而是让你知道要查哪里。某层为空不是失败，而是分析结果：例如没有记忆、没有适应、没有工具，都说明系统边界。
**Q1 English:** What is the core design issue on page 6?
**Answer:** The spine is a checklist for inspecting the system. It covers human involvement, sensing, context, memory, knowledge, model, planning, tools, action, environment, feedback, and adaptation.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Empty layer / 空层：某一层不存在或只是占位，同样是有意义的系统分析发现。
**Q2 English:** What is the most important concept on this page?
**Answer:** Empty layer: 某一层不存在或只是占位，同样是有意义的系统分析发现。

## 第 7 页：Layers 1 and 2: the human and sensing

Source ID: `src-a5decf9f86a2-pdf_page-00007`

![PDF page 7](../assets/pages/page_007.png)

### 原文
```text
Layers 1 and 2: the human and sensing

Lecture 02 · The spine on the scanner

Sensing starts with the person’s goal and the signals available.

• The person wants a clean copy of the page and 

brings a mental model shaped by the last 
scanner they used.

• In this example, the camera supplies thirty 
frames a second; motion and orientation 
sensors indicate whether the phone is steady 
and level.

• Touch adds shutter taps and corner drags. 

Property 1 holds because sensing goes beyond 
explicit commands: nobody has to say “this is a 
page”.
```

### 完整中文翻译
第 1 层和第 2 层：人和感知。

第 2 讲 - 扫描器上的脊柱。

感知从人的目标和可用信号开始。

- 用户想得到一份干净的页面副本，并带着由上一次使用的扫描器塑造出的心理模型。
- 在这个例子中，相机每秒提供 30 帧；运动和方向传感器指示手机是否稳定和水平。
- 触摸输入包括快门点击和角点拖拽。属性 1 成立，因为感知超出了显式命令：没有人需要说“这是一页纸”。

### 中文释义
这页把 scanner 的前两层展开。人带着目标和心理模型进入系统；系统通过相机、运动传感器、方向传感器和触摸收集信号。这里的智能不是用户明确命令，而是系统从信号中看出“页面”。

### English Explanation
The scanner begins with the person's goal and available signals. Sensing goes beyond explicit commands because the system detects a page without the user saying so.

### 概念解析
- **Sensing beyond commands / 超越命令的感知**：系统收集环境、身体或行为信号，而不只是执行用户显式指令。
- **Mental model / 心理模型**：用户对扫描器如何工作的预期，会影响他们如何操作和理解错误。

### 自测问题
**Q1 中文：** 第 7 页的核心设计问题是什么？
**答：** 这页把 scanner 的前两层展开。人带着目标和心理模型进入系统；系统通过相机、运动传感器、方向传感器和触摸收集信号。这里的智能不是用户明确命令，而是系统从信号中看出“页面”。
**Q1 English:** What is the core design issue on page 7?
**Answer:** The scanner begins with the person's goal and available signals. Sensing goes beyond explicit commands because the system detects a page without the user saying so.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Sensing beyond commands / 超越命令的感知：系统收集环境、身体或行为信号，而不只是执行用户显式指令。
**Q2 English:** What is the most important concept on this page?
**Answer:** Sensing beyond commands: 系统收集环境、身体或行为信号，而不只是执行用户显式指令。

## 第 8 页：Layers 3 to 5: context, memory and knowledge

Source ID: `src-a5decf9f86a2-pdf_page-00008`

![PDF page 8](../assets/pages/page_008.png)

### 原文
```text
Layers 3 to 5: context, memory and knowledge

Lecture 02 · The spine on the scanner

Context, memory and knowledge change how the same frame is interpreted.

• Context describes the current situation: is this 

the first page or the fifth, in portrait or landscape, 
under a lamp?

• Memory retains information between uses, such 

as your last page size, preferred filter and 
destination folder.

• Knowledge supplies language data for text 
recognition and standard page sizes. These 
layers add information beyond the current frame.
```

### 完整中文翻译
第 3 到第 5 层：上下文、记忆和知识。

第 2 讲 - 扫描器上的脊柱。

上下文、记忆和知识会改变同一帧画面的解释方式。

- 上下文描述当前情境：这是第一页还是第五页？竖屏还是横屏？是否在台灯下？
- 记忆保留跨使用的信息，例如你上一次的页面尺寸、偏好的滤镜和目标文件夹。
- 知识提供文字识别所需的语言数据和标准页面尺寸。这些层加入了当前画面之外的信息。

### 中文释义
同一张图像不只由像素决定。上下文告诉系统当前情况，记忆给出个人历史，知识提供一般规则。三者都会影响扫描器如何解释边界、方向和文字。

### English Explanation
Context, memory, and knowledge add information beyond the current frame. They shape how the scanner interprets page size, orientation, filtering, and text recognition.

### 概念解析
- **Context / 上下文**：当前任务和环境条件，例如第几页、方向、光照。
- **Memory / 记忆**：系统跨次保留的用户偏好或历史。
- **Knowledge / 知识**：通用语言、页面尺寸或领域规则。

### 自测问题
**Q1 中文：** 第 8 页的核心设计问题是什么？
**答：** 同一张图像不只由像素决定。上下文告诉系统当前情况，记忆给出个人历史，知识提供一般规则。三者都会影响扫描器如何解释边界、方向和文字。
**Q1 English:** What is the core design issue on page 8?
**Answer:** Context, memory, and knowledge add information beyond the current frame. They shape how the scanner interprets page size, orientation, filtering, and text recognition.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Context / 上下文：当前任务和环境条件，例如第几页、方向、光照。
**Q2 English:** What is the most important concept on this page?
**Answer:** Context: 当前任务和环境条件，例如第几页、方向、光照。

## 第 9 页：Layer 6: the model

Source ID: `src-a5decf9f86a2-pdf_page-00009`

![PDF page 9](../assets/pages/page_009.png)

### 原文
```text
Layer 6: the model

Lecture 02 · The spine on the scanner

The model turns signals into claims about the page.

• Edge detection identifies strong edges (Canny, 
1986). The scanner fits a quadrilateral: a four-
sided candidate for the page boundary.

• Perspective estimation computes the transform 

that flattens the tilted page. Text recognition
then reads its characters; Tesseract is one 
example (Smith, 2007).

• Property 2, interpretation under uncertainty, 

applies to every step: the boundary, tilt or 
recognised word can be wrong.

Canny (1986); Smith (2007).
```

### 完整中文翻译
第 6 层：模型。

第 2 讲 - 扫描器上的脊柱。

模型把信号转化为关于页面的主张。

- 边缘检测识别强边缘（Canny，1986）。扫描器拟合一个四边形，也就是页面边界的四边候选。
- 透视估计计算把倾斜页面压平的变换。随后文字识别读取字符；Tesseract 是一个例子（Smith，2007）。
- 属性 2，也就是不确定性下的解释，适用于每一步：边界、倾斜角或识别出的词都可能出错。

Canny（1986）；Smith（2007）。

### 中文释义
模型层负责把传感数据变成判断：哪里是纸张边界、如何校正透视、文字是什么。每个判断都是概率性的，不是绝对真相，所以后续界面需要让用户检查和修正。

### English Explanation
The model turns signals into claims: edges, quadrilaterals, perspective transforms, and recognized text. Each claim is uncertain and can be wrong.

### 概念解析
- **Edge detection / 边缘检测**：识别图像中强烈变化的边界，用于找页面轮廓。
- **Perspective estimation / 透视估计**：计算如何把斜拍页面变换成平整视图。
- **OCR / 光学字符识别**：从图像中识别文字，Tesseract 是经典例子。

### 自测问题
**Q1 中文：** 第 9 页的核心设计问题是什么？
**答：** 模型层负责把传感数据变成判断：哪里是纸张边界、如何校正透视、文字是什么。每个判断都是概率性的，不是绝对真相，所以后续界面需要让用户检查和修正。
**Q1 English:** What is the core design issue on page 9?
**Answer:** The model turns signals into claims: edges, quadrilaterals, perspective transforms, and recognized text. Each claim is uncertain and can be wrong.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Edge detection / 边缘检测：识别图像中强烈变化的边界，用于找页面轮廓。
**Q2 English:** What is the most important concept on this page?
**Answer:** Edge detection: 识别图像中强烈变化的边界，用于找页面轮廓。

## 第 10 页：Layers 7 and 8: planning and action

Source ID: `src-a5decf9f86a2-pdf_page-00010`

![PDF page 10](../assets/pages/page_010.png)

### 原文
```text
Layers 7 and 8: planning and action

Lecture 02 · The spine on the scanner

Planning chooses the next step; action makes it happen.

• Planning and decision determine whether to 
capture now, wait for a steadier frame, ask the 
person or make an assumption.

• Tools and action crop, rotate, flatten, enhance, 
recognise, save and share the page; the chosen 
inference changes what they do.

• The output channel carries the result to the 
person: a spatial overlay, an informational 
message or, in another system, a physical motor.
```

### 完整中文翻译
第 7 层和第 8 层：规划与行动。

第 2 讲 - 扫描器上的脊柱。

规划选择下一步；行动让它发生。

- 规划和决策决定是现在捕捉、等待更稳定的一帧、询问用户，还是做出假设。
- 工具和行动会裁剪、旋转、压平、增强、识别、保存并分享页面；选定的推断会改变它们做什么。
- 输出通道把结果传给人：空间覆盖层、信息消息，或者在其他系统中是物理电机。

### 中文释义
模型只是提出解释，规划层决定怎么处理解释，行动层真正改变状态。扫描器可以等一等、自动拍摄、提示用户或直接裁剪。不同选择会改变用户控制感和错误成本。

### English Explanation
Planning chooses the next step and action executes it. The scanner may capture, wait, ask, assume, crop, rotate, recognize, save, or share through different output channels.

### 概念解析
- **Planning / 规划**：根据目标、不确定性和上下文选择下一步。
- **Action / 行动**：系统实际改变图像、文件、界面或外部环境的操作。

### 自测问题
**Q1 中文：** 第 10 页的核心设计问题是什么？
**答：** 模型只是提出解释，规划层决定怎么处理解释，行动层真正改变状态。扫描器可以等一等、自动拍摄、提示用户或直接裁剪。不同选择会改变用户控制感和错误成本。
**Q1 English:** What is the core design issue on page 10?
**Answer:** Planning chooses the next step and action executes it. The scanner may capture, wait, ask, assume, crop, rotate, recognize, save, or share through different output channels.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Planning / 规划：根据目标、不确定性和上下文选择下一步。
**Q2 English:** What is the most important concept on this page?
**Answer:** Planning: 根据目标、不确定性和上下文选择下一步。

## 第 11 页：Layers 9 to 11: closing the loop

Source ID: `src-a5decf9f86a2-pdf_page-00011`

![PDF page 11](../assets/pages/page_011.png)

### 原文
```text
Layers 9 to 11: closing the loop

Lecture 02 · The spine on the scanner

The person’s response closes the loop at two timescales.

• The environment now contains a cropped 

image, which may be right or wrong.

• Feedback closes the immediate loop: the person 
drags a corner, retakes or accepts the scan, and 
the system responds by re-cropping when 
needed.

• Adaptation changes behaviour over time as 

page size, filter and folder become defaults. This 
human response is Property 4; without it, the 
scanner is a pipeline.
```

### 完整中文翻译
第 9 到第 11 层：闭合循环。

第 2 讲 - 扫描器上的脊柱。

人的回应在两个时间尺度上闭合循环。

- 环境现在包含一张裁剪后的图片，它可能正确，也可能错误。
- 反馈闭合即时循环：用户拖拽角点、重新拍摄或接受扫描，系统在需要时重新裁剪。
- 适应会随着时间改变行为，例如页面尺寸、滤镜和文件夹成为默认选项。人的回应就是属性 4；没有它，扫描器只是流水线。

### 中文释义
闭环意味着用户不是最后的旁观者，而是能改变系统下一步。即时反馈是拖角、重拍、接受；长期适应是系统把偏好变成默认。

### English Explanation
The loop closes when the person's response changes what happens next. Immediate feedback supports re-cropping; adaptation changes defaults over time.

### 概念解析
- **Feedback / 反馈**：系统让人看到结果并允许回应。
- **Adaptation / 适应**：系统根据长期行为改变未来默认行为。
- **Pipeline / 流水线**：没有人的回应影响下一步的线性处理流程。

### 自测问题
**Q1 中文：** 第 11 页的核心设计问题是什么？
**答：** 闭环意味着用户不是最后的旁观者，而是能改变系统下一步。即时反馈是拖角、重拍、接受；长期适应是系统把偏好变成默认。
**Q1 English:** What is the core design issue on page 11?
**Answer:** The loop closes when the person's response changes what happens next. Immediate feedback supports re-cropping; adaptation changes defaults over time.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Feedback / 反馈：系统让人看到结果并允许回应。
**Q2 English:** What is the most important concept on this page?
**Answer:** Feedback: 系统让人看到结果并允许回应。

## 第 12 页：Tracing the mis-crop to its layer

Source ID: `src-a5decf9f86a2-pdf_page-00012`

![PDF page 12](../assets/pages/page_012.png)

### 原文
```text
Tracing the mis-crop to its layer

Lecture 02 · Worked example

Trace the symptom to a layer before choosing a fix.

• Sensing, context and model suggest different 

causes: a blurred frame, a wrong page 
assumption or the detector choosing the wrong 
edge.

• Action and feedback suggest different repairs: 

delay premature auto-capture, or enlarge a 
corner handle that the person cannot drag.

• In my experience, most “the AI got it wrong”

complaints live in action or feedback. Test each 
diagnosis by tracing the evidence across all five 
layers.
```

### 完整中文翻译
把裁剪错误追踪到它所在的层。

第 2 讲 - worked example。

先把症状追踪到某一层，再选择修复。

- 感知、上下文和模型暗示不同原因：模糊帧、错误的页面假设，或检测器选错了边。
- 行动和反馈暗示不同修复：延迟过早的自动捕捉，或放大用户拖不动的角点手柄。
- 根据讲者经验，大多数“AI 搞错了”的抱怨其实位于行动或反馈层。要通过跨五层追踪证据来测试每个诊断。

### 中文释义
同一个错误表象可以来自不同层，修复也完全不同。不要把所有问题归咎于模型。用户无法修正、系统过早行动、反馈控件太小，都可能被误认为“AI 错了”。

### English Explanation
The same visible symptom can come from sensing, context, model, action, or feedback. The fix depends on the diagnosed layer.

### 概念解析
- **Symptom vs cause / 症状与原因**：看到的错误只是表象，真正原因需要沿层追踪证据。
- **Action/feedback failure / 行动或反馈失败**：系统行动时机或用户修正路径设计不当，常被误报为模型失败。

### 自测问题
**Q1 中文：** 第 12 页的核心设计问题是什么？
**答：** 同一个错误表象可以来自不同层，修复也完全不同。不要把所有问题归咎于模型。用户无法修正、系统过早行动、反馈控件太小，都可能被误认为“AI 错了”。
**Q1 English:** What is the core design issue on page 12?
**Answer:** The same visible symptom can come from sensing, context, model, action, or feedback. The fix depends on the diagnosed layer.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Symptom vs cause / 症状与原因：看到的错误只是表象，真正原因需要沿层追踪证据。
**Q2 English:** What is the most important concept on this page?
**Answer:** Symptom vs cause: 看到的错误只是表象，真正原因需要沿层追踪证据。

## 第 13 页：Intelligence can sit at any layer

Source ID: `src-a5decf9f86a2-pdf_page-00013`

![PDF page 13](../assets/pages/page_013.png)

### 原文
```text
Intelligence can sit at any layer

Lecture 02 · The spine

Locate the inference, then inspect the layers around it.

• The document scanner infers the page 
boundary in the model layer; a learning 
thermostat infers your schedule through 
memory and adaptation.

• A coding agent uses inference in planning and 
tool use to decide which file to open, which test 
to run and whether to continue.

• The auto-brightness example adapts without 

interpreting your intent or task. Under our 
working definition, adaptation alone does not 
make it an intelligent interactive system.
```

### 完整中文翻译
智能可以位于任何层。

第 2 讲 - 脊柱。

定位推断，然后检查它周围的层。

- 文档扫描器在模型层推断页面边界；学习型恒温器通过记忆和适应推断你的日程。
- 编码智能体在规划和工具使用中进行推断，决定打开哪个文件、运行哪个测试以及是否继续。
- 自动亮度例子会适应，但并不解释你的意图或任务。按我们的工作定义，只有适应并不足以让它成为智能交互系统。

### 中文释义
智能不总在模型层。它可以在记忆、适应、规划、工具使用中出现。判断时先问：系统到底在哪里推断了什么？单纯自动适应不一定满足智能交互定义。

### English Explanation
Inference can appear in different layers: model, memory, adaptation, planning, or tool use. Adaptation alone is not enough under the working definition.

### 概念解析
- **Locate the inference / 定位推断**：分析系统时先找出哪一层在做不确定解释。
- **Adaptation alone / 单独适应**：系统改变行为但没有解释意图或任务，不一定构成智能交互。

### 自测问题
**Q1 中文：** 第 13 页的核心设计问题是什么？
**答：** 智能不总在模型层。它可以在记忆、适应、规划、工具使用中出现。判断时先问：系统到底在哪里推断了什么？单纯自动适应不一定满足智能交互定义。
**Q1 English:** What is the core design issue on page 13?
**Answer:** Inference can appear in different layers: model, memory, adaptation, planning, or tool use. Adaptation alone is not enough under the working definition.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Locate the inference / 定位推断：分析系统时先找出哪一层在做不确定解释。
**Q2 English:** What is the most important concept on this page?
**Answer:** Locate the inference: 分析系统时先找出哪一层在做不确定解释。

## 第 14 页：One scale of autonomy

Source ID: `src-a5decf9f86a2-pdf_page-00014`

![PDF page 14](../assets/pages/page_014.png)

### 原文
```text
One scale of autonomy

Lecture 02 · Simple, agentic, multi-agent

Choose the simplest design that does the job.

• A simple system makes one inference in one 
turn, then the person decides what happens 
next.

• An agentic system observes, decides, acts with 
tools, checks the result and continues until it 
meets a goal or stops to ask.

• A multi-agent system coordinates several such 
loops. This is a structural choice whose added 
coordination must earn its place.

Russell & Norvig (2020); Anthropic (2024), practitioner guidance.
```

### 完整中文翻译
一条自主性尺度。

第 2 讲 - 简单、智能体、多智能体。

选择能完成工作的最简单设计。

- 简单系统在一次互动中做一次推断，然后由人决定接下来发生什么。
- 智能体系统会观察、决策、使用工具行动、检查结果，并持续到达到目标或停下来询问。
- 多智能体系统协调多个这样的循环。这是一种结构选择，额外协调必须证明自己值得存在。

Russell & Norvig（2020）；Anthropic（2024）实践指南。

### 中文释义
自主性不是越高越好。简单系统、agentic system、多智能体系统代表不同复杂度。课程给出的设计原则是：先选择足够简单的结构，只有当额外自治和协调真的带来收益时再升级。

### English Explanation
The autonomy scale runs from simple systems to agentic systems to multi-agent systems. The lecture's design principle is to choose the simplest design that does the job.

### 概念解析
- **Agentic system / 智能体系统**：能观察、决策、调用工具、检查结果并继续推进目标的系统。
- **Multi-agent system / 多智能体系统**：多个智能体循环之间需要协调的系统。

### 自测问题
**Q1 中文：** 第 14 页的核心设计问题是什么？
**答：** 自主性不是越高越好。简单系统、agentic system、多智能体系统代表不同复杂度。课程给出的设计原则是：先选择足够简单的结构，只有当额外自治和协调真的带来收益时再升级。
**Q1 English:** What is the core design issue on page 14?
**Answer:** The autonomy scale runs from simple systems to agentic systems to multi-agent systems. The lecture's design principle is to choose the simplest design that does the job.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Agentic system / 智能体系统：能观察、决策、调用工具、检查结果并继续推进目标的系统。
**Q2 English:** What is the most important concept on this page?
**Answer:** Agentic system: 能观察、决策、调用工具、检查结果并继续推进目标的系统。

## 第 15 页：The scanner at three points on the scale

Source ID: `src-a5decf9f86a2-pdf_page-00015`

![PDF page 15](../assets/pages/page_015.png)

### 原文
```text
The scanner at three points on the scale

Lecture 02 · Simple, agentic, multi-agent

Ask whether extra autonomy earns its cost.

• With the simple scanner, you point the phone, it 

finds and crops the page, and you correct a 
corner if needed.

• With an agentic scanner, you say “file this 

receipt”; it scans, reads, checks and files, asking 
when it is unsure.

• The multi-agent design assigns scanning, 

reading, policy checking, filing and reporting to 
five loops. Because each step depends on the 
previous one, five loops add hand-overs but no 
benefit.
```

### 完整中文翻译
扫描器在自主性尺度上的三个位置。

第 2 讲 - 简单、智能体、多智能体。

问额外自主性是否值得它的成本。

- 简单扫描器：你把手机对准页面，它发现并裁剪页面，需要时你修正一个角点。
- 智能体扫描器：你说“归档这张收据”；它扫描、读取、检查并归档，不确定时询问。
- 多智能体设计把扫描、读取、规则检查、归档和报告分配给五个循环。因为每一步依赖前一步，五个循环增加交接，却没有带来收益。

### 中文释义
这个例子说明多智能体不是高级默认答案。如果任务步骤强依赖、线性推进，把它拆成多个 agent 可能只增加交接和故障点。

### English Explanation
The scanner example shows that multi-agent design is not automatically better. If steps are sequential and dependent, extra loops add hand-offs without benefit.

### 概念解析
- **Smallest sufficient design / 最小充分设计**：能完成任务且复杂度最低的设计。
- **Hand-off cost / 交接成本**：多个循环之间传递状态和责任带来的额外复杂度。

### 自测问题
**Q1 中文：** 第 15 页的核心设计问题是什么？
**答：** 这个例子说明多智能体不是高级默认答案。如果任务步骤强依赖、线性推进，把它拆成多个 agent 可能只增加交接和故障点。
**Q1 English:** What is the core design issue on page 15?
**Answer:** The scanner example shows that multi-agent design is not automatically better. If steps are sequential and dependent, extra loops add hand-offs without benefit.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Smallest sufficient design / 最小充分设计：能完成任务且复杂度最低的设计。
**Q2 English:** What is the most important concept on this page?
**Answer:** Smallest sufficient design: 能完成任务且复杂度最低的设计。

## 第 16 页：What moves along the scale

Source ID: `src-a5decf9f86a2-pdf_page-00016`

![PDF page 16](../assets/pages/page_016.png)

### 原文
```text
What moves along the scale

Lecture 02 · Simple, agentic, multi-agent

More autonomous steps create more work for inspection and recovery.

• In these scanner designs, initiative and 

inference rise: one proposal becomes several 
actions, and one inference becomes a chain of 
dependent inferences.

• Visibility and reversibility fall in the illustrated 

progression: inspecting one crop becomes 
reading a trace, while undoing one crop becomes 
undoing a sequence.

• The cost of being wrong rises too. Ask “would a 
simpler system do?” last, once you know the 
system, the control and the evidence.
```

### 完整中文翻译
沿自主性尺度移动时，什么发生变化。

第 2 讲 - 简单、智能体、多智能体。

更多自主步骤会为检查和恢复创造更多工作。

- 在这些扫描器设计中，主动权和推断上升：一个建议变成多个行动，一个推断变成一串相互依赖的推断。
- 在图示推进中，可见性和可撤销性下降：检查一次裁剪变成阅读轨迹，撤销一次裁剪变成撤销一连串操作。
- 错误成本也会上升。最后再问“更简单的系统是否足够？”，前提是你已经了解系统、控制和证据。

### 中文释义
自主性提升会把 L01 的四变量再次拉出来：主动权、推断上升，但可见性、可撤销性下降。设计者必须补上检查、日志、预览和恢复路径。

### English Explanation
As autonomy increases, initiative and inference rise while visibility and reversibility tend to fall. Inspection and recovery become more demanding.

### 概念解析
- **Inspection work / 检查工作**：用户或开发者为了理解系统行为必须阅读轨迹、日志、状态或证据。
- **Recovery work / 恢复工作**：系统出错后恢复正确状态所需的步骤和成本。

### 自测问题
**Q1 中文：** 第 16 页的核心设计问题是什么？
**答：** 自主性提升会把 L01 的四变量再次拉出来：主动权、推断上升，但可见性、可撤销性下降。设计者必须补上检查、日志、预览和恢复路径。
**Q1 English:** What is the core design issue on page 16?
**Answer:** As autonomy increases, initiative and inference rise while visibility and reversibility tend to fall. Inspection and recovery become more demanding.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Inspection work / 检查工作：用户或开发者为了理解系统行为必须阅读轨迹、日志、状态或证据。
**Q2 English:** What is the most important concept on this page?
**Answer:** Inspection work: 用户或开发者为了理解系统行为必须阅读轨迹、日志、状态或证据。

## 第 17 页：Your turn: place three systems

Source ID: `src-a5decf9f86a2-pdf_page-00017`

![PDF page 17](../assets/pages/page_017.png)

### 原文
```text
Your turn: place three systems

Lecture 02 · Interaction 2

Place each system on the scale and defend the smallest sufficient design.

• A is phone autocorrect, which replaces a word as 

you type. B reads your inbox, drafts replies, 
sends follow-ups approved in bulk and books 
meetings.

• C is a support “team”: separate bots route the 

query, search the manual, write the answer and 
check its tone.

• Take two minutes to classify each as simple, 
agentic or multi-agent and name the smallest 
design that would do. Then we will argue about 
B.
```

### 完整中文翻译
轮到你：放置三个系统。

第 2 讲 - 互动 2。

把每个系统放到尺度上，并为最小充分设计辩护。

- A 是手机自动更正，会在你打字时替换一个词。B 会读取你的收件箱、起草回复、批量发送已批准的跟进邮件并预订会议。
- C 是一个客服“团队”：独立 bot 分别负责路由问题、搜索手册、撰写答案和检查语气。
- 用两分钟把 A、B、C 分类为简单、智能体或多智能体，并说出足够完成任务的最小设计。然后课堂会争论 B。

### 中文释义
这页是把自主性尺度应用到真实系统。重点是分类后还要问：更简单的设计是否足够？例如 C 看似多智能体，但也许一个 agent 加工具就够。

### English Explanation
The activity asks students to classify systems on the autonomy scale and defend the smallest sufficient design.

### 概念解析
- **Classification by autonomy / 按自主性分类**：根据系统是否单次推断、是否持续行动、是否协调多个循环来分类。

### 自测问题
**Q1 中文：** 第 17 页的核心设计问题是什么？
**答：** 这页是把自主性尺度应用到真实系统。重点是分类后还要问：更简单的设计是否足够？例如 C 看似多智能体，但也许一个 agent 加工具就够。
**Q1 English:** What is the core design issue on page 17?
**Answer:** The activity asks students to classify systems on the autonomy scale and defend the smallest sufficient design.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Classification by autonomy / 按自主性分类：根据系统是否单次推断、是否持续行动、是否协调多个循环来分类。
**Q2 English:** What is the most important concept on this page?
**Answer:** Classification by autonomy: 根据系统是否单次推断、是否持续行动、是否协调多个循环来分类。

## 第 18 页：Every inference is a bet

Source ID: `src-a5decf9f86a2-pdf_page-00018`

![PDF page 18](../assets/pages/page_018.png)

### 原文
```text
Every inference is a bet

Lecture 02 · Uncertainty

Uncertainty is a design input whenever the system makes an inference.

• In this illustration, the detector holds a 

distribution over candidate quadrilaterals and 
shows the highest-scoring one: the person sees 
one confident-looking rectangle.

• Recognisers, recommenders and language 
models also choose among possible outputs. 
The person usually encounters the chosen 
inference without seeing all the alternatives.

• Intrinsic uncertainty means the system can still 
be wrong. Design what the person can see and 
do when its preferred interpretation fails.
```

### 完整中文翻译
每一次推断都是一次押注。

第 2 讲 - 不确定性。

只要系统进行推断，不确定性就是设计输入。

- 图示中，检测器在候选四边形上持有一个分布，并显示得分最高的一个；用户看到的是一个看起来很自信的矩形。
- 识别器、推荐器和语言模型也会在多个可能输出中选择。用户通常只遇到被选中的推断，看不到所有替代项。
- 内在不确定性意味着系统仍可能出错。要设计当首选解释失败时，用户能看见什么、能做什么。

### 中文释义
系统输出经常看起来确定，但内部其实是在多个候选中选择。设计不能只展示最终答案，还要考虑置信度、备选、纠错入口和失败后的用户行动。

### English Explanation
Inference is a bet among alternatives. Users often see only the chosen interpretation, so designers must expose what people can see and do when it fails.

### 概念解析
- **Uncertainty / 不确定性**：推断不是确定事实，而是在多个可能解释中选择。
- **Candidate distribution / 候选分布**：模型对多个可能结果的相对支持程度。

### 自测问题
**Q1 中文：** 第 18 页的核心设计问题是什么？
**答：** 系统输出经常看起来确定，但内部其实是在多个候选中选择。设计不能只展示最终答案，还要考虑置信度、备选、纠错入口和失败后的用户行动。
**Q1 English:** What is the core design issue on page 18?
**Answer:** Inference is a bet among alternatives. Users often see only the chosen interpretation, so designers must expose what people can see and do when it fails.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Uncertainty / 不确定性：推断不是确定事实，而是在多个可能解释中选择。
**Q2 English:** What is the most important concept on this page?
**Answer:** Uncertainty: 推断不是确定事实，而是在多个可能解释中选择。

## 第 19 页：Each layer's story for being wrong

Source ID: `src-a5decf9f86a2-pdf_page-00019`

![PDF page 19](../assets/pages/page_019.png)

### 原文
```text
Each layer's story for being wrong

Lecture 02 · Uncertainty

Every layer needs a visible route from error to correction.

• For sensing, context and model, show signal 

quality, assumptions and inferences with 
confidence, so the person can retry or reject a 
wrong interpretation.

• For planning and action, show what the system 

is about to do and scope its services when in 
doubt; support approval, dismissal and 
correction.

• For feedback and adaptation, confirm that 
corrections were taken and provide global 
controls over what the system learns.

Course applications of Amershi et al. (2019).
```

### 完整中文翻译
每一层都需要说明自己如何出错。

第 2 讲 - 不确定性。

每一层都需要一条从错误到修正的可见路径。

- 对感知、上下文和模型，要显示信号质量、假设和带置信度的推断，让用户能重试或拒绝错误解释。
- 对规划和行动，要显示系统即将做什么，并在有疑问时限定服务范围；支持批准、忽略和修正。
- 对反馈和适应，要确认修正已被采纳，并提供对系统学习内容的全局控制。

这是对 Amershi 等（2019）指南的课程应用。

### 中文释义
这页把不确定性变成设计清单：不同层出错时，用户需要不同信息和控制。修复不是统一的“加解释”，而是要匹配层次。

### English Explanation
Each layer needs a visible route from error to correction. The appropriate control depends on whether the error is in sensing, inference, planning, action, feedback, or adaptation.

### 概念解析
- **Confidence / 置信度**：系统对某个推断的把握程度。
- **Global controls / 全局控制**：用户控制系统长期学习、默认设置和记忆的总开关或管理界面。

### 自测问题
**Q1 中文：** 第 19 页的核心设计问题是什么？
**答：** 这页把不确定性变成设计清单：不同层出错时，用户需要不同信息和控制。修复不是统一的“加解释”，而是要匹配层次。
**Q1 English:** What is the core design issue on page 19?
**Answer:** Each layer needs a visible route from error to correction. The appropriate control depends on whether the error is in sensing, inference, planning, action, feedback, or adaptation.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Confidence / 置信度：系统对某个推断的把握程度。
**Q2 English:** What is the most important concept on this page?
**Answer:** Confidence: 系统对某个推断的把握程度。

## 第 20 页：Reliable, safe, trustworthy: where this goes

Source ID: `src-a5decf9f86a2-pdf_page-00020`

![PDF page 20](../assets/pages/page_020.png)

### 原文
```text
Reliable, safe, trustworthy: where this goes

Lecture 02 · Book anchor

Design for reliable, safe and trustworthy interaction.

• Reliable means the system repeatedly does 
what it should, with evidence. Safe means its 
failures are contained and the cost of being 
wrong is bounded.

• Trustworthy means people can see enough to 

calibrate their reliance: they can judge how much 
to depend on the system.

• Shneiderman’s two-dimensional framework

(2022) places computer automation and human 
control on separate axes, allowing a design to be 
high on both.

After Shneiderman (2022); illustrative placements.
```

### 完整中文翻译
可靠、安全、可信：这会走向哪里。

第 2 讲 - 书籍锚点。

为可靠、安全、可信的互动而设计。

- 可靠意味着系统能重复做它应该做的事，并且有证据。安全意味着失败被限制住，错误成本有边界。
- 可信意味着人们能看到足够信息来校准依赖：他们能判断自己应该在多大程度上依赖系统。
- Shneiderman 的二维框架（2022）把计算机自动化和人类控制放在两条独立轴上，让一个设计可以在两者上都很高。

根据 Shneiderman（2022）；图中位置为示意。

### 中文释义
这页连接 Lecture 03。好的系统不是自动化越高越好，而是在可靠、安全、可信上有证据，并同时提高自动化与人的控制。

### English Explanation
Reliable, safe, and trustworthy interaction requires evidence, bounded failure costs, and enough visibility for calibrated reliance. Shneiderman's framework separates automation from human control.

### 概念解析
- **Calibrated reliance / 校准后的依赖**：用户根据系统实际可靠性决定依赖程度，既不过度信任也不过度不用。
- **Human control / 人类控制**：用户监督、批准、纠正和撤销系统行为的能力。

### 自测问题
**Q1 中文：** 第 20 页的核心设计问题是什么？
**答：** 这页连接 Lecture 03。好的系统不是自动化越高越好，而是在可靠、安全、可信上有证据，并同时提高自动化与人的控制。
**Q1 English:** What is the core design issue on page 20?
**Answer:** Reliable, safe, and trustworthy interaction requires evidence, bounded failure costs, and enough visibility for calibrated reliance. Shneiderman's framework separates automation from human control.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Calibrated reliance / 校准后的依赖：用户根据系统实际可靠性决定依赖程度，既不过度信任也不过度不用。
**Q2 English:** What is the most important concept on this page?
**Answer:** Calibrated reliance: 用户根据系统实际可靠性决定依赖程度，既不过度信任也不过度不用。

## 第 21 页：The twenty questions, shown once

Source ID: `src-a5decf9f86a2-pdf_page-00021`

![PDF page 21](../assets/pages/page_021.png)

### 原文
```text
The twenty questions, shown once

Lecture 02 · The target

Use the twenty questions to examine an unfamiliar system.

1–2  Problem and intelligence
1.  What problem is it solving?
2.  What makes it intelligent?

3–6  Sensing, context, memory, knowledge
3.  What does it sense?
4.  What context does it receive?
5.  What does it remember?
6.  What knowledge does it retrieve?

7–11  Models, planning, tools, actions, loops
7.  What does the model infer or generate?
8.  Does it plan?
9.  Which tools can it use?
10.  What actions can it take?
11.  What loop or workflow coordinates those actions?

12–16  The human’s place and control
12.  Where is the human in that loop?
13.  What control does the human retain?
14.  What happens when the system is uncertain?
15.  What happens when something fails?
16.  How can the user recover?

17–20  Evidence, consequences, simplicity
17.  What evidence shows the system helps?
18.  What are the safety and privacy implications?
19.  What conclusions does the evaluation actually support?
20.  Would a simpler, non-agentic system have been sufficient?

The list returns as a release checklist (Lecture 27) and a self-audit (Lecture 28); question 20 is always 
asked last.
```

### 完整中文翻译
二十个问题，只在这里完整展示一次。

第 2 讲 - 目标。

用二十个问题检查一个不熟悉的系统。

1-2 问题与智能：1. 它在解决什么问题？2. 什么让它算作智能？

3-6 感知、上下文、记忆、知识：3. 它感知什么？4. 它接收什么上下文？5. 它记住什么？6. 它检索什么知识？

7-11 模型、规划、工具、行动、循环：7. 模型推断或生成什么？8. 它会规划吗？9. 它能使用哪些工具？10. 它能采取什么行动？11. 什么循环或工作流协调这些行动？

12-16 人的位置与控制：12. 人在循环中的哪里？13. 人保留什么控制？14. 系统不确定时会发生什么？15. 出错时会发生什么？16. 用户如何恢复？

17-20 证据、后果、简单性：17. 什么证据表明系统有帮助？18. 安全和隐私影响是什么？19. 评估实际支持了什么结论？20. 更简单、非智能体系统是否已经足够？

这个清单会在第 27 讲作为发布检查表、第 28 讲作为自我审计再次出现；第 20 个问题总是最后问。

### 中文释义
这是项目和考试都很有用的检查表。它把概念脊柱、人的控制、证据、安全、隐私和最小充分设计统一成 20 个问题。特别注意第 20 个问题最后问，因为要先理解系统再判断是否过度设计。

### English Explanation
The twenty questions operationalize the spine as an analysis checklist. They cover problem, intelligence, layers, control, uncertainty, evidence, safety, privacy, evaluation, and simplicity.

### 概念解析
- **Release checklist / 发布检查表**：系统上线前用来确认问题、层次、控制、证据和风险的清单。
- **Self-audit / 自我审计**：设计者对自己系统进行结构化反思和证据核查。

### 自测问题
**Q1 中文：** 第 21 页的核心设计问题是什么？
**答：** 这是项目和考试都很有用的检查表。它把概念脊柱、人的控制、证据、安全、隐私和最小充分设计统一成 20 个问题。特别注意第 20 个问题最后问，因为要先理解系统再判断是否过度设计。
**Q1 English:** What is the core design issue on page 21?
**Answer:** The twenty questions operationalize the spine as an analysis checklist. They cover problem, intelligence, layers, control, uncertainty, evidence, safety, privacy, evaluation, and simplicity.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Release checklist / 发布检查表：系统上线前用来确认问题、层次、控制、证据和风险的清单。
**Q2 English:** What is the most important concept on this page?
**Answer:** Release checklist: 系统上线前用来确认问题、层次、控制、证据和风险的清单。

## 第 22 页：Your project: draft its spine

Source ID: `src-a5decf9f86a2-pdf_page-00022`

![PDF page 22](../assets/pages/page_022.png)

### 原文
```text
Your project: draft its spine

Lecture 02 · Project connection

Your project starts with one page that makes its interaction explicit.

• For your intended system, mark which spine 

layers exist and which are stubbed: 
placeholders for components your prototype will 
simulate.

• Mark where the intelligence sits, name its 

output channel and state what the user sees. 
Complete the five-slot sentence below.

• This page is unmarked. It seeds the Phase 1 

problem statement and the Phase 2 architecture 
diagram.
```

### 完整中文翻译
你的项目：起草它的脊柱。

第 2 讲 - 项目连接。

你的项目从一页明确互动的图开始。

- 对你的目标系统，标出哪些脊柱层存在，哪些只是 stub，也就是原型会模拟的组件占位符。
- 标出智能位于哪里，命名它的输出通道，并说明用户能看见什么。完成下面的五槽句子。
- 这一页不计分。它会为阶段 1 的问题陈述和阶段 2 的架构图打底。

### 中文释义
项目要求你把系统结构讲清楚：哪些层是真的，哪些是模拟占位；智能在哪里；用户通过什么通道看到什么。这样可以避免项目只停留在“我要做一个 AI app”。

### English Explanation
The project task asks students to make the interaction explicit by marking spine layers, stubs, intelligence location, output channel, and what the user sees.

### 概念解析
- **Stub / 占位组件**：原型中暂时模拟而非完整实现的组件。
- **Five-slot sentence / 五槽句子**：用于压缩说明系统感知、推断、行动、输出通道和用户可见内容的句式。

### 自测问题
**Q1 中文：** 第 22 页的核心设计问题是什么？
**答：** 项目要求你把系统结构讲清楚：哪些层是真的，哪些是模拟占位；智能在哪里；用户通过什么通道看到什么。这样可以避免项目只停留在“我要做一个 AI app”。
**Q1 English:** What is the core design issue on page 22?
**Answer:** The project task asks students to make the interaction explicit by marking spine layers, stubs, intelligence location, output channel, and what the user sees.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Stub / 占位组件：原型中暂时模拟而非完整实现的组件。
**Q2 English:** What is the most important concept on this page?
**Answer:** Stub: 原型中暂时模拟而非完整实现的组件。

## 第 23 页：What must be present, and how to look inside

Source ID: `src-a5decf9f86a2-pdf_page-00023`

![PDF page 23](../assets/pages/page_023.png)

### 原文
```text
What must be present, and how to look inside

Lecture 02 · Synthesis

The four properties define the system; the spine helps you analyse it.

• It must sense signals beyond commands, 

interpret under uncertainty, act through an 
output channel and close the loop with a 
human. All four must hold together.

• Walk the conceptual spine to locate the 

intelligence and ask what happens at each layer 
when an inference is wrong.

• An empty layer is a result of the analysis. Judge 

the system by what the interaction does for 
human activity.
```

### 完整中文翻译
必须具备什么，以及如何看进系统内部。

第 2 讲 - 综合。

四个属性定义系统；脊柱帮助你分析系统。

- 系统必须感知超出命令的信号，在不确定性下解释，通过输出通道行动，并与人闭合循环。四者必须同时成立。
- 沿概念脊柱行走，定位智能，并询问每一层在推断错误时会发生什么。
- 空层是分析结果。根据互动对人类活动产生的影响来评价系统。

### 中文释义
总结页：四属性回答“是不是智能交互系统”，概念脊柱回答“如何分析它”。最终评价仍回到人类活动，而不是只看模型技术。

### English Explanation
The synthesis combines the four properties with the spine. A system is judged by the interaction's effect on human activity, not only by technical performance.

### 概念解析
- **Human activity / 人类活动**：用户真正要完成的工作、理解、控制和恢复过程。

### 自测问题
**Q1 中文：** 第 23 页的核心设计问题是什么？
**答：** 总结页：四属性回答“是不是智能交互系统”，概念脊柱回答“如何分析它”。最终评价仍回到人类活动，而不是只看模型技术。
**Q1 English:** What is the core design issue on page 23?
**Answer:** The synthesis combines the four properties with the spine. A system is judged by the interaction's effect on human activity, not only by technical performance.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Human activity / 人类活动：用户真正要完成的工作、理解、控制和恢复过程。
**Q2 English:** What is the most important concept on this page?
**Answer:** Human activity: 用户真正要完成的工作、理解、控制和恢复过程。

## 第 24 页：References and further reading

Source ID: `src-a5decf9f86a2-pdf_page-00024`

![PDF page 24](../assets/pages/page_024.png)

### 原文
```text
References and further reading

Lecture 02 · References

These sources connect design claims to evidence.

Working definition, four properties, output channels and five-slot template: the module’s own definition, given on slides 4, 5, 10 and 22 of 
this lecture.

Shneiderman, B. (2022). Human-Centered AI. Oxford University Press. Read Part 1 (chapters 2–3); the reliable–safe–trustworthy goals and 
the two-dimensional human-centred AI (HCAI) framework follow in Part 2.

Russell, S., & Norvig, P. (2020). Artificial Intelligence: A Modern Approach (4th ed.). Pearson. Chapter 2: agents, environments, agent types.

Amershi, S., Weld, D., Vorvoreanu, M., Fourney, A., Nushi, B., Collisson, P., Suh, J., Iqbal, S., Bennett, P. N., Inkpen, K., Teevan, J., Kikin-
Gil, R., & Horvitz, E. (2019). Guidelines for Human-AI Interaction. CHI 2019, Paper 3.

Horvitz, E. (1999). Principles of Mixed-Initiative User Interfaces. CHI 1999, 159–166.

Anthropic (2024, 19 December). Building effective agents. anthropic.com/research/building-effective-agents (practitioner guidance; 
accessed 16 September 2026).

Canny, J. (1986). A Computational Approach to Edge Detection. IEEE Transactions on Pattern Analysis and Machine Intelligence, PAMI-
8(6), 679–698.

Smith, R. (2007). An Overview of the Tesseract OCR Engine. Proceedings of ICDAR 2007, 629–633.
```

### 完整中文翻译
参考文献与延伸阅读。

第 2 讲 - 参考文献。

这些来源把设计主张连接到证据。

工作定义、四个属性、输出通道和五槽模板：来自本模块自己的定义，见本讲第 4、5、10 和 22 页。

Shneiderman, B.（2022）。《Human-Centered AI》。Oxford University Press。阅读第 1 部分第 2-3 章；可靠、安全、可信目标以及二维 HCAI 框架在第 2 部分展开。

Russell, S., & Norvig, P.（2020）。《Artificial Intelligence: A Modern Approach》第 4 版。Pearson。第 2 章：智能体、环境和智能体类型。

Amershi 等（2019）。《Guidelines for Human-AI Interaction》。CHI 2019, Paper 3。

Horvitz, E.（1999）。《Principles of Mixed-Initiative User Interfaces》。CHI 1999，159-166。

Anthropic（2024 年 12 月 19 日）。《Building effective agents》。anthropic.com/research/building-effective-agents，实践指南；访问日期 2026 年 9 月 16 日。

Canny, J.（1986）。《A Computational Approach to Edge Detection》。IEEE TPAMI，PAMI-8(6)，679-698。

Smith, R.（2007）。《An Overview of the Tesseract OCR Engine》。ICDAR 2007，629-633。

### 中文释义
参考页显示本讲的三个来源群：HCAI 与可靠/安全/可信，智能体结构与自主性，扫描器案例中的边缘检测和 OCR。项目写作时可按主题选读。

### English Explanation
The references connect the lecture to human-centered AI, agents, mixed initiative, human-AI guidelines, edge detection, and OCR.

### 概念解析
- **Evidence anchor / 证据锚点**：课件主张背后的文献来源，可用于项目和复习时追溯。

### 自测问题
**Q1 中文：** 第 24 页的核心设计问题是什么？
**答：** 参考页显示本讲的三个来源群：HCAI 与可靠/安全/可信，智能体结构与自主性，扫描器案例中的边缘检测和 OCR。项目写作时可按主题选读。
**Q1 English:** What is the core design issue on page 24?
**Answer:** The references connect the lecture to human-centered AI, agents, mixed initiative, human-AI guidelines, edge detection, and OCR.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Evidence anchor / 证据锚点：课件主张背后的文献来源，可用于项目和复习时追溯。
**Q2 English:** What is the most important concept on this page?
**Answer:** Evidence anchor: 课件主张背后的文献来源，可用于项目和复习时追溯。

## 第 25 页：Optional viewing: agents acting alone

Source ID: `src-a5decf9f86a2-pdf_page-00025`

![PDF page 25](../assets/pages/page_025.png)

### 原文
```text
Optional viewing: agents acting alone

Follow what the system observes, plans and does, then examine human control.

• While watching, ask what it observed through 

its environment and sensing, and what 
context or memory mattered.

• Identify the tools and actions it could use. Ask 
where a human should see, stop or correct it 
through control and feedback.

• Discuss the implications of a system that can 
observe, plan, use tools, act and keep going 
beyond producing an answer.

Screenshot: Black Hat USA 2026 conference talk. Video, not part of the 50-minute lecture: 
youtube.com/watch?v=87DyyMV0kCY
```

### 完整中文翻译
可选观看：独立行动的智能体。

跟踪系统观察了什么、规划了什么、做了什么，然后检查人类控制。

- 观看时，询问它通过环境和感知观察到了什么，以及哪些上下文或记忆重要。
- 识别它能使用的工具和采取的行动。询问人应该在哪里看见、停止或纠正它，也就是通过控制和反馈介入。
- 讨论一个系统能够观察、规划、使用工具、行动并在产生答案之外继续运行，这意味着什么。

截图：Black Hat USA 2026 会议演讲。视频不是 50 分钟讲座的一部分：youtube.com/watch?v=87DyyMV0kCY。

### 中文释义
可选观看把本讲概念扩展到更强的 agents。重点不是视频本身，而是用概念脊柱追踪观察、上下文、记忆、工具、行动和人类控制。

### English Explanation
The optional viewing extends the spine to agents acting beyond answer generation. Students should inspect observation, planning, tool use, action, control, and feedback.

### 概念解析
- **Agent acting alone / 独立行动的智能体**：能够持续观察、规划和调用工具的系统，需要特别设计人类可见性与停止/纠错能力。

### 自测问题
**Q1 中文：** 第 25 页的核心设计问题是什么？
**答：** 可选观看把本讲概念扩展到更强的 agents。重点不是视频本身，而是用概念脊柱追踪观察、上下文、记忆、工具、行动和人类控制。
**Q1 English:** What is the core design issue on page 25?
**Answer:** The optional viewing extends the spine to agents acting beyond answer generation. Students should inspect observation, planning, tool use, action, control, and feedback.

**Q2 中文：** 本页最重要的概念是什么？
**答：** Agent acting alone / 独立行动的智能体：能够持续观察、规划和调用工具的系统，需要特别设计人类可见性与停止/纠错能力。
**Q2 English:** What is the most important concept on this page?
**Answer:** Agent acting alone: 能够持续观察、规划和调用工具的系统，需要特别设计人类可见性与停止/纠错能力。
