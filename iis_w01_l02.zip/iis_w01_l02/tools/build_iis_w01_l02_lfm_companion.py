from __future__ import annotations

import html
import json
import re
import shutil
import subprocess
from datetime import datetime
from pathlib import Path


PDF = Path(r"E:\UOB Artificial Intelligence\Intelligent Interactive Systems\Week 1\W01_L02_Ingredients_of_an_Intelligent_Interactive_System_v5_novideo.pdf")
SLUG = "iis_w01_l02"
TITLE = "Ingredients of an Intelligent Interactive System"
WORK = Path(r"E:\UOB Artificial Intelligence\Codex Workspace\learn_from_materials") / SLUG
KB = WORK / f"{SLUG}.learnkb"
ASSETS = WORK / "assets" / "pages"
DELIVERY = WORK / "delivery"
OUT_HTML = DELIVERY / "IIS_W01_L02_page_by_page_companion.html"
OUT_MD = DELIVERY / "IIS_W01_L02_page_by_page_companion.md"


PAGES = {
    1: {
        "title": "Ingredients of an Intelligent Interactive Systems",
        "translation": "智能交互系统的组成要素。\n\n智能交互系统 - 第 1 周 - 第 2 讲。\n\n伯明翰大学。\n\n本讲会打开系统内部，跟踪它与人的互动过程。\n\n- 把工作定义应用到一个具体系统上。\n- 沿着概念脊柱追踪一次失败，定位它属于哪一层。",
        "cn": "这一页给出本讲目标：从第 1 讲的用户体验框架转向系统内部结构。你要学会把一个智能交互系统拆成层次，并在系统出错时定位是哪一层导致失败。",
        "en": "This opening slide shifts from user-facing interaction to the system's internal ingredients. The lecture teaches students to apply the working definition and trace failures through layers.",
        "concepts": [["Conceptual spine / 概念脊柱", "一个逐层分析系统的检查表，用来追踪人、感知、上下文、模型、行动、反馈和适应之间的关系。"]],
    },
    2: {
        "title": "The mis-cropped page",
        "translation": "裁剪错误的页面。\n\n第 2 讲 - 引入。\n\n一次糟糕的裁剪给了我们一个可以调查的具体失败案例。\n\n- 你的手机识别出一页纸并进行裁剪，但这次扫描在一侧包含了一条桌面边缘。\n- 在互动 1 中，请投票判断负责出错的层：感知、上下文、模型、行动，还是反馈。\n- 保留你的第一个答案：我们会带着一种诊断错误的方法回到这一页。",
        "cn": "这页用手机扫描裁剪错误作为贯穿案例。重点不是马上猜“AI 错了”，而是把症状追踪到具体层：是传感输入模糊、上下文假设错、模型边缘检测错，还是用户无法修正反馈。",
        "en": "The mis-cropped scan is a concrete diagnostic case. The lecture will return to it after giving a layer-by-layer method for locating the cause of failure.",
        "concepts": [["Failure diagnosis / 失败诊断", "先描述症状，再定位到系统层次，最后选择修复方案。不同层出错需要不同修复。"]],
    },
    3: {
        "title": "From the frame to the box",
        "translation": "从框架到盒子内部。\n\n第 2 讲 - 中心问题。\n\n今天我们从用户体验移动到系统组成要素。\n\n- 第 1 讲用主动权、推断、可见性和可撤销性描述系统对人做了什么。\n- 中心问题：一个系统要同时算作智能并且交互式，必须具备什么？我们如何看进系统内部？\n- 概念脊柱提供逐层检查表，你现在可以应用它，以后也可以为它辩护。",
        "cn": "第 1 讲是外部评价：系统如何改变用户。第 2 讲是内部分析：系统由哪些层组成，智能放在哪里，失败如何穿过层传播。",
        "en": "Lecture 01 described effects on the person; Lecture 02 opens the box and asks what components must be present for a system to be both intelligent and interactive.",
        "concepts": [["Initiative, inference, visibility, reversibility / 主动权、推断、可见性、可撤销性", "第 1 讲的用户侧框架，在第 2 讲中会与系统内部层次连接起来。"]],
    },
    4: {
        "title": "The working definition",
        "translation": "工作定义。\n\n第 2 讲 - 定义。\n\n智能必须被设计进互动中。\n\n- 系统在人及其情境的循环中进行感知、解释、行动和适应。\n- 它关于意图、状态或偏好的模型是一种推断：它是对信号的最佳解释，并且可能出错。\n- 我们评价质量时，不只看模型准确率，也看互动对人类活动产生了什么影响。",
        "cn": "这一页给出本课对智能交互系统的工作定义。关键是 loop：系统不是离线做预测，而是在人的情境中感知、解释、行动、适应。模型输出永远是可错的推断。",
        "en": "The working definition treats intelligence as part of an interaction loop. The system senses, interprets, acts, and adapts with a person and context, while model accuracy is only one part of quality.",
        "concepts": [["Inference / 推断", "系统对信号作出的最佳解释，例如用户意图、当前状态或偏好；它不是事实本身，可能错误。"]],
    },
    5: {
        "title": "Four properties, all required",
        "translation": "四个属性，全部都必须具备。\n\n第 2 讲 - 定义。\n\n一个智能交互系统必须同时满足四个属性。\n\n1. 感知：收集超出显式命令之外的信号。\n2. 不确定性下的解释：推断一个没有被逐字说明的意图、偏好或情境，并且这种推断可能出错。\n3. 通过输出通道行动：系统根据推断改变自身行为，并通过信息、空间或物理通道到达人。\n4. 与人形成闭环：人的反应会改变系统接下来做什么。四个属性必须同时成立。",
        "cn": "这是本讲最核心的定义页。只有感知、解释、行动、闭环同时存在，才算智能交互系统。单纯自动化、单次预测或没有人类反馈的流水线都不完整。",
        "en": "The four required properties are sensing, interpretation under uncertainty, action through an output channel, and a closed human loop. They must hold together.",
        "concepts": [["Closed loop / 闭环", "系统输出影响人，人的反应又影响系统下一步行为。没有这个回路，系统只是 pipeline。"], ["Output channel / 输出通道", "系统把行动或信息传给人的方式，可以是信息、空间或物理通道。"]],
    },
    6: {
        "title": "The conceptual spine at a glance",
        "translation": "概念脊柱一览。\n\n第 2 讲 - 脊柱。\n\n概念脊柱是调查系统的检查表。\n\n- 从人、感知、上下文、记忆、知识和模型开始：谁参与其中？什么信号到达？什么被保留？什么被推断？\n- 继续看规划、工具和行动、环境、反馈和适应：接下来发生什么？人的反应如何改变系统？\n- 在每个连接处，检查控制、不确定性、验证、安全、隐私和评估。把它当分析工具；空层也是有意义的发现。",
        "cn": "概念脊柱不是必须每层都复杂，而是让你知道要查哪里。某层为空不是失败，而是分析结果：例如没有记忆、没有适应、没有工具，都说明系统边界。",
        "en": "The spine is a checklist for inspecting the system. It covers human involvement, sensing, context, memory, knowledge, model, planning, tools, action, environment, feedback, and adaptation.",
        "concepts": [["Empty layer / 空层", "某一层不存在或只是占位，同样是有意义的系统分析发现。"], ["Verification / 验证", "检查系统推断或行动是否有证据支持、是否可被用户或设计者确认。"]],
    },
    7: {
        "title": "Layers 1 and 2: the human and sensing",
        "translation": "第 1 层和第 2 层：人和感知。\n\n第 2 讲 - 扫描器上的脊柱。\n\n感知从人的目标和可用信号开始。\n\n- 用户想得到一份干净的页面副本，并带着由上一次使用的扫描器塑造出的心理模型。\n- 在这个例子中，相机每秒提供 30 帧；运动和方向传感器指示手机是否稳定和水平。\n- 触摸输入包括快门点击和角点拖拽。属性 1 成立，因为感知超出了显式命令：没有人需要说“这是一页纸”。",
        "cn": "这页把 scanner 的前两层展开。人带着目标和心理模型进入系统；系统通过相机、运动传感器、方向传感器和触摸收集信号。这里的智能不是用户明确命令，而是系统从信号中看出“页面”。",
        "en": "The scanner begins with the person's goal and available signals. Sensing goes beyond explicit commands because the system detects a page without the user saying so.",
        "concepts": [["Sensing beyond commands / 超越命令的感知", "系统收集环境、身体或行为信号，而不只是执行用户显式指令。"], ["Mental model / 心理模型", "用户对扫描器如何工作的预期，会影响他们如何操作和理解错误。"]],
    },
    8: {
        "title": "Layers 3 to 5: context, memory and knowledge",
        "translation": "第 3 到第 5 层：上下文、记忆和知识。\n\n第 2 讲 - 扫描器上的脊柱。\n\n上下文、记忆和知识会改变同一帧画面的解释方式。\n\n- 上下文描述当前情境：这是第一页还是第五页？竖屏还是横屏？是否在台灯下？\n- 记忆保留跨使用的信息，例如你上一次的页面尺寸、偏好的滤镜和目标文件夹。\n- 知识提供文字识别所需的语言数据和标准页面尺寸。这些层加入了当前画面之外的信息。",
        "cn": "同一张图像不只由像素决定。上下文告诉系统当前情况，记忆给出个人历史，知识提供一般规则。三者都会影响扫描器如何解释边界、方向和文字。",
        "en": "Context, memory, and knowledge add information beyond the current frame. They shape how the scanner interprets page size, orientation, filtering, and text recognition.",
        "concepts": [["Context / 上下文", "当前任务和环境条件，例如第几页、方向、光照。"], ["Memory / 记忆", "系统跨次保留的用户偏好或历史。"], ["Knowledge / 知识", "通用语言、页面尺寸或领域规则。"]],
    },
    9: {
        "title": "Layer 6: the model",
        "translation": "第 6 层：模型。\n\n第 2 讲 - 扫描器上的脊柱。\n\n模型把信号转化为关于页面的主张。\n\n- 边缘检测识别强边缘（Canny，1986）。扫描器拟合一个四边形，也就是页面边界的四边候选。\n- 透视估计计算把倾斜页面压平的变换。随后文字识别读取字符；Tesseract 是一个例子（Smith，2007）。\n- 属性 2，也就是不确定性下的解释，适用于每一步：边界、倾斜角或识别出的词都可能出错。\n\nCanny（1986）；Smith（2007）。",
        "cn": "模型层负责把传感数据变成判断：哪里是纸张边界、如何校正透视、文字是什么。每个判断都是概率性的，不是绝对真相，所以后续界面需要让用户检查和修正。",
        "en": "The model turns signals into claims: edges, quadrilaterals, perspective transforms, and recognized text. Each claim is uncertain and can be wrong.",
        "concepts": [["Edge detection / 边缘检测", "识别图像中强烈变化的边界，用于找页面轮廓。"], ["Perspective estimation / 透视估计", "计算如何把斜拍页面变换成平整视图。"], ["OCR / 光学字符识别", "从图像中识别文字，Tesseract 是经典例子。"]],
    },
    10: {
        "title": "Layers 7 and 8: planning and action",
        "translation": "第 7 层和第 8 层：规划与行动。\n\n第 2 讲 - 扫描器上的脊柱。\n\n规划选择下一步；行动让它发生。\n\n- 规划和决策决定是现在捕捉、等待更稳定的一帧、询问用户，还是做出假设。\n- 工具和行动会裁剪、旋转、压平、增强、识别、保存并分享页面；选定的推断会改变它们做什么。\n- 输出通道把结果传给人：空间覆盖层、信息消息，或者在其他系统中是物理电机。",
        "cn": "模型只是提出解释，规划层决定怎么处理解释，行动层真正改变状态。扫描器可以等一等、自动拍摄、提示用户或直接裁剪。不同选择会改变用户控制感和错误成本。",
        "en": "Planning chooses the next step and action executes it. The scanner may capture, wait, ask, assume, crop, rotate, recognize, save, or share through different output channels.",
        "concepts": [["Planning / 规划", "根据目标、不确定性和上下文选择下一步。"], ["Action / 行动", "系统实际改变图像、文件、界面或外部环境的操作。"]],
    },
    11: {
        "title": "Layers 9 to 11: closing the loop",
        "translation": "第 9 到第 11 层：闭合循环。\n\n第 2 讲 - 扫描器上的脊柱。\n\n人的回应在两个时间尺度上闭合循环。\n\n- 环境现在包含一张裁剪后的图片，它可能正确，也可能错误。\n- 反馈闭合即时循环：用户拖拽角点、重新拍摄或接受扫描，系统在需要时重新裁剪。\n- 适应会随着时间改变行为，例如页面尺寸、滤镜和文件夹成为默认选项。人的回应就是属性 4；没有它，扫描器只是流水线。",
        "cn": "闭环意味着用户不是最后的旁观者，而是能改变系统下一步。即时反馈是拖角、重拍、接受；长期适应是系统把偏好变成默认。",
        "en": "The loop closes when the person's response changes what happens next. Immediate feedback supports re-cropping; adaptation changes defaults over time.",
        "concepts": [["Feedback / 反馈", "系统让人看到结果并允许回应。"], ["Adaptation / 适应", "系统根据长期行为改变未来默认行为。"], ["Pipeline / 流水线", "没有人的回应影响下一步的线性处理流程。"]],
    },
    12: {
        "title": "Tracing the mis-crop to its layer",
        "translation": "把裁剪错误追踪到它所在的层。\n\n第 2 讲 - worked example。\n\n先把症状追踪到某一层，再选择修复。\n\n- 感知、上下文和模型暗示不同原因：模糊帧、错误的页面假设，或检测器选错了边。\n- 行动和反馈暗示不同修复：延迟过早的自动捕捉，或放大用户拖不动的角点手柄。\n- 根据讲者经验，大多数“AI 搞错了”的抱怨其实位于行动或反馈层。要通过跨五层追踪证据来测试每个诊断。",
        "cn": "同一个错误表象可以来自不同层，修复也完全不同。不要把所有问题归咎于模型。用户无法修正、系统过早行动、反馈控件太小，都可能被误认为“AI 错了”。",
        "en": "The same visible symptom can come from sensing, context, model, action, or feedback. The fix depends on the diagnosed layer.",
        "concepts": [["Symptom vs cause / 症状与原因", "看到的错误只是表象，真正原因需要沿层追踪证据。"], ["Action/feedback failure / 行动或反馈失败", "系统行动时机或用户修正路径设计不当，常被误报为模型失败。"]],
    },
    13: {
        "title": "Intelligence can sit at any layer",
        "translation": "智能可以位于任何层。\n\n第 2 讲 - 脊柱。\n\n定位推断，然后检查它周围的层。\n\n- 文档扫描器在模型层推断页面边界；学习型恒温器通过记忆和适应推断你的日程。\n- 编码智能体在规划和工具使用中进行推断，决定打开哪个文件、运行哪个测试以及是否继续。\n- 自动亮度例子会适应，但并不解释你的意图或任务。按我们的工作定义，只有适应并不足以让它成为智能交互系统。",
        "cn": "智能不总在模型层。它可以在记忆、适应、规划、工具使用中出现。判断时先问：系统到底在哪里推断了什么？单纯自动适应不一定满足智能交互定义。",
        "en": "Inference can appear in different layers: model, memory, adaptation, planning, or tool use. Adaptation alone is not enough under the working definition.",
        "concepts": [["Locate the inference / 定位推断", "分析系统时先找出哪一层在做不确定解释。"], ["Adaptation alone / 单独适应", "系统改变行为但没有解释意图或任务，不一定构成智能交互。"]],
    },
    14: {
        "title": "One scale of autonomy",
        "translation": "一条自主性尺度。\n\n第 2 讲 - 简单、智能体、多智能体。\n\n选择能完成工作的最简单设计。\n\n- 简单系统在一次互动中做一次推断，然后由人决定接下来发生什么。\n- 智能体系统会观察、决策、使用工具行动、检查结果，并持续到达到目标或停下来询问。\n- 多智能体系统协调多个这样的循环。这是一种结构选择，额外协调必须证明自己值得存在。\n\nRussell & Norvig（2020）；Anthropic（2024）实践指南。",
        "cn": "自主性不是越高越好。简单系统、agentic system、多智能体系统代表不同复杂度。课程给出的设计原则是：先选择足够简单的结构，只有当额外自治和协调真的带来收益时再升级。",
        "en": "The autonomy scale runs from simple systems to agentic systems to multi-agent systems. The lecture's design principle is to choose the simplest design that does the job.",
        "concepts": [["Agentic system / 智能体系统", "能观察、决策、调用工具、检查结果并继续推进目标的系统。"], ["Multi-agent system / 多智能体系统", "多个智能体循环之间需要协调的系统。"]],
    },
    15: {
        "title": "The scanner at three points on the scale",
        "translation": "扫描器在自主性尺度上的三个位置。\n\n第 2 讲 - 简单、智能体、多智能体。\n\n问额外自主性是否值得它的成本。\n\n- 简单扫描器：你把手机对准页面，它发现并裁剪页面，需要时你修正一个角点。\n- 智能体扫描器：你说“归档这张收据”；它扫描、读取、检查并归档，不确定时询问。\n- 多智能体设计把扫描、读取、规则检查、归档和报告分配给五个循环。因为每一步依赖前一步，五个循环增加交接，却没有带来收益。",
        "cn": "这个例子说明多智能体不是高级默认答案。如果任务步骤强依赖、线性推进，把它拆成多个 agent 可能只增加交接和故障点。",
        "en": "The scanner example shows that multi-agent design is not automatically better. If steps are sequential and dependent, extra loops add hand-offs without benefit.",
        "concepts": [["Smallest sufficient design / 最小充分设计", "能完成任务且复杂度最低的设计。"], ["Hand-off cost / 交接成本", "多个循环之间传递状态和责任带来的额外复杂度。"]],
    },
    16: {
        "title": "What moves along the scale",
        "translation": "沿自主性尺度移动时，什么发生变化。\n\n第 2 讲 - 简单、智能体、多智能体。\n\n更多自主步骤会为检查和恢复创造更多工作。\n\n- 在这些扫描器设计中，主动权和推断上升：一个建议变成多个行动，一个推断变成一串相互依赖的推断。\n- 在图示推进中，可见性和可撤销性下降：检查一次裁剪变成阅读轨迹，撤销一次裁剪变成撤销一连串操作。\n- 错误成本也会上升。最后再问“更简单的系统是否足够？”，前提是你已经了解系统、控制和证据。",
        "cn": "自主性提升会把 L01 的四变量再次拉出来：主动权、推断上升，但可见性、可撤销性下降。设计者必须补上检查、日志、预览和恢复路径。",
        "en": "As autonomy increases, initiative and inference rise while visibility and reversibility tend to fall. Inspection and recovery become more demanding.",
        "concepts": [["Inspection work / 检查工作", "用户或开发者为了理解系统行为必须阅读轨迹、日志、状态或证据。"], ["Recovery work / 恢复工作", "系统出错后恢复正确状态所需的步骤和成本。"]],
    },
    17: {
        "title": "Your turn: place three systems",
        "translation": "轮到你：放置三个系统。\n\n第 2 讲 - 互动 2。\n\n把每个系统放到尺度上，并为最小充分设计辩护。\n\n- A 是手机自动更正，会在你打字时替换一个词。B 会读取你的收件箱、起草回复、批量发送已批准的跟进邮件并预订会议。\n- C 是一个客服“团队”：独立 bot 分别负责路由问题、搜索手册、撰写答案和检查语气。\n- 用两分钟把 A、B、C 分类为简单、智能体或多智能体，并说出足够完成任务的最小设计。然后课堂会争论 B。",
        "cn": "这页是把自主性尺度应用到真实系统。重点是分类后还要问：更简单的设计是否足够？例如 C 看似多智能体，但也许一个 agent 加工具就够。",
        "en": "The activity asks students to classify systems on the autonomy scale and defend the smallest sufficient design.",
        "concepts": [["Classification by autonomy / 按自主性分类", "根据系统是否单次推断、是否持续行动、是否协调多个循环来分类。"]],
    },
    18: {
        "title": "Every inference is a bet",
        "translation": "每一次推断都是一次押注。\n\n第 2 讲 - 不确定性。\n\n只要系统进行推断，不确定性就是设计输入。\n\n- 图示中，检测器在候选四边形上持有一个分布，并显示得分最高的一个；用户看到的是一个看起来很自信的矩形。\n- 识别器、推荐器和语言模型也会在多个可能输出中选择。用户通常只遇到被选中的推断，看不到所有替代项。\n- 内在不确定性意味着系统仍可能出错。要设计当首选解释失败时，用户能看见什么、能做什么。",
        "cn": "系统输出经常看起来确定，但内部其实是在多个候选中选择。设计不能只展示最终答案，还要考虑置信度、备选、纠错入口和失败后的用户行动。",
        "en": "Inference is a bet among alternatives. Users often see only the chosen interpretation, so designers must expose what people can see and do when it fails.",
        "concepts": [["Uncertainty / 不确定性", "推断不是确定事实，而是在多个可能解释中选择。"], ["Candidate distribution / 候选分布", "模型对多个可能结果的相对支持程度。"]],
    },
    19: {
        "title": "Each layer's story for being wrong",
        "translation": "每一层都需要说明自己如何出错。\n\n第 2 讲 - 不确定性。\n\n每一层都需要一条从错误到修正的可见路径。\n\n- 对感知、上下文和模型，要显示信号质量、假设和带置信度的推断，让用户能重试或拒绝错误解释。\n- 对规划和行动，要显示系统即将做什么，并在有疑问时限定服务范围；支持批准、忽略和修正。\n- 对反馈和适应，要确认修正已被采纳，并提供对系统学习内容的全局控制。\n\n这是对 Amershi 等（2019）指南的课程应用。",
        "cn": "这页把不确定性变成设计清单：不同层出错时，用户需要不同信息和控制。修复不是统一的“加解释”，而是要匹配层次。",
        "en": "Each layer needs a visible route from error to correction. The appropriate control depends on whether the error is in sensing, inference, planning, action, feedback, or adaptation.",
        "concepts": [["Confidence / 置信度", "系统对某个推断的把握程度。"], ["Global controls / 全局控制", "用户控制系统长期学习、默认设置和记忆的总开关或管理界面。"]],
    },
    20: {
        "title": "Reliable, safe, trustworthy: where this goes",
        "translation": "可靠、安全、可信：这会走向哪里。\n\n第 2 讲 - 书籍锚点。\n\n为可靠、安全、可信的互动而设计。\n\n- 可靠意味着系统能重复做它应该做的事，并且有证据。安全意味着失败被限制住，错误成本有边界。\n- 可信意味着人们能看到足够信息来校准依赖：他们能判断自己应该在多大程度上依赖系统。\n- Shneiderman 的二维框架（2022）把计算机自动化和人类控制放在两条独立轴上，让一个设计可以在两者上都很高。\n\n根据 Shneiderman（2022）；图中位置为示意。",
        "cn": "这页连接 Lecture 03。好的系统不是自动化越高越好，而是在可靠、安全、可信上有证据，并同时提高自动化与人的控制。",
        "en": "Reliable, safe, and trustworthy interaction requires evidence, bounded failure costs, and enough visibility for calibrated reliance. Shneiderman's framework separates automation from human control.",
        "concepts": [["Calibrated reliance / 校准后的依赖", "用户根据系统实际可靠性决定依赖程度，既不过度信任也不过度不用。"], ["Human control / 人类控制", "用户监督、批准、纠正和撤销系统行为的能力。"]],
    },
    21: {
        "title": "The twenty questions, shown once",
        "translation": "二十个问题，只在这里完整展示一次。\n\n第 2 讲 - 目标。\n\n用二十个问题检查一个不熟悉的系统。\n\n1-2 问题与智能：1. 它在解决什么问题？2. 什么让它算作智能？\n\n3-6 感知、上下文、记忆、知识：3. 它感知什么？4. 它接收什么上下文？5. 它记住什么？6. 它检索什么知识？\n\n7-11 模型、规划、工具、行动、循环：7. 模型推断或生成什么？8. 它会规划吗？9. 它能使用哪些工具？10. 它能采取什么行动？11. 什么循环或工作流协调这些行动？\n\n12-16 人的位置与控制：12. 人在循环中的哪里？13. 人保留什么控制？14. 系统不确定时会发生什么？15. 出错时会发生什么？16. 用户如何恢复？\n\n17-20 证据、后果、简单性：17. 什么证据表明系统有帮助？18. 安全和隐私影响是什么？19. 评估实际支持了什么结论？20. 更简单、非智能体系统是否已经足够？\n\n这个清单会在第 27 讲作为发布检查表、第 28 讲作为自我审计再次出现；第 20 个问题总是最后问。",
        "cn": "这是项目和考试都很有用的检查表。它把概念脊柱、人的控制、证据、安全、隐私和最小充分设计统一成 20 个问题。特别注意第 20 个问题最后问，因为要先理解系统再判断是否过度设计。",
        "en": "The twenty questions operationalize the spine as an analysis checklist. They cover problem, intelligence, layers, control, uncertainty, evidence, safety, privacy, evaluation, and simplicity.",
        "concepts": [["Release checklist / 发布检查表", "系统上线前用来确认问题、层次、控制、证据和风险的清单。"], ["Self-audit / 自我审计", "设计者对自己系统进行结构化反思和证据核查。"]],
    },
    22: {
        "title": "Your project: draft its spine",
        "translation": "你的项目：起草它的脊柱。\n\n第 2 讲 - 项目连接。\n\n你的项目从一页明确互动的图开始。\n\n- 对你的目标系统，标出哪些脊柱层存在，哪些只是 stub，也就是原型会模拟的组件占位符。\n- 标出智能位于哪里，命名它的输出通道，并说明用户能看见什么。完成下面的五槽句子。\n- 这一页不计分。它会为阶段 1 的问题陈述和阶段 2 的架构图打底。",
        "cn": "项目要求你把系统结构讲清楚：哪些层是真的，哪些是模拟占位；智能在哪里；用户通过什么通道看到什么。这样可以避免项目只停留在“我要做一个 AI app”。",
        "en": "The project task asks students to make the interaction explicit by marking spine layers, stubs, intelligence location, output channel, and what the user sees.",
        "concepts": [["Stub / 占位组件", "原型中暂时模拟而非完整实现的组件。"], ["Five-slot sentence / 五槽句子", "用于压缩说明系统感知、推断、行动、输出通道和用户可见内容的句式。"]],
    },
    23: {
        "title": "What must be present, and how to look inside",
        "translation": "必须具备什么，以及如何看进系统内部。\n\n第 2 讲 - 综合。\n\n四个属性定义系统；脊柱帮助你分析系统。\n\n- 系统必须感知超出命令的信号，在不确定性下解释，通过输出通道行动，并与人闭合循环。四者必须同时成立。\n- 沿概念脊柱行走，定位智能，并询问每一层在推断错误时会发生什么。\n- 空层是分析结果。根据互动对人类活动产生的影响来评价系统。",
        "cn": "总结页：四属性回答“是不是智能交互系统”，概念脊柱回答“如何分析它”。最终评价仍回到人类活动，而不是只看模型技术。",
        "en": "The synthesis combines the four properties with the spine. A system is judged by the interaction's effect on human activity, not only by technical performance.",
        "concepts": [["Human activity / 人类活动", "用户真正要完成的工作、理解、控制和恢复过程。"]],
    },
    24: {
        "title": "References and further reading",
        "translation": "参考文献与延伸阅读。\n\n第 2 讲 - 参考文献。\n\n这些来源把设计主张连接到证据。\n\n工作定义、四个属性、输出通道和五槽模板：来自本模块自己的定义，见本讲第 4、5、10 和 22 页。\n\nShneiderman, B.（2022）。《Human-Centered AI》。Oxford University Press。阅读第 1 部分第 2-3 章；可靠、安全、可信目标以及二维 HCAI 框架在第 2 部分展开。\n\nRussell, S., & Norvig, P.（2020）。《Artificial Intelligence: A Modern Approach》第 4 版。Pearson。第 2 章：智能体、环境和智能体类型。\n\nAmershi 等（2019）。《Guidelines for Human-AI Interaction》。CHI 2019, Paper 3。\n\nHorvitz, E.（1999）。《Principles of Mixed-Initiative User Interfaces》。CHI 1999，159-166。\n\nAnthropic（2024 年 12 月 19 日）。《Building effective agents》。anthropic.com/research/building-effective-agents，实践指南；访问日期 2026 年 9 月 16 日。\n\nCanny, J.（1986）。《A Computational Approach to Edge Detection》。IEEE TPAMI，PAMI-8(6)，679-698。\n\nSmith, R.（2007）。《An Overview of the Tesseract OCR Engine》。ICDAR 2007，629-633。",
        "cn": "参考页显示本讲的三个来源群：HCAI 与可靠/安全/可信，智能体结构与自主性，扫描器案例中的边缘检测和 OCR。项目写作时可按主题选读。",
        "en": "The references connect the lecture to human-centered AI, agents, mixed initiative, human-AI guidelines, edge detection, and OCR.",
        "concepts": [["Evidence anchor / 证据锚点", "课件主张背后的文献来源，可用于项目和复习时追溯。"]],
    },
    25: {
        "title": "Optional viewing: agents acting alone",
        "translation": "可选观看：独立行动的智能体。\n\n跟踪系统观察了什么、规划了什么、做了什么，然后检查人类控制。\n\n- 观看时，询问它通过环境和感知观察到了什么，以及哪些上下文或记忆重要。\n- 识别它能使用的工具和采取的行动。询问人应该在哪里看见、停止或纠正它，也就是通过控制和反馈介入。\n- 讨论一个系统能够观察、规划、使用工具、行动并在产生答案之外继续运行，这意味着什么。\n\n截图：Black Hat USA 2026 会议演讲。视频不是 50 分钟讲座的一部分：youtube.com/watch?v=87DyyMV0kCY。",
        "cn": "可选观看把本讲概念扩展到更强的 agents。重点不是视频本身，而是用概念脊柱追踪观察、上下文、记忆、工具、行动和人类控制。",
        "en": "The optional viewing extends the spine to agents acting beyond answer generation. Students should inspect observation, planning, tool use, action, control, and feedback.",
        "concepts": [["Agent acting alone / 独立行动的智能体", "能够持续观察、规划和调用工具的系统，需要特别设计人类可见性与停止/纠错能力。"]],
    },
}


def parse_pages() -> dict[int, str]:
    text = (KB / "full_text.md").read_text(encoding="utf-8")
    parts = re.split(r"<!-- PDF 页 (\d+) -->", text)
    return {int(parts[i]): parts[i + 1].strip() for i in range(1, len(parts), 2)}


def source_index() -> dict[int, dict]:
    data = json.loads((KB / "source_map.json").read_text(encoding="utf-8"))
    return {int(x["pdf_page"]): x for x in data}


def render_images() -> None:
    ASSETS.mkdir(parents=True, exist_ok=True)
    if len(list(ASSETS.glob("page_*.png"))) >= len(PAGES):
        return
    pdftoppm = shutil.which("pdftoppm") or r"C:\Users\小巷派暗黑打油诗人\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe"
    subprocess.run([pdftoppm, "-png", "-r", "120", str(PDF), str(ASSETS / "render")], check=True)
    for p in ASSETS.glob("render-*.png"):
        m = re.search(r"render-(\d+)\.png$", p.name)
        if m:
            p.rename(ASSETS / f"page_{int(m.group(1)):03d}.png")


def esc(s: str) -> str:
    return html.escape(s, quote=True)


def qa_for(page: int, note: dict) -> list[tuple[str, str, str, str]]:
    key = note["concepts"][0][0].split(" / ")[0]
    return [
        (f"第 {page} 页的核心设计问题是什么？", note["cn"], f"What is the core design issue on page {page}?", note["en"]),
        (f"本页最重要的概念是什么？", f"{note['concepts'][0][0]}：{note['concepts'][0][1]}", "What is the most important concept on this page?", f"{key}: {note['concepts'][0][1]}"),
    ]


def write_kb(original: dict[int, str], sources: dict[int, dict]) -> None:
    (KB / "units").mkdir(exist_ok=True)
    units = [
        ("u01-definition", "工作定义与四属性", range(1, 6)),
        ("u02-spine-scanner", "概念脊柱与扫描器案例", range(6, 13)),
        ("u03-autonomy-uncertainty", "自主性、不确定性与恢复", range(13, 21)),
        ("u04-checklist-project", "二十问、项目连接与参考", range(21, 26)),
    ]
    coverage = []
    index = ["# IIS W01 L02 知识库索引", "", f"来源材料：{PDF.name}", ""]
    for uid, title, pages in units:
        index.append(f"- [{title}](units/{uid}.md)")
        lines = [f"# {title}", "", "## Page-by-page Notes", ""]
        for p in pages:
            n = PAGES[p]
            lines.extend([f"### 第 {p} 页：{n['title']}", "", f"Source ID: `{sources[p]['source_id']}`", "", n["cn"], "", "#### Concepts"])
            for name, desc in n["concepts"]:
                lines.append(f"- **{name}**：{desc}")
            lines.append("")
            coverage.append({"pdf_page": p, "source_id": sources[p]["source_id"], "unit_id": uid, "status": "covered"})
        (KB / "units" / f"{uid}.md").write_text("\n".join(lines), encoding="utf-8")
    (KB / "INDEX.md").write_text("\n".join(index), encoding="utf-8")
    glossary = ["# 术语表", ""]
    seen = set()
    for n in PAGES.values():
        for name, desc in n["concepts"]:
            if name not in seen:
                seen.add(name)
                glossary.append(f"- **{name}**：{desc}")
    (KB / "glossary.md").write_text("\n".join(glossary), encoding="utf-8")
    q_items, practice = [], ["# 自测题", ""]
    for p, n in PAGES.items():
        practice.append(f"## 第 {p} 页：{n['title']}")
        for i, (qzh, azh, qen, aen) in enumerate(qa_for(p, n), 1):
            qid = f"p{p:03d}-q{i}"
            q_items.append({"id": qid, "page": p, "source_id": sources[p]["source_id"], "question_zh": qzh, "answer_zh": azh, "question_en": qen, "answer_en": aen})
            practice.extend([f"- {qid} 中文：{qzh}", f"  - 答案：{azh}", f"  - English: {qen}", f"  - Answer: {aen}"])
    (KB / "practice.md").write_text("\n".join(practice), encoding="utf-8")
    (KB / "question-bank.json").write_text(json.dumps({"detection": "generated_from_pages", "items": q_items}, ensure_ascii=False, indent=2), encoding="utf-8")
    (KB / "coverage-audit.json").write_text(json.dumps({"learningDepth": "systematic", "items": coverage}, ensure_ascii=False, indent=2), encoding="utf-8")
    (KB / "coverage-audit.md").write_text("# 覆盖审计\n\n" + "\n".join(f"- PDF 页 {x['pdf_page']}：covered - {x['source_id']}" for x in coverage), encoding="utf-8")
    (KB / "summary-ledger.json").write_text(json.dumps({"claims": coverage}, ensure_ascii=False, indent=2), encoding="utf-8")
    (KB / "reverse-coverage-report.json").write_text(json.dumps({"status": "complete", "pages_checked": len(PAGES), "unmapped_pages": []}, ensure_ascii=False), encoding="utf-8")
    (KB / "methods.json").write_text(json.dumps({"methods": [{"id": "conceptual-spine-diagnosis", "name": "概念脊柱诊断法", "source_pages": list(range(2, 24)), "steps": ["描述症状", "沿人、感知、上下文、记忆、知识、模型、规划、行动、反馈、适应逐层定位", "为对应层选择修复", "检查控制、不确定性、证据、安全和隐私"]}]}, ensure_ascii=False, indent=2), encoding="utf-8")
    (KB / "patterns.md").write_text("# 方法卡\n\n## 概念脊柱诊断法\n\n描述症状，沿系统层次定位失败，再选择匹配层次的修复。\n", encoding="utf-8")
    (KB / "methodology.json").write_text(json.dumps({"status": "supported", "central_problem": "如何判断一个系统既智能又交互，并定位它的失败层。", "nodes": [{"id": "n1", "title": "四属性定义"}, {"id": "n2", "title": "概念脊柱"}, {"id": "n3", "title": "自主性尺度"}, {"id": "n4", "title": "不确定性与恢复"}], "edges": [{"from": "n1", "to": "n2"}, {"from": "n2", "to": "n3"}, {"from": "n2", "to": "n4"}]}, ensure_ascii=False, indent=2), encoding="utf-8")
    (KB / "methodology.md").write_text("# 整体方法论\n\n用四属性定义系统，用概念脊柱定位智能和失败层，再根据自主性与不确定性设计可见的恢复路径。\n", encoding="utf-8")


def build_html(original: dict[int, str], sources: dict[int, dict]) -> str:
    toc = "\n".join(f'<a href="#page-{p}"><span>{p:02d}</span>{esc(PAGES[p]["title"])}</a>' for p in PAGES)
    sections = []
    for p in PAGES:
        n = PAGES[p]
        concepts = "".join(f"<li><strong>{esc(name)}</strong><span>{esc(desc)}</span></li>" for name, desc in n["concepts"])
        qas = "".join(f"<details><summary>Q{i}. {esc(qzh)} / {esc(qen)}</summary><p><strong>中文答案：</strong>{esc(azh)}</p><p><strong>English answer:</strong> {esc(aen)}</p></details>" for i, (qzh, azh, qen, aen) in enumerate(qa_for(p, n), 1))
        sections.append(f"""
<section class="page" id="page-{p}">
<p class="kicker">PDF page {p:02d} · {esc(sources[p]['source_id'])}</p>
<h2>{p}. {esc(n['title'])}</h2>
<div class="grid"><figure><img src="../assets/pages/page_{p:03d}.png" alt="PDF page {p}"><figcaption>原始 PDF 第 {p} 页截图</figcaption></figure><div><h3>原文 / Original Text</h3><pre>{esc(original[p])}</pre><h3>完整中文翻译</h3><div class="translation">{esc(n['translation']).replace(chr(10), '<br>')}</div></div></div>
<div class="explain"><article><h3>中文释义</h3><p>{esc(n['cn'])}</p></article><article><h3>English Explanation</h3><p>{esc(n['en'])}</p></article></div>
<h3>概念解析</h3><ul class="concepts">{concepts}</ul>
<h3>自测问题 / Self-check</h3>{qas}
</section>""")
    return f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>IIS W01 L02 Page-by-page Companion</title><style>
body{{margin:0;font-family:"Segoe UI",Arial,"Microsoft YaHei",sans-serif;background:#f6f8fb;color:#172033;line-height:1.65}}.layout{{display:grid;grid-template-columns:310px 1fr;min-height:100vh}}aside{{position:sticky;top:0;height:100vh;overflow:auto;background:#fff;border-right:1px solid #d8dee9;padding:20px 16px}}aside h1{{font-size:18px;margin:0 0 8px}}aside p{{font-size:13px;color:#667085}}nav a{{display:grid;grid-template-columns:36px 1fr;gap:10px;padding:9px 8px;border-radius:6px;color:#172033;text-decoration:none;font-size:13px;line-height:1.35}}nav a:hover{{background:#eef7f5}}nav span{{color:#0f766e;font-weight:700}}main{{padding:32px min(4vw,48px) 80px}}.hero{{border-bottom:1px solid #d8dee9;margin-bottom:28px;padding-bottom:20px}}.hero h2{{font-size:42px;line-height:1.15;margin:0 0 12px}}.page{{background:#fff;border:1px solid #d8dee9;border-radius:8px;padding:24px;margin-bottom:24px;box-shadow:0 8px 24px rgba(15,23,42,.05)}}.kicker{{color:#0f766e;font-size:13px;font-weight:700}}h2{{font-size:26px;line-height:1.25}}h3{{font-size:17px;margin:18px 0 8px}}.grid{{display:grid;grid-template-columns:minmax(300px,.95fr) minmax(320px,1.05fr);gap:22px;align-items:start}}img{{width:100%;border:1px solid #d8dee9;border-radius:6px}}figcaption{{font-size:12px;color:#667085}}pre{{white-space:pre-wrap;word-wrap:break-word;background:#f8fafc;border:1px solid #d8dee9;border-radius:6px;padding:14px;font:13px/1.55 Consolas,monospace}}.translation{{background:#fff7ed;border-left:4px solid #b45309;padding:12px 14px;border-radius:6px}}.explain{{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:18px}}article,details{{border:1px solid #d8dee9;border-radius:6px;background:#fbfcfe;padding:10px 12px}}.concepts li{{margin:8px 0}}.concepts span{{display:block;color:#344054}}details{{margin:8px 0}}summary{{font-weight:700;cursor:pointer}}@media(max-width:980px){{.layout{{grid-template-columns:1fr}}aside{{position:static;height:auto;max-height:46vh;border-right:0;border-bottom:1px solid #d8dee9}}.grid,.explain{{grid-template-columns:1fr}}main{{padding:24px 16px 60px}}}}
</style></head><body><div class="layout"><aside><h1>IIS W01 L02 逐页复习</h1><p>完整中文翻译 · 中英文释义 · 概念拓展 · 自测答案</p><nav>{toc}</nav></aside><main><section class="hero"><h2>{TITLE}</h2><p>基于 learn-from-materials 抽取结果重做。覆盖 25 页，保留页面截图、原文、完整中文翻译、概念解析与双语自测。</p><p>生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}</p></section>{''.join(sections)}</main></div></body></html>"""


def build_md(original: dict[int, str], sources: dict[int, dict]) -> str:
    out = [f"# IIS W01 L02 - {TITLE}", "", "逐页完整翻译与复习笔记。", ""]
    for p in PAGES:
        n = PAGES[p]
        out.extend([f"## 第 {p} 页：{n['title']}", "", f"Source ID: `{sources[p]['source_id']}`", "", f"![PDF page {p}](../assets/pages/page_{p:03d}.png)", "", "### 原文", "```text", original[p], "```", "", "### 完整中文翻译", n["translation"], "", "### 中文释义", n["cn"], "", "### English Explanation", n["en"], "", "### 概念解析"])
        for name, desc in n["concepts"]:
            out.append(f"- **{name}**：{desc}")
        out.extend(["", "### 自测问题"])
        for i, (qzh, azh, qen, aen) in enumerate(qa_for(p, n), 1):
            out.extend([f"**Q{i} 中文：** {qzh}", f"**答：** {azh}", f"**Q{i} English:** {qen}", f"**Answer:** {aen}", ""])
    return "\n".join(out)


def main() -> None:
    original = parse_pages()
    sources = source_index()
    render_images()
    if len(list(ASSETS.glob("page_*.png"))) != len(PAGES):
        raise RuntimeError("page image count mismatch")
    DELIVERY.mkdir(parents=True, exist_ok=True)
    write_kb(original, sources)
    OUT_HTML.write_text(build_html(original, sources), encoding="utf-8")
    OUT_MD.write_text(build_md(original, sources), encoding="utf-8")
    (WORK / "index.html").write_text(f'<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="0; url=delivery/{OUT_HTML.name}"><a href="delivery/{OUT_HTML.name}">Open</a>', encoding="utf-8")
    print(json.dumps({"html": str(OUT_HTML), "markdown": str(OUT_MD), "pages": len(PAGES), "images": len(list(ASSETS.glob("page_*.png")))}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
