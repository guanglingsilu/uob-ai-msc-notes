# 人本设计三承诺

## Page-by-page Notes

### 第 1 页：Human-Centred Intelligent Interaction and the Shape of the Module

Source ID: `src-b91e955ebdec-pdf_page-00001`

本讲把“以人为中心”从口号变成可检验标准：用户是否保留控制、系统是否清楚地表达能力与边界、主动权规则是否可说明。

#### Concepts
- **Human-centred design / 以人为中心设计**：把人的活动、控制、理解、恢复和责任放在系统设计中心。

### 第 2 页：Two inbox assistants, one tagline

Source ID: `src-b91e955ebdec-pdf_page-00002`

这一页说明 human-centred 不是看宣传语，而是看控制结构。B 更接近以人为中心，因为它保留了审批和撤销。

#### Concepts
- **Human control / 人类控制**：人在系统行动前后保留审核、批准、撤销和纠错能力。

### 第 3 页：'Human-centred' as three commitments

Source ID: `src-b91e955ebdec-pdf_page-00003`

三个承诺是本讲骨架：错误先问设计责任；自动化不必牺牲控制；系统何时行动必须有规则。

#### Concepts
- **Accountability / 问责**：用户失败时先检查设计，而不是把责任推给用户。
- **Initiative rule / 主动权规则**：说明在什么条件下人或系统采取下一步行动。

### 第 4 页：Shneiderman's two-dimensional framework

Source ID: `src-b91e955ebdec-pdf_page-00004`

核心误区是把自动化和控制当成此消彼长。Shneiderman 框架要求我们寻找“高自动化 + 高控制”的设计。

#### Concepts
- **Two-dimensional HCAI framework / 二维 HCAI 框架**：用自动化和人类控制两条独立轴评估系统，而不是只问自动化高低。

### 第 5 页：Moving a design on the plane

Source ID: `src-b91e955ebdec-pdf_page-00005`

这页很实用：你不一定要换模型才能改善人本性。只要加 proposal、review、undo，就能增加控制。

#### Concepts
- **Proposal-review-undo / 提议-审查-撤销**：让系统先建议，人再批准，并提供撤销路径的控制模式。
