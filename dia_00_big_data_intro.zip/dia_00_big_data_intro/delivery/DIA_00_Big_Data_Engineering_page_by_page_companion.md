# Introduction to Big Data Engineering

课程：Data-Intensive Artificial Intelligence

## 第 1 页：数据密集型人工智能:

Source ID: `src-71dd5f6f81d7-pdf_page-00001`

![PDF page 1](../assets/pages/page_001.jpg)

### 原文 / Original Text

```text
Data-intensive AI:
Introduction to Big Data Engineering

Prof. Paolo Missier
School of Computer Science
University of Birmingham, UK

Data-intensive AI
2026/27 Sem 1
```

### 完整中文翻译

数据密集型人工智能:
大数据工程导论
教授 Paolo Missier
计算机科学学院
伯明翰大学, UK
数据密集型人工智能
2026/27 Sem 1

### 中文释义

本页围绕“Data-intensive AI:”展开。课件中的关键信息包括：数据密集型人工智能:；大数据工程导论；教授 Paolo Missier；计算机科学学院。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data-intensive AI:'. The slide includes: Data-intensive AI:; Introduction to Big Data Engineering; Prof. Paolo Missier; School of Computer Science. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“Data-intensive AI:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 1 页的核心主题是什么？
**答：** 本页围绕“Data-intensive AI:”展开。课件中的关键信息包括：数据密集型人工智能:；大数据工程导论；教授 Paolo Missier；计算机科学学院。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 1?
**Answer:** This page presents 'Data-intensive AI:'. The slide includes: Data-intensive AI:; Introduction to Big Data Engineering; Prof. Paolo Missier; School of Computer Science. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'Data-intensive AI:'. The slide includes: Data-intensive AI:; Introduction to Big Data Engineering; Prof. Paolo Missier; School of Computer Science. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

## 第 2 页：从数据到推理的价值链

Source ID: `src-71dd5f6f81d7-pdf_page-00002`

![PDF page 2](../assets/pages/page_002.jpg)

### 原文 / Original Text

```text
The data-to-inference value chain

Training-ready 
datasets

Model

Source
datasets

Dataset
- Selection
- Integration

Source data quality
Task-agnostic

- Supervised / 
Unsupervised    Machine 
Learning
- Deep Learning
- Transformers --> LLMs

Inference
Prediction
Generation
Emergent structure
```

### 完整中文翻译

从数据到推理的价值链
Training-ready
datasets
Model
Source
datasets
Dataset
- Selection
- Integration
源数据质量
与任务无关
- Supervised /
Unsupervised Machine
Learning
- 深度学习
- Transformers --> LLMs
Inference
Prediction
Generation
Emergent structure

### 中文释义

本页围绕“The data-to-inference value chain”展开。课件中的关键信息包括：从数据到推理的价值链；Training-ready；datasets；Model。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'The data-to-inference value chain'. The slide includes: The data-to-inference value chain; Training-ready; datasets; Model. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“The data-to-inference value chain”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 2 页的核心主题是什么？
**答：** 本页围绕“The data-to-inference value chain”展开。课件中的关键信息包括：从数据到推理的价值链；Training-ready；datasets；Model。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 2?
**Answer:** This page presents 'The data-to-inference value chain'. The slide includes: The data-to-inference value chain; Training-ready; datasets; Model. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：深度学习 / deep learning
**答：** 用多层神经网络从数据中学习表示和映射，现代视觉任务常用。
**Q2 English:** Explain the concept on this page: deep learning
**Answer:** The page focuses on deep learning. This page presents 'The data-to-inference value chain'. The slide includes: The data-to-inference value chain; Training-ready; datasets; Model. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

## 第 3 页：Data-centric AI

Source ID: `src-71dd5f6f81d7-pdf_page-00003`

![PDF page 3](../assets/pages/page_003.jpg)

### 原文 / Original Text

```text
Data-centric AI

D

M

D

M’

(

(

,

,

D

)

)

M

Optimise M

Improve D

(

(

,

,

D’

M

)

)

Zha, D., et al. (2023). "Data-centric Artificial Intelligence: A Survey." arXiv preprint arXiv:2303.10158

Prerna Singh, Systematic review of data-centric approaches in artificial intelligence and machine 
learning, Data Science and Management, (6,3), 2023, https://doi.org/10.1016/j.dsm.2023.06.001.

Bhatt, N., Bhatt, N., Prajapati, P. et al. A Data-Centric Approach to improve performance of deep learning 
models. Sci Rep 14, 22329 (2024). https://doi.org/10.1038/s41598-024-73643-x
```

### 完整中文翻译

Data-centric AI
D
M
D
M’
(
(
,
,
D
)
)
M
Optimise M
Improve D
(
(
,
,
D’
M
)
)
Zha, D., et al. (2023). "Data-centric Artificial Intelligence: A Survey." arXiv preprint arXiv:2303.10158
Prerna Singh, Systematic review of data-centric approaches in artificial intelligence and machine
参考链接：learning, Data Science and Management, (6,3), 2023, https://doi.org/10.1016/j.dsm.2023.06.001.
Bhatt, N., Bhatt, N., Prajapati, P. et al. A Data-Centric Approach to improve performance of 深度学习
参考链接：models. Sci Rep 14, 22329 (2024). https://doi.org/10.1038/s41598-024-73643-x

### 中文释义

本页围绕“Data-centric AI”展开。课件中的关键信息包括：Data-centric AI；D；M；D。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data-centric AI'. The slide includes: Data-centric AI; D; M; D. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“Data-centric AI”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 3 页的核心主题是什么？
**答：** 本页围绕“Data-centric AI”展开。课件中的关键信息包括：Data-centric AI；D；M；D。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 3?
**Answer:** This page presents 'Data-centric AI'. The slide includes: Data-centric AI; D; M; D. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：深度学习 / deep learning
**答：** 用多层神经网络从数据中学习表示和映射，现代视觉任务常用。
**Q2 English:** Explain the concept on this page: deep learning
**Answer:** The page focuses on deep learning. This page presents 'Data-centric AI'. The slide includes: Data-centric AI; D; M; D. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

## 第 4 页：大数据

Source ID: `src-71dd5f6f81d7-pdf_page-00004`

![PDF page 4](../assets/pages/page_004.jpg)

### 原文 / Original Text

```text
4

Big Data
```

### 完整中文翻译

4
大数据

### 中文释义

本页围绕“Big Data”展开。课件中的关键信息包括：4；大数据。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Big Data'. The slide includes: 4; Big Data. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“Big Data”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 4 页的核心主题是什么？
**答：** 本页围绕“Big Data”展开。课件中的关键信息包括：4；大数据。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 4?
**Answer:** This page presents 'Big Data'. The slide includes: 4; Big Data. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'Big Data'. The slide includes: 4; Big Data. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

## 第 5 页：Data growth

Source ID: `src-71dd5f6f81d7-pdf_page-00005`

![PDF page 5](../assets/pages/page_005.jpg)

### 原文 / Original Text

```text
Data growth

 106B Megabyte
 109B Gigabyte
 1012B Terabyte
 1015B Petabyte
 1018B Exabyte
 1021B Zettabyte

90% of world's data:

 generated over last two years
```

### 完整中文翻译

Data growth
 106B Megabyte
 109B Gigabyte
 1012B Terabyte
 1015B Petabyte
 1018B Exabyte
 1021B Zettabyte
90% of world's data:
 generated over last two years

### 中文释义

本页围绕“Data growth”展开。课件中的关键信息包括：Data growth； 106B Megabyte； 109B Gigabyte； 1012B Terabyte。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data growth'. The slide includes: Data growth;  106B Megabyte;  109B Gigabyte;  1012B Terabyte. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“Data growth”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 5 页的核心主题是什么？
**答：** 本页围绕“Data growth”展开。课件中的关键信息包括：Data growth； 106B Megabyte； 109B Gigabyte； 1012B Terabyte。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 5?
**Answer:** This page presents 'Data growth'. The slide includes: Data growth;  106B Megabyte;  109B Gigabyte;  1012B Terabyte. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'Data growth'. The slide includes: Data growth;  106B Megabyte;  109B Gigabyte;  1012B Terabyte. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

## 第 6 页：大数据 for AI

Source ID: `src-71dd5f6f81d7-pdf_page-00006`

![PDF page 6](../assets/pages/page_006.jpg)

### 原文 / Original Text

```text
Big Data for AI

Domain

Volume

Variety

Velocity

Model purpose

NLP / LLMs

~12–20T tokens
(PB-scale corpora)

Web text, books,
code, image/video

~1000× growth
since 2019

General-purpose
generation

Particle physics 
/ CERN LHC

~10,000 EB/yr raw →
tens of PB/yr stored

High-dimensional
detector readings

~4 TB/s raw;
μs-level filtering

Real-time ML triggers
selecting events

Genomics /
UK Biobank

30+ PB total
(27.5 PB genomic)

Genomes, imaging,
EHR, biomarkers

Streaming /
Netflix

Logs from 100s of
millions of users

Clicks, watch time,
pauses, searches

1,000s 
genomes/mo;
15+ yr 
longitudinal

Continuous,
per-session 
updates

Disease-risk
prediction (MILTON)

Ranking & 
recommendation
```

### 完整中文翻译

大数据 for AI
Domain
Volume
Variety
Velocity
Model purpose
NLP / LLMs
~12–20T tokens
(PB-scale corpora)
Web text, books,
code, image/video
~1000× growth
since 2019
General-purpose
generation
Particle physics
/ CERN LHC
~10,000 EB/yr raw →
tens of PB/yr stored
High-dimensional
detector readings
~4 TB/s raw;
μs-level filtering
Real-time 机器学习 triggers
selecting events
Genomics /
UK Biobank
30+ PB total
(27.5 PB genomic)
Genomes, imaging,
EHR, biomarkers
Streaming /
Netflix
Logs from 100s of
millions of users
Clicks, watch time,
pauses, searches
1,000s
genomes/mo;
15+ yr
longitudinal
Continuous,
per-session
updates
Disease-risk
prediction (MILTON)
Ranking &
recommendation

### 中文释义

本页围绕“Big Data for AI”展开。课件中的关键信息包括：大数据 for AI；Domain；Volume；Variety。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Big Data for AI'. The slide includes: Big Data for AI; Domain; Volume; Variety. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **MAR / 随机缺失**：缺失与其他可观测变量有关，但不直接由缺失值本身决定。

拓展复习：把“Big Data for AI”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 6 页的核心主题是什么？
**答：** 本页围绕“Big Data for AI”展开。课件中的关键信息包括：大数据 for AI；Domain；Volume；Variety。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 6?
**Answer:** This page presents 'Big Data for AI'. The slide includes: Big Data for AI; Domain; Volume; Variety. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：随机缺失 / MAR
**答：** 缺失与其他可观测变量有关，但不直接由缺失值本身决定。
**Q2 English:** Explain the concept on this page: MAR
**Answer:** The page focuses on MAR. This page presents 'Big Data for AI'. The slide includes: Big Data for AI; Domain; Volume; Variety. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

## 第 7 页：大数据 for AI

Source ID: `src-71dd5f6f81d7-pdf_page-00007`

![PDF page 7](../assets/pages/page_007.jpg)

### 原文 / Original Text

```text
Big Data for AI

Domain

Volume

Variety

Velocity

Purpose

Google Search: 
PageRank at 
Web Scale

billions of pages, 
tens of billions of 
edges

Pure link structure 
(URLs)

Continuous re-
crawling

Rank pages / linear 
algebra

Collaborative 
Filtering
Netflix, 
Amazon…

Purchase/rating 
histories. hundreds 
of millions of users 
and items

user–item and 
item–item 
interaction 
matrices

Recomputed 
continuously

Matrix factorisation & 
item-item similarity 

Link Prediction 
in graphs
Linkedin

~1 billion member 
nodes
billions of 
connection edges

Graph structure 
plus profile, activity, 
and mutual-
connection signals

Recomputed 
continuously 

Heuristic/statistical 
link prediction 
(triangle-closing)
```

### 完整中文翻译

大数据 for AI
Domain
Volume
Variety
Velocity
Purpose
Google Search:
PageRank at
Web Scale
billions of pages,
tens of billions of
edges
Pure link structure
(URLs)
Continuous re-
crawling
Rank pages / linear
algebra
Collaborative
Filtering
Netflix,
Amazon…
Purchase/rating
histories. hundreds
of millions of users
and items
user–item and
item–item
interaction
matrices
Recomputed
continuously
Matrix factorisation &
item-item similarity
Link Prediction
in graphs
Linkedin
~1 billion member
nodes
billions of
connection edges
Graph structure
plus profile, activity,
and mutual-
connection signals
Recomputed
continuously
Heuristic/statistical
link prediction
(triangle-closing)

### 中文释义

本页围绕“Big Data for AI”展开。课件中的关键信息包括：大数据 for AI；Domain；Volume；Variety。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Big Data for AI'. The slide includes: Big Data for AI; Domain; Volume; Variety. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“Big Data for AI”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 7 页的核心主题是什么？
**答：** 本页围绕“Big Data for AI”展开。课件中的关键信息包括：大数据 for AI；Domain；Volume；Variety。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 7?
**Answer:** This page presents 'Big Data for AI'. The slide includes: Big Data for AI; Domain; Volume; Variety. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'Big Data for AI'. The slide includes: Big Data for AI; Domain; Volume; Variety. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

## 第 8 页：Data analytics and 机器学习

Source ID: `src-71dd5f6f81d7-pdf_page-00008`

![PDF page 8](../assets/pages/page_008.jpg)

### 原文 / Original Text

```text
Data analytics and machine learning

2. Predictive Analytics

Data → Model → Predictions

Supervised learning:

• Decision trees
• Random forests
• Support Vector Machines
• …

Unsupervised learning:

Training
set

Model
training 

New Data
instances

Model 

Predictions

Data points
In space

clustering

Natural data
aggregations

• K-means
• Topic modelling
• …
Ex. Anomaly detection in network traffic

Analysis of graph structures
Ex. Social media graphs
- people’s connections

Ex. Analysis of co-occurrences 
networks

User / item analysis
Ex. Product recommendations

Time series analysis
Ex. Current best routes → predicted best routes

8
```

### 完整中文翻译

Data analytics and 机器学习
2. Predictive Analytics
Data → Model → Predictions
监督学习:
• Decision trees
• Random forests
• Support Vector Machines
• …
无监督学习:
Training
set
Model
training
New Data
instances
Model
Predictions
Data points
In space
聚类
Natural data
aggregations
• K-means
• Topic modelling
• …
Ex. 异常检测 in network traffic
Analysis of graph structures
Ex. Social media graphs
- people’s connections
Ex. Analysis of co-occurrences
networks
User / item analysis
Ex. Product recommendations
Time series analysis
Ex. Current best routes → predicted best routes
8

### 中文释义

本页围绕“Data analytics and machine learning”展开。课件中的关键信息包括：Data analytics and 机器学习；2. Predictive Analytics；Data → Model → Predictions；监督学习:。复习时先抓住检测：同时判断目标类别与位置，通常输出边界框。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data analytics and machine learning'. The slide includes: Data analytics and machine learning; 2. Predictive Analytics; Data → Model → Predictions; Supervised learning:. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。

拓展复习：把“Data analytics and machine learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 8 页的核心主题是什么？
**答：** 本页围绕“Data analytics and machine learning”展开。课件中的关键信息包括：Data analytics and 机器学习；2. Predictive Analytics；Data → Model → Predictions；监督学习:。复习时先抓住检测：同时判断目标类别与位置，通常输出边界框。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 8?
**Answer:** This page presents 'Data analytics and machine learning'. The slide includes: Data analytics and machine learning; 2. Predictive Analytics; Data → Model → Predictions; Supervised learning:. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：检测 / detection
**答：** 同时判断目标类别与位置，通常输出边界框。
**Q2 English:** Explain the concept on this page: detection
**Answer:** The page focuses on detection. This page presents 'Data analytics and machine learning'. The slide includes: Data analytics and machine learning; 2. Predictive Analytics; Data → Model → Predictions; Supervised learning:. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

## 第 9 页：大数据 processing: technology

Source ID: `src-71dd5f6f81d7-pdf_page-00009`

![PDF page 9](../assets/pages/page_009.jpg)

### 原文 / Original Text

```text
Big Data processing: technology

• Most examples above require similar underlying large-scale data processing capability

What sort of processing?

- Selecting and Ingesting: which data sources? Load into “data lakes” for efficient processing

- Cleaning: deduplication, missing data imputation, outlier detection

- Integrating joining, transforming
```

### 完整中文翻译

大数据 processing: technology
• Most examples above require similar underlying large-scale data processing capability
问题：What sort of processing？
- Selecting and Ingesting: which data sources? Load into “数据湖” for efficient processing
- Cleaning: deduplication, 缺失数据 插补, 离群点 检测
- Integrating joining, transforming

### 中文释义

本页围绕“Big Data processing: technology”展开。课件中的关键信息包括：大数据 processing: technology；• Most examples above require similar underlying large-scale data processing capability；问题：What sort of processing？；- Selecting and Ingesting: which data sources? Load into “数据湖” for efficient processing。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Big Data processing: technology'. The slide includes: Big Data processing: technology; • Most examples above require similar underlying large-scale data processing capability; What sort of processing?; - Selecting and Ingesting: which data sources? Load into “data lakes” for efficient processing. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data lake / 数据湖**：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
- **join / 连接**：按键把表横向组合；键的语义不一致时会产生看似正确但实际错误的数据视图。
- **imputation / 插补**：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。
- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。

拓展复习：把“Big Data processing: technology”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 9 页的核心主题是什么？
**答：** 本页围绕“Big Data processing: technology”展开。课件中的关键信息包括：大数据 processing: technology；• Most examples above require similar underlying large-scale data processing capability；问题：What sort of processing？；- Selecting and Ingesting: which data sources? Load into “数据湖” for efficient processing。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 9?
**Answer:** This page presents 'Big Data processing: technology'. The slide includes: Big Data processing: technology; • Most examples above require similar underlying large-scale data processing capability; What sort of processing?; - Selecting and Ingesting: which data sources? Load into “data lakes” for efficient processing. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据湖 / Data lake
**答：** 保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
**Q2 English:** Explain the concept on this page: Data lake
**Answer:** The page focuses on Data lake. This page presents 'Big Data processing: technology'. The slide includes: Big Data processing: technology; • Most examples above require similar underlying large-scale data processing capability; What sort of processing?; - Selecting and Ingesting: which data sources? Load into “data lakes” for efficient processing. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

## 第 10 页：数据工程 + Data Science technology stack

Source ID: `src-71dd5f6f81d7-pdf_page-00010`

![PDF page 10](../assets/pages/page_010.jpg)

### 原文 / Original Text

```text
Data Engineering + Data Science technology stack

-
-

Exploratory Data analytics
Predictive modelling

Machine Learning
Deep Learning
Visual analytics

Data wrangling 
Data Quality processes

Distributed data 
processing

Data acquisition and storage

NoSQL, Graph DBMS
Distributed File Systems
Data Lakes

People

Markets

Cities

Machines

Streaming data

Static data
```

### 完整中文翻译

数据工程 + Data Science technology stack
-
-
Exploratory Data analytics
Predictive modelling
机器学习
深度学习
Visual analytics
Data wrangling
数据质量 processes
分布式 data
processing
Data acquisition and storage
NoSQL, Graph DBMS
分布式 File Systems
数据湖
People
Markets
Cities
Machines
Streaming data
Static data

### 中文释义

本页围绕“Data Engineering + Data Science technology stack”展开。课件中的关键信息包括：数据工程 + Data Science technology stack；-；-；Exploratory Data analytics。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data Engineering + Data Science technology stack'. The slide includes: Data Engineering + Data Science technology stack; -; -; Exploratory Data analytics. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data lake / 数据湖**：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
- **MAR / 随机缺失**：缺失与其他可观测变量有关，但不直接由缺失值本身决定。
- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“Data Engineering + Data Science technology stack”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 10 页的核心主题是什么？
**答：** 本页围绕“Data Engineering + Data Science technology stack”展开。课件中的关键信息包括：数据工程 + Data Science technology stack；-；-；Exploratory Data analytics。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 10?
**Answer:** This page presents 'Data Engineering + Data Science technology stack'. The slide includes: Data Engineering + Data Science technology stack; -; -; Exploratory Data analytics. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据湖 / Data lake
**答：** 保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
**Q2 English:** Explain the concept on this page: Data lake
**Answer:** The page focuses on Data lake. This page presents 'Data Engineering + Data Science technology stack'. The slide includes: Data Engineering + Data Science technology stack; -; -; Exploratory Data analytics. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

## 第 11 页：大数据 Architecture: Azure and Databricks

Source ID: `src-71dd5f6f81d7-pdf_page-00011`

![PDF page 11](../assets/pages/page_011.jpg)

### 原文 / Original Text

```text
Big Data Architecture: Azure and Databricks

Source:
https://techcommunity.microsoft.com/t5/analytics-on-azure/how-to-reduce-infrastructure-costs-by-up-to-80-with-azure/ba-p/1820280
```

### 完整中文翻译

大数据 Architecture: Azure and Databricks
Source:
参考链接：https://techcommunity.microsoft.com/t5/analytics-on-azure/how-to-reduce-infrastructure-costs-by-up-to-80-with-azure/ba-p/1820280

### 中文释义

本页围绕“Big Data Architecture: Azure and Databricks”展开。课件中的关键信息包括：大数据 Architecture: Azure and Databricks；Source:；参考链接：https://techcommunity.microsoft.com/t5/analytics-on-azure/how-to-reduce-infrastructure-costs-by-up-to-80-with-azure/ba-p/1820280。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Big Data Architecture: Azure and Databricks'. The slide includes: Big Data Architecture: Azure and Databricks; Source:; https://techcommunity.microsoft.com/t5/analytics-on-azure/how-to-reduce-infrastructure-costs-by-up-to-80-with-azure/ba-p/1820280. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“Big Data Architecture: Azure and Databricks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 11 页的核心主题是什么？
**答：** 本页围绕“Big Data Architecture: Azure and Databricks”展开。课件中的关键信息包括：大数据 Architecture: Azure and Databricks；Source:；参考链接：https://techcommunity.microsoft.com/t5/analytics-on-azure/how-to-reduce-infrastructure-costs-by-up-to-80-with-azure/ba-p/1820280。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 11?
**Answer:** This page presents 'Big Data Architecture: Azure and Databricks'. The slide includes: Big Data Architecture: Azure and Databricks; Source:; https://techcommunity.microsoft.com/t5/analytics-on-azure/how-to-reduce-infrastructure-costs-by-up-to-80-with-azure/ba-p/1820280. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'Big Data Architecture: Azure and Databricks'. The slide includes: Big Data Architecture: Azure and Databricks; Source:; https://techcommunity.microsoft.com/t5/analytics-on-azure/how-to-reduce-infrastructure-costs-by-up-to-80-with-azure/ba-p/1820280. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.
