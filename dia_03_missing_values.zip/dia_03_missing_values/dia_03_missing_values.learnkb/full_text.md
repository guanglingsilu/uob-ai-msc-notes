# 来源：3. Data Quality I - missing values - Lecture Notes.pdf

<!-- SOURCE: 3. Data Quality I - missing values - Lecture Notes.pdf -->

<!-- PDF 页 1 -->

Data Quality I:
missing values and data imputation

Prof. Paolo Missier
School of Computer Science
University of Birmingham, UK

Data-intensive AI
2026/27 Sem 1

<!-- PDF 页 2 -->

Data Quality Issues covered in this lecture

Structural
- Missing / null values
- Out-of-range values
- Duplicate records

Semantic
Skewed distributions

ML-Specific
- Class imbalance
- Data leakage

<!-- PDF 页 3 -->

Missing data – I

<!-- PDF 页 4 -->

Missing data - II

<!-- PDF 页 5 -->

Null or missing?

Source: NYPD Motor Vehicle Collision Dataset

Credits: https://www.residentmar.io/2016/06/12/null-and-missing-data-python.html

<!-- PDF 页 6 -->

Null or missing?

Data missing at random (MAR)
- ad hoc imputation sometimes possible
- Makes descriptive analytics imprecise
- But may not be useful for modelling  

Data missing NOT at random (MNAR)
- May be an important feature for modelling
- Statistical approaches to imputation may work

Representing missing / null data:
- Python: None data type and value
- Numpy: np.nan (for numerical data)
- R: distinction between missing data (NA) and non-data (null)

<!-- PDF 页 7 -->

Missing vs Null Values

Type

MCAR

MAR

MNAR

Meaning
Missing Completely At Random
sensor noise
Missing At Random
conditional on other cols
Missing Not At Random
absence encodes info

Taxi Example

passenger_count = NULL (device glitch)

tip = NULL when payment = cash

fare = NULL → disputed / cancelled trip

<!-- PDF 页 8 -->

Missing vs Null Values

Column
pickup_datetime
fare_amount
passenger_count
trip_distance
pickup_borough

Value
2024-01-15 08:32
NULL
NULL
0.0
NULL

Status
✓ present
✗ target missing

feature missing
sentinel value

✗ join failure

Consequence for ML

• Most algorithms crash on NULL input features

• Dropping all incomplete rows can remove up to 30% of data

• Imputing wrongly introduces systematic bias

<!-- PDF 页 9 -->

A classification of missing-ness

Missing Completely at Random (MCAR) – No systematic relationship between the missing 
data and any other data or why the data is missing
•

There is no reason that makes some data more likely to be missing than other

Missing at Random (MAR) – There may be a systematic reason why some of the data is 
missing, but this knowledge does not help us with imputation
•

if men are more likely to tell you their weight than women, weight is MAR

Missing Not at Random (MNAR) – there is a relationship between the propensity of a value to 
be missing and its values
• Medical study: data more likely to be missing from some specific strata of the cohort

•
•

The sickest people may be more likely to drop out of the study
This correlation may suggest how to impute data from the dropout population

Source: https://www.theanalysisfactor.com/missing-data-mechanism/

<!-- PDF 页 10 -->

How to handle Missing Values?

The strategy depends on which column is null and why it is null.

1

2

3

4

5

Audit first: count NULLs per column and compute null-%. Columns with >60% 
missing are candidates for dropping entirely.

Target column (fare_amount): rows with NULL target cannot contribute to 
supervised learning → drop those rows.

Numerical features: impute with median (robust to outliers). Never use mean on 
skewed distributions like fare or distance.

Categorical features (borough): impute with sentinel string "Unknown" —
preserves the fact that location was missing as a signal.

Sentinel values (distance = 0.0): re-encode as NULL first, then apply median 
imputation — a zero-distance trip is physically impossible.

Spark Implementation Pattern

# 1. Audit
null_counts = trips.select([

F.sum(F.col(c).isNull().cast("int")).alias(c)

for c in trips.columns])

# 2. Drop rows missing the TARGET

trips = trips.filter(F.col("fare_amount").isNotNull())

# 3. Impute numerical features with median
trips = trips.fillna({

"passenger_count": median_passenger,
"trip_distance":   median_distance,

})

Key insight: approxQuantile() computes medians across all workers in a single scan 
— the result is two scalars sent to the driver, not millions of rows.

<!-- PDF 页 11 -->

Univariate vs Multivariate Imputation

Model target variable using regression
Use other variables to train a model that 
can predict the missing values on the 
target variable
- Eg a regression model

Use the distribution of available values 
for a variable to impute the remaining 
values
- mean, median, …

Pros: very simple strategy
Cons:
- all imputed values are the same
- adds bias around the mean of the 

distribution

- Reduces natural variance in the data 

Scikit implementation:  SimpleImputer

<!-- PDF 页 12 -->

KNN: nearest-neighbour imputation

Key idea: 
- A distance function can be defined on the space of values for target variable X

- Eg Euclidean distance for numeric values

- K defines how many neighbours of a record with missing values will be consulted

- Each missing feature is imputed 
using values from K nearest 
neighbours that have a value for the 
feature

Scikit implementation:  
Nearest neighbors imputation,

<!-- PDF 页 13 -->

MICE: Multiple imputation by chained equations

Key concepts:

- Extends the idea of using regression to impute missing values for one variable, to 
simultaneously imputing all missing values across the entire table

- Rather than performing one regression, MICE iteratively improves the imputed 
values through a sequence / chain of regression models

Note: works for data where missing data is MAR. Implementing MICE when data are not 
MAR could result in biased estimates (see [1,3] below)

<!-- PDF 页 14 -->

MICE: key references

[1] Azur, Melissa J., Elizabeth A. Stuart, Constantine Frangakis, and Philip J. Leaf. ‘Multiple Imputation by Chained 
Equations: What Is It and How Does It Work?’ International Journal of Methods in Psychiatric Research 20, no. 1 (24 
February 2011): 40–49. https://doi.org/10.1002/mpr.329.

[2] Buuren, Stef van, and Karin Groothuis-Oudshoorn. ‘Mice: Multivariate Imputation by Chained Equations in R’. 
Journal of Statistical Software 45, no. 1 (12 December 2011): 1–67. https://doi.org/10.18637/jss.v045.i03.

[3] Graham, John W. "Missing data analysis: Making it work in the real world." Annual review of psychology 60.1 
(2009): 549-576. https://www.personal.psu.edu/jxb14/M554/articles/Graham2009.pdf

<!-- PDF 页 15 -->

The MICE approach

Suppose you only have three variables A, B, C.

Start by a simple imputation of each of the missing values. - for example, the mean. These values are 
“place holders” as they will be replaced

Inner loop
1. Select one variable, say A, and build a regression model to predict A given B and C

Note: the model may not include all remaining variables

2. Use predictions from the model to impute the missing values in A
Repeat steps 1, 2 by choosing another variable (B or C in this example)

At the end of this loop, all missing variables have been imputed.

Outer loop:
Repeat the inner loop until the imputed values become stable – or a fixed number of iterations (10)

<!-- PDF 页 16 -->

The MICE approach

<!-- PDF 页 17 -->

Issue: Out-of-Range / Physically Impossible Values

Values that pass NULL checks but violate physical or business constraints. They are present but wrong.

Column
fare_amount
fare_amount
trip_distance
trip_distance
passenger_count
trip_duration
trip_duration

Impossible Value
−$12.50
$8,900
0.00 miles
847 miles
0
−5 mins
18 hours

Physical Reason
Fare cannot be negative
Exceeds any plausible NYC fare
A completed trip has distance > 0
No NYC trip crosses state lines
At least 1 passenger per trip
Dropoff before pickup
Meter left running overnight

These values pass schema validation but 
semantically implausible

Out-of-range values are not detectable 
from the schema alone

— the model learns a wrong 
baseline

zero distances: speed = distance/time --> NaN or Inf

<!-- PDF 页 18 -->

Handling Duplicate Records

- The same real-world event appears more than once.
- Duplicates inflate counts, bias aggregations, and leaks training rows into the test set.

Exact duplicates: every column is identical
-

Typically caused by double-ingestion (ETL retry)

Why They Cause ML Failures

• If a duplicate row appears in both train and test sets, the model “memorises” it — test 

accuracy is artificially inflated

• Count aggregations (trips per hour, demand forecasting) are systematically wrong

• Fare total inflated in revenue reports

<!-- PDF 页 19 -->

Near-duplicates

Ex: same pickup/dropoff location and overlapping times, minor column differences
–one record has a tip and one does not

Field
pickup_datetime
dropoff_datetime
pickup_location_id
dropoff_location_id
fare_amount
tip_amount
total_amount

Record A
08:32:00
08:47:00
132
79
$12.50
$2.00
$14.50

Record B
08:32:00
08:47:00
132
79
$12.50
$0.00
$12.50

Same trip — tip recorded in one system, not the other.
Neither record is wrong in isolation.

<!-- PDF 页 20 -->

Canonical Mapping: values to labels

Replace all raw encodings with a controlled vocabulary using an explicit, documented mapping. 

Raw Value(s)
1, 1.0
2, 2.0
3, 3.0
4, 4.0
99, NULL, other

Canonical Label
credit_card
cash
no_charge
dispute
unknown

Reason
Both encode same concept
—
—
—
Preserve as signal

trips = trips.withColumn(
"payment_type_label",

F.when(F.col("payment_type").isin(1, 1.0), "credit_card")
.when(F.col("payment_type").isin(2, 2.0), "cash")

.when(F.col("payment_type").isin(3, 3.0), "no_charge")

.when(F.col("payment_type").isin(4, 4.0), "dispute")
.otherwise("unknown")

<!-- PDF 页 21 -->

Canonical Mapping: values to labels

Discover all distinct values first: groupBy(col).count() reveals every encoding variant — never 
assume you know them in advance.

Define the mapping as a data contract: version-controlled, shared across all notebooks. 
Updating it in one place propagates everywhere.

Never use otherwise(null): unknown codes carry information ("something went wrong"). A 
named "unknown" label preserves that signal.

Verify after mapping: re-run groupBy on the new column. The result should contain only the 
expected canonical labels.

<!-- PDF 页 22 -->

Issue: Skewed Distributions

A feature's values are heavily concentrated at one end.
Linear models assume approximate normality — a skewed input produces a biased model

fare_amount Distribution (Taxi Dataset)

$0–$5
$5–$15
$15–$30
$30–$100
>$100
Skewness ≈ +4.2 (strongly right-skewed). The mean ($12.80) 
is pulled far above the median ($9.50) by airport fares.

45%
38%
12%
4%
1%

Note: The transform matters most for linear models and neural networks.

<!-- PDF 页 23 -->

Log Transformations Reduce Skew

Apply log(1 + x) to compress the right tail, making the distribution approximately symmetric.
Inverse with exp(x) − 1 to recover original units.

Before vs After — Skewness

Column
fare_amount
trip_distance
trip_duration_mins

Raw Skewness After log1p
+4.2
+6.1
+3.8

+0.4
+0.3
+0.2

trips = (trips

.withColumn("log_fare",

F.log1p(F.col("fare_amount")))

.withColumn("log_distance",

F.log1p(F.col("trip_distance")))

# Recover original scale after prediction:

predictions.withColumn("predicted_fare",

F.expm1(F.col("log_prediction")))

<!-- PDF 页 24 -->

Handling Class Imbalance

One class vastly outnumbers the other
A classifier that predicts the majority class on every row achieves high accuracy but zero utility.

Task: predict whether tip_amount > 20% of 
fare_amount.

Geographic skew: airport trips (JFK, LGA) have 
systemically higher tips.
Manhattan short trips have lower tips

Low tip (0)
High tip (1)

82%
18%

High-Tip Classification

Naïve classifier (predict 0) Value
Accuracy
Recall (class 1)

82%
0%

F1 score

0.00

Note
Looks good — is useless
Never detects a high tip
True measure of 
uselessness

<!-- PDF 页 25 -->

Rebalancing: undersampling strategies

Three complementary approaches
the right choice depends on dataset size and the cost of false negatives vs false positives

A — Undersampling
Randomly remove majority-
class rows until ratio reaches 
target (e.g. 1:1 or 2:1).

B — Class Weights
Keep all rows
assign higher loss weight to 
minority-class rows. No data 
removed.

Evaluation rule: never use accuracy as the primary metric on imbalanced data.
Use F1 score, AUC-ROC, or precision-recall AUC

<!-- PDF 页 26 -->

Data Leakage: outcome / covariate correlations

A feature available at training time contains information derived from the target
- either directly or indirectly.
The model appears excellent but fails completely in production.

Feature

total_amount

tip_amount

Leakage 
Type
Direct

Why it leaks

total = fare + tip + tolls. Contains the target.

Direct

High-tip task: tip IS the target signal.

congestion_surcharge

Indirect

Added to the fare bill

A model with R² = 0.99 on the test set but R² = 0.42 in production is almost 
always a leakage problem. The test set was contaminated with target 
information.

<!-- PDF 页 27 -->

Detecting & Removing Leakage

Feature importance check: after training, inspect the model's feature importances. If a 
feature dominates (e.g. 85% importance), investigate whether it leaks the target.

Correlation audit: compute Pearson correlation between each feature and the target. Any |r| > 
0.9 with the target is a strong leakage signal — legitimate features rarely correlate this highly.

Allowable Features — Taxi Prediction

Available at trip start?
Yes
Yes

Feature
pickup_datetime
pickup_location_id
dropoff_location_id Yes (by driver)
passenger_count
rate_code_id
tip_amount
total_amount
trip_distance

Yes
Yes
No — paid at end
No — end of trip
Partial — GPS est.

Status
✓ Safe
✓ Safe
✓ Safe
✓ Safe
✓ Safe
✗ Leaks
✗ Leaks

Careful
