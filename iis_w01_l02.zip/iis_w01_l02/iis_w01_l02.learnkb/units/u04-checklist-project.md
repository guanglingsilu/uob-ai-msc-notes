# 二十问、项目连接与参考

## Page-by-page Notes

### 第 21 页：The twenty questions, shown once

Source ID: `src-a5decf9f86a2-pdf_page-00021`

这是项目和考试都很有用的检查表。它把概念脊柱、人的控制、证据、安全、隐私和最小充分设计统一成 20 个问题。特别注意第 20 个问题最后问，因为要先理解系统再判断是否过度设计。

#### Concepts
- **Release checklist / 发布检查表**：系统上线前用来确认问题、层次、控制、证据和风险的清单。
- **Self-audit / 自我审计**：设计者对自己系统进行结构化反思和证据核查。

### 第 22 页：Your project: draft its spine

Source ID: `src-a5decf9f86a2-pdf_page-00022`

项目要求你把系统结构讲清楚：哪些层是真的，哪些是模拟占位；智能在哪里；用户通过什么通道看到什么。这样可以避免项目只停留在“我要做一个 AI app”。

#### Concepts
- **Stub / 占位组件**：原型中暂时模拟而非完整实现的组件。
- **Five-slot sentence / 五槽句子**：用于压缩说明系统感知、推断、行动、输出通道和用户可见内容的句式。

### 第 23 页：What must be present, and how to look inside

Source ID: `src-a5decf9f86a2-pdf_page-00023`

总结页：四属性回答“是不是智能交互系统”，概念脊柱回答“如何分析它”。最终评价仍回到人类活动，而不是只看模型技术。

#### Concepts
- **Human activity / 人类活动**：用户真正要完成的工作、理解、控制和恢复过程。

### 第 24 页：References and further reading

Source ID: `src-a5decf9f86a2-pdf_page-00024`

参考页显示本讲的三个来源群：HCAI 与可靠/安全/可信，智能体结构与自主性，扫描器案例中的边缘检测和 OCR。项目写作时可按主题选读。

#### Concepts
- **Evidence anchor / 证据锚点**：课件主张背后的文献来源，可用于项目和复习时追溯。

### 第 25 页：Optional viewing: agents acting alone

Source ID: `src-a5decf9f86a2-pdf_page-00025`

可选观看把本讲概念扩展到更强的 agents。重点不是视频本身，而是用概念脊柱追踪观察、上下文、记忆、工具、行动和人类控制。

#### Concepts
- **Agent acting alone / 独立行动的智能体**：能够持续观察、规划和调用工具的系统，需要特别设计人类可见性与停止/纠错能力。
