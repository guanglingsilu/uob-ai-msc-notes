# 自测题

## 第 1 页：Human-Centred Intelligent Interaction and the Shape of the Module
- p001-q1 中文：第 1 页最重要的设计判断是什么？
  - 答案：本讲把“以人为中心”从口号变成可检验标准：用户是否保留控制、系统是否清楚地表达能力与边界、主动权规则是否可说明。
  - English: What is the key design judgement on page 1?
  - Answer: The lecture turns human-centred design into testable commitments for intelligent systems.
- p001-q2 中文：解释本页概念：Human-centred design / 以人为中心设计
  - 答案：把人的活动、控制、理解、恢复和责任放在系统设计中心。
  - English: Explain this concept: Human-centred design / 以人为中心设计
  - Answer: 把人的活动、控制、理解、恢复和责任放在系统设计中心。
## 第 2 页：Two inbox assistants, one tagline
- p002-q1 中文：第 2 页最重要的设计判断是什么？
  - 答案：这一页说明 human-centred 不是看宣传语，而是看控制结构。B 更接近以人为中心，因为它保留了审批和撤销。
  - English: What is the key design judgement on page 2?
  - Answer: The difference between the two assistants is not productivity but retained human control.
- p002-q2 中文：解释本页概念：Human control / 人类控制
  - 答案：人在系统行动前后保留审核、批准、撤销和纠错能力。
  - English: Explain this concept: Human control / 人类控制
  - Answer: 人在系统行动前后保留审核、批准、撤销和纠错能力。
## 第 3 页：'Human-centred' as three commitments
- p003-q1 中文：第 3 页最重要的设计判断是什么？
  - 答案：三个承诺是本讲骨架：错误先问设计责任；自动化不必牺牲控制；系统何时行动必须有规则。
  - English: What is the key design judgement on page 3?
  - Answer: The three commitments are accountability, two independent dimensions, and explicit initiative rules.
- p003-q2 中文：解释本页概念：Accountability / 问责
  - 答案：用户失败时先检查设计，而不是把责任推给用户。
  - English: Explain this concept: Accountability / 问责
  - Answer: 用户失败时先检查设计，而不是把责任推给用户。
## 第 4 页：Shneiderman's two-dimensional framework
- p004-q1 中文：第 4 页最重要的设计判断是什么？
  - 答案：核心误区是把自动化和控制当成此消彼长。Shneiderman 框架要求我们寻找“高自动化 + 高控制”的设计。
  - English: What is the key design judgement on page 4?
  - Answer: Shneiderman's framework separates automation from human control so a design can aim to be high on both.
- p004-q2 中文：解释本页概念：Two-dimensional HCAI framework / 二维 HCAI 框架
  - 答案：用自动化和人类控制两条独立轴评估系统，而不是只问自动化高低。
  - English: Explain this concept: Two-dimensional HCAI framework / 二维 HCAI 框架
  - Answer: 用自动化和人类控制两条独立轴评估系统，而不是只问自动化高低。
## 第 5 页：Moving a design on the plane
- p005-q1 中文：第 5 页最重要的设计判断是什么？
  - 答案：这页很实用：你不一定要换模型才能改善人本性。只要加 proposal、review、undo，就能增加控制。
  - English: What is the key design judgement on page 5?
  - Answer: A design can gain human control through proposal, review, and undo without changing the underlying model.
- p005-q2 中文：解释本页概念：Proposal-review-undo / 提议-审查-撤销
  - 答案：让系统先建议，人再批准，并提供撤销路径的控制模式。
  - English: Explain this concept: Proposal-review-undo / 提议-审查-撤销
  - Answer: 让系统先建议，人再批准，并提供撤销路径的控制模式。
## 第 6 页：Eighteen guidelines in four phases
- p006-q1 中文：第 6 页最重要的设计判断是什么？
  - 答案：Amershi 指南把人机 AI 互动拆成生命周期：开始、过程中、出错时、长期使用中。每个阶段都有不同设计责任。
  - English: What is the key design judgement on page 6?
  - Answer: The eighteen guidelines cover the lifecycle of human-AI interaction: initially, during interaction, when wrong, and over time.
- p006-q2 中文：解释本页概念：Guidelines for Human-AI Interaction / 人机 AI 交互指南
  - 答案：Amershi 等提出的 18 条设计指南，用于改善 AI 系统可理解、可控和可恢复性。
  - English: Explain this concept: Guidelines for Human-AI Interaction / 人机 AI 交互指南
  - Answer: Amershi 等提出的 18 条设计指南，用于改善 AI 系统可理解、可控和可恢复性。
## 第 7 页：Initially and during: G1 to G6
- p007-q1 中文：第 7 页最重要的设计判断是什么？
  - 答案：前六条关心用户一开始如何理解系统：它能做什么、做得多可靠、什么时候出现、是否相关、是否符合社会场景且不带偏见。
  - English: What is the key design judgement on page 7?
  - Answer: G1-G6 make capability, reliability, timing, relevance, social norms, and bias visible.
- p007-q2 中文：解释本页概念：Capability envelope / 能力边界
  - 答案：系统能可靠完成和不能完成的范围。
  - English: Explain this concept: Capability envelope / 能力边界
  - Answer: 系统能可靠完成和不能完成的范围。
## 第 8 页：When wrong and over time: G7 to G18
- p008-q1 中文：第 8 页最重要的设计判断是什么？
  - 答案：后十二条承认 AI 会错，所以要设计恢复和长期学习控制。重点不是让系统永不出错，而是错了之后人能看见、理解和修正。
  - English: What is the key design judgement on page 8?
  - Answer: G7-G18 address invocation, dismissal, correction, scoped uncertainty, explanation, memory, cautious learning, feedback, consequences, controls, and change notifications.
- p008-q2 中文：解释本页概念：Cautious learning / 谨慎学习
  - 答案：系统从用户行为中学习时不要过度推广，应让用户知道并能控制。
  - English: Explain this concept: Cautious learning / 谨慎学习
  - Answer: 系统从用户行为中学习时不要过度推广，应让用户知道并能控制。
## 第 9 页：Who moves next is a design decision
- p009-q1 中文：第 9 页最重要的设计判断是什么？
  - 答案：Mixed initiative 的本质是分配下一步行动权：人做、系统做，还是系统建议人决定。选择取决于置信度、注意力和错误成本。
  - English: What is the key design judgement on page 9?
  - Answer: Mixed initiative treats the next move as a shared design decision based on uncertainty, attention, and cost.
- p009-q2 中文：解释本页概念：Mixed initiative / 混合主动权
  - 答案：人和系统都可以推动任务，但谁行动由明确规则决定。
  - English: Explain this concept: Mixed initiative / 混合主动权
  - Answer: 人和系统都可以推动任务，但谁行动由明确规则决定。
## 第 10 页：Act, ask or wait
- p010-q1 中文：第 10 页最重要的设计判断是什么？
  - 答案：这是主动权规则的简洁公式。系统何时自动行动不应凭感觉，而要把置信度、错误成本和用户注意状态写成可测试规则。
  - English: What is the key design judgement on page 10?
  - Answer: Act, ask, or wait should be chosen by considering confidence, error cost, and attention.
- p010-q2 中文：解释本页概念：Act-ask-wait rule / 行动-询问-等待规则
  - 答案：高置信低成本就行动；有不确定或成本就询问；否则等待。
  - English: Explain this concept: Act-ask-wait rule / 行动-询问-等待规则
  - Answer: 高置信低成本就行动；有不确定或成本就询问；否则等待。
## 第 11 页：The gulf between expectation and experience
- p011-q1 中文：第 11 页最重要的设计判断是什么？
  - 答案：宣传和界面会塑造用户期待。如果系统看起来像真人助理，用户会期待它理解更多；实际能力不足就形成 expectation gulf。
  - English: What is the key design judgement on page 11?
  - Answer: The expectation gulf is a mismatch between what people expect an assistant to understand and what it reliably does.
- p011-q2 中文：解释本页概念：Expectation gulf / 期待鸿沟
  - 答案：系统呈现出的能力形象与真实体验之间的差距。
  - English: Explain this concept: Expectation gulf / 期待鸿沟
  - Answer: 系统呈现出的能力形象与真实体验之间的差距。
## 第 12 页：The gulf is a mental-model mismatch
- p012-q1 中文：第 12 页最重要的设计判断是什么？
  - 答案：期待鸿沟不是单纯用户误会，而是系统没有给足证据让用户校准心理模型。能力边界、可靠性、范围限定和解释都是校准工具。
  - English: What is the key design judgement on page 12?
  - Answer: The gulf can be reduced by making limits, reliability, uncertainty, and explanations visible so users can revise their mental models.
- p012-q2 中文：解释本页概念：Mental-model mismatch / 心理模型错配
  - 答案：用户以为系统怎样工作，与系统实际可靠能力不一致。
  - English: Explain this concept: Mental-model mismatch / 心理模型错配
  - Answer: 用户以为系统怎样工作，与系统实际可靠能力不一致。
## 第 13 页：Your turn: name the guideline, then the fix
- p013-q1 中文：第 13 页最重要的设计判断是什么？
  - 答案：练习要求你不要只说“体验差”，而要把问题映射到具体指南和三个承诺。例如误触发送破坏主动权与可撤销性，静默改档案破坏谨慎学习与通知。
  - English: What is the key design judgement on page 13?
  - Answer: The activity trains diagnosis: name the broken guideline, propose a repair, and link it to one of the commitments.
- p013-q2 中文：解释本页概念：Guideline diagnosis / 指南诊断
  - 答案：把交互失败映射到具体人机 AI 指南，再提出修复。
  - English: Explain this concept: Guideline diagnosis / 指南诊断
  - Answer: 把交互失败映射到具体人机 AI 指南，再提出修复。
## 第 14 页：The recommender, initially
- p014-q1 中文：第 14 页最重要的设计判断是什么？
  - 答案：推荐系统一开始就要亮明能力边界、可靠性和用户模型位置。这样用户才知道推荐来自哪里，也知道它不会越权。
  - English: What is the key design judgement on page 14?
  - Answer: The recommender should initially reveal capability, reliability, confidence, and where the user model can be inspected.
- p014-q2 中文：解释本页概念：User model / 用户模型
  - 答案：系统保存的关于用户偏好、历史和推断的表示。
  - English: Explain this concept: User model / 用户模型
  - Answer: 系统保存的关于用户偏好、历史和推断的表示。
## 第 15 页：The recommender, during interaction
- p015-q1 中文：第 15 页最重要的设计判断是什么？
  - 答案：推荐不是只给结果，还要让用户检查“为什么现在推荐这个”。时机、情境相关性和简短理由能增强可见性。
  - English: What is the key design judgement on page 15?
  - Answer: During interaction, timing, relevance, and reasons make recommendations checkable.
- p015-q2 中文：解释本页概念：Reason-giving / 给出理由
  - 答案：用简短证据说明推荐为何出现，帮助用户挑战或校准系统推断。
  - English: Explain this concept: Reason-giving / 给出理由
  - Answer: 用简短证据说明推荐为何出现，帮助用户挑战或校准系统推断。
## 第 16 页：The recommender, when wrong
- p016-q1 中文：第 16 页最重要的设计判断是什么？
  - 答案：真正修复推荐错误要改原因，而不是只删结果。系统需要识别异常行为、暂停学习或让用户标记“不是我”。
  - English: What is the key design judgement on page 16?
  - Answer: When a recommender is wrong, correction should address the mistaken profile update, not only dismiss the visible tile.
- p016-q2 中文：解释本页概念：Cause-level correction / 原因层修正
  - 答案：修正导致错误输出的用户模型或学习记录，而不是只隐藏表面结果。
  - English: Explain this concept: Cause-level correction / 原因层修正
  - Answer: 修正导致错误输出的用户模型或学习记录，而不是只隐藏表面结果。
## 第 17 页：Slide 16 comments
- p017-q1 中文：第 17 页最重要的设计判断是什么？
  - 答案：这一页是课件批注，不是正式授课内容。它提醒我们：引用或编号如果不自明，会增加理解负担；更好的做法是把引用连接到概念。
  - English: What is the key design judgement on page 17?
  - Answer: This page contains review comments rather than lecture content. It highlights that references should be concept-linked rather than opaque numbers.
- p017-q2 中文：解释本页概念：Review comment / 课件批注
  - 答案：课件制作过程中的反馈，不应和正式课程主张混淆。
  - English: Explain this concept: Review comment / 课件批注
  - Answer: 课件制作过程中的反馈，不应和正式课程主张混淆。
## 第 18 页：The recommender, over time: the fix
- p018-q1 中文：第 18 页最重要的设计判断是什么？
  - 答案：这页给出推荐器长期学习的好设计：不要因为一天异常就改用户模型；要通知变化、显示证据，并提供全局控制。
  - English: What is the key design judgement on page 18?
  - Answer: The fix is cautious, visible, controllable adaptation: repeated evidence, change notifications, and global controls.
- p018-q2 中文：解释本页概念：Guest session / 访客会话
  - 答案：允许他人使用设备而不污染主用户模型的模式。
  - English: Explain this concept: Guest session / 访客会话
  - Answer: 允许他人使用设备而不污染主用户模型的模式。
## 第 19 页：The project is a compact research paper
- p019-q1 中文：第 19 页最重要的设计判断是什么？
  - 答案：项目不是单纯做 demo，而是小型研究：问题、文献、空白、贡献、原型和证据必须连起来。
  - English: What is the key design judgement on page 19?
  - Answer: The project is framed as a compact research paper: question, system, evidence, and contribution.
- p019-q2 中文：解释本页概念：Research contribution / 研究贡献
  - 答案：项目相对已有工作的新增价值，可以体现在问题、设计、实现或评估证据上。
  - English: Explain this concept: Research contribution / 研究贡献
  - Answer: 项目相对已有工作的新增价值，可以体现在问题、设计、实现或评估证据上。
## 第 20 页：Eleven weeks, three phases, one final exam
- p020-q1 中文：第 20 页最重要的设计判断是什么？
  - 答案：这页是 assessment 结构。重要的是项目三阶段持续推进，Canvas quiz 用于练习，不计入成绩。
  - English: What is the key design judgement on page 20?
  - Answer: The assessment structure is 20% project across three phases and 80% final exam; weekly quizzes are formative.
- p020-q2 中文：解释本页概念：Formative assessment / 形成性评估
  - 答案：用于学习反馈但不计入最终成绩的练习。
  - English: Explain this concept: Formative assessment / 形成性评估
  - Answer: 用于学习反馈但不计入最终成绩的练习。
## 第 21 页：Three books, and how the module reads them
- p021-q1 中文：第 21 页最重要的设计判断是什么？
  - 答案：这页告诉你如何用书：不是泛读，而是按 lecture anchor 读。每本书支撑不同部分：HCAI、日常设计心理学、XR。
  - English: What is the key design judgement on page 21?
  - Answer: The module uses three books as chapter anchors, not as whole-book reading assignments.
- p021-q2 中文：解释本页概念：Chapter anchor / 章节锚点
  - 答案：每讲指定的阅读定位，用于支撑当前设计问题。
  - English: Explain this concept: Chapter anchor / 章节锚点
  - Answer: 每讲指定的阅读定位，用于支撑当前设计问题。
## 第 22 页：Who is it for, and what does that commit us to?
- p022-q1 中文：第 22 页最重要的设计判断是什么？
  - 答案：总结页把本讲压缩成项目原则：先问为谁设计，再用指南和主动权规则保证人在系统推断与行动中仍保留控制。
  - English: What is the key design judgement on page 22?
  - Answer: The synthesis connects human-centred commitments to project work and later module checkpoints.
- p022-q2 中文：解释本页概念：Gap sentence / 研究空白句
  - 答案：用一句话说明现有工作没有解决什么，以及你的项目切入点。
  - English: Explain this concept: Gap sentence / 研究空白句
  - Answer: 用一句话说明现有工作没有解决什么，以及你的项目切入点。
## 第 23 页：References and further reading
- p023-q1 中文：第 23 页最重要的设计判断是什么？
  - 答案：参考页把每个概念的学术来源对应起来。复习时按主题读：HCAI 看 Shneiderman，日常设计看 Norman，指南看 Amershi，主动权看 Horvitz，期待鸿沟看 Luger & Sellen。
  - English: What is the key design judgement on page 23?
  - Answer: The references map each design claim to its supporting literature.
- p023-q2 中文：解释本页概念：Citation mapping / 引文映射
  - 答案：把课程概念与支撑文献一一对应，便于复习和项目引用。
  - English: Explain this concept: Citation mapping / 引文映射
  - Answer: 把课程概念与支撑文献一一对应，便于复习和项目引用。