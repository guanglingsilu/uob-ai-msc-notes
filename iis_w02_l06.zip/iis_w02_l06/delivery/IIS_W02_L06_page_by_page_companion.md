# Action, Error, Agency and Decision

逐页完整翻译与复习笔记。

## 第 1 页：Action, Error, Agency and Decision

Source ID: `src-94b2bad90a89-pdf_page-00001`

![PDF page 1](../assets/pages/page_001.png)

### 原文
```text
Action, Error, Agency 
and Decision

Intelligent Interactive Systems  ·  Week 2  ·  Lecture 06
University of Birmingham

Course-own diagram. A thermostat that learns, and the five ideas of the 
lecture.
```

### 完整中文翻译
行动、错误、能动性与决策。

智能交互系统 - 第 2 周 - 第 6 讲。伯明翰大学。

课程自绘图：一个会学习的恒温器，以及本讲的五个概念。

### 中文释义
本讲把前两讲的注意、记忆和心理模型连接到行动：用户如何知道能做什么，为什么会错，系统替人行动时能动性感如何改变。

### English Explanation
This lecture connects cues and mental models to action, error, agency, and decision-making.

### 概念解析
- **Agency / 能动性感**：人感觉“是我在行动并造成结果”的主观体验。

### 自测问题
**Q1 中文：** 第 1 页的核心复习点是什么？
**答：** 本讲把前两讲的注意、记忆和心理模型连接到行动：用户如何知道能做什么，为什么会错，系统替人行动时能动性感如何改变。
**Q1 English:** What is the key revision point on page 1?
**Answer:** This lecture connects cues and mental models to action, error, agency, and decision-making.

**Q2 中文：** 解释本页概念：Agency / 能动性感
**答：** 人感觉“是我在行动并造成结果”的主观体验。
**Q2 English:** Explain this concept: Agency / 能动性感
**Answer:** 人感觉“是我在行动并造成结果”的主观体验。

## 第 2 页：A door that needs a sign

Source ID: `src-94b2bad90a89-pdf_page-00002`

![PDF page 2](../assets/pages/page_002.png)

### 原文
```text
A door that needs a sign

Lecture 06 · Hook

A plate says "push" and a handle says 
"pull"; a signifier tells us which affordance 
is available.

Interaction 1: give one word for what the plate 
invites and one for what the handle invites.

An assistant that can send email but shows 
no sign has the same design problem: 
capability without a visible signifier; a 
thermostat that changes with no visible cause 
removes the handle as well.
```

### 完整中文翻译
一扇需要标识的门。

第 6 讲 - 引入。

一块板说“推”，一个把手说“拉”；signifier 告诉我们哪个 affordance 可用。

互动 1：用一个词说出板子邀请什么，用一个词说出把手邀请什么。

一个能发邮件却没有标识的助手有同样设计问题：有能力但没有可见 signifier；一个没有可见原因就改变的恒温器甚至把把手也移除了。

### 中文释义
门的例子说明 affordance 和 signifier 的区别。智能系统也需要把能力显示出来，否则用户不知道如何行动或如何控制。

### English Explanation
The door example introduces affordance and signifier, then maps them onto intelligent systems that hide capability or control.

### 概念解析
- **Affordance / 可供性**：对象或系统允许某个人做的事情。
- **Signifier / 能指**：可感知的线索，告诉用户可供性存在。

### 自测问题
**Q1 中文：** 第 2 页的核心复习点是什么？
**答：** 门的例子说明 affordance 和 signifier 的区别。智能系统也需要把能力显示出来，否则用户不知道如何行动或如何控制。
**Q1 English:** What is the key revision point on page 2?
**Answer:** The door example introduces affordance and signifier, then maps them onto intelligent systems that hide capability or control.

**Q2 中文：** 解释本页概念：Affordance / 可供性
**答：** 对象或系统允许某个人做的事情。
**Q2 English:** Explain this concept: Affordance / 可供性
**Answer:** 对象或系统允许某个人做的事情。

## 第 3 页：Acting through a system, and being acted for

Source ID: `src-94b2bad90a89-pdf_page-00003`

![PDF page 3](../assets/pages/page_003.png)

### 原文
```text
Acting through a system, and being acted for

Lecture 06 · Central question

Lecture 04 asked whether a 
cue arrives; Lecture 05 
asked what the person holds 
and which model forms.

Today asks how people act, 
why they err, and what 
changes when a system acts 
on their behalf.

We connect signifiers, gulfs, 
errors, agency, decision, and 
automation through the 
person's cue-built model of 
action.
```

### 完整中文翻译
通过系统行动，以及被系统代为行动。

第 6 讲 - 中心问题。

第 4 讲问线索是否到达；第 5 讲问人保持什么、形成什么模型。

今天问人如何行动、为什么出错，以及当系统代表他们行动时发生什么变化。

我们通过人由线索建立的行动模型，把 signifier、鸿沟、错误、能动性、决策和自动化连接起来。

### 中文释义
中心问题是行动结构：用户不只是接收反馈，还要通过系统行动；当系统替人行动时，责任和控制会变复杂。

### English Explanation
The lecture asks how people act through systems and what changes when systems act on their behalf.

### 概念解析
- **Action model / 行动模型**：用户基于线索形成的关于如何行动、会发生什么的理解。

### 自测问题
**Q1 中文：** 第 3 页的核心复习点是什么？
**答：** 中心问题是行动结构：用户不只是接收反馈，还要通过系统行动；当系统替人行动时，责任和控制会变复杂。
**Q1 English:** What is the key revision point on page 3?
**Answer:** The lecture asks how people act through systems and what changes when systems act on their behalf.

**Q2 中文：** 解释本页概念：Action model / 行动模型
**答：** 用户基于线索形成的关于如何行动、会发生什么的理解。
**Q2 English:** Explain this concept: Action model / 行动模型
**Answer:** 用户基于线索形成的关于如何行动、会发生什么的理解。

## 第 4 页：Affordance, signifier, mapping

Source ID: `src-94b2bad90a89-pdf_page-00004`

![PDF page 4](../assets/pages/page_004.png)

### 原文
```text
Affordance, signifier, mapping

Lecture 06 · Action

An affordance is what an object or system 
allows this person to do, whether or not it 
is visible.

A signifier is the perceivable cue that 
communicates the affordance; it is the part 
design can control.

Mapping links controls to effects: Norman's 
stove works because knob positions mirror 
burner positions, so labels are unnecessary.

Course-own diagram after Norman (2013), chapter 1.
```

### 完整中文翻译
可供性、能指、映射。

第 6 讲 - 行动。

可供性是一个对象或系统允许这个人做什么，无论它是否可见。

能指是传达可供性的可感知线索；这是设计可以控制的部分。

映射把控制与效果连接起来：Norman 的炉灶之所以有效，是因为旋钮位置映射炉头位置，所以不需要标签。

课程自绘图，基于 Norman（2013）第 1 章。

### 中文释义
三概念是行动设计基础：系统能做什么、如何显示能做什么、控制和效果是否自然对应。

### English Explanation
Affordance, signifier, and mapping explain how users discover and perform actions.

### 概念解析
- **Mapping / 映射**：控制项与系统效果之间的对应关系。

### 自测问题
**Q1 中文：** 第 4 页的核心复习点是什么？
**答：** 三概念是行动设计基础：系统能做什么、如何显示能做什么、控制和效果是否自然对应。
**Q1 English:** What is the key revision point on page 4?
**Answer:** Affordance, signifier, and mapping explain how users discover and perform actions.

**Q2 中文：** 解释本页概念：Mapping / 映射
**答：** 控制项与系统效果之间的对应关系。
**Q2 English:** Explain this concept: Mapping / 映射
**Answer:** 控制项与系统效果之间的对应关系。

## 第 5 页：What tells you what a system can do?

Source ID: `src-94b2bad90a89-pdf_page-00005`

![PDF page 5](../assets/pages/page_005.png)

### 原文
```text
What tells you what a system can do?

Lecture 06 · Action

A microphone icon signifies speech, but it 
does not say which phrases or capabilities 
the system supports.

Suggestion chips are strong signifiers 
because they expose capabilities the person 
can recognise.

"Ask me anything" is a false signifier: a 
learning thermostat that silently overrides its 
dial also signals a control it does not honour.

Course-own mock-ups of six signifiers; none is a screenshot.
```

### 完整中文翻译
是什么告诉你系统能做什么？

第 6 讲 - 行动。

麦克风图标表示可以说话，但它没有说明系统支持哪些短语或能力。

建议 chips 是强 signifier，因为它们暴露了人可以识别的能力。

“问我任何事”是假的 signifier：一个学习型恒温器如果静默覆盖旋钮，也在发出一个它并不遵守的控制信号。

课程自制六个 signifier mock-up；没有一个是真实截图。

### 中文释义
AI 系统常有“能力不明”的问题。建议 chips 比空白输入框更强，因为它把可做事项放到世界中。

### English Explanation
A cue must indicate not just input mode but supported capability; suggestion chips are stronger signifiers than blank prompts.

### 概念解析
- **False signifier / 假能指**：界面暗示某种能力或控制存在，但系统实际上不支持或不遵守。

### 自测问题
**Q1 中文：** 第 5 页的核心复习点是什么？
**答：** AI 系统常有“能力不明”的问题。建议 chips 比空白输入框更强，因为它把可做事项放到世界中。
**Q1 English:** What is the key revision point on page 5?
**Answer:** A cue must indicate not just input mode but supported capability; suggestion chips are stronger signifiers than blank prompts.

**Q2 中文：** 解释本页概念：False signifier / 假能指
**答：** 界面暗示某种能力或控制存在，但系统实际上不支持或不遵守。
**Q2 English:** Explain this concept: False signifier / 假能指
**Answer:** 界面暗示某种能力或控制存在，但系统实际上不支持或不遵守。

## 第 6 页：The two gulfs

Source ID: `src-94b2bad90a89-pdf_page-00006`

![PDF page 6](../assets/pages/page_006.png)

### 原文
```text
The two gulfs

Lecture 06 · Action

Norman's seven stages move from goal, 
plan, and specification to performance, 
then perception, interpretation, and 
comparison.

The gulf of execution asks how to act; the gulf 
of evaluation asks what happened and 
whether it matches the goal.

Signifiers narrow execution, while feedback 
and a runnable mental model narrow 
evaluation.

Course-own diagram after Norman (1986; 2013, chapter 2).
```

### 完整中文翻译
两个鸿沟。

第 6 讲 - 行动。

Norman 的七阶段从目标、计划和指定，到执行，再到感知、解释和比较。

执行鸿沟问如何行动；评价鸿沟问发生了什么，以及它是否符合目标。

Signifier 缩小执行鸿沟；反馈和可运行心理模型缩小评价鸿沟。

课程自绘图，基于 Norman（1986；2013 第 2 章）。

### 中文释义
两个鸿沟是用户行动理论核心。用户要先知道怎么做，再知道做了之后发生了什么。AI 系统常同时扩大两者。

### English Explanation
The gulf of execution concerns how to act; the gulf of evaluation concerns understanding what happened.

### 概念解析
- **Gulf of execution / 执行鸿沟**：用户目标与可执行操作之间的距离。
- **Gulf of evaluation / 评价鸿沟**：系统结果与用户理解/目标比较之间的距离。

### 自测问题
**Q1 中文：** 第 6 页的核心复习点是什么？
**答：** 两个鸿沟是用户行动理论核心。用户要先知道怎么做，再知道做了之后发生了什么。AI 系统常同时扩大两者。
**Q1 English:** What is the key revision point on page 6?
**Answer:** The gulf of execution concerns how to act; the gulf of evaluation concerns understanding what happened.

**Q2 中文：** 解释本页概念：Gulf of execution / 执行鸿沟
**答：** 用户目标与可执行操作之间的距离。
**Q2 English:** Explain this concept: Gulf of execution / 执行鸿沟
**Answer:** 用户目标与可执行操作之间的距离。

## 第 7 页：A thermostat that learns

Source ID: `src-94b2bad90a89-pdf_page-00007`

![PDF page 7](../assets/pages/page_007.png)

### 原文
```text
A thermostat that learns

Lecture 06 · Worked example

You set 21, but the 
thermostat drops to 19 at 
ten and warms again on 
Thursday; the system has 
acted on an inferred 
pattern.

Comfort improves and the 
bill falls, yet neither the 
person nor the system 
makes the cause visible.

When the gulf of evaluation 
widens, the person feels less 
able to say "I acted".
```

### 完整中文翻译
一个会学习的恒温器。

第 6 讲 - worked example。

你设置 21 度，但恒温器在晚上十点降到 19 度，并在周四再次升温；系统基于推断模式采取了行动。

舒适度提高，账单下降，但人和系统都没有让原因可见。

当评价鸿沟扩大时，人会更难说“是我行动了”。

### 中文释义
恒温器案例说明：系统可能带来好结果，但如果原因不可见，用户会失去控制感和能动性感。

### English Explanation
A learning thermostat may improve outcomes while widening the gulf of evaluation and weakening agency.

### 概念解析
- **Learning thermostat / 学习型恒温器**：通过推断用户日程和偏好自动改变温度的系统。

### 自测问题
**Q1 中文：** 第 7 页的核心复习点是什么？
**答：** 恒温器案例说明：系统可能带来好结果，但如果原因不可见，用户会失去控制感和能动性感。
**Q1 English:** What is the key revision point on page 7?
**Answer:** A learning thermostat may improve outcomes while widening the gulf of evaluation and weakening agency.

**Q2 中文：** 解释本页概念：Learning thermostat / 学习型恒温器
**答：** 通过推断用户日程和偏好自动改变温度的系统。
**Q2 English:** Explain this concept: Learning thermostat / 学习型恒温器
**Answer:** 通过推断用户日程和偏好自动改变温度的系统。

## 第 8 页：Where the gulfs sit on the spine

Source ID: `src-94b2bad90a89-pdf_page-00008`

![PDF page 8](../assets/pages/page_008.png)

### 原文
```text
Where the gulfs sit on the spine

Lecture 06 · Application

Prompting can narrow the gulf of 
execution while opening a new question: 
did the system understand me?

Agents can widen evaluation because many 
hidden steps separate a request from visible 
results.

Observability narrows evaluation again by 
showing what happened, why, and what 
comes next; assistance and embodiment also 
shape agency.

Course-own diagram. The Lecture 02 spine with both gulfs marked and four later lectures placed on 
them.
```

### 完整中文翻译
鸿沟位于概念脊柱的哪里。

第 6 讲 - 应用。

提示可以缩小执行鸿沟，同时打开一个新问题：系统理解我了吗？

智能体会扩大评价鸿沟，因为许多隐藏步骤把请求与可见结果分开。

可观察性通过显示发生了什么、为什么发生、接下来会怎样来再次缩小评价鸿沟；辅助和具身也会塑造能动性。

课程自绘图：第 2 讲脊柱标出两个鸿沟和后续四讲。

### 中文释义
这页把 Norman 的鸿沟放回 L02 脊柱。agent 的问题在于隐藏步骤太多；observability 是缩小评价鸿沟的关键。

### English Explanation
Observability narrows the gulf of evaluation by showing what happened, why, and what comes next.

### 概念解析
- **Observability / 可观察性**：用户能看见系统内部状态、行动轨迹和后续计划的程度。

### 自测问题
**Q1 中文：** 第 8 页的核心复习点是什么？
**答：** 这页把 Norman 的鸿沟放回 L02 脊柱。agent 的问题在于隐藏步骤太多；observability 是缩小评价鸿沟的关键。
**Q1 English:** What is the key revision point on page 8?
**Answer:** Observability narrows the gulf of evaluation by showing what happened, why, and what comes next.

**Q2 中文：** 解释本页概念：Observability / 可观察性
**答：** 用户能看见系统内部状态、行动轨迹和后续计划的程度。
**Q2 English:** Explain this concept: Observability / 可观察性
**Answer:** 用户能看见系统内部状态、行动轨迹和后续计划的程度。

## 第 9 页：Slips versus mistakes

Source ID: `src-94b2bad90a89-pdf_page-00009`

![PDF page 9](../assets/pages/page_009.png)

### 原文
```text
Slips versus mistakes

Lecture 06 · Error

A slip preserves the right intention but 
executes the wrong action; a mistake 
begins with a wrong intention, rule, or 
guess (Reason, 1990).

Slips need constraints, confirmation, or undo; 
mistakes need a better model and clearer 
feedback.

Diagnose the error before redesigning, 
because the wrong remedy can irritate users 
or fail.

Course-own diagram after Reason (1990) and Norman (2013), chapter 5.
```

### 完整中文翻译
失误与错误判断。

第 6 讲 - 错误。

Slip 保留正确意图但执行了错误动作；mistake 从错误意图、规则或猜测开始（Reason，1990）。

Slip 需要约束、确认或撤销；mistake 需要更好的模型和更清楚的反馈。

先诊断错误再重新设计，因为错误补救会惹恼用户或无效。

课程自绘图，基于 Reason（1990）和 Norman（2013）第 5 章。

### 中文释义
错误类型不同，修复也不同。把 mistake 当 slip 加确认，可能只是增加负担；把 slip 当 mistake 加解释，也解决不了误触。

### English Explanation
Slips and mistakes need different remedies, so diagnosis comes before redesign.

### 概念解析
- **Slip / 失手**：意图正确但执行动作错。
- **Mistake / 错误判断**：意图、规则或理解本身错。

### 自测问题
**Q1 中文：** 第 9 页的核心复习点是什么？
**答：** 错误类型不同，修复也不同。把 mistake 当 slip 加确认，可能只是增加负担；把 slip 当 mistake 加解释，也解决不了误触。
**Q1 English:** What is the key revision point on page 9?
**Answer:** Slips and mistakes need different remedies, so diagnosis comes before redesign.

**Q2 中文：** 解释本页概念：Slip / 失手
**答：** 意图正确但执行动作错。
**Q2 English:** Explain this concept: Slip / 失手
**Answer:** 意图正确但执行动作错。

## 第 10 页：Three kinds of error in one voice assistant

Source ID: `src-94b2bad90a89-pdf_page-00010`

![PDF page 10](../assets/pages/page_010.png)

### 原文
```text
Three kinds of error in one voice assistant

Lecture 06 · Error

"Call Sam" dialling Samantha is a system 
recognition error: the system inferred the 
wrong target.

"Call Sam" when you meant to text is a user 
slip; setting an alarm believing it repeats daily 
is a user mistake.

Each needs a different remedy: show what 
was heard, confirm risky actions, and expose 
the system's model.

Course-own table; the assistant is generic.
```

### 完整中文翻译
一个语音助手中的三类错误。

第 6 讲 - 错误。

“Call Sam”拨给 Samantha 是系统识别错误：系统推断了错误目标。

当你其实想发短信却说“Call Sam”是用户 slip；设置闹钟并以为它每天重复是用户 mistake。

每一种都需要不同补救：显示听到了什么、确认高风险行动、暴露系统模型。

课程自制表格；助手为泛化示例。

### 中文释义
同一表面问题可能是系统识别错、用户失手或用户误解。修复要匹配根因。

### English Explanation
A voice-assistant failure can be system inference, user slip, or user mistake, each needing a different remedy.

### 概念解析
- **System recognition error / 系统识别错误**：系统把输入或目标推断错。

### 自测问题
**Q1 中文：** 第 10 页的核心复习点是什么？
**答：** 同一表面问题可能是系统识别错、用户失手或用户误解。修复要匹配根因。
**Q1 English:** What is the key revision point on page 10?
**Answer:** A voice-assistant failure can be system inference, user slip, or user mistake, each needing a different remedy.

**Q2 中文：** 解释本页概念：System recognition error / 系统识别错误
**答：** 系统把输入或目标推断错。
**Q2 English:** Explain this concept: System recognition error / 系统识别错误
**Answer:** 系统把输入或目标推断错。

## 第 11 页：Your turn: slip, mistake, or system inference?

Source ID: `src-94b2bad90a89-pdf_page-00011`

![PDF page 11](../assets/pages/page_011.png)

### 原文
```text
Your turn: slip, mistake, or system inference?

Lecture 06 · Interaction 2

Classify five failures—
wrong-window send, lane 
assistant, photo tag, two 
listeners, and a deleting 
agent—as slip, mistake, 
or system inference.

Name the remedy in three 
words, and mark cases that 
need two labels because 
human and system errors 
interact.

Take two minutes, then 
defend the agent case.
```

### 完整中文翻译
轮到你：slip、mistake，还是系统推断？

第 6 讲 - 互动 2。

把五个失败分类：错窗口发送、车道助手、照片标签、两个监听器和删除智能体，分为 slip、mistake 或系统推断。

用三个词命名补救措施，并标记需要两个标签的情况，因为人类错误和系统错误会相互作用。

用两分钟完成，然后为 agent 案例辩护。

### 中文释义
练习强调复合错误：人和系统可能同时贡献错误。删除 agent 这类高后果场景尤其需要双标签分析和恢复设计。

### English Explanation
The activity trains error diagnosis, including cases where human and system errors interact.

### 概念解析
- **Compound error / 复合错误**：人类错误和系统推断错误共同造成失败。

### 自测问题
**Q1 中文：** 第 11 页的核心复习点是什么？
**答：** 练习强调复合错误：人和系统可能同时贡献错误。删除 agent 这类高后果场景尤其需要双标签分析和恢复设计。
**Q1 English:** What is the key revision point on page 11?
**Answer:** The activity trains error diagnosis, including cases where human and system errors interact.

**Q2 中文：** 解释本页概念：Compound error / 复合错误
**答：** 人类错误和系统推断错误共同造成失败。
**Q2 English:** Explain this concept: Compound error / 复合错误
**Answer:** 人类错误和系统推断错误共同造成失败。

## 第 12 页：The sense of agency

Source ID: `src-94b2bad90a89-pdf_page-00012`

![PDF page 12](../assets/pages/page_012.png)

### 原文
```text
The sense of agency

Lecture 06 · Agency

The sense of agency is a computed feeling 
built from intention, action, predicted 
outcome, and comparison (Haggard, 2017).

It is strongest when an intended action is 
followed promptly by the predicted result.

Delay, mismatched outcomes, and actions not 
one's own weaken agency; perceived control 
extends the same feeling over time.

Course-own diagram after Haggard (2017).
```

### 完整中文翻译
能动性感。

第 6 讲 - 能动性。

能动性感是一种计算出来的感觉，由意图、行动、预测结果和比较构成（Haggard，2017）。

当意图行动后迅速出现预测结果时，它最强。

延迟、不匹配结果和非本人行动会削弱能动性感；感知到的控制会在更长时间上延伸这种感觉。

课程自绘图，基于 Haggard（2017）。

### 中文释义
能动性感不是抽象哲学，而是交互体验：我想做、我做了、结果如预期出现。智能系统替人行动会打断这个链条。

### English Explanation
Agency is strongest when intended action is promptly followed by predicted outcome.

### 概念解析
- **Sense of agency / 能动性感**：人感觉自己是行动和结果来源的体验。

### 自测问题
**Q1 中文：** 第 12 页的核心复习点是什么？
**答：** 能动性感不是抽象哲学，而是交互体验：我想做、我做了、结果如预期出现。智能系统替人行动会打断这个链条。
**Q1 English:** What is the key revision point on page 12?
**Answer:** Agency is strongest when intended action is promptly followed by predicted outcome.

**Q2 中文：** 解释本页概念：Sense of agency / 能动性感
**答：** 人感觉自己是行动和结果来源的体验。
**Q2 English:** Explain this concept: Sense of agency / 能动性感
**Answer:** 人感觉自己是行动和结果来源的体验。

## 第 13 页：The thermostat, redesigned for agency

Source ID: `src-94b2bad90a89-pdf_page-00013`

![PDF page 13](../assets/pages/page_013.png)

### 原文
```text
The thermostat, redesigned for agency

Lecture 06 · Agency

"Set to 21 by you, 18:40" 
and "lowered by schedule, 
22:00" make the cause of 
each change visible.

An override should persist 
until the person releases it, 
and the interface should say 
that it will.

"What I have learned about 
your week" should be 
editable, with changes 
announced before they 
happen; learning can remain 
while agency is restored.
```

### 完整中文翻译
为能动性感重新设计恒温器。

第 6 讲 - 能动性。

“由你设置为 21 度，18:40”和“由日程降低，22:00”让每次变化的原因可见。

覆盖设置应一直保持到用户释放它，并且界面应说明这一点。

“我学到了你这一周的什么”应该可编辑，并在变化发生前宣布；学习可以保留，同时恢复能动性感。

### 中文释义
设计不必取消学习功能，而是让原因、覆盖、学习内容和即将发生的改变可见可控。

### English Explanation
Agency can be restored by making causes visible, overrides persistent, and learned patterns editable.

### 概念解析
- **Override / 覆盖设置**：用户临时或明确覆盖自动化行为的控制。

### 自测问题
**Q1 中文：** 第 13 页的核心复习点是什么？
**答：** 设计不必取消学习功能，而是让原因、覆盖、学习内容和即将发生的改变可见可控。
**Q1 English:** What is the key revision point on page 13?
**Answer:** Agency can be restored by making causes visible, overrides persistent, and learned patterns editable.

**Q2 中文：** 解释本页概念：Override / 覆盖设置
**答：** 用户临时或明确覆盖自动化行为的控制。
**Q2 English:** Explain this concept: Override / 覆盖设置
**Answer:** 用户临时或明确覆盖自动化行为的控制。

## 第 14 页：Who feels they acted?

Source ID: `src-94b2bad90a89-pdf_page-00014`

![PDF page 14](../assets/pages/page_014.png)

### 原文
```text
Who feels they acted?

Lecture 06 · Agency

In a simple assistant, the person acts and 
the system proposes, so agency remains 
clear.

In an agentic system, the person initiates a 
multi-step process and the system acts; 
agency becomes shared and potentially 
unclear.

When the system decides without the 
person's intention, the person becomes an 
observer; co-agency requires initiation and a 
visible veto.

Course-own diagram. The Lecture 02 autonomy scale annotated for agency.
```

### 完整中文翻译
谁感觉是自己行动了？

第 6 讲 - 能动性。

在简单助手中，人行动，系统提出建议，所以能动性仍然清楚。

在智能体系统中，人启动多步骤过程，系统行动；能动性变成共享且可能不清晰。

当系统在没有人意图的情况下决策时，人变成观察者；共同能动性需要启动和可见否决权。

课程自绘图：第 2 讲自主性尺度加上能动性注释。

### 中文释义
自主性越高，越要设计 who acted 的可见性。共同能动性不是系统任意行动，而是人启动、系统执行、人能否决。

### English Explanation
As autonomy rises, agency becomes shared and needs visible initiation and veto.

### 概念解析
- **Co-agency / 共同能动性**：人和系统共同推进任务，但人的启动、监督和否决仍清楚可见。

### 自测问题
**Q1 中文：** 第 14 页的核心复习点是什么？
**答：** 自主性越高，越要设计 who acted 的可见性。共同能动性不是系统任意行动，而是人启动、系统执行、人能否决。
**Q1 English:** What is the key revision point on page 14?
**Answer:** As autonomy rises, agency becomes shared and needs visible initiation and veto.

**Q2 中文：** 解释本页概念：Co-agency / 共同能动性
**答：** 人和系统共同推进任务，但人的启动、监督和否决仍清楚可见。
**Q2 English:** Explain this concept: Co-agency / 共同能动性
**Answer:** 人和系统共同推进任务，但人的启动、监督和否决仍清楚可见。

## 第 15 页：Bounded rationality: people satisfice

Source ID: `src-94b2bad90a89-pdf_page-00015`

![PDF page 15](../assets/pages/page_015.png)

### 原文
```text
Bounded rationality: people satisfice

Lecture 06 · Decision

Simon (1955) describes 
bounded rationality: people 
search until an option is good 
enough, constrained by 
attention, memory, and time.

Joachims et al. (2005) swapped 
the top two search results and 
found that people still clicked 
the first.

Whatever the system ranks first 
becomes a decision made on 
the person's behalf, whether or 
not it is labelled as one.
```

### 完整中文翻译
有限理性：人会满足化。

第 6 讲 - 决策。

Simon（1955）描述有限理性：人在注意、记忆和时间限制下搜索，直到某个选项足够好。

Joachims 等（2005）交换搜索结果前两名后发现，人们仍然点击第一项。

系统排在第一位的东西就成了代表人做出的决策，无论它是否被标记为决策。

### 中文释义
排序本身就是影响决策。用户不会无限比较，而会满足化，所以系统默认和排名具有行动力量。

### English Explanation
Rankings shape decisions because people satisfice under attention, memory, and time constraints.

### 概念解析
- **Bounded rationality / 有限理性**：人在有限注意、记忆和时间下寻找足够好的选项，而非最优选项。
- **Satisficing / 满足化**：找到足够好选项就停止搜索。

### 自测问题
**Q1 中文：** 第 15 页的核心复习点是什么？
**答：** 排序本身就是影响决策。用户不会无限比较，而会满足化，所以系统默认和排名具有行动力量。
**Q1 English:** What is the key revision point on page 15?
**Answer:** Rankings shape decisions because people satisfice under attention, memory, and time constraints.

**Q2 中文：** 解释本页概念：Bounded rationality / 有限理性
**答：** 人在有限注意、记忆和时间下寻找足够好的选项，而非最优选项。
**Q2 English:** Explain this concept: Bounded rationality / 有限理性
**Answer:** 人在有限注意、记忆和时间下寻找足够好的选项，而非最优选项。

## 第 16 页：Heuristics and biases: anchoring

Source ID: `src-94b2bad90a89-pdf_page-00016`

![PDF page 16](../assets/pages/page_016.png)

### 原文
```text
Heuristics and biases: anchoring

Lecture 06 · Decision

In an anchoring 
demonstration, a random 
wheel landing on 10 or 65 
shifted median estimates to 
25 or 45 (Tversky and 
Kahneman, 1974).

Anchoring, availability, and 
representativeness are 
heuristics through which a 
bounded mind makes 
decisions.

An assistant's first draft 
anchors the edit, so generating 
a draft is already a decision.
```

### 完整中文翻译
启发式与偏差：锚定。

第 6 讲 - 决策。

在锚定演示中，一个随机轮盘停在 10 或 65，会把中位估计移动到 25 或 45（Tversky 和 Kahneman，1974）。

锚定、可得性和代表性是有限心智做决策时使用的启发式。

助手的第一稿会锚定编辑，因此生成草稿本身已经是一种决策。

### 中文释义
LLM 草稿不是中立起点。它会锚定用户后续编辑方向，所以“只是生成初稿”也在影响决策。

### English Explanation
An assistant's first draft anchors later edits, so draft generation is already a decision.

### 概念解析
- **Anchoring / 锚定**：初始数值或建议影响后续判断。

### 自测问题
**Q1 中文：** 第 16 页的核心复习点是什么？
**答：** LLM 草稿不是中立起点。它会锚定用户后续编辑方向，所以“只是生成初稿”也在影响决策。
**Q1 English:** What is the key revision point on page 16?
**Answer:** An assistant's first draft anchors later edits, so draft generation is already a decision.

**Q2 中文：** 解释本页概念：Anchoring / 锚定
**答：** 初始数值或建议影响后续判断。
**Q2 English:** Explain this concept: Anchoring / 锚定
**Answer:** 初始数值或建议影响后续判断。

## 第 17 页：Automation bias: introduced and parked

Source ID: `src-94b2bad90a89-pdf_page-00017`

![PDF page 17](../assets/pages/page_017.png)

### 原文
```text
Automation bias: introduced and parked

Lecture 06 · Decision

Parasuraman and Riley (1997) distinguish 
use, misuse, disuse, and abuse of 
automation.

An aid that was usually right but sometimes 
wrong led people to make both omission and 
commission errors (Skitka et al., 1999).

Parked means introduced now but not 
revisited in a scheduled lecture; optional 
material extends it, so agents are never 
taught without their human cost.

EO1

Course-own diagram after Parasuraman and Riley (1997) and Skitka, Mosier and Burdick (1999).
```

### 完整中文翻译
自动化偏差：介绍并暂放。

第 6 讲 - 决策。

Parasuraman 和 Riley（1997）区分自动化的使用、误用、不用和滥用。

一个通常正确但偶尔错误的辅助系统会导致人产生 omission 和 commission errors（Skitka 等，1999）。

“暂放”意味着现在介绍但不在已排定讲座中回访；可选材料会扩展它，因此 agent 永远不会在不讲人类成本的情况下被教授。

课程自绘图，基于 Parasuraman 和 Riley（1997）以及 Skitka、Mosier 和 Burdick（1999）。

### 中文释义
自动化偏差提醒我们：人可能过度依赖或错误拒绝自动化。通常正确的系统反而会诱导更危险的忽视。

### English Explanation
Automation bias covers misuse and disuse; usually-right aids can create omission and commission errors.

### 概念解析
- **Automation bias / 自动化偏差**：人因自动化建议而过度依赖、忽略或错误行动的倾向。

### 自测问题
**Q1 中文：** 第 17 页的核心复习点是什么？
**答：** 自动化偏差提醒我们：人可能过度依赖或错误拒绝自动化。通常正确的系统反而会诱导更危险的忽视。
**Q1 English:** What is the key revision point on page 17?
**Answer:** Automation bias covers misuse and disuse; usually-right aids can create omission and commission errors.

**Q2 中文：** 解释本页概念：Automation bias / 自动化偏差
**答：** 人因自动化建议而过度依赖、忽略或错误行动的倾向。
**Q2 English:** Explain this concept: Automation bias / 自动化偏差
**Answer:** 人因自动化建议而过度依赖、忽略或错误行动的倾向。

## 第 18 页：Slide 17 comment

Source ID: `src-94b2bad90a89-pdf_page-00018`

![PDF page 18](../assets/pages/page_018.png)

### 原文
```text
Slide 17

EO1 

Not clear. What is parked - are u going to return to it by week 10?
Eyal Ofek, 2026-09-23T15:51:57.628
```

### 完整中文翻译
第 17 页批注。

EO1：不清楚。什么被暂放？你会在第 10 周回到它吗？

Eyal Ofek，2026-09-23。

### 中文释义
这是课件批注，指出“parked”的含义需要更清晰。当前课件解释为：介绍但不在排定讲座中回访。

### English Explanation
This review comment asks for clarification of what 'parked' means.

### 概念解析
- **Terminology clarity / 术语清晰度**：课件中暂放、预告等词需要明确范围，避免学生误解。

### 自测问题
**Q1 中文：** 第 18 页的核心复习点是什么？
**答：** 这是课件批注，指出“parked”的含义需要更清晰。当前课件解释为：介绍但不在排定讲座中回访。
**Q1 English:** What is the key revision point on page 18?
**Answer:** This review comment asks for clarification of what 'parked' means.

**Q2 中文：** 解释本页概念：Terminology clarity / 术语清晰度
**答：** 课件中暂放、预告等词需要明确范围，避免学生误解。
**Q2 English:** Explain this concept: Terminology clarity / 术语清晰度
**Answer:** 课件中暂放、预告等词需要明确范围，避免学生误解。

## 第 19 页：Phase 1: mark your storyboard

Source ID: `src-94b2bad90a89-pdf_page-00019`

![PDF page 19](../assets/pages/page_019.png)

### 原文
```text
Phase 1: mark your storyboard

Lecture 06 · Project connection

For Phase 1 of your project, mark five 
storyboard frames: the goal, the person's 
action, the system's inference and action, 
the result, and recovery.

For each frame, record who acts (P, S, or 
both), which gulf is involved, and which 
signifier is shown.

A frame with S and no visible cause is the 
thermostat problem; bring the marked 
storyboard to Lab 2.

EO1

Course-own worksheet. Phase 2 storyboards are assessed; this draft is not.
```

### 完整中文翻译
阶段 1：标注你的 storyboard。

第 6 讲 - 项目连接。

为阶段 1 项目，标注五个 storyboard frame：目标、人的行动、系统推断和行动、结果、恢复。

对每一帧记录谁行动（P、S 或 both）、涉及哪个鸿沟，以及显示了哪个 signifier。

如果某一帧是 S 且没有可见原因，就是恒温器问题；把标注好的 storyboard 带到 Lab 2。

课程自制 worksheet。阶段 2 storyboard 会计分；这个草稿不计分。

### 中文释义
项目任务要求你把行动、系统推断、结果和恢复画出来，并标注谁在行动。这样能暴露“系统行动但原因不可见”的问题。

### English Explanation
The project task maps storyboards to actor, gulf, signifier, and recovery.

### 概念解析
- **Storyboard audit / 故事板审计**：逐帧标注人/系统行动、鸿沟、signifier 和恢复路径。

### 自测问题
**Q1 中文：** 第 19 页的核心复习点是什么？
**答：** 项目任务要求你把行动、系统推断、结果和恢复画出来，并标注谁在行动。这样能暴露“系统行动但原因不可见”的问题。
**Q1 English:** What is the key revision point on page 19?
**Answer:** The project task maps storyboards to actor, gulf, signifier, and recovery.

**Q2 中文：** 解释本页概念：Storyboard audit / 故事板审计
**答：** 逐帧标注人/系统行动、鸿沟、signifier 和恢复路径。
**Q2 English:** Explain this concept: Storyboard audit / 故事板审计
**Answer:** 逐帧标注人/系统行动、鸿沟、signifier 和恢复路径。

## 第 20 页：Slide 18 comment

Source ID: `src-94b2bad90a89-pdf_page-00020`

![PDF page 20](../assets/pages/page_020.png)

### 原文
```text
Slide 18

EO1 

Is this the beginning of the project? Maybe it requires a title and a slide to announce it?
Eyal Ofek, 2026-09-23T15:53:40.419
```

### 完整中文翻译
第 18 页批注。

EO1：这是项目部分的开始吗？也许需要一个标题和一页幻灯片来宣布它？

Eyal Ofek，2026-09-23。

### 中文释义
这是课件批注，提醒项目连接部分可能需要更明显的过渡。

### English Explanation
This review comment suggests making the project section transition clearer.

### 概念解析
- **Section transition / 章节过渡**：用标题或提示明确从理论转到项目任务。

### 自测问题
**Q1 中文：** 第 20 页的核心复习点是什么？
**答：** 这是课件批注，提醒项目连接部分可能需要更明显的过渡。
**Q1 English:** What is the key revision point on page 20?
**Answer:** This review comment suggests making the project section transition clearer.

**Q2 中文：** 解释本页概念：Section transition / 章节过渡
**答：** 用标题或提示明确从理论转到项目任务。
**Q2 English:** Explain this concept: Section transition / 章节过渡
**Answer:** 用标题或提示明确从理论转到项目任务。

## 第 21 页：The week's theories, and where each returns

Source ID: `src-94b2bad90a89-pdf_page-00021`

![PDF page 21](../assets/pages/page_021.png)

### 原文
```text
The week's theories, and where each returns

Lecture 06 · Synthesis and bridge

Lecture 04 supplied 
attention, detection, 
integration, limits, and 
feedback timing; Lecture 05 
added working memory, 
recognition, load, mental 
models, and explanations.

Today adds signifiers, the two 
gulfs, slips and mistakes, 
agency, decision, and 
automation.

For Lab 2, storyboard your 
problem and mark every frame 
with today's concepts.
```

### 完整中文翻译
本周理论，以及它们在哪里回归。

第 6 讲 - 综合与过渡。

第 4 讲提供了注意力、检测、整合、限制和反馈时机；第 5 讲加入工作记忆、识别、负荷、心理模型和解释。

今天加入 signifier、两个鸿沟、slip 与 mistake、能动性、决策和自动化。

为 Lab 2，用 storyboard 表达你的问题，并用今天的概念标注每一帧。

### 中文释义
这页把 Week 2 全部理论汇总成项目工具箱。Lab 2 的核心是把 storyboard 逐帧概念化。

### English Explanation
The synthesis gathers Week 2 concepts and directs students to apply them to Lab 2 storyboards.

### 概念解析
- **Week 2 theory toolkit / 第二周理论工具箱**：注意、记忆、心理模型、行动、错误、能动性和决策等用于分析交互的概念集合。

### 自测问题
**Q1 中文：** 第 21 页的核心复习点是什么？
**答：** 这页把 Week 2 全部理论汇总成项目工具箱。Lab 2 的核心是把 storyboard 逐帧概念化。
**Q1 English:** What is the key revision point on page 21?
**Answer:** The synthesis gathers Week 2 concepts and directs students to apply them to Lab 2 storyboards.

**Q2 中文：** 解释本页概念：Week 2 theory toolkit / 第二周理论工具箱
**答：** 注意、记忆、心理模型、行动、错误、能动性和决策等用于分析交互的概念集合。
**Q2 English:** Explain this concept: Week 2 theory toolkit / 第二周理论工具箱
**Answer:** 注意、记忆、心理模型、行动、错误、能动性和决策等用于分析交互的概念集合。

## 第 22 页：References and further reading

Source ID: `src-94b2bad90a89-pdf_page-00022`

![PDF page 22](../assets/pages/page_022.png)

### 原文
```text
References and further reading

Lecture 06 · References

Norman, D. A. (2013). The Design of Everyday Things (revised and expanded edition). Basic Books. Chapters 
1–2 and 5.

Norman, D. A. (1986). Cognitive engineering. In D. A. Norman & S. W. Draper (Eds.), User Centered System Design 
(pp. 31–61). Lawrence Erlbaum.

Reason, J. (1990). Human Error. Cambridge University Press.

Haggard, P. (2017). Sense of agency in the human brain. Nature Reviews Neuroscience, 18(4), 196–207.

Simon, H. A. (1955). A behavioral model of rational choice. Quarterly Journal of Economics, 69(1), 99–118.

Tversky, A., & Kahneman, D. (1974). Judgment under uncertainty: heuristics and biases. Science, 185(4157), 1124–
1131.

Joachims, T., Granka, L., Pan, B., Hembrooke, H., & Gay, G. (2005). Accurately interpreting clickthrough data as 
implicit feedback. SIGIR 2005, 154–161.

Parasuraman, R., & Riley, V. (1997). Humans and automation: use, misuse, disuse, abuse. Human Factors, 39(2), 
230–253.

Skitka, L. J., Mosier, K. L., & Burdick, M. (1999). Does automation bias decision-making? International Journal of 
Human-Computer Studies, 51(5), 991–1006.

Shneiderman, B. (2022). Human-Centered AI. Oxford University Press; the control-centre design metaphor, previewed.   
·   Full list with verification notes: W02_L06_references.md

Course-own diagram. The sources grouped by what they support.
```

### 完整中文翻译
参考文献与延伸阅读。

第 6 讲 - 参考文献。

Norman（2013）《The Design of Everyday Things》修订扩展版，第 1-2 章和第 5 章。

Norman（1986）《Cognitive engineering》，见 User Centered System Design，31-61。

Reason（1990）《Human Error》。Cambridge University Press。

Haggard（2017）《Sense of agency in the human brain》。Nature Reviews Neuroscience, 18(4), 196-207。

Simon（1955）《A behavioral model of rational choice》。Quarterly Journal of Economics, 69(1), 99-118。

Tversky 与 Kahneman（1974）《Judgment under uncertainty: heuristics and biases》。Science, 185(4157), 1124-1131。

Joachims 等（2005）《Accurately interpreting clickthrough data as implicit feedback》。SIGIR 2005, 154-161。

Parasuraman 与 Riley（1997）《Humans and automation: use, misuse, disuse, abuse》。Human Factors, 39(2), 230-253。

Skitka、Mosier 与 Burdick（1999）《Does automation bias decision-making?》。IJHCS, 51(5), 991-1006。

Shneiderman（2022）《Human-Centered AI》；控制中心设计隐喻预告。完整核验注释：W02_L06_references.md。

### 中文释义
参考页覆盖 Norman 行动理论、Reason 错误分类、Haggard 能动性、Simon 有限理性、Tversky/Kahneman 启发式、自动化偏差等。

### English Explanation
The references anchor action theory, error, agency, bounded rationality, heuristics, ranking effects, and automation bias.

### 概念解析
- **Action-theory sources / 行动理论来源**：支撑 affordance、鸿沟、错误、能动性和自动化决策的文献。

### 自测问题
**Q1 中文：** 第 22 页的核心复习点是什么？
**答：** 参考页覆盖 Norman 行动理论、Reason 错误分类、Haggard 能动性、Simon 有限理性、Tversky/Kahneman 启发式、自动化偏差等。
**Q1 English:** What is the key revision point on page 22?
**Answer:** The references anchor action theory, error, agency, bounded rationality, heuristics, ranking effects, and automation bias.

**Q2 中文：** 解释本页概念：Action-theory sources / 行动理论来源
**答：** 支撑 affordance、鸿沟、错误、能动性和自动化决策的文献。
**Q2 English:** Explain this concept: Action-theory sources / 行动理论来源
**Answer:** 支撑 affordance、鸿沟、错误、能动性和自动化决策的文献。

## 第 23 页：Watch the first 90 seconds clip of Wargames (1983)

Source ID: `src-94b2bad90a89-pdf_page-00023`

![PDF page 23](../assets/pages/page_023.png)

### 原文
```text
Watch the first 90 seconds clip of Wargames (1983)

Gulf of evaluation: the humans can see missile tracks, but they cannot 
tell whether those tracks correspond to real missiles or a simulation. 

Mental model / signifier problem: the interface presents the information 
exactly as though it were real. There is essentially no signifier 
distinguishing simulation from reality. 

System inference/error: the displayed state is wrong from the operators’ 
perspective, but it arrives with strong authority — “confidence is high.” 

Automation bias: because the system is normally trusted, people start 
acting on its output instead of independently checking the world. 
Bounded rationality: under extreme time pressure, the operators cannot 
inspect everything; they act on the first apparently credible interpretation. 

Agency: the interesting question becomes who is actually making the 
decision? The general technically decides, but the computer has framed 
the situation and recommended the action. 
Ranking/default effect: WOPR recommends a full retaliatory strike. That 
recommendation itself becomes a powerful anchor for the human 
decision. 

Error diagnosis: is this a human mistake, a system inference problem, 
or an interface/feedback failure? It is actually a combination—which 
makes it excellent for discussion.

https://youtu.be/9RRGvAB4HF8?si=iVceCeyGYdRvguXY
```

### 完整中文翻译
观看《WarGames》（1983）前 90 秒片段。

评价鸿沟：人能看到导弹轨迹，但无法判断轨迹对应真实导弹还是模拟。

心理模型/signifier 问题：界面呈现信息的方式完全像真实情况；基本没有 signifier 区分模拟和现实。

系统推断/错误：从操作员角度看，显示状态是错误的，但它带着强权威到达：“confidence is high”。

自动化偏差：因为系统通常被信任，人们开始依据其输出行动，而不是独立核查世界。

有限理性：在极端时间压力下，操作员无法检查一切；他们依据第一个看似可信的解释行动。

能动性：有趣问题变成到底是谁在做决策？将军技术上做决定，但计算机框定了情境并建议行动。

排序/默认效应：WOPR 建议全面报复性打击。这个建议本身成为人类决策的强锚点。

错误诊断：这是人类 mistake、系统推断问题，还是界面/反馈失败？实际上是组合问题，因此非常适合讨论。

YouTube 链接见课件。

### 中文释义
可选片段把本讲所有概念放入高风险决策场景：评价鸿沟、signifier、自动化偏差、有限理性、能动性、锚定和复合错误。

### English Explanation
The WarGames clip is a compact case for gulf of evaluation, signifier failure, automation bias, bounded rationality, agency, anchoring, and compound error.

### 概念解析
- **High-stakes automation / 高风险自动化**：系统输出会影响重大决策，要求更强可见性、核查和人类控制。

### 自测问题
**Q1 中文：** 第 23 页的核心复习点是什么？
**答：** 可选片段把本讲所有概念放入高风险决策场景：评价鸿沟、signifier、自动化偏差、有限理性、能动性、锚定和复合错误。
**Q1 English:** What is the key revision point on page 23?
**Answer:** The WarGames clip is a compact case for gulf of evaluation, signifier failure, automation bias, bounded rationality, agency, anchoring, and compound error.

**Q2 中文：** 解释本页概念：High-stakes automation / 高风险自动化
**答：** 系统输出会影响重大决策，要求更强可见性、核查和人类控制。
**Q2 English:** Explain this concept: High-stakes automation / 高风险自动化
**Answer:** 系统输出会影响重大决策，要求更强可见性、核查和人类控制。
