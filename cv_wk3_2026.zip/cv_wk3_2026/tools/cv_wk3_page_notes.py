"""Manually curated, source-grounded notes for Computer Vision Week 3.

The generic companion builder is retained for the other lecture packs, but this
deck gets page-specific wording so that the Chinese translation is meaningful
and the equations, caveats, and visual labels are not replaced by heuristics.
"""

PAGE_NOTES = {}


def add(page, title, translation, cn, en, concepts, extension, qa):
    PAGE_NOTES[page] = {
        "title": title,
        "translation": translation,
        "cn": cn,
        "en": en,
        "concepts": concepts,
        "extension": extension,
        "qa": qa,
    }


def q(qzh, azh, qen, aen):
    return (qzh, azh, qen, aen)


add(1, "Week 3-1：图像处理基础",
    "本讲是 Computer Vision and Imaging 第 3 周第 1 部分。课程主题为图像处理基础，授课教师为 Qingjie Meng 博士，职务是医疗人工智能方向助理教授，所属单位为计算机科学学院。",
    "这一部分从数字图像的形成和表示开始，逐步介绍图像之间的算术运算、像素级和邻域运算、距离度量、邻域与连通性、几何变换以及直方图处理。",
    "This is Week 3-1 of Computer Vision and Imaging. It introduces the foundations of image processing, from image formation and representation to arithmetic operations, neighbourhood operations, distances, connectivity, geometric transformations, and histogram processing.",
    [("Digital image processing", "数字图像处理", "对数字化图像进行获取、增强、分析和解释的过程。"),
     ("Image representation", "图像表示", "用像素位置和像素值描述图像。"),
     ("Image enhancement", "图像增强", "通过变换使图像更适合观察或后续分析。")],
    "复习时先记住本讲的主线：表示图像 -> 改变像素或邻域 -> 处理空间结构 -> 分析灰度分布。后续滤波、分割和特征提取都建立在这条主线上。",
    [q("本部分主要覆盖哪些图像处理主题？", "包括图像形成与表示、图像算术、像素与邻域运算、距离、连通性、几何变换和直方图处理。", "Which image-processing topics are covered in this part?", "Image formation and representation, image arithmetic, pixel and neighbourhood operations, distance, connectivity, geometric transformations, and histogram processing.")])

add(2, "Outline：本讲结构",
    "本页列出本讲的提纲：图像处理的基本步骤；图像形成与表示；图像之间的算术运算；单像素运算和邻域运算；距离度量；邻域与连通性；几何变换；直方图处理。",
    "提纲展示了从低级操作到结构分析再到灰度统计的学习顺序。先掌握像素值如何被表示和运算，再理解空间关系，最后利用直方图描述整幅图像的灰度分布。",
    "The outline moves from basic low-level image operations to spatial relationships and then to histogram-based intensity analysis.",
    [("Single-pixel operation", "单像素运算", "输出像素只由输入图像同一位置的像素决定。"),
     ("Neighbourhood operation", "邻域运算", "输出像素由中心像素及其邻域共同决定。"),
     ("Histogram processing", "直方图处理", "根据灰度级出现频率改变或分析图像对比度。")],
    "可以把提纲当作考试复习清单：每个小节至少要能写出定义、核心公式、一个用途和一个可能的副作用。",
    [q("单像素运算和邻域运算的关键区别是什么？", "单像素运算只看当前位置，邻域运算还会读取中心像素周围的像素。", "What is the key difference between a single-pixel operation and a neighbourhood operation?", "A single-pixel operation uses only the pixel at the same position, whereas a neighbourhood operation also uses surrounding pixels.")])

add(3, "图像处理的基本步骤",
    "图示给出低级数字图像处理的一般流程：先进行图像获取，再进行滤波与增强，之后进行分割、特征提取和模式分类。图像会在流程中产生新的图像或特征；知识库为处理和分类提供先验知识。",
    "获取解决‘图像从哪里来’，滤波和增强解决‘怎样改善图像’，分割解决‘哪些像素属于目标’，特征提取解决‘怎样用更紧凑的量描述目标’，模式分类解决‘目标属于什么类别’。这些步骤不是绝对固定的流水线，具体任务可能跳过或反复使用某些步骤。",
    "The diagram presents a typical low-level digital image-processing pipeline: image acquisition, filtering and enhancement, segmentation, feature extraction, and pattern classification. A knowledge base can support the decisions, while images and features are produced along the way.",
    [("Segmentation", "图像分割", "把图像划分为具有意义的区域或目标。"),
     ("Feature extraction", "特征提取", "把图像或区域转换成用于比较和分类的特征。"),
     ("Knowledge base", "知识库", "保存用于解释、约束或决策的先验知识。")],
    "现代视觉系统通常是迭代式的：检测结果可以反过来指导分割，知识或模型也可以影响增强参数。考试中要区分‘处理步骤’和‘步骤之间传递的数据类型’。",
    [q("分割和特征提取分别回答什么问题？", "分割确定哪些像素属于哪些区域；特征提取把这些区域转换为可用于分析或分类的描述量。", "What questions do segmentation and feature extraction answer?", "Segmentation determines which pixels belong to which regions; feature extraction converts those regions into descriptors for analysis or classification.")])

add(4, "图像形成模型",
    "数字图像可表示为 f(x,y)=i(x,y)r(x,y)，其中 f(x,y) 是观测到的图像，i(x,y) 是照明分量，r(x,y) 是反射分量。像素强度 l=f(x,y) 位于 [Lmin,Lmax] 内；常见范围包括 [0,1] 或 [0,255]。",
    "图像亮度通常同时受到光源和物体反射特性的影响。照明分量描述照到场景上的光，反射分量描述物体把光反射回来的能力。因此，同一个物体在不同照明下可能产生不同的图像强度。",
    "The image-formation model separates an observed image into illumination and reflectance: f(x,y)=i(x,y)r(x,y). The intensity is bounded by the chosen representation range, such as [0,1] or [0,255].",
    [("Illumination", "照明分量", "到达物体表面的光照强度。"),
     ("Reflectance", "反射分量", "物体对入射光的反射特性。"),
     ("Intensity range", "强度范围", "允许的最小和最大像素值。")],
    "该乘法模型解释了为什么阴影会影响图像。经典处理方法会在对数域把乘法关系变成加法关系，再分别估计照明和反射。",
    [q("图像形成模型中的 f、i、r 分别表示什么？", "f 是观测图像，i 是照明，r 是反射，三者满足 f=i*r。", "What do f, i, and r represent in the image-formation model?", "f is the observed image, i is illumination, and r is reflectance, with f=i*r.")])

add(5, "数字图像的表示",
    "数字图像可以写成一个二维数组。位置 (i,j) 处的元素 a_ij=f(i,j)，表示图像函数 f 在该位置的像素值。数组的行和列分别对应离散的空间坐标，数组元素的数值对应亮度或颜色信息。",
    "连续图像经过空间采样和强度量化后，才得到可存储、计算的数字图像。这里的表示方式强调‘位置’和‘数值’是两个不同维度：位置说明像素在哪里，数值说明该像素是什么强度。",
    "A digital image is represented as a two-dimensional array. The element a_ij equals f(i,j), the sampled image value at the discrete position (i,j).",
    [("Sampling", "采样", "把连续空间位置变成离散的像素位置。"),
     ("Quantisation", "量化", "把连续强度映射到有限个数字灰度级。"),
     ("Pixel", "像素", "数字图像中一个位置及其对应数值的基本单元。")],
    "分辨率通常同时涉及空间采样密度和灰度级数量。增加像素数量改善空间细节，增加灰度级数量改善强度变化的表达能力，但两者都会增加数据量。",
    [q("a_ij 表示什么？", "它表示数字图像在第 i 行、第 j 列位置的像素值。", "What does a_ij represent?", "It represents the pixel value of the digital image at row i and column j.")])

add(6, "图像之间的算术运算",
    "对两幅图像进行逐像素运算可以得到新的图像。加法 s=f+g 常用于降噪；减法 d=f-g 常用于检测强度变化；乘法 p=f×g 常用于掩膜；除法 v=f÷g 常用于阴影校正。运算通常要求图像尺寸和像素对应位置一致。",
    "四种算术运算把两幅图像在同一位置的像素组合起来。它们不是抽象的数学练习，而是对应实际的视觉任务：加法可平均噪声，减法可突出变化，乘法可选择区域，除法可消除照明不均匀。",
    "Pixelwise arithmetic combines corresponding pixels of two images. Addition supports noise reduction, subtraction highlights changes, multiplication implements masking, and division supports shading correction.",
    [("Pixelwise operation", "逐像素运算", "每个输出位置只组合输入图像对应位置的值。"),
     ("Masking", "掩膜", "用一幅图像控制另一幅图像哪些位置被保留或抑制。"),
     ("Shading correction", "阴影校正", "补偿由不均匀照明造成的缓慢强度变化。")],
    "实际实现要注意溢出、截断和除零问题。例如 8 位图像加法可能超过 255，除法中应对很小的分母进行保护。",
    [q("四种算术运算分别有哪些典型用途？", "加法降噪，减法检测变化，乘法掩膜，除法进行阴影校正。", "What are the typical uses of the four arithmetic operations?", "Addition reduces noise, subtraction detects changes, multiplication performs masking, and division corrects shading.")])

add(7, "图像加法与噪声降低",
    "设 f(x,y) 为无噪声图像，η(x,y) 为加性噪声，受污染图像为 g(x,y)=f(x,y)+η(x,y)。对同一场景的 K 幅独立噪声图像求平均，可得到 g_bar(x,y)=1/K 乘以各幅 g_i(x,y) 的和。示例比较了 K=5、10、20、50、100 时的降噪效果。",
    "如果噪声的均值接近零且不同图像中的噪声相互独立，求平均会保留稳定的真实信号，同时让随机噪声相互抵消。K 越大，通常越平滑，但需要更多次采集，且不能消除系统性误差或运动造成的错位。",
    "For additive noise, g(x,y)=f(x,y)+η(x,y). Averaging K independent observations reduces zero-mean random noise while preserving the underlying image. The slide illustrates results for K=5, 10, 20, 50, and 100.",
    [("Additive noise", "加性噪声", "以相加方式叠加到原图像上的噪声。"),
     ("Ensemble average", "多次观测平均", "对多幅同场景图像逐像素求平均。"),
     ("Independent noise", "独立噪声", "不同观测中的噪声不会相互依赖。")],
    "平均后噪声方差通常按 1/K 缩小，标准差按 1/sqrt(K) 缩小。这个结论依赖独立同分布和正确配准，不能把不同位置或不同场景的图像直接平均。",
    [q("为什么多幅图像求平均可以降噪？", "零均值且独立的随机噪声在平均中会相互抵消，而真实图像内容在各次观测中保持一致。", "Why can averaging multiple images reduce noise?", "Independent zero-mean random noise tends to cancel in the average, while the underlying image content remains consistent across observations.")])

add(8, "图像减法与变化检测",
    "两幅图像相减得到 d(x,y)=f(x,y)-g(x,y)。如果两幅图像大部分区域相同，相减结果会在相同区域接近零，而在发生强度变化的位置产生明显响应。因此，图像减法可以用于图像比较和变化检测。",
    "减法关注的是差异而不是绝对亮度。应用中通常还要考虑配准误差、光照变化和噪声，否则轻微的错位或亮度漂移也会被误判为目标变化。",
    "Subtraction produces d(x,y)=f(x,y)-g(x,y). Similar areas cancel, while changes between the two images produce large positive or negative responses.",
    [("Difference image", "差分图像", "表示两幅图像对应像素差异的图像。"),
     ("Change detection", "变化检测", "根据差分响应寻找场景发生变化的位置。"),
     ("Registration", "图像配准", "将不同图像的同一物理位置对齐。")],
    "在实际变化检测中常使用绝对差 |f-g|、阈值化和形态学后处理。先配准再相减通常比直接相减可靠。",
    [q("相减结果中为什么相同区域接近零？", "因为相同位置的像素值彼此抵消，f(x,y)-g(x,y) 接近零。", "Why are unchanged regions close to zero after subtraction?", "Their corresponding pixel values cancel, so f(x,y)-g(x,y) is close to zero.")])

add(9, "图像乘法与掩膜",
    "两幅图像逐像素相乘得到 d(x,y)=f(x,y)g(x,y)。当 g 是取值为 0 或 1 的掩膜时，掩膜为 1 的位置保留 f，为 0 的位置被抑制。因此乘法可实现区域选择和掩膜操作。",
    "乘法可以把空间选择编码进一幅图像。二值掩膜最直观；灰度掩膜还可以实现软选择，使某些区域部分保留而不是完全保留或完全删除。",
    "Pixelwise multiplication gives d(x,y)=f(x,y)g(x,y). A binary mask preserves selected pixels and suppresses pixels where the mask is zero.",
    [("Binary mask", "二值掩膜", "只使用 0 和 1 控制像素保留或抑制。"),
     ("Region of interest", "感兴趣区域", "需要重点分析的图像区域。"),
     ("Soft mask", "软掩膜", "用 0 到 1 之间的值进行部分加权。")],
    "掩膜的坐标、尺寸和图像必须匹配。若像素值范围是 [0,255]，掩膜常先归一化到 [0,1]，否则乘法会造成严重缩放和溢出。",
    [q("掩膜中 0 和 1 分别有什么作用？", "0 抑制对应位置，1 保留对应位置的原图像值。", "What do 0 and 1 do in a mask?", "Zero suppresses the corresponding location, while one preserves the original value there.")])

add(10, "图像除法与阴影校正",
    "两幅图像逐像素相除得到 v(x,y)=f(x,y)/g(x,y)。如果 g 描述照明或背景的缓慢变化，除法可以补偿不均匀照明，从而实现阴影校正。",
    "除法适合处理乘性变化，例如图像形成模型中的照明项。它对分母很敏感：分母接近零时会放大噪声，因此实际算法需要设置下限、加小常数或在对数域进行处理。",
    "Pixelwise division produces v(x,y)=f(x,y)/g(x,y). When g represents a slowly varying illumination field, division can correct shading.",
    [("Multiplicative variation", "乘性变化", "会按比例改变像素强度的变化，例如照明不均匀。"),
     ("Shading field", "阴影场/照明场", "描述背景照明随空间缓慢变化的场。"),
     ("Numerical stability", "数值稳定性", "避免分母太小导致输出爆炸。")],
    "阴影校正常先估计平滑背景，再用原图除以背景。校正后还需要重新归一化到合法强度范围，并检查是否放大了暗区噪声。",
    [q("为什么除法可用于阴影校正？", "因为不均匀照明通常以乘法形式影响图像，除以估计的照明场可以消除这种变化。", "Why can division be used for shading correction?", "Uneven illumination often affects the image multiplicatively, so dividing by an estimated illumination field compensates for it.")])

add(11, "单像素运算：图像负片",
    "单像素变换把输入像素 z 映射为输出像素 s。图中给出的变换是 T(z)=L-1-z，其中 L 是灰度级数；当 L=255 时，像素值会按 s=254-z 的形式反转。结果是亮区域变暗，暗区域变亮，形成图像负片。",
    "单像素运算不需要邻域信息，每个位置独立处理。负片变换会反转强度顺序，适合观察暗背景中的亮细节或传统胶片式表示，但它不是一般意义上的对比度增强。",
    "A single-pixel transform maps each input intensity z independently. The negative transform is T(z)=L-1-z, which reverses the intensity ordering.",
    [("Point transform", "点变换", "只根据当前像素值决定输出像素值的变换。"),
     ("Negative image", "负片图像", "将低强度变成高强度、高强度变成低强度的图像。"),
     ("Gray-level count", "灰度级数 L", "可用强度等级的总数。")],
    "实现时要区分最大灰度值和灰度级数量：若 8 位图像有 256 个等级，则 L=256，最大值是 255。这个 off-by-one 是常见错误。",
    [q("负片变换的公式是什么？", "T(z)=L-1-z；当灰度级数为 256 时，最大灰度值为 255。", "What is the formula for the negative transform?", "T(z)=L-1-z; for 256 gray levels, the maximum gray value is 255.")])

add(12, "邻域运算",
    "以坐标 (x,y) 为中心定义邻域 S_xy。输出图像 g(x,y) 的像素值由输入图像 f 在该邻域内的像素共同决定。邻域可以是 3×3、5×5 等规则窗口，也可以依据问题定义为其他形状。",
    "邻域运算把局部空间结构纳入计算，因此能够平滑噪声、检测边缘或统计局部特征。窗口大小决定观察范围：窗口越大，平滑或统计更强，但细节也更容易被抹掉。",
    "A neighbourhood operation defines a set S_xy centred at (x,y). The output g(x,y) is computed from the input values of f inside that neighbourhood.",
    [("Neighbourhood S_xy", "邻域 S_xy", "以中心位置 (x,y) 为参考的局部像素集合。"),
     ("Local operation", "局部运算", "只使用输入图像的局部区域进行计算。"),
     ("Window size", "窗口大小", "决定运算使用的空间范围。")],
    "边界像素没有完整邻域，需要选择零填充、复制边界、镜像或只处理有效区域。边界策略会影响滤波结果，不能被忽略。",
    [q("邻域运算中的 S_xy 表示什么？", "它表示以 (x,y) 为中心、用于计算输出像素的局部邻域。", "What does S_xy represent in a neighbourhood operation?", "It is the local neighbourhood centred at (x,y) used to compute the output pixel.")])

add(13, "距离度量",
    "若 p、q、s 分别位于 (x,y)、(u,v)、(w,z)，距离应满足非负性、同一性、对称性和三角不等式：D(p,q)>=0，且 D(p,q)=0 当且仅当 p=q；D(p,q)=D(q,p)；D(p,s)<=D(p,q)+D(q,s)。常见距离包括欧氏距离 De、城市街区距离 D4 和棋盘距离 D8。",
    "欧氏距离是通常的直线距离；城市街区距离只允许水平或垂直移动；棋盘距离允许八方向移动，距离由两个坐标差的最大值决定。选择哪一种距离会改变邻域形状和连通关系。",
    "A valid distance metric is non-negative, symmetric, zero only for identical points, and satisfies the triangle inequality. The common image-grid metrics are Euclidean, city-block, and chessboard distances.",
    [("Euclidean distance", "欧氏距离", "De=sqrt((x-u)^2+(y-v)^2)。"),
     ("City-block distance", "城市街区距离", "D4=|x-u|+|y-v|，只沿水平和垂直方向计步。"),
     ("Chessboard distance", "棋盘距离", "D8=max(|x-u|,|y-v|)，允许对角移动。")],
    "距离度量不仅用于找邻居，也用于聚类、形态学、路径搜索和最近邻分类。要先确认坐标是否各向同性；像素物理间距不相等时应使用加权距离。",
    [q("D4 和 D8 的主要区别是什么？", "D4 只允许水平或垂直移动并相加坐标差；D8 允许对角移动并取坐标差的最大值。", "What is the main difference between D4 and D8?", "D4 uses only horizontal and vertical moves and sums coordinate differences; D8 allows diagonal moves and takes their maximum.")])

add(14, "三种网格距离的几何形状",
    "图中比较了城市街区距离、欧氏距离和棋盘距离形成的邻域。对于相同距离半径，D4 的等距集合呈菱形，欧氏距离呈圆形，D8 的等距集合呈方形。",
    "邻域的形状来自距离的定义。D4 更强调四连通结构，D8 更强调八连通结构；欧氏距离具有旋转对称性，但在离散网格上仍要用像素近似。",
    "The diagram compares the neighbourhood shapes induced by city-block, Euclidean, and chessboard distances: diamond-like, circular, and square-like respectively.",
    [("Metric-induced neighbourhood", "由距离诱导的邻域", "把距离不超过某个阈值的点集合起来。"),
     ("Four-connectivity", "四连通", "只把水平和垂直相邻像素视为直接相邻。"),
     ("Eight-connectivity", "八连通", "把水平、垂直和对角相邻像素都纳入。")],
    "在离散图像中，距离度量、邻域定义和连通性必须配套。混用 4 邻域和 8 邻域可能产生不同的区域数量和边界。",
    [q("为什么三种距离的邻域形状不同？", "因为它们允许的移动方式和计算坐标差的方法不同。", "Why do the three distances produce different neighbourhood shapes?", "They allow different moves and compute coordinate differences in different ways.")])

add(15, "邻域与连通性：像素邻居",
    "对位于 (x,y) 的像素 p，水平和垂直方向的邻居组成 N4(p)，也称四邻域；对角方向的邻居组成 ND(p)；八邻域为 N8(p)={N4(p),ND(p)}。",
    "邻域定义说明两个像素是否能一步到达。四邻域只连接共享边的像素，八邻域还连接共享角的像素。这是后续路径、区域和轮廓定义的基础。",
    "For a pixel p at (x,y), N4(p) contains horizontal and vertical neighbours, ND(p) contains diagonal neighbours, and N8(p) is their union.",
    [("N4", "四邻域", "像素的上、下、左、右邻居。"),
     ("ND", "对角邻域", "像素的四个对角邻居。"),
     ("N8", "八邻域", "四邻域与对角邻域的并集。")],
    "边界像素的邻域会少于内部像素。实现连通域算法时，要明确是否越界忽略，以及是否使用 4 邻域或 8 邻域。",
    [q("N8(p) 如何由 N4(p) 和 ND(p) 构成？", "N8(p) 是 N4(p) 与 ND(p) 的并集。", "How is N8(p) formed from N4(p) and ND(p)?", "N8(p) is the union of N4(p) and ND(p).")])

add(16, "邻域与连通性：网格示意",
    "图示用网格展示中心像素 p 在 (x,y) 处的邻域关系，并区分共享边的水平/垂直邻居和共享角的对角邻居。邻域关系决定从一个像素向周围像素扩展时允许的方向。",
    "连通性不是像素自身的属性，而是由邻域规则和允许的强度集合共同定义的关系。同一组像素在 4 连通下可能分成多个区域，在 8 连通下可能合并。",
    "The grid illustrates the neighbours of a central pixel p at (x,y), separating edge-sharing neighbours from diagonal neighbours. The selected neighbourhood determines which expansion directions are allowed.",
    [("Adjacency", "邻接", "两个像素按照选定邻域规则直接相邻。"),
     ("Connectivity", "连通性", "像素之间能否通过一条合法路径相互到达。"),
     ("Grid topology", "网格拓扑", "由离散网格上的邻域规则定义的空间关系。")],
    "处理细线和斜线时，4 连通与 8 连通的选择尤其重要。为了避免前景和背景同时出现拓扑歧义，常对二者使用互补的连通定义。",
    [q("邻域规则会影响什么结果？", "它会影响哪些像素相邻、哪些像素连成区域，以及最终的边界和连通分量。", "What results are affected by the neighbourhood rule?", "It affects adjacency, connected regions, connected components, and the resulting boundaries.")])

add(17, "邻接、连通性与 m-邻接",
    "集合 V 是用于定义邻接的允许强度值集合。二值图像中，如果只研究值为 1 的前景，可取 V={1}。课件列出 4 邻接、8 邻接和 m 邻接。连通性按照这些邻接标准建立区域之间的边界；灰度图像通常需要把多个强度值放入 V。",
    "邻域告诉我们几何上哪些位置相近，V 则进一步限定哪些像素值可以参与关系。m 邻接的目的，是在保留必要对角连接的同时消除 8 邻接可能产生的歧义。",
    "V is the set of intensity values allowed when defining adjacency. In a binary image, V={1} can define foreground adjacency. The slide distinguishes 4-, 8-, and m-adjacency; grayscale images usually use a larger V.",
    [("Set V", "强度集合 V", "允许参与邻接或连通定义的像素值集合。"),
     ("m-adjacency", "m-邻接", "通过条件限制对角连接以减少 8 邻接歧义。"),
     ("Connected component", "连通分量", "在指定邻接规则下互相连通的最大像素集合。")],
    "m-邻接的关键不是‘比 8 邻接更多’，而是有条件地允许对角邻接。做题时必须先写出 V，再检查共同 4 邻居中是否存在 V 中像素。",
    [q("V 在邻接定义中起什么作用？", "V 限定哪些强度值的像素可以被视为目标并参与邻接。", "What role does V play in adjacency?", "V restricts which intensity-valued pixels are considered part of the object and allowed to be adjacent.")])

add(18, "8 邻接与 m 邻接的歧义",
    "图中比较了一个像素排列、8 邻接的虚线连接，以及 m 邻接。8 邻接会把对角位置直接连起来，但在某些排列中可能产生多种连接解释；m 邻接通过检查共同的 4 邻域来删除这种歧义。",
    "8 邻接适合保持斜线连通，但可能让本来想分开的区域通过角点相连。m 邻接在对角连接前增加条件，因此可以在保留结构和避免错误合并之间折中。",
    "The slide contrasts an arrangement, diagonal links under 8-adjacency, and m-adjacency. m-adjacency removes ambiguities by allowing a diagonal link only when the common 4-neighbours do not create an alternative connection.",
    [("Ambiguous diagonal connection", "有歧义的对角连接", "对角相接可能让区域数量或边界解释不唯一。"),
     ("m-adjacent", "m-邻接", "满足额外共同邻域条件的对角邻接。"),
     ("Topology preservation", "拓扑保持", "尽量保持区域数量和连接结构的正确关系。")],
    "选择连通规则相当于选择图结构。机器学习前的预处理如果改变了连通性，后续目标计数、轮廓长度和区域统计都会改变。",
    [q("m 邻接要解决什么问题？", "它要避免 8 邻接中对角连接导致的连接歧义。", "What problem does m-adjacency solve?", "It avoids ambiguities caused by diagonal connections in 8-adjacency.")])

add(19, "路径、连通分量与区域邻接",
    "从 p=(x0,y0) 到 q=(xn,yn) 的路径是一个像素序列，其中相邻像素按选定规则邻接且像素互不重复。如果路径完全位于集合 S 内，则 p 与 q 在 S 中连通。连通分量是 S 中最大的连通子集。若 Ri 与 Rj 的并集连通，则两个区域相邻；否则它们不相邻且互不相交。",
    "这些定义把局部的邻接关系扩展为全局的区域关系。路径回答‘能否走到’，连通分量回答‘一组像素中有几个独立对象’，区域邻接回答‘两个区域是否共享连接关系’。",
    "A path is a sequence of distinct pixels with adjacent consecutive pixels. Two pixels are connected in S when a path between them lies entirely in S. A connected component is a maximal connected subset.",
    [("Path", "路径", "由连续邻接像素构成的序列。"),
     ("Connected component", "连通分量", "不能再扩大的连通子集。"),
     ("Region adjacency", "区域邻接", "两个区域的并集仍然连通时的区域关系。")],
    "洪水填充、深度优先搜索和并查集都可以求连通分量。算法结果必须标注使用的邻接方式，否则‘分成几个区域’没有唯一答案。",
    [q("连通分量为什么要定义为最大连通子集？", "因为这样可以把所有彼此可达的像素完整归入同一个区域，且不能再加入保持连通的像素。", "Why is a connected component defined as a maximal connected subset?", "It groups all mutually reachable pixels into one complete region and cannot be enlarged while remaining connected.")])

add(20, "前景、背景与补集",
    "图中有 K 个互不相交的区域 Rk。前景并集记为 Ru=R1∪R2∪...∪RK，其补集记为 Ru 的补集，代表背景。前景区域之间不重叠，背景包含不属于前景并集的像素。",
    "把图像划分为前景与背景是分割的基本形式。补集的定义依赖图像的整个定义域：不是‘没有标注的任意位置’，而是定义域中除前景外的所有位置。",
    "The slide defines K disjoint regions Rk, their union Ru as the foreground, and the complement of Ru as the background.",
    [("Disjoint regions", "互不相交区域", "任意两个区域没有共同像素。"),
     ("Union", "并集", "把所有前景区域合并为一个集合。"),
     ("Complement", "补集", "在图像定义域内不属于目标集合的像素。")],
    "前景/背景的角色可以按任务改变，例如医学图像中的器官、病灶或背景都可能成为前景。分割评价常比较预测前景与真实前景的交并比等指标。",
    [q("Ru 的补集在图像中通常表示什么？", "表示定义域内所有不属于前景并集 Ru 的像素，也就是背景。", "What does the complement of Ru usually represent?", "It contains all pixels in the image domain not belonging to the foreground union Ru, namely the background.")])

add(21, "轮廓与边界",
    "区域 R 的边界由那些属于 R、且至少有一个邻居位于补集中的像素构成。课件指出，同一组像素在 4 邻接和 8 邻接下可能得到不同的轮廓判定：如果邻接标准改变，哪些像素接触背景也会改变。",
    "边界是区域内部和背景之间的接口。边界定义必须同时说明区域、背景和邻域规则；只说‘外圈像素’并不严格，因为对角接触是否算接触取决于邻域。",
    "The boundary of a region R consists of pixels in R having at least one neighbour in the complement. The result depends on whether 4- or 8-adjacency is used.",
    [("Boundary/contour", "边界/轮廓", "与背景邻接的目标区域像素集合。"),
     ("Foreground", "前景", "当前要提取或分析的目标区域。"),
     ("Background", "背景", "前景集合在图像定义域中的补集。")],
    "轮廓提取是边缘检测、形状描述和形态学操作的基础。用 8 邻接定义前景时，背景常使用 4 邻接来避免前景和背景同时对角连通造成矛盾。",
    [q("一个前景像素什么时候属于轮廓？", "当它属于区域 R 且至少有一个按指定邻域定义的邻居属于背景补集时，它属于轮廓。", "When is a foreground pixel on the contour?", "It is on the contour when it belongs to R and at least one neighbour under the chosen rule belongs to the background complement.")])

add(22, "4 邻接与 8 邻接下的轮廓",
    "图中直接对比了使用 8 邻接和 4 邻接得到的轮廓。相同的区域像素排列在不同邻域规则下，会有不同的边界像素集合，因此轮廓位置和形状可能不同。",
    "这是上一页定义的具体视觉例子。做轮廓题时不要只凭图形直觉，应逐个检查每个前景像素是否存在符合规则的背景邻居。",
    "The diagram compares contours obtained with 8-adjacency and 4-adjacency. The same pixel arrangement can therefore produce different boundary sets.",
    [("Contour extraction", "轮廓提取", "根据目标与背景邻接关系找出边界像素。"),
     ("Adjacency-dependent boundary", "依邻接定义的边界", "邻域规则不同，边界结果可能不同。"),
     ("Pixel arrangement", "像素排列", "构成离散区域的空间布局。")],
    "轮廓结果不仅影响可视化，还影响周长、形状特征和后续对象识别。工程代码中应把 connectivity 作为显式参数。",
    [q("为什么同一图像可以得到不同轮廓？", "因为轮廓判定依赖邻域规则，4 邻接与 8 邻接对背景接触的判断不同。", "Why can the same image produce different contours?", "Contour membership depends on the neighbourhood rule, and 4- and 8-adjacency judge background contact differently.")])

add(23, "几何变换：齐次坐标",
    "几何变换 T 会改变图像中像素的空间位置或排列。为了统一表达平移等操作，通常使用齐次坐标和 3×3 矩阵。输入坐标经过矩阵变换后得到新的坐标，像素强度本身可以保持不变，但需要重新采样到输出网格。",
    "几何变换改变的是‘像素在哪里’，而不是首先改变‘像素是多少’。平移、旋转、缩放和错切可以组合成一个仿射变换矩阵；输出图像还涉及插值和边界处理。",
    "A geometric transformation T changes the spatial arrangement of image points. Homogeneous coordinates and a 3×3 matrix provide a unified representation, especially for translation and affine transformations.",
    [("Geometric transformation", "几何变换", "改变像素空间坐标或图像形状的变换。"),
     ("Homogeneous coordinates", "齐次坐标", "用额外坐标维度把平移纳入矩阵乘法。"),
     ("Affine transformation", "仿射变换", "保持直线和平行性的一类二维变换。")],
    "前向映射容易留下空洞，实际图像变换常用逆向映射：遍历输出像素，反查输入位置，再用最近邻、双线性或双三次插值取值。",
    [q("为什么平移通常需要齐次坐标？", "普通二维线性矩阵不能直接表示加法平移，加入齐次坐标后可以用 3×3 矩阵统一表示。", "Why are homogeneous coordinates useful for translation?", "A standard 2D linear matrix cannot directly express an additive translation; homogeneous coordinates allow it to be represented by one 3x3 matrix.")])

add(24, "几何变换的六种形式",
    "表格列出六种变换及其仿射矩阵和坐标方程。恒等变换保持 x、y 不变；缩放/反射使用 x'=c_x x、y'=c_y y，其中缩放因子取 -1 可实现反射；绕原点旋转满足 x'=x cosθ-y sinθ、y'=x sinθ+y cosθ；平移满足 x'=x+t_x、y'=y+t_y；垂直错切满足 x'=x+s_v y、y'=y；水平错切满足 x'=x、y'=s_h x+y。",
    "这些变换都属于二维仿射变换。矩阵中的参数控制尺度、角度、平移量或剪切强度。右侧示例用字母 T 展示变换后的形状与位置变化。",
    "The table presents identity, scaling/reflection, rotation about the origin, translation, vertical shear, and horizontal shear, together with their affine matrices and coordinate equations.",
    [("Identity", "恒等变换", "x'=x、y'=y，不改变位置。"),
     ("Rotation", "旋转", "绕原点按角度 θ 改变方向。"),
     ("Shear", "错切", "使一个坐标依赖另一个坐标，从而倾斜图形。")],
    "矩阵乘法的顺序会影响组合变换结果，例如先旋转后平移通常不等于先平移后旋转。实现旋转时还要明确旋转中心；绕图像中心旋转通常要先平移到原点。",
    [q("垂直错切和水平错切分别改变哪个坐标？", "垂直错切令 x'=x+s_v y、y'=y；水平错切令 x'=x、y'=s_h x+y。", "Which coordinate changes in vertical and horizontal shear?", "Vertical shear uses x'=x+s_v y and y'=y; horizontal shear uses x'=x and y'=s_h x+y.")])

add(25, "图像直方图",
    "对于 L 级灰度图像 f(x,y)，r_k 表示第 k 个灰度级。未归一化直方图为 h(r_k)=n_k，其中 n_k 是灰度级 r_k 的像素数量；归一化直方图为 p(r_k)=h(r_k)/(MN)=n_k/(MN)，M、N 是图像的尺寸。p(r_k) 可以估计各灰度级出现的概率。",
    "直方图忽略像素的空间位置，只统计每个强度出现了多少次。因此它能反映亮度、对比度和动态范围，但不能单独描述物体的形状或空间布局。",
    "For an L-level image, h(r_k)=n_k counts pixels at intensity r_k. The normalized histogram p(r_k)=n_k/(MN) estimates the probability of each intensity level.",
    [("Histogram", "直方图", "统计每个灰度级像素数量的分布。"),
     ("Normalized histogram", "归一化直方图", "把计数除以总像素数，得到概率估计。"),
     ("Dynamic range", "动态范围", "图像实际使用的强度区间宽度。")],
    "直方图均衡化使用的是灰度分布，不需要知道空间位置；所以两个空间结构完全不同的图像可能拥有相似直方图。",
    [q("归一化直方图为什么可以看作概率估计？", "因为每个灰度级的像素数除以总像素数，就是随机抽取一个像素落在该灰度级的频率估计。", "Why can a normalized histogram be viewed as a probability estimate?", "The count at a level divided by the total pixel count estimates the frequency that a random pixel has that intensity.")])

add(26, "图像与直方图的关系",
    "本页用多幅图像及其直方图展示灰度分布与视觉外观的关系。不同图像可能表现为暗、亮、低对比度或高对比度；直方图分别集中在低灰度、高灰度、窄范围或宽范围。",
    "直方图是图像的全局强度摘要。集中在低灰度通常意味着图像偏暗，集中在高灰度通常意味着偏亮，分布窄表示对比度低，分布宽表示使用了更宽的动态范围。",
    "The examples pair images with histograms to show how dark, bright, low-contrast, and high-contrast appearances correspond to different intensity distributions.",
    [("Dark image", "偏暗图像", "像素主要集中在低灰度区域。"),
     ("Bright image", "偏亮图像", "像素主要集中在高灰度区域。"),
     ("Contrast", "对比度", "图像强度变化范围或可分辨程度。")],
    "直方图形状只能提供统计线索。遇到多峰直方图时，峰可能对应不同物体或背景，阈值分割可以利用峰之间的谷，但仍要结合空间信息。",
    [q("低对比度图像的直方图通常有什么特征？", "像素集中在较窄的灰度范围内，而不是覆盖整个可用动态范围。", "What is typical of the histogram of a low-contrast image?", "Its pixels occupy a relatively narrow intensity range instead of the full available dynamic range.")])

add(27, "对比度拉伸",
    "低对比度图像的强度值集中在较窄范围内。对比度拉伸把这些值扩展到更宽的区间，理想情况下覆盖 [0,L-1]。图中比较了低对比度原图与拉伸后的图像。",
    "拉伸不会创造原图中不存在的细节，但会扩大已有强度差异，使视觉结构更清楚。线性拉伸要注意异常值，否则少量极亮或极暗像素会占用范围并压缩主体对比度。",
    "Contrast stretching expands a narrow intensity range toward [0,L-1]. It increases the visibility of existing intensity differences but does not create new spatial detail.",
    [("Contrast stretching", "对比度拉伸", "把实际灰度范围映射到更宽的输出范围。"),
     ("Low contrast", "低对比度", "像素强度集中在较窄范围，层次差异不明显。"),
     ("Clipping", "截断", "把超出范围的值限制到最小或最大输出值。")],
    "常见做法是用百分位数估计有效下、上界，减少离群点对拉伸的影响。拉伸与均衡化不同：前者通常使用简单的范围映射，后者使用累积分布函数。",
    [q("对比度拉伸的主要目标是什么？", "扩大图像实际使用的强度范围，使已有的亮度差异更容易观察。", "What is the main goal of contrast stretching?", "To expand the used intensity range so existing brightness differences become easier to see.")])

add(28, "直方图均衡化：基本映射",
    "直方图均衡化通过重新分配 [0,L-1] 内的强度值改善灰度分布。变换 T(r) 在 0<=r<=L-1 上单调递增，并满足 0<=T(r)<=L-1。低对比度图像经过映射 T 后得到均衡化图像。",
    "均衡化的核心是利用累积分布函数把频繁出现的强度区间拉开，把稀疏区间压缩或重新分配。单调性保证灰度顺序不会反转，但离散实现可能出现空灰度级或多个输入级映射到同一级。",
    "Histogram equalisation redistributes intensity values within [0,L-1]. The transform T is monotonic increasing and maps the original range into the legal output range.",
    [("Histogram equalisation", "直方图均衡化", "依据累积分布重新映射灰度以改善整体对比度。"),
     ("Monotonic transform", "单调变换", "输入强度顺序保持不反转的映射。"),
     ("CDF", "累积分布函数", "从低到高累加直方图概率的函数。")],
    "离散均衡化常写为 s_k=(L-1) sum_{j=0}^k p_r(r_j)，再进行取整。均衡后的直方图不一定严格平坦，这是有限样本和量化造成的正常现象。",
    [q("直方图均衡化中的 T(r) 需要满足什么性质？", "它应当单调递增，并把输入范围 [0,L-1] 映射到同一合法输出范围。", "What properties should T(r) have in histogram equalisation?", "It should be monotonic increasing and map [0,L-1] into the same legal output range.")])

add(29, "直方图均衡化：图像效果",
    "图中展示暗图像、亮图像、低对比度图像和高对比度图像，以及它们经过映射 T(r_k) 后的结果和直方图。均衡化通常使输出灰度分布更分散，从而提高整体对比度，但结果取决于原始直方图。",
    "均衡化不是简单地把所有图像变成相同外观。对于已经高对比度的图像，均衡化可能增强噪声或产生不自然效果；它更适合需要整体动态范围改善的场景。",
    "The examples show how dark, bright, low-contrast, and high-contrast images and their histograms change after applying T(r_k). The output distribution is generally spread over a wider range.",
    [("Intensity mapping", "强度映射", "把每个输入灰度级转换成输出灰度级。"),
     ("Global enhancement", "全局增强", "使用整幅图像统计量进行增强。"),
     ("Noise amplification", "噪声放大", "增强过程中同时放大了随机或细小强度波动。")],
    "均衡化对光照不均匀的图像可能不够理想，此时可使用局部均衡化或 CLAHE，并限制局部直方图的增益以避免噪声过度增强。",
    [q("直方图均衡化为什么可能放大噪声？", "噪声对应的灰度波动也会参与灰度映射，若被拉伸到更宽范围，就会变得更明显。", "Why can histogram equalisation amplify noise?", "Noise intensity variations also participate in the mapping and may be stretched over a wider range, making them more visible.")])

add(30, "第一部分总结",
    "本页回顾第一部分的主题：图像处理基本步骤、图像形成与表示、图像算术、单像素和邻域运算、距离度量、邻域与连通性、几何变换以及直方图处理。",
    "复习到这里应能把一个视觉问题映射到合适的操作：噪声可考虑加法平均或滤波，变化可考虑减法，区域选择可考虑掩膜，照明不均匀可考虑除法或直方图方法，空间位置变化可考虑几何变换。",
    "This summary revisits the first part: basic image-processing steps, image formation and representation, image arithmetic, pixel and neighbourhood operations, distances, connectivity, geometric transformations, and histogram processing.",
    [("Processing pipeline", "处理流程", "从获取到增强、分割、特征和分类的总体框架。"),
     ("Spatial relationship", "空间关系", "由邻域、距离和连通性描述的位置结构。"),
     ("Intensity distribution", "强度分布", "由直方图描述的全局灰度统计。")],
    "考试复习可以用‘现象 -> 操作 -> 假设 -> 风险’四步法：先判断问题，再写公式和用途，说明成立条件，最后指出边界、噪声或量化风险。",
    [q("本部分的知识可以按哪三条主线复习？", "按图像表示与强度、空间邻域与连通、全局灰度统计三条主线复习。", "What three lines can be used to revise this part?", "Revise it through representation and intensity, spatial neighbourhood and connectivity, and global intensity statistics.")])

add(31, "Q&A：第一部分问答页",
    "本页是第一部分的 Q&A 环节分隔页。页面没有列出可提取的具体问题文本，问题和回答需要结合前面关于图像表示、算术运算、空间关系、几何变换和直方图的内容进行复习。",
    "复习时应能解释每个公式的变量、每种操作的用途、邻域规则对结果的影响，以及为什么图像增强方法需要满足特定假设。",
    "This is the Q&A divider for Part 1. No specific question text is listed on the slide; the questions should be answered using the preceding material.",
    [("Revision question", "复习问题", "用来检查是否能从定义、公式和应用解释知识点的问题。"),
     ("Source-grounded answer", "基于课件的答案", "明确区分课件直接给出的内容和进一步推导。")],
    "建议自测时不要只背定义：给自己一个图像问题，说明选择哪种运算、需要什么假设，以及可能出现什么失败模式。",
    [q("第一部分至少要掌握哪几类问题？", "要掌握图像如何表示、像素如何运算、空间关系如何定义、几何如何变换以及灰度统计如何处理。", "What categories of questions should be mastered for Part 1?", "How images are represented, how pixels are operated on, how spatial relations are defined, how geometry is transformed, and how intensity statistics are processed.")])

add(32, "Week 3-2：空间滤波",
    "本讲是 Computer Vision and Imaging 第 3 周第 2 部分，主题是空间滤波。内容包括空间滤波的机制、相关与卷积、图像退化模型、平滑滤波、均值/高斯/顺序统计滤波，以及用于锐化的高通滤波。",
    "这一部分从‘一个输出像素如何由邻域计算’出发，先建立线性滤波和退化模型，再分别讨论降噪平滑和增强边缘的锐化。",
    "This is Week 3-2 on spatial filtering. It covers filtering mechanics, correlation and convolution, image degradation, smoothing filters, mean/Gaussian/order-statistics filters, and sharpening with high-pass filters.",
    [("Spatial filtering", "空间滤波", "在图像坐标域用局部窗口计算输出像素。"),
     ("Smoothing", "平滑", "抑制快速变化和噪声，通常会带来模糊。"),
     ("Sharpening", "锐化", "增强强度突变和边缘，使细节更突出。")],
    "第二部分的主线是‘滤波器如何组合邻域像素’。先分清相关和卷积，再根据噪声类型选择平滑方法，最后理解导数和拉普拉斯如何产生锐化。",
    [q("第二部分主要研究什么？", "主要研究空间滤波的计算机制、退化模型、平滑降噪和高通锐化。", "What is the main focus of Part 2?", "The mechanics of spatial filtering, degradation models, smoothing for denoising, and high-pass sharpening.")])

add(33, "第二部分提纲",
    "提纲包括：空间滤波机制，即相关和卷积；图像退化模型；空间滤波方法，包括图像平滑或低通滤波、均值/高斯/顺序统计滤波，以及图像锐化或高通滤波。",
    "平滑和锐化是相反但互补的目标：平滑降低局部变化，锐化强调局部变化。退化模型提供了‘观测图像是如何从原图得到的’的解释，帮助选择恢复或滤波方法。",
    "The outline covers spatial filtering mechanics, correlation and convolution, the image degradation model, smoothing/low-pass filtering, mean/Gaussian/order-statistics filters, and sharpening/high-pass filtering.",
    [("Low-pass filter", "低通滤波器", "保留缓慢变化，抑制快速变化的滤波器。"),
     ("High-pass filter", "高通滤波器", "强调快速变化和边缘的滤波器。"),
     ("Order-statistics filter", "顺序统计滤波器", "根据邻域像素排序位置选择输出。")],
    "选择滤波器时要同时考虑目标：是降低噪声、保留边缘、增强轮廓，还是估计退化过程。不能只根据‘滤波’这个名称判断效果。",
    [q("低通和高通滤波的目标分别是什么？", "低通主要平滑和抑制快速变化，高通主要增强快速变化和边缘。", "What are the goals of low-pass and high-pass filtering?", "Low-pass filtering smooths and suppresses rapid changes; high-pass filtering enhances rapid changes and edges.")])

add(34, "滤波与频率成分",
    "滤波的含义是通过、修改或拒绝图像中的特定频率成分。‘滤波器’这一名称借自频率域。低通滤波保留低频并产生平滑/模糊；高通滤波保留高频并突出边缘；带通和带阻分别保留或拒绝某个频率范围。",
    "虽然本讲重点是空间域，但低频和高频仍是理解滤波效果的有用语言。缓慢变化的背景通常对应低频，边缘、细纹理和噪声通常包含较多高频。",
    "Filtering passes, modifies, or rejects selected frequency components. Low-pass filtering smooths or blurs, high-pass filtering emphasizes edges, while band-pass and band-reject filters select or reject a frequency band.",
    [("Frequency component", "频率成分", "图像强度变化快慢对应的成分。"),
     ("Low frequency", "低频", "空间上缓慢变化的亮度结构。"),
     ("High frequency", "高频", "空间上快速变化的边缘、纹理或噪声。")],
    "空间域卷积与频率域乘法由卷积定理联系起来。实际选择空间滤波还是频率滤波，要看核大小、边界处理、计算成本和任务需求。",
    [q("为什么边缘通常包含高频成分？", "边缘处强度在短空间距离内快速变化，因此对应较高空间频率。", "Why do edges usually contain high-frequency components?", "Intensity changes rapidly over a short spatial distance at an edge, corresponding to higher spatial frequencies.")])

add(35, "线性空间滤波",
    "线性空间滤波是图像 f 与滤波核 w 的系数进行邻域乘积并求和。核的大小 m×n 决定邻域范围，系数决定滤波行为，中心系数 w(0,0) 对齐于 f(x,y)。输出为 g(x,y)=sum_{s=-a..a} sum_{t=-b..b} w(s,t)f(x+s,y+t)，其中 m=2a+1、n=2b+1。",
    "计算时把核覆盖到图像局部，逐项相乘，再把所有乘积相加。核系数为正且和为 1 往往产生平滑；系数包含正负并且总和接近 0，往往响应边缘或变化。",
    "A linear spatial filter computes a sum of products between a kernel w and a local neighbourhood of image f. For a centred kernel, g(x,y)=sum w(s,t)f(x+s,y+t).",
    [("Kernel", "滤波核", "定义局部加权组合方式的系数矩阵。"),
     ("Linear filter", "线性滤波器", "输出是邻域像素的加权线性组合。"),
     ("Coefficient sum", "系数和", "影响常量区域的输出偏差和整体亮度。")],
    "边界处核会超出图像，需要定义 padding。核的奇数尺寸方便定义唯一中心；实现时还要确认是相关还是已经旋转过的卷积核。",
    [q("线性空间滤波的输出如何计算？", "把核中每个系数与对应邻域像素相乘，再把所有乘积求和。", "How is a linear spatial-filter output computed?", "Multiply each kernel coefficient by its corresponding neighbourhood pixel and sum all products.")])

add(36, "滤波核与局部像素",
    "图中展示滤波核的系数如何覆盖输入图像局部区域，并以中心位置 (x,y) 为参照，把每个系数与对应像素值相乘后求和得到输出像素。",
    "这页把公式变成了手算步骤：定位中心、对齐窗口、逐项相乘、求和，然后移动窗口到下一个位置。理解这个过程比死记公式更能避免索引错位。",
    "The diagram shows a kernel overlaid on a local image neighbourhood. Each coefficient is multiplied by the aligned pixel value, and the products are summed to produce the output at (x,y).",
    [("Kernel alignment", "核对齐", "把核中心与当前输出位置对应。"),
     ("Sliding window", "滑动窗口", "将局部核逐位置移动遍历图像。"),
     ("Dot product", "点积", "两个同形数组逐项相乘后求和。")],
    "手算或写代码时，最常见错误是把核中心、输出坐标和输入窗口的索引混在一起。先画出窗口并标出中心，再写求和范围。",
    [q("计算某个输出像素时，核的中心应该对齐哪里？", "应对齐输入图像中对应的中心位置 (x,y)。", "Where should the kernel centre be aligned when computing an output pixel?", "It should align with the corresponding input position (x,y).")])

add(37, "相关与卷积",
    "相关操作把滤波核在图像上移动，在每个位置计算核与局部图像的乘积和。卷积的计算过程相同，但在滑动前先把核旋转 180 度。课件用一维例子比较了二者。",
    "如果核关于中心对称，相关和卷积的结果相同；如果核不对称，旋转方向会改变响应。很多库的 filter/correlation 接口与数学卷积约定不同，因此必须核对文档。",
    "Correlation slides the kernel and sums products. Convolution performs the same operation after rotating the kernel by 180 degrees. Symmetric kernels give identical results for the two operations.",
    [("Correlation", "相关", "不先翻转核，直接滑动并求乘积和。"),
     ("Convolution", "卷积", "先将核旋转 180 度，再进行滑动求和。"),
     ("Kernel symmetry", "核对称性", "中心对称时相关与卷积的结果一致。")],
    "边缘检测核通常不对称，因此相关/卷积的方向差异会影响边缘符号和方向。复现课件结果时，应明确库函数到底实现的是哪一种。",
    [q("卷积相对相关多了哪一步？", "卷积在滑动核之前把核旋转 180 度。", "What extra step does convolution have compared with correlation?", "It rotates the kernel by 180 degrees before sliding it.")])

add(38, "二维相关与卷积示例",
    "本页将相关和卷积扩展到二维图像。二维核覆盖输入图像的局部窗口，逐元素相乘并求和；卷积版本还要把二维核旋转 180 度。示例用图像网格说明输出位置与窗口之间的对应关系。",
    "二维情形的核心仍是点积，只是窗口同时沿行和列移动。核的中心和边界处理决定输出尺寸，因此要区分 full、same 和 valid 等模式。",
    "The two-dimensional example applies the same sliding sum-of-products to an image window. For convolution, the two-dimensional kernel is rotated by 180 degrees first.",
    [("2D kernel", "二维滤波核", "在行和列方向定义局部加权。"),
     ("Output position", "输出位置", "当前窗口中心对应的结果坐标。"),
     ("Boundary mode", "边界模式", "规定窗口超出图像时如何计算输出。")],
    "输出大小可由输入尺寸、核尺寸、步长和 padding 一起决定。深度学习中的卷积层通常使用交叉相关实现，但仍沿用‘convolution’名称。",
    [q("二维滤波与一维滤波相比增加了什么？", "窗口需要同时沿行和列移动，核和局部图像都成为二维数组。", "What is added when moving from one-dimensional to two-dimensional filtering?", "The window moves along both rows and columns, and both the kernel and local input are two-dimensional arrays.")])

add(39, "图像退化模型",
    "退化模型描述原图像 f 如何经过退化过程得到观测图像 g。若已知或估计退化算子 H 和噪声 η，就可以尝试估计恢复图像 f_hat。图中把原图、退化过程、观测图像和恢复结果联系起来。",
    "退化可能来自模糊、运动、光学系统或噪声。恢复不是简单地把图像变清晰，而是根据退化模型进行逆问题估计；模型不准确时，强行反演可能放大噪声。",
    "The degradation model relates the original image f to the observed image g through a degradation operator H and noise η. Given knowledge of H and η, an estimated restored image f_hat can be sought.",
    [("Degradation operator H", "退化算子 H", "描述模糊、成像系统等对原图的作用。"),
     ("Restoration", "图像恢复", "依据退化模型估计更接近原图的结果。"),
     ("Inverse problem", "逆问题", "从观测结果推断产生它的未知原始信号。")],
    "恢复与增强的目标不同：恢复更强调物理或统计模型的一致性，增强更强调视觉效果。设计恢复算法前应先判断 H 和噪声是否可估计。",
    [q("退化模型中 H 和 η 分别表示什么？", "H 表示退化过程或算子，η 表示加入的噪声。", "What do H and η represent in the degradation model?", "H represents the degradation process/operator, and η represents added noise.")])

add(40, "加性噪声假设",
    "课件假设噪声与空间坐标无关，并且与图像本身不相关。在这种情况下，观测图像可以写成 g=f+η。噪声 η 可看作随机变量，其概率密度函数有助于选择和设计滤波器。课件也提醒，这一假设在某些 X 射线或核医学成像场景中并不现实。",
    "空间平稳、与信号不相关的加性噪声便于建模和分析，但不是所有成像噪声都满足。光子计数噪声往往与信号强度有关，某些传感器噪声也可能是乘性或相关噪声。",
    "The slide assumes that noise is independent of spatial coordinates and uncorrelated with the image, giving the additive model g=f+η. Its PDF helps design filters, but the assumption may be unrealistic for some X-ray and nuclear-medicine images.",
    [("Stationary noise", "平稳噪声", "统计特性不随空间位置改变的噪声。"),
     ("Probability density function", "概率密度函数", "描述连续随机变量取值分布的函数。"),
     ("Signal-dependent noise", "与信号相关的噪声", "噪声统计特性随真实强度改变。")],
    "遇到信号相关噪声时，不能盲目使用固定方差的加性模型。可以考虑方差稳定变换、泊松模型或针对传感器的噪声校准。",
    [q("为什么课件强调加性噪声假设可能不现实？", "因为真实成像噪声可能依赖信号强度、空间位置或传感器物理过程，而不是固定、独立的加性噪声。", "Why may the additive-noise assumption be unrealistic?", "Real imaging noise may depend on signal intensity, location, or sensor physics rather than being fixed independent additive noise.")])

add(41, "常见噪声模型",
    "表格列出常见加性噪声模型及其概率密度、均值、方差和随机生成变量，包括 Gaussian、log-normal、uniform、Rayleigh、exponential 和 gamma。表中还用 E1+E2+...+Eb 表示由多个指数随机变量相加形成的 gamma 型随机量。",
    "不同噪声模型的分布形状和参数含义不同。均值描述中心位置，方差描述波动幅度；知道噪声模型后，可以选择更合适的滤波器或仿真方式。",
    "The table lists common additive-noise models with their PDFs, means, variances, and random-variable generators: Gaussian, log-normal, uniform, Rayleigh, exponential, and gamma. A gamma variable can be formed by summing exponential variables E1 through Eb.",
    [("Gaussian noise", "高斯噪声", "常用对称分布噪声模型，由均值和方差控制。"),
     ("Uniform noise", "均匀噪声", "在给定区间内等概率取值。"),
     ("Gamma noise", "Gamma 噪声", "可由多个指数随机变量之和构造的非负分布模型。")],
    "模拟噪声时要区分‘抽样分布’和‘叠加到图像后的像素范围’。生成的噪声可能使像素超出合法范围，必须裁剪或采用浮点表示后再归一化。",
    [q("噪声模型中的均值和方差分别描述什么？", "均值描述噪声分布的中心，方差描述噪声取值的波动程度。", "What do the mean and variance describe in a noise model?", "The mean describes the centre of the noise distribution, while the variance describes its variability.")])

add(42, "噪声模型的概率密度",
    "本页用曲线展示不同噪声模型的概率密度函数。曲线的形状体现噪声可能取值的范围、偏斜程度和集中位置；这些差异会影响噪声在图像中的视觉表现以及滤波器的选择。",
    "高斯分布通常关于均值对称，均匀分布在区间内平坦，指数和 Gamma 分布具有明显偏斜，Rayleigh 和 log-normal 也表现出非对称特性。不要仅凭名称假定所有噪声都对称。",
    "The page plots PDFs for different noise models. Their shapes reveal support, skewness, and concentration, which influence both visual appearance and filter design.",
    [("PDF shape", "概率密度形状", "反映随机噪声取值的相对可能性。"),
     ("Skewness", "偏度", "分布向一侧拖尾的非对称程度。"),
     ("Support", "支持集", "随机变量可能取值的范围。")],
    "噪声识别可以结合直方图、统计检验和成像物理，而不是只看单张图。对真实数据，还要验证噪声是否随亮度变化。",
    [q("为什么噪声 PDF 的形状对滤波器选择有用？", "它告诉我们噪声的范围、偏斜和波动规律，便于选择对该统计特性更有效的滤波方法。", "Why is the shape of a noise PDF useful for filter selection?", "It describes the noise range, skew, and variability, helping select a filter suited to those statistics.")])

add(43, "椒盐噪声",
    "椒盐噪声会把部分像素随机变成黑色或白色，像素值落在 [0,L-1] 的两端。被污染的概率为 P=Ps+Pp，其中 Ps 和 Pp 分别表示盐噪声和椒噪声的概率。",
    "盐噪声对应明亮的脉冲点，椒噪声对应黑暗的脉冲点。它不是平滑的小幅波动，而是少量极端离群像素，因此中值滤波通常比均值滤波更适合。",
    "Salt-and-pepper noise randomly changes pixels to black or white extremes in [0,L-1]. The probability of corruption is P=Ps+Pp, where Ps and Pp are the salt and pepper probabilities.",
    [("Salt noise", "盐噪声", "把像素推向高强度端的脉冲噪声。"),
     ("Pepper noise", "椒噪声", "把像素推向低强度端的脉冲噪声。"),
     ("Impulse noise", "脉冲噪声", "少量像素出现极端异常值的噪声。")],
    "中值滤波依靠排序，对极端离群值不敏感。窗口过大仍会损失细线和小目标，因此要在去噪和细节之间权衡。",
    [q("椒盐噪声的总污染概率如何表示？", "P=Ps+Pp，其中 Ps 是盐噪声概率，Pp 是椒噪声概率。", "How is the total corruption probability for salt-and-pepper noise expressed?", "P=Ps+Pp, where Ps is the salt probability and Pp is the pepper probability.")])

add(44, "不同噪声图像及其直方图",
    "本页把原始图像分别加入 Gaussian、log-normal、uniform、Rayleigh、exponential、Gamma 和 salt-and-pepper 噪声，并展示对应图像。图像外观显示了不同噪声模型的纹理和离群点差异。",
    "连续分布噪声通常覆盖较多灰度值，椒盐噪声则产生明显的黑白脉冲点。只观察视觉结果可能混淆模型，最好同时结合直方图和已知成像条件。",
    "The page shows an original image corrupted with Gaussian, log-normal, uniform, Rayleigh, exponential, gamma, and salt-and-pepper noise. The visual patterns differ in smooth variation versus extreme impulses.",
    [("Noise simulation", "噪声仿真", "按指定概率模型生成并叠加噪声。"),
     ("Outlier pixel", "离群像素", "明显偏离邻域或正常分布的像素。"),
     ("Noise appearance", "噪声外观", "噪声在图像纹理、亮度和极端点上的表现。")],
    "评估滤波器时应在同一原图和可控噪声参数下比较，而不是只看不同图像的主观清晰度。可使用 MSE、PSNR、SSIM 等指标补充视觉判断。",
    [q("哪类噪声最容易在图像中表现为黑白极端点？", "椒盐脉冲噪声。", "Which noise type most clearly appears as black and white extreme points?", "Salt-and-pepper impulse noise.")])

add(45, "噪声图像的直方图",
    "本页继续展示不同加性噪声图像及其直方图，横轴覆盖从 0 到 L-1 的灰度范围。直方图可以显示噪声使灰度分布变宽、偏斜，或在两端产生额外峰值。",
    "图像示例说明噪声模型不只是改变局部外观，也会改变全局强度统计。椒盐噪声常在两端增加尖峰，而连续噪声会以不同方式扩散原始直方图。",
    "This page continues the image-and-histogram comparison for additive noise models. Histograms over 0 to L-1 reveal spreading, skew, or extra peaks at the intensity extremes.",
    [("Histogram shift", "直方图偏移", "噪声使整体强度分布中心发生变化。"),
     ("Histogram spread", "直方图扩散", "噪声使强度覆盖范围变宽。"),
     ("Endpoint peak", "端点峰", "在最低或最高灰度处出现的集中峰。")],
    "如果噪声均值不为零，去噪后可能还存在亮度偏差；因此不能只比较方差，还要检查均值和动态范围是否改变。",
    [q("直方图如何帮助识别椒盐噪声？", "如果黑白脉冲较多，直方图在最低和最高灰度端往往出现明显额外峰值。", "How can a histogram help identify salt-and-pepper noise?", "Many black and white impulses often create noticeable extra peaks at the minimum and maximum intensity levels.")])

add(46, "均值滤波器",
    "均值滤波是通过空间卷积进行线性降噪的方法。最简单的是算术平均或盒式滤波器：把邻域 S_xy 中的像素求平均。为避免对常量区域产生偏置，滤波核系数的总和应为 1。",
    "均值滤波把邻域差异平均掉，因此适合抑制随机噪声，但也会模糊边缘。窗口越大，平滑越强，细节损失和边缘扩散也越明显。",
    "Mean filtering is a linear spatial-convolution method for noise reduction. The arithmetic mean or box filter averages pixels in S_xy, and kernel coefficients should sum to one to avoid bias.",
    [("Arithmetic mean filter", "算术均值滤波", "用邻域像素平均值替换中心像素。"),
     ("Box filter", "盒式滤波器", "邻域内系数相等的均值核。"),
     ("Bias", "偏置", "滤波后常量区域整体亮度发生系统性改变。")],
    "均值核系数和为 1 是直流增益为 1 的条件。对椒盐噪声，均值容易被极端值拉偏，因此通常考虑中值或其他顺序统计滤波。",
    [q("为什么均值滤波核的系数通常要和为 1？", "这样常量区域的输出仍等于原常量值，不会产生整体亮度偏置。", "Why should mean-filter coefficients usually sum to one?", "Then a constant region remains constant and no overall brightness bias is introduced.")])

add(47, "均值滤波示例与课件标注",
    "本页比较原始图像以及 5×5、11×11、21×21 窗口的滤波结果。页面标题属于均值滤波部分，但图中英文标注写有 median filter outputs；本页应按原始课件保留这一标注，不能擅自改写。",
    "示例体现窗口增大后的典型趋势：结果更平滑，但边缘和细节更模糊。‘mean filters’标题与‘median filter outputs’标注存在术语不一致，复习时应记住这是课件原文的疑点，并结合老师讲解或实验代码确认具体算子。",
    "The slide compares the original image with outputs for 5x5, 11x11, and 21x21 filtering windows. Although the section is about mean filters, the visible label says “median filter outputs”; this wording discrepancy should be preserved and checked against the lecture or lab code.",
    [("Window size", "窗口尺寸", "局部滤波所覆盖的像素范围。"),
     ("Blur", "模糊", "局部平均造成高频细节和边缘变弱。"),
     ("Source discrepancy", "课件术语不一致", "标题与图中标注可能指向不同滤波器。")],
    "不要把这页的标注不一致当成自己的翻译错误。实验复现时应直接检查调用的是 mean、median 还是其他滤波函数，并比较它们对椒盐噪声和边缘的效果。",
    [q("为什么窗口从 5×5 增大到 21×21 会更模糊？", "更大的窗口平均了更广范围的像素，抑制变化更强，因此边缘和细节损失更多。", "Why does a 21x21 window produce more blur than a 5x5 window?", "It averages over a larger area, suppressing more variation and therefore losing more edges and details.")])

add(48, "均值滤波器的变体",
    "本页介绍几何均值滤波、调和均值滤波和反调和均值滤波。图像强度归一化到 0 到 1 时，几何均值使用邻域像素乘积的开方/幂次平均；调和均值使用像素倒数和的倒数；反调和均值由阶数 Q 控制对高、低强度像素的偏好。",
    "三种滤波器都利用邻域统计，但对极端值的响应不同。几何均值通常比算术均值保留更多细节；调和均值对高亮离群点有抑制能力；反调和均值可以通过 Q 的正负选择抑制盐噪声或椒噪声。",
    "The page introduces geometric-mean, harmonic-mean, and contraharmonic-mean filters. With intensities normalised to 0-1, they use multiplicative, reciprocal, and order-controlled neighbourhood statistics respectively.",
    [("Geometric mean filter", "几何均值滤波", "用邻域像素乘积的几何平均替换中心值。"),
     ("Harmonic mean filter", "调和均值滤波", "使用邻域倒数的平均来计算输出。"),
     ("Contraharmonic mean", "反调和均值", "用阶数 Q 调节高低强度像素的影响。")],
    "对含零像素的数据，调和均值的倒数形式需要数值保护。反调和均值的 Q 不能同时有效抑制两种相反极性的脉冲噪声，通常要先判断噪声类型。",
    [q("反调和均值中的 Q 控制什么？", "Q 控制邻域中高强度和低强度像素对输出的相对影响，从而影响对盐噪声或椒噪声的抑制。", "What does Q control in a contraharmonic mean filter?", "Q controls the relative influence of high- and low-intensity pixels and therefore which impulse polarity is suppressed.")])

add(49, "几何均值滤波示例",
    "图中对含 Gaussian 噪声的图像分别使用 3×3 算术均值滤波和 3×3 几何均值滤波，并比较输出。几何均值通过乘法聚合邻域强度，通常在降噪的同时保留更多局部结构。",
    "算术均值容易受到特别大的像素影响；几何均值在正值范围内对比例关系更敏感，可能产生不同的平滑效果。选择时要根据噪声模型和图像强度范围判断。",
    "The example compares a 3x3 arithmetic mean filter and a 3x3 geometric mean filter on a Gaussian-noisy image. The geometric mean aggregates intensities multiplicatively and may preserve local structure differently.",
    [("Gaussian noise", "高斯噪声", "常用的连续、近似对称随机噪声。"),
     ("Geometric averaging", "几何平均", "用乘积的 n 次方根汇总正值。"),
     ("Detail preservation", "细节保留", "平滑后仍保留边缘和纹理的程度。")],
    "几何均值要求处理的强度通常为正；若图像含零或负值，需要先变换数据或选择更稳妥的滤波方式。",
    [q("几何均值与算术均值的核心区别是什么？", "算术均值相加后除以数量，几何均值把正像素相乘后取相应次方根。", "What is the core difference between arithmetic and geometric means?", "The arithmetic mean adds values and divides by their count; the geometric mean multiplies positive values and takes the corresponding root.")])

add(50, "调和均值滤波示例",
    "图中展示调和均值滤波在 Gaussian 噪声和 salt 噪声下的输出。调和均值由邻域像素倒数构成，对大值和小值的敏感性与算术均值不同，因此在特定噪声下可以得到更合适的结果。",
    "调和均值会强烈受到接近零的像素影响。它在处理亮点型噪声时可能有优势，但遇到椒噪声或零值时要特别小心，并且需要防止分母为零。",
    "The examples show harmonic-mean filtering for Gaussian and salt noise. Because the filter is based on reciprocal values, its response to very small intensities differs from that of the arithmetic mean.",
    [("Harmonic mean", "调和均值", "邻域像素倒数平均的倒数。"),
     ("Reciprocal sensitivity", "倒数敏感性", "接近零的像素在倒数中影响很大。"),
     ("Salt noise", "盐噪声", "表现为高亮脉冲点的噪声。")],
    "使用调和均值时必须处理零值和极小值。不要只根据‘滤波后更平滑’判断好坏，要检查是否削弱了目标边缘和亮点。",
    [q("调和均值为什么要小心零值？", "因为零的倒数不存在，接近零的值还会在倒数和中产生很大影响。", "Why must zero values be handled carefully in a harmonic mean filter?", "The reciprocal of zero is undefined, and values near zero can dominate the reciprocal sum.")])

add(51, "反调和均值与 Q",
    "反调和均值滤波由阶数 Q 控制。课件列出不同 Q 与噪声极性的组合：对于盐噪声通常选择 Q<0，例如 Q=-3；对于椒噪声通常选择 Q>0，例如 Q=3。使用错误符号可能保留或增强目标噪声。",
    "反调和均值通过加权的高次幂与低次幂比值改变极端像素的影响。Q 的符号决定偏向抑制高亮脉冲还是低亮脉冲，但单个 Q 不能同时完美消除两种噪声。",
    "The contraharmonic mean filter uses an order Q. The slide lists Q<0, such as Q=-3, for salt noise and Q>0, such as Q=3, for pepper noise; the sign must match the impulse polarity.",
    [("Order Q", "阶数 Q", "控制反调和均值对邻域强度的权重。"),
     ("Impulse polarity", "脉冲极性", "噪声是偏向高强度端还是低强度端。"),
     ("Parameter selection", "参数选择", "根据噪声类型和强度选择滤波参数。")],
    "复习时记忆方向比死记示例数字更重要：Q<0 抑制盐噪声，Q>0 抑制椒噪声。实际参数还要通过验证集或视觉质量评估调整。",
    [q("抑制盐噪声和椒噪声时 Q 的符号如何选择？", "抑制盐噪声取负 Q，抑制椒噪声取正 Q。", "How should the sign of Q be chosen for salt and pepper noise?", "Use negative Q for salt noise and positive Q for pepper noise.")])

add(52, "高斯滤波器",
    "高斯滤波器是各向同性滤波器，响应不依赖方向。核为 w(s,t)=1/k exp(-(s^2+t^2)/(2σ^2))，其中 s 和 t 覆盖 m×n 窗口，σ^2 是方差，k 是归一化常数，使所有核系数之和为 1。若 s^2+t^2=r^2，则 w(r)=1/k exp(-r^2/(2σ^2))。",
    "距离中心越远，权重按高斯函数衰减；σ 越大，衰减越慢，平滑范围越广。高斯核通常比盒式均值更平滑自然，因为邻近中心的像素权重更大。",
    "A Gaussian filter is isotropic. Its weights are w(s,t)=1/k exp(-(s^2+t^2)/(2σ^2)), normalised so that the kernel sums to one. σ^2 controls the spread.",
    [("Isotropic", "各向同性", "旋转方向时响应性质保持一致。"),
     ("Gaussian kernel", "高斯核", "按距中心距离衰减的平滑核。"),
     ("Variance σ^2", "方差 σ^2", "控制高斯权重衰减范围。")],
    "有限窗口只是对无限高斯函数的截断近似。窗口尺寸应随 σ 选择，太小会截断重要权重，太大则增加计算量。",
    [q("高斯核中的 σ 增大有什么效果？", "权重衰减变慢，参与平滑的范围变宽，输出通常更平滑也更模糊。", "What happens when σ increases in a Gaussian kernel?", "Weights decay more slowly, the effective smoothing range widens, and the result is generally smoother and blurrier.")])

add(53, "均值滤波与高斯滤波比较",
    "本页比较原始图像、均值滤波输出和高斯滤波输出。两者都能平滑图像，但高斯滤波让中心附近像素获得更高权重，通常能减少盒式平均的突兀边界效应。",
    "滤波器的视觉结果取决于窗口和参数。比较时要保持近似的有效平滑尺度，并同时观察噪声、边缘、纹理和计算成本。",
    "The page compares an original image with mean-filter and Gaussian-filter outputs. Both smooth the image, while the Gaussian gives larger weights to pixels near the centre.",
    [("Box averaging", "盒式平均", "窗口内像素使用相同权重。"),
     ("Gaussian weighting", "高斯加权", "中心附近像素权重更高。"),
     ("Edge preservation", "边缘保留", "平滑后边缘位置和强度仍被保留的程度。")],
    "高斯滤波并不等于真正保边。若任务必须保留边缘，可考虑中值、双边滤波或引导滤波，并明确其额外假设。",
    [q("均值滤波和高斯滤波的权重有什么不同？", "均值滤波通常给窗口内像素相同权重，高斯滤波让距离中心近的像素权重更大。", "How do the weights differ between mean and Gaussian filtering?", "A mean filter usually gives equal weights within the window, while a Gaussian filter gives larger weights to pixels nearer the centre.")])

add(54, "顺序统计滤波器",
    "顺序统计滤波器先把邻域 S_xy 中的像素值排序，再根据排序位置选择输出。中值滤波选择中间值；最大值滤波选择第 100 百分位；最小值滤波选择第 0 百分位；中点滤波取最大值和最小值的中点。",
    "与线性滤波不同，顺序统计滤波不计算固定加权和，而是使用邻域的秩次信息。中值对极端离群点更稳健，因此常用于脉冲噪声，同时比同尺寸线性平滑更少模糊边缘。",
    "Order-statistics filters sort the intensity values in S_xy and select an output according to rank. Median, maximum, minimum, and midpoint filters are examples.",
    [("Median filter", "中值滤波", "把邻域排序后的中间强度作为输出。"),
     ("Maximum filter", "最大值滤波", "选择邻域中的最高强度，等同第 100 百分位。"),
     ("Minimum filter", "最小值滤波", "选择邻域中的最低强度，等同第 0 百分位。")],
    "窗口元素个数最好取奇数，才能有唯一中值。排序滤波通常更适合脉冲噪声，但窗口过大仍会改变形状和移除细小目标。",
    [q("顺序统计滤波与线性滤波的核心区别是什么？", "顺序统计滤波依据排序后的秩次选值，线性滤波依据固定系数对邻域做加权求和。", "What is the core difference between order-statistics and linear filters?", "Order-statistics filters select by rank after sorting, whereas linear filters compute a weighted sum with fixed coefficients.")])

add(55, "中值滤波效果",
    "本页展示中值滤波对 salt-and-pepper 噪声和 Gaussian 噪声的处理结果。中值滤波对脉冲离群点通常非常有效，并且在相同窗口尺寸下比线性平滑更少产生边缘模糊。",
    "中值滤波会用邻域中较典型的值替换极端值，所以黑白脉冲会被去除。对高斯噪声，它也能平滑，但不一定比专门针对高斯统计的线性滤波更有效。",
    "The examples show median filtering for salt-and-pepper and Gaussian noise. Median filtering is especially effective for impulse noise and usually blurs edges less than linear smoothing of the same size.",
    [("Robust filter", "稳健滤波器", "对少量极端离群值不太敏感的滤波器。"),
     ("Median replacement", "中值替换", "用排序后的中间值替换中心像素。"),
     ("Impulse removal", "脉冲去除", "消除少量极亮或极暗的异常像素。")],
    "判断效果时要区分去噪和保真：中值滤波可能改变纹理或细线，不能简单说‘没有模糊’。应比较边缘、目标面积和噪声残留。",
    [q("为什么中值滤波特别适合椒盐噪声？", "椒盐噪声是极端离群值，排序后通常位于两端，不容易改变中值。", "Why is median filtering especially suitable for salt-and-pepper noise?", "Salt-and-pepper values are extreme outliers at the ends of the sorted list and therefore often do not change the median.")])

add(56, "最大值与最小值滤波",
    "最大值滤波等同于选择第 100 百分位，会保留最亮点，并使相邻暗区域趋向变亮；它可减少 pepper 噪声。最小值滤波等同于第 0 百分位，会保留最暗点，并使相邻亮区域趋向变暗；它可减少 salt 噪声。",
    "最大值和最小值都属于顺序统计滤波，也与形态学膨胀/腐蚀有联系。它们不是普通的平滑滤波，会有明确的形状偏置：最大值扩张亮区域，最小值扩张暗区域。",
    "The maximum filter selects the 100th percentile and reduces pepper noise; the minimum filter selects the 0th percentile and reduces salt noise. They respectively expand bright and dark structures.",
    [("Maximum filter", "最大值滤波", "输出邻域最大强度值。"),
     ("Minimum filter", "最小值滤波", "输出邻域最小强度值。"),
     ("Morphological relation", "形态学联系", "最大/最小操作分别与膨胀/腐蚀有密切关系。")],
    "窗口形状决定区域扩张方向和程度。使用最大/最小滤波前，应先确认目标是亮目标还是暗目标，以及是否能接受面积改变。",
    [q("最大值滤波和最小值滤波分别适合哪类脉冲噪声？", "最大值滤波减少椒噪声，最小值滤波减少盐噪声。", "Which impulse noise does each filter reduce?", "The maximum filter reduces pepper noise, while the minimum filter reduces salt noise.")])

add(57, "最大值与最小值示例",
    "图中比较原图、最小值滤波输出和最大值滤波输出。最小值操作会让局部像素向暗值靠近，最大值操作会让局部像素向亮值靠近，因此二者的形状变化方向相反。",
    "这个例子帮助把百分位定义和视觉效果联系起来。观察结果时要注意：滤波不仅改变噪声，也会改变亮区域或暗区域的边界和面积。",
    "The example compares the original image with minimum- and maximum-filter outputs. Minimum operations push local values darker, while maximum operations push them brighter, producing opposite shape effects.",
    [("Percentile filter", "百分位滤波", "按排序位置选择邻域输出。"),
     ("Bright-region expansion", "亮区域扩张", "最大值操作使亮结构向邻域扩展。"),
     ("Dark-region expansion", "暗区域扩张", "最小值操作使暗结构向邻域扩展。")],
    "如果输出目标是去噪而不是形态改变，可以先使用小窗口，并在处理前后比较目标面积和边缘位置。",
    [q("最大值和最小值操作对亮暗区域的影响方向是什么？", "最大值倾向扩张亮区域，最小值倾向扩张暗区域。", "How do maximum and minimum operations affect bright and dark regions?", "Maximum tends to expand bright regions, while minimum tends to expand dark regions.")])

add(58, "中点滤波器",
    "中点滤波器取邻域最大值和最小值的中点：输出为 (max+min)/2。课件指出，它对 Gaussian 或 uniform 等随机噪声尤其有用，因为它用两个极值概括局部范围，而不是只取平均。",
    "中点滤波与中值滤波不同：中值是排序列表的中间元素，中点是最大值和最小值的平均。它适合某些有界随机噪声，但对极端离群值可能敏感。",
    "A midpoint filter outputs the midpoint between the maximum and minimum values in the neighbourhood, (max+min)/2. It can be useful for random noise such as Gaussian or uniform noise.",
    [("Midpoint filter", "中点滤波", "取邻域最大值和最小值的平均。"),
     ("Bounded random noise", "有界随机噪声", "噪声取值大致限制在一定范围内。"),
     ("Median versus midpoint", "中值与中点", "中值取排序中间项，中点取两端平均。")],
    "如果最大值或最小值本身被离群点污染，中点也会被拉动。因此选择中点滤波前要确认噪声模型和极值可靠性。",
    [q("中点滤波和中值滤波有什么不同？", "中点滤波取最大值与最小值的平均，中值滤波取排序后的中间值。", "How does a midpoint filter differ from a median filter?", "A midpoint filter averages the maximum and minimum, whereas a median filter selects the middle sorted value.")])

add(59, "空间高通滤波与锐化",
    "锐化突出强度变化，平滑则通过空间平均减弱变化。锐化可以看作空间微分：导数响应与不连续处的变化幅度有关，因此能增强边缘和细节。课件指出，锐化常用于医学成像和工业检测。",
    "低通滤波抑制高频，锐化滤波强调高频。锐化不是无条件改善图像：它也会增强噪声和伪影，所以通常要先降噪或限制增强强度。",
    "Sharpening highlights intensity transitions, whereas smoothing reduces them through spatial averaging. Spatial differentiation responds to discontinuities, making sharpening useful in medical imaging and industrial inspection.",
    [("Sharpening", "锐化", "增强边缘和快速强度变化。"),
     ("Spatial differentiation", "空间微分", "用导数描述强度随空间的变化。"),
     ("Discontinuity", "不连续/突变", "强度在很短距离内发生明显变化的位置。")],
    "高通增强通常要和原图组合才能得到自然结果，例如 unsharp masking 和 high-boost filtering。直接显示导数图可能只得到边缘响应而不是完整图像。",
    [q("为什么锐化也可能放大噪声？", "噪声通常包含快速空间变化，也会被高通或微分操作增强。", "Why can sharpening also amplify noise?", "Noise often contains rapid spatial changes, so high-pass or derivative operations enhance it as well.")])

add(60, "边缘与不连续形式",
    "图中用 step、ramp、impulse 和 triangular 等一维强度剖面展示不同不连续或变化形式。阶跃在一个位置突然改变，斜坡在一段范围内逐渐改变，脉冲是局部突起，三角形先上升后下降。",
    "一阶和二阶导数对这些剖面的响应不同。理解这些理想化形状有助于预测边缘检测器会在哪里产生响应，以及为什么二阶导数可能出现双边缘或过零点。",
    "The slide illustrates step, ramp, impulse, and triangular intensity profiles. They represent abrupt changes, gradual changes, local spikes, and a rise followed by a fall.",
    [("Step edge", "阶跃边缘", "强度在一个位置发生突然变化。"),
     ("Ramp edge", "斜坡边缘", "强度在一段距离内逐渐变化。"),
     ("Impulse", "脉冲", "局部短促的强度峰或谷。")],
    "真实边缘通常被采样、模糊和噪声改变，不会是理想阶跃。边缘检测要在定位精度、抗噪性和响应宽度之间取舍。",
    [q("为什么要学习 step、ramp 和 impulse 这些理想剖面？", "它们能帮助分析不同导数和滤波器对突变、渐变和局部异常的响应。", "Why study ideal step, ramp, and impulse profiles?", "They help analyse how derivatives and filters respond to abrupt changes, gradual changes, and local anomalies.")])

add(61, "一阶和二阶导数的响应",
    "对常量区域，一阶和二阶导数都为零。一阶导数在阶跃或斜坡的起始变化处非零，并沿斜坡保持响应；二阶导数在阶跃或斜坡的起点和终点产生响应，但沿线性斜坡内部为零。",
    "一阶导数更适合表示变化方向和边缘强度，二阶导数对变化起止位置更敏感。二阶导数也更容易放大噪声，因此实际使用常需要平滑或尺度选择。",
    "For constant regions, both first and second derivatives are zero. The first derivative responds along a ramp and at the onset of a change; the second derivative responds at the start and end of a change and is zero inside a linear ramp.",
    [("First derivative", "一阶导数", "响应强度变化率，并保留变化方向。"),
     ("Second derivative", "二阶导数", "响应变化率的变化，对起止和过零敏感。"),
     ("Ramp", "斜坡", "在一段区域内近似线性变化的剖面。")],
    "离散图像中的导数由差分近似，差分间隔和噪声会影响响应。拉普拉斯算子就是把两个方向的二阶导数合并起来。",
    [q("二阶导数在斜坡内部为什么为零？", "线性斜坡的一阶导数为常数，常数再求导后为零。", "Why is the second derivative zero inside a linear ramp?", "The first derivative of a linear ramp is constant, and differentiating that constant gives zero.")])

add(62, "导数响应的进一步示意",
    "本页继续说明一阶和二阶导数对常量区域、边缘起点、斜坡和变化终点的响应。核心规律保持不变：一阶导数在变化过程中给出响应，二阶导数在变化的开始和结束位置给出更集中的响应。",
    "把图像边缘看作一维剖面，可以通过导数响应定位边缘。二阶导数的过零位置常用于边缘定位，但必须警惕噪声造成的额外过零点。",
    "This page continues the derivative-response illustration. The first derivative responds through a change, while the second derivative gives more concentrated responses at the beginning and end of a change.",
    [("Zero crossing", "过零点", "二阶导数由正变负或由负变正的位置。"),
     ("Edge localisation", "边缘定位", "确定边缘在空间中的具体位置。"),
     ("Derivative response", "导数响应", "导数算子对图像强度结构产生的输出。")],
    "实际边缘检测常把高斯平滑与导数结合，例如先平滑再求导，降低噪声造成的虚假响应。尺度越大，定位越稳但细节越容易丢失。",
    [q("二阶导数过零点为什么可能被用来定位边缘？", "边缘附近强度变化的二阶响应会改变符号，过零位置常对应结构变化中心。", "Why can a second-derivative zero crossing locate an edge?", "The second-derivative response changes sign near an edge, and the zero crossing often corresponds to the centre of the structural change.")])

add(63, "拉普拉斯算子",
    "拉普拉斯算子是简单的各向同性二阶导数算子：∇²f=∂²f/∂x²+∂²f/∂y²。离散化后，可以使用不含对角项的核 [0,1,0;1,-4,1;0,1,0]，或含对角项的核 [1,1,1;1,-8,1;1,1,1]。",
    "拉普拉斯把 x 和 y 两个方向的二阶变化合并，因此对边缘和细节敏感。不同核的中心系数和邻居数量不同，但都体现中心与周围像素的二阶差分关系。",
    "The Laplacian is a simple isotropic second-derivative operator: ∇²f=∂²f/∂x²+∂²f/∂y². Common discrete kernels use four neighbours with centre -4 or eight neighbours with centre -8.",
    [("Laplacian", "拉普拉斯算子", "两个正交方向二阶导数之和。"),
     ("Isotropic operator", "各向同性算子", "对方向没有偏好，旋转后性质保持一致。"),
     ("Discrete kernel", "离散核", "用有限邻域近似连续微分算子。")],
    "拉普拉斯核的符号可能因教材和实现约定相反；关键是保持公式、核和后续加/减操作的一致性。边界和噪声会显著影响二阶导数结果。",
    [q("拉普拉斯算子由哪些方向的二阶导数组成？", "它由 x 方向和 y 方向的二阶偏导数相加组成。", "Which directional second derivatives form the Laplacian?", "It is the sum of the second partial derivatives in the x and y directions.")])

add(64, "拉普拉斯锐化与背景恢复",
    "拉普拉斯输出通常在无特征的暗背景上表现为灰色边缘。为了恢复具有原始背景的锐化图像，可以把拉普拉斯图像与原图相加（或按所采用的核符号约定相减）。图中展示原图、拉普拉斯结果以及使用含/不含对角项核的效果。",
    "拉普拉斯图像本身主要表达变化，不是完整的自然图像。与原图组合后，平坦区域仍由原图提供，边缘由拉普拉斯响应增强；核的符号决定组合时使用加法还是减法。",
    "A Laplacian result often shows greyish edges on a dark, otherwise featureless background. Adding the Laplacian image to the original recovers the background and sharpens the image, with the sign adjusted to the kernel convention.",
    [("Laplacian sharpening", "拉普拉斯锐化", "把拉普拉斯高频响应组合回原图以增强边缘。"),
     ("Diagonal-neighbour kernel", "含对角邻居的核", "使用八邻域近似二阶导数。"),
     ("Background recovery", "背景恢复", "把原图重新加入以保留平坦区域亮度。")],
    "锐化前通常要先控制噪声，因为拉普拉斯会放大高频噪声。比较两种核时要同时比较方向敏感性、边缘宽度和噪声响应。",
    [q("为什么要把拉普拉斯结果和原图组合？", "拉普拉斯结果主要显示变化和边缘，加入原图可以恢复平坦背景并形成完整的锐化图像。", "Why combine the Laplacian result with the original image?", "The Laplacian mainly shows changes and edges; adding the original restores the flat background and forms a complete sharpened image.")])

add(65, "第二部分总结",
    "本页回顾第二部分：空间滤波机制（相关和卷积）、图像退化模型、空间滤波方法、图像平滑/低通滤波、均值/高斯/顺序统计滤波，以及图像锐化/高通滤波。",
    "复习时应能从噪声类型选择滤波器：随机平滑噪声可考虑均值或高斯，椒盐噪声常考虑中值，亮/暗脉冲可考虑最大/最小，边缘增强可考虑高通或拉普拉斯，但都要评估细节损失和噪声放大。",
    "This summary revisits correlation and convolution, degradation models, smoothing/low-pass filters, mean/Gaussian/order-statistics filters, and sharpening/high-pass filters.",
    [("Filter selection", "滤波器选择", "根据噪声、边缘和任务目标选择合适方法。"),
     ("Denoising", "去噪", "抑制噪声并尽量保留真实结构。"),
     ("Edge enhancement", "边缘增强", "突出强度突变和结构轮廓。")],
    "可以用一张表总结：高斯噪声 -> 均值/高斯；椒盐噪声 -> 中值；盐噪声 -> 最小值或合适 Q；椒噪声 -> 最大值或合适 Q；锐化 -> 高通/拉普拉斯并注意噪声。",
    [q("选择空间滤波器时最重要的三个依据是什么？", "噪声统计类型、是否需要保留边缘/细节，以及可接受的计算和形状变化代价。", "What are three important criteria for choosing a spatial filter?", "The noise statistics, the need to preserve edges/details, and the acceptable computational and shape-change cost.")])

add(66, "Q&A：第二部分问答页",
    "本页是第二部分的 Q&A 环节分隔页。页面没有列出具体问题文本；复习问题应围绕相关与卷积、噪声模型、均值/高斯/顺序统计滤波，以及拉普拉斯锐化展开。",
    "高质量回答应包含定义、公式或计算步骤、适用噪声、优点与限制，并能解释为什么一个滤波器在某类图像上比另一个更合适。",
    "This is the Q&A divider for Part 2. No specific question text is listed; revision should focus on correlation/convolution, noise models, smoothing filters, order statistics, and Laplacian sharpening.",
    [("Filter comparison", "滤波器比较", "从公式、噪声适配性、边缘保留和副作用比较方法。"),
     ("Revision explanation", "复习解释", "不仅说结论，还能说明机制和适用条件。")],
    "自测时可以手写一个 3×3 窗口的相关、卷积、中值和拉普拉斯计算，再解释每种输出对应的视觉效果。",
    [q("第二部分的综合题应怎样组织答案？", "先定义方法，再写计算公式或步骤，说明适用噪声和效果，最后讨论边界、模糊或噪声放大等限制。", "How should an answer to an integrative Part 2 question be organised?", "Define the method, give its formula or steps, state suitable noise and expected effect, then discuss limits such as boundaries, blur, or noise amplification.")])


def validate():
    expected = set(range(1, 67))
    actual = set(PAGE_NOTES)
    missing = expected - actual
    extra = actual - expected
    if missing or extra:
        raise ValueError(f"Week 3 page notes mismatch; missing={sorted(missing)}, extra={sorted(extra)}")


validate()

