# Scalable Distributed Data Processing

课程：Data-Intensive Artificial Intelligence

## 第 1 页：可扩展分布式数据处理：基本概念

Source ID: `src-401b272e1225-pdf_page-00001`

![PDF page 1](../assets/pages/page_001.jpg)

### 原文 / Original Text

```text
Scalable Distributed data processing:
fundamental concepts

Prof. Paolo Missier
School of Computer Science
University of Birmingham, UK

Data-intensive AI
2026/27 Sem 1
```

### 完整中文翻译

本讲主题是可扩展的分布式数据处理基本概念。授课教师为 Paolo Missier 教授，所属单位是伯明翰大学计算机科学学院；课程属于数据密集型人工智能，学期为 2026/27 第一学期。

### 中文释义

本讲围绕一个核心问题展开：当数据规模变大时，如何通过多台机器和更多资源完成数据处理，同时控制延迟、通信、成本和系统复杂度。

### English Explanation

This lecture introduces fundamental concepts in scalable distributed data processing. It is taught by Professor Paolo Missier in the School of Computer Science at the University of Birmingham for Data-intensive AI in Semester 1 of 2026/27.

### 概念解析与拓展

- **Distributed data processing / 分布式数据处理**：把数据处理任务分配给多台机器共同执行。
- **Scalability / 可扩展性**：输入规模或资源规模变化时，系统仍能以可接受的性能工作。
- **Speedup / 加速比**：单处理器时间与并行系统时间的比值。

今天的复习主线是：理想并行 -> 通信开销 -> 串行部分 -> 负载不均衡 -> 分区和扩展策略。

### 自测问题 / Self-check

**Q1 中文：** 本讲最核心的问题是什么？
**答：** 研究如何利用多台机器处理大数据，同时控制延迟、通信开销和扩展成本。
**Q1 English:** What is the central problem of this lecture?
**Answer:** How to process large datasets with multiple machines while controlling latency, communication overhead, and scaling cost.

## 第 2 页：本讲关键概念

Source ID: `src-401b272e1225-pdf_page-00002`

![PDF page 2](../assets/pages/page_002.jpg)

### 原文 / Original Text

```text
Key concepts in this lecture

“Big Data”: datasets that are large enough to benefit a distributed computing architecture
- If you run a distributed algorithm on a small dataset, the overhead associated with managing the data 
allocation to the resources may be larger than the theoretical benefit

- Speedup: the ratio of the time taken to complete a task on a single processor to the time taken on a 

parallel system with $n$ processors

- embarrassing parallelism: an ideal situation where there are no dependencies between elements of the 

input dataset when executing the task

- Amdahl's Law and Gustafson's Law: quantifying the limitations on available parallelism for a specific 

processing task
```

### 完整中文翻译

大数据是规模足够大、能够从分布式计算架构中受益的数据集。如果在小数据集上运行分布式算法，管理数据分配和计算资源的开销可能反而大于理论收益。加速比是单处理器完成任务的时间与使用 n 个处理器的并行系统完成任务的时间之比。易并行性是输入元素之间没有依赖、可以独立处理的理想情况。阿姆达尔定律和古斯塔夫森定律用于量化具体处理任务中并行性的限制。

### 中文释义

‘大数据’不是单纯指文件很大，而是指分布式架构带来的收益足以抵消协调开销。加速比、易并行性、阿姆达尔定律和古斯塔夫森定律构成后续分析的基础。

### English Explanation

Big Data refers to datasets large enough to benefit from a distributed computing architecture. On a small dataset, the overhead of allocating data and resources may exceed the theoretical benefit. Speedup compares single-processor time with parallel time; embarrassingly parallel work has no dependencies between input elements. Amdahl's and Gustafson's laws quantify limits on parallelism.

### 概念解析与拓展

- **Big Data / 大数据**：需要分布式架构才能在成本或性能上获得明显收益的数据。
- **Embarrassingly parallel / 易并行**：各个输入子任务互不依赖，几乎可以独立执行。
- **Overhead / 开销**：为了协调、通信、调度和管理并行任务而付出的额外时间或资源。

判断一个任务是否值得分布式化时，要比较任务规模、单机基线、通信量和调度开销，而不是只看处理器数量。

### 自测问题 / Self-check

**Q1 中文：** 为什么小数据集不一定适合分布式算法？
**答：** 因为数据分配、调度和通信的额外开销可能超过并行计算带来的收益。
**Q1 English:** Why may a small dataset not suit a distributed algorithm?
**Answer:** Data allocation, scheduling, and communication overhead may exceed the benefit of parallel computation.

## 第 3 页：可扩展分布式数据处理

Source ID: `src-401b272e1225-pdf_page-00003`

![PDF page 3](../assets/pages/page_003.jpg)

### 原文 / Original Text

```text
Scalable Distributed data processing

Distributed computing involves using multiple machines to run an algorithm.

Here we focus specifically on distributed data processing
- We have seen some of the target algorithms in previous lectures:

- Checking and improving data quality (missingness, anomalies)
- Data analytics through aggregation and visualisation

- We will see that graph algorithms may also benefit from a multi-machine computing infrastructure
```

### 完整中文翻译

分布式计算使用多台机器共同运行算法。本讲重点是分布式数据处理。前面已经见过一些目标算法，例如检查和改进数据质量，包括缺失值和异常检测，以及通过聚合和可视化进行数据分析。后面还会看到图算法也可以从多机器计算基础设施中受益。

### 中文释义

分布式处理并不只服务于机器学习训练，也适用于数据清洗、聚合、可视化和图计算。关键是把整体任务拆成可以在多台机器上协作完成的工作。

### English Explanation

Distributed computing uses multiple machines to run an algorithm. This lecture focuses on distributed data processing, including data-quality checks, aggregation and visualisation, and later graph algorithms.

### 概念解析与拓展

- **Data quality / 数据质量**：数据是否完整、有效、一致并适合后续分析。
- **Aggregation / 聚合**：把多条记录汇总为统计量或更高层结果。
- **Graph algorithm / 图算法**：在节点和边组成的图结构上进行计算。

同一种分布式基础设施可能服务于不同算法，但算法的依赖关系、通信模式和分区方式会不同。

### 自测问题 / Self-check

**Q1 中文：** 本讲举出的分布式数据处理任务有哪些？
**答：** 数据质量检查、聚合与可视化，以及图算法。
**Q1 English:** Which distributed data-processing tasks are mentioned?
**Answer:** Data-quality checks, aggregation and visualisation, and graph algorithms.

## 第 4 页：可扩展性：定义与关键问题

Source ID: `src-401b272e1225-pdf_page-00004`

![PDF page 4](../assets/pages/page_004.jpg)

### 原文 / Original Text

```text
Scalability: Definitions and Key Questions

Context: “Big Data” : 
Key conceps: scalability. Given an algorithm/processing task, this relates size of the input dataset 
with the size of the resources allocated to complete the task.

Here “performance” = latency: the time it takes for the algorithm to process the entire input

1. Fixed size input, increasing resources:
- How does performance increase as a function of the size of the computing resources? When 

does adding more resources stop being beneficial?

2. Fixed size resources, increasing input size:
- How does performance decrease as a function of the size of the computing resources?

3. Considering the input size / resource size envelope, what are the cost/benefits trade-offs?
```

### 完整中文翻译

在大数据背景下，可扩展性研究输入数据集大小与分配资源规模之间的关系。这里的性能用延迟表示，即算法处理完整个输入所需的时间。课件提出三个问题：固定输入规模、增加资源时性能如何变化，什么时候继续增加资源不再有益；固定资源规模、增加输入规模时性能如何下降；综合考虑输入规模和资源规模时，成本与收益如何权衡。

### 中文释义

可扩展性不是‘资源越多越快’这么简单。需要分别考察强扩展、弱扩展以及资源成本：固定问题看增加资源能否降低时间，固定资源看能处理多大数据，最后还要判断增加资源是否值得。

### English Explanation

Scalability relates input size to the resources allocated to a processing task. Performance is measured as latency. The slide asks about adding resources for a fixed input, increasing input for fixed resources, and the cost-benefit trade-off across the input/resource envelope.

### 概念解析与拓展

- **Latency / 延迟**：从任务开始到整个任务完成所经过的时间。
- **Strong scaling / 强扩展**：固定问题规模，增加资源并观察运行时间变化。
- **Weak scaling / 弱扩展**：资源和问题规模一起增加，观察单位工作量的性能。

工程上常同时记录吞吐量、延迟、资源利用率和成本。只降低延迟但成本增长过快，可能不是好的扩展方案。

### 自测问题 / Self-check

**Q1 中文：** 可扩展性分析要回答哪三个问题？
**答：** 增加资源对固定输入的影响、固定资源处理更大输入时的影响，以及输入规模和资源规模之间的成本收益权衡。
**Q1 English:** What three questions does scalability analysis ask?
**Answer:** The effect of more resources on fixed input, the effect of larger input with fixed resources, and the cost-benefit trade-off between input and resources.

## 第 5 页：加速比与理想线性加速

Source ID: `src-401b272e1225-pdf_page-00005`

![PDF page 5](../assets/pages/page_005.jpg)

### 原文 / Original Text

```text
Speedup

The speedup 𝑆 n  achieved when using 𝑛 > 1 processors is the ratio of the time taken to 
complete a task on a single processor to the time taken on a parallel system with 𝑛 
processors:

𝑆 n =

𝑇1
𝑇n

Where  𝑇1  is the wall-clock time (latency) measured when using one processor (the baseline) and 𝑇n is the 
latency when 𝑛 processors are deployed to solve the task

Ideal (linear) speedup:
If every processor does exactly 
exactly 𝑛:

1

𝑛

And 

 of the total work and there is no overhead, the speedup is 

𝑇𝑛 =

𝑇1
𝑛

𝑆 𝑛 =

𝑇1
𝑛

  =  𝑛
```

### 完整中文翻译

使用 n>1 个处理器时，加速比定义为 S_n=T_1/T_n。T_1 是使用一个处理器时测得的墙钟时间，也就是基线；T_n 是使用 n 个处理器完成任务的延迟。如果每个处理器承担完全相等的工作，并且没有任何并行开销，则 T_n=T_1/n，因而 S_n=n，这就是理想的线性加速。

### 中文释义

理想线性加速意味着处理器数量翻倍，运行时间就减半。但这个结论要求工作可均匀划分、没有通信和调度开销，也没有串行部分，现实系统通常达不到。

### English Explanation

Speedup with n processors is S_n=T_1/T_n, where T_1 is the single-processor wall-clock time and T_n is the parallel latency. Under perfectly balanced work and zero overhead, T_n=T_1/n and S_n=n, called ideal linear speedup.

### 概念解析与拓展

- **Wall-clock time / 墙钟时间**：从开始执行到任务完成实际经过的时间。
- **Baseline / 基线**：用于比较的单处理器或原始配置。
- **Linear speedup / 线性加速**：加速比等于处理器数量 n。

实验中应先测量稳定的 T_1，再比较不同 n 的 T_n；不要用理论单线程复杂度代替真实基线。

### 自测问题 / Self-check

**Q1 中文：** 加速比 S_n 的公式是什么？
**答：** S_n=T_1/T_n，其中 T_1 是单处理器时间，T_n 是 n 个处理器的时间。
**Q1 English:** What is the formula for speedup S_n?
**Answer:** S_n=T_1/T_n, where T_1 is the single-processor time and T_n is the time with n processors.

## 第 6 页：降低理想加速比的因素

Source ID: `src-401b272e1225-pdf_page-00006`

![PDF page 6](../assets/pages/page_006.jpg)

### 原文 / Original Text

```text
Factors that reduce ideal speedup

1. Communication overhead: Processors must exchange intermediate results; this takes time 

proportional to the volume of data transferred

2. Serial sections in the execution: Some fraction of the task cannot be parallelised 
- typically, loops that build a result incrementally at each iteration

3. Load imbalance: If some processors finish their share earlier than others, they sit idle while the 
slowest one completes — the job's wall-clock time is always determined by the slowest 
participant
```

### 完整中文翻译

有三个主要因素会降低理想加速。第一是通信开销：处理器必须交换中间结果，耗时通常与传输数据量有关。第二是执行中的串行部分：有些任务不能并行，例如每次迭代都增量构建结果的循环。第三是负载不均衡：一些处理器提前完成后会空闲，整个墙钟时间由最慢的处理器决定。

### 中文释义

并行化的瓶颈可能来自网络、算法依赖或数据分布。优化时不能只增加处理器，应先判断哪一种开销占主导。

### English Explanation

Three factors reduce ideal speedup: communication overhead, serial sections that cannot be parallelised, and load imbalance. The wall-clock completion time is determined by the slowest participant.

### 概念解析与拓展

- **Communication overhead / 通信开销**：处理器交换数据和中间结果所消耗的额外时间。
- **Serial section / 串行部分**：必须按顺序执行、不能同时分配给多个处理器的部分。
- **Load imbalance / 负载不均衡**：不同处理器承担的工作量不相等。

一个实用诊断顺序是先测网络传输，再检查是否存在不可并行循环，最后查看每个分区的处理时间和数据量。

### 自测问题 / Self-check

**Q1 中文：** 为什么最慢的处理器决定墙钟时间？
**答：** 并行任务通常要等待所有参与者完成，最慢的处理器完成前整体任务不能结束。
**Q1 English:** Why does the slowest processor determine wall-clock time?
**Answer:** The overall task usually waits for all participants, so it cannot finish before the slowest processor does.

## 第 7 页：考虑通信开销的现实加速比

Source ID: `src-401b272e1225-pdf_page-00007`

![PDF page 7](../assets/pages/page_007.jpg)

### 原文 / Original Text

```text
Realistic speedup with communication overhead

We will be working with “share-nothing” processors
- Each processor has a local memory and the only way for processors to share data is to move it across a (local) 

network.

- This data movement incurs a communication overhead.
- We denote the total communication overhead between any pair of processors over the entire processing with 𝑇𝑐

We simply add 𝑇𝑐 to the total wall-clock time for the 𝑛 processors configuration:

The speedup is then expressed as:

𝑇𝑛 =

𝑇1
𝑛

+ 𝑇𝑐

𝑆 𝑛 =

𝑇1
𝑇𝑛

=

𝑛

1 + 𝑛 ⋅

𝑇𝑐
𝑇1

High communication overhead / large 𝑇𝑐 → smaller speedup
Low communication overhead / small 𝑇𝑐 → larger speedup
```

### 完整中文翻译

课件采用 share-nothing 处理器：每个处理器拥有本地内存，处理器之间只能通过本地网络移动数据。数据移动产生通信开销，记整个处理过程任意处理器对之间的总通信开销为 T_c。于是 T_n=T_1/n+T_c，加速比为 S_n=T_1/T_n=n/(1+n·T_c/T_1)。通信开销越高，T_c 越大，加速比越小；通信开销越低，加速比越大。

### 中文释义

理想并行时间 T_1/n 只是计算部分；网络通信会直接加回总时间。即使增加处理器，若通信量随 n 增长，收益也会逐渐变小。

### English Explanation

The slide assumes share-nothing processors with local memory and network-based data movement. With total communication cost T_c, T_n=T_1/n+T_c and S_n=n/(1+n·T_c/T_1). Larger communication overhead means lower speedup.

### 概念解析与拓展

- **Share-nothing / 无共享架构**：每台机器有本地内存，数据共享必须通过网络传输。
- **T_c / 通信开销 T_c**：整个并行执行中的总数据传输时间。
- **Communication-to-computation ratio / 通信计算比**：通信时间相对于单机计算时间的比例。

减少 shuffle、压缩数据、让相关数据靠近处理节点，通常比盲目增加节点更能提高分布式任务的加速比。

### 自测问题 / Self-check

**Q1 中文：** 现实加速比公式中 T_c 的作用是什么？
**答：** T_c 被加到并行计算时间上，表示通信会增加总延迟并限制加速比。
**Q1 English:** What is the role of T_c in the realistic speedup formula?
**Answer:** T_c is added to the parallel computation time, representing extra latency that limits speedup.

## 第 8 页：效率

Source ID: `src-401b272e1225-pdf_page-00008`

![PDF page 8](../assets/pages/page_008.jpg)

### 原文 / Original Text

```text
Efficiency

Efficiency = speedup / number of processors     (speedup per processor)

𝐸 𝑛 =

𝑆 𝑛
𝑛

=

1

1 + 𝑛 ⋅

𝑇𝑐
𝑇1

Max efficiency 𝐸 𝑛 = 1 is achieved when 𝑇𝑐 = 0 (no overhead).

In practice, efficiency decreases with the number 𝑛 of processors, because 
more communication is required, increasing 𝑇𝑐
```

### 完整中文翻译

效率定义为加速比除以处理器数量，即 E_n=S_n/n=1/(1+n·T_c/T_1)，也可理解为每个处理器带来的平均加速。最大效率 E_n=1 在 T_c=0、完全没有开销时取得。实践中，处理器数量 n 增加会带来更多通信，T_c 增大，效率通常下降。

### 中文释义

加速比回答‘快了多少’，效率回答‘每个处理器用得有多充分’。加速比继续上升并不代表效率没有下降。

### English Explanation

Efficiency is speedup per processor: E_n=S_n/n=1/(1+n·T_c/T_1). Maximum efficiency is 1 when communication overhead is zero; in practice efficiency tends to decrease as more processors require more communication.

### 概念解析与拓展

- **Efficiency / 效率**：加速比与处理器数量的比值。
- **Processor utilisation / 处理器利用率**：处理器实际用于有效工作而非等待或通信的程度。
- **Diminishing return / 边际收益递减**：继续增加资源带来的额外收益越来越小。

比较两个系统时不要只看完成时间，也要看 E_n 和成本。低效率但非常短的任务可能仍值得使用，取决于业务目标。

### 自测问题 / Self-check

**Q1 中文：** 效率和加速比的区别是什么？
**答：** 加速比是相对于单处理器快了多少，效率是这个加速比平均分摊到每个处理器后的结果。
**Q1 English:** What is the difference between speedup and efficiency?
**Answer:** Speedup measures total improvement over one processor; efficiency is that speedup normalised by the number of processors.

## 第 9 页：串行执行导致的现实加速比

Source ID: `src-401b272e1225-pdf_page-00009`

![PDF page 9](../assets/pages/page_009.jpg)

### 原文 / Original Text

```text
Realistic speedup with serial execution
```

### 完整中文翻译

图中展示一个包含并行部分和串行部分的程序。数组元素的加法可以并行执行：每个处理器完成一个加法；随后 sum=0 之后的循环需要逐次执行 sum=sum+c(i)，只能由一个处理器完成；最后每个处理器可以并行更新自己的 a(k) 和 b(k) 值。中间的求和循环就是串行瓶颈。

### 中文释义

这个示例说明：即使大部分代码都能并行，只要存在必须按顺序累积的部分，整体速度就会受到限制。并行化时要观察数据依赖，而不是只看循环是否很长。

### English Explanation

The diagram separates parallel and serial code. Element-wise additions and final per-processor updates can run in parallel, but the incremental sum loop is a serial section handled by one processor.

### 概念解析与拓展

- **Data dependency / 数据依赖**：后一步必须等待前一步结果，限制并行执行。
- **Reduction / 归约**：把多个局部结果组合成一个结果，例如求和。
- **Serial bottleneck / 串行瓶颈**：不可并行部分限制整体完成时间。

求和可用树形归约把串行链缩短为对数级深度，但仍需要通信和同步；这是分布式聚合的典型设计。

### 自测问题 / Self-check

**Q1 中文：** 图中哪一段是串行瓶颈？
**答：** 逐次执行 sum=sum+c(i) 的累加循环是串行部分。
**Q1 English:** Which part is the serial bottleneck in the diagram?
**Answer:** The incremental loop sum=sum+c(i) is the serial section.

## 第 10 页：带串行部分的加速比：阿姆达尔定律

Source ID: `src-401b272e1225-pdf_page-00010`

![PDF page 10](../assets/pages/page_010.jpg)

### 原文 / Original Text

```text
Speedup with Serial Sections: Amdahl’s law

Let 0 ≤ 𝛼 ≤ 1 denote the serial fraction of the task, and let us assume there is no overhead (𝑇𝑐 = 0)
This means that a fraction 𝛼 of the computation cannot be divided into concurrent sub-tasks.
The remaining  1 − 𝛼  can be apportioned to the 𝑛 processors.
This gives:

𝑇𝑛 = 𝛼𝑇1 + 1 − 𝛼

𝑇1
𝑛

The resulting speedup is:

𝑆 𝑛 =

𝑇1
𝑇𝑛

=

𝛼 +

1
1 − 𝛼
𝑛

Efficiency:  𝐸 𝑛 =

𝑆 𝑛

𝑛

=

1

𝑛𝛼+1–𝛼

Thus, the max speedup when using 𝑛 processors is limited by the serial fraction 𝛼:

lim
𝑛→∞

𝑆 𝑛 =

1
𝛼
```

### 完整中文翻译

令 0<=α<=1 表示任务中不可并行的串行比例，并假设没有通信开销。串行部分耗时 αT_1，可并行部分耗时 (1-α)T_1/n，因此 T_n=αT_1+(1-α)T_1/n。加速比 S_n=1/(α+(1-α)/n)，效率 E_n=1/(nα+1-α)。当 n 趋于无穷时，最大加速比为 lim S_n=1/α。

### 中文释义

阿姆达尔定律告诉我们，固定输入规模下，增加无限处理器也不能消除串行部分。α 越小，理论上限越高；α=0 才可能实现理想线性加速。

### English Explanation

Let α be the serial fraction and assume no communication overhead. T_n=αT_1+(1-α)T_1/n, S_n=1/(α+(1-α)/n), and E_n=1/(nα+1-α). As n approaches infinity, the maximum speedup is 1/α.

### 概念解析与拓展

- **Serial fraction α / 串行比例 α**：任务中不能并行的工作所占比例。
- **Amdahl's law / 阿姆达尔定律**：给定固定输入和串行比例时，增加处理器的加速上限。
- **Asymptotic speedup / 渐近加速比**：处理器数量趋于无穷时的理论加速上限。

阿姆达尔定律适合回答固定问题规模的强扩展问题。实际系统还要把通信开销加入模型，真实上限会更低。

### 自测问题 / Self-check

**Q1 中文：** 阿姆达尔定律给出的最大加速比是什么？
**答：** 当处理器数趋于无穷时，最大加速比为 1/α，其中 α 是串行比例。
**Q1 English:** What maximum speedup does Amdahl's law give?
**Answer:** As the processor count tends to infinity, the maximum speedup is 1/α, where α is the serial fraction.

## 第 11 页：阿姆达尔定律示例

Source ID: `src-401b272e1225-pdf_page-00011`

![PDF page 11](../assets/pages/page_011.jpg)

### 原文 / Original Text

```text
Amdahl’s law: examples

Serial fraction α

Max possible speedup Meaning

50%

20%

5%

1%

0%

2×

5×

20×

100×

∞

Half the job is serial; a thousand processors give at most a 2× 
improvement

Even with unlimited hardware, you cannot go faster than 5×

A well-parallelised job; 20× is achievable with ~100 
processors

Near-ideal; requires very careful engineering to achieve

Purely embarrassingly parallel; linear speedup holds

Quick exercise 
For 𝛼 = 50%, calculate the achievable speedup for 
n = 4, 8, 16
Comment on those figures
```

### 完整中文翻译

表格列出串行比例 α、最大可能加速比及其含义：α=50% 时上限为 2 倍，即使使用一千个处理器也最多提升 2 倍；α=20% 时上限为 5 倍；α=5% 时上限为 20 倍；α=1% 时上限为 100 倍但需要精细工程；α=0% 时是纯易并行任务，线性加速成立。快速练习要求对 α=50%、n=4、8、16 计算实际加速比并评论结果。

### 中文释义

表格强调小的串行比例也很重要。α=50% 时 S_4=1/(0.5+0.5/4)=1.6，S_8≈1.78，S_16≈1.88，处理器翻倍的收益迅速变小。

### English Explanation

The table shows maximum speedups for serial fractions of 50%, 20%, 5%, 1%, and 0%. For α=50%, the exercise asks for n=4, 8, and 16; the speedups are 1.6, about 1.78, and about 1.88, showing diminishing returns.

### 概念解析与拓展

- **Maximum possible speedup / 最大可能加速比**：由串行比例决定的理论上限。
- **Diminishing returns / 收益递减**：增加处理器后每次新增资源带来的加速越来越小。
- **Purely embarrassingly parallel / 纯易并行**：α=0、没有串行部分的理想任务。

答题时不仅写数值，还要说明为什么 n 从 4 增加到 16 后加速增长很小：串行部分始终存在。

### 自测问题 / Self-check

**Q1 中文：** 当 α=50%、n=4 时加速比是多少？
**答：** S_4=1/(0.5+0.5/4)=1.6 倍。
**Q1 English:** For α=50% and n=4, what is the speedup?
**Answer:** S_4=1/(0.5+0.5/4)=1.6 times.

## 第 12 页：带通信开销的阿姆达尔定律

Source ID: `src-401b272e1225-pdf_page-00012`

![PDF page 12](../assets/pages/page_012.jpg)

### 原文 / Original Text

```text
Amdahl’s law with communication overhead

𝑇𝑛 = 𝛼𝑇1 + 1 − 𝛼

+ 𝑇𝑐

𝑇1
𝑛

1

𝑆 𝑛 =

𝑇1
𝑇𝑛

=

𝛼 𝑛 − 1 + 1 + 𝑛

𝑇𝑐
𝑇1

As before, maximum speedup factor is determined not by the number of parallel processors 
employed but 
→ by the fraction of the computation that is not parallelized and the communication overhead

lim
𝑛→∞

𝑆 𝑛 =

1

𝛼 +

𝑇𝑐
𝑇1
```

### 完整中文翻译

当存在串行比例 α 和通信开销 T_c 时，T_n=αT_1+(1-α)T_1/n+T_c。相应加速比为 S_n=T_1/T_n。随着 n 趋于无穷，最大加速比为 1/(α+T_c/T_1)。因此并行上限不是由处理器数量本身决定，而是由不可并行比例和通信开销共同决定。

### 中文释义

这是比单独阿姆达尔定律更现实的模型：即使 α 很小，如果 T_c 相对于 T_1 很大，增加处理器仍可能没有明显收益。

### English Explanation

With serial fraction α and communication cost T_c, T_n=αT_1+(1-α)T_1/n+T_c. The asymptotic speedup is 1/(α+T_c/T_1), so both the serial fraction and communication overhead limit scaling.

### 概念解析与拓展

- **Communication-aware Amdahl model / 考虑通信的阿姆达尔模型**：把串行比例和通信时间同时纳入加速比分析。
- **Parallel fraction / 并行比例**：可以分配给多个处理器同时执行的工作比例。
- **Asymptotic limit / 渐近上限**：资源无限增加时仍无法突破的性能上限。

优化顺序通常是减少串行代码、降低通信量、改进数据布局，然后再考虑增加机器数。

### 自测问题 / Self-check

**Q1 中文：** 带通信开销时，最大加速比由什么决定？
**答：** 由串行比例 α 和相对通信开销 T_c/T_1 共同决定。
**Q1 English:** What determines maximum speedup when communication overhead exists?
**Answer:** The serial fraction α and the relative communication overhead T_c/T_1 together determine it.

## 第 13 页：古斯塔夫森定律

Source ID: `src-401b272e1225-pdf_page-00013`

![PDF page 13](../assets/pages/page_013.jpg)

### 原文 / Original Text

```text
Gustafson's Law 

Suppose we keep increasing 𝑛. 

Amdahl’s law quantifies the max speedup given a fixed input size and a task with serial fraction 𝛼.
It provides a limit in latency reduction as a function of 𝑛.

Gustafson's Law provides a complementary perspective: 
it quantifies the increase in input size that can be processed in the same time by a larger number 𝑛’ > 𝑛 of 
processors
“if I increase 𝑛, I can use the extra capacity to process a larger input in the same time”
```

### 完整中文翻译

阿姆达尔定律研究固定输入规模下，增加处理器能够带来的最大加速比，描述延迟随 n 增加的上限。古斯塔夫森定律提供互补视角：当处理器数量增加到 n' 时，可以利用新增容量在相同时间内处理更大的输入。也就是说，增加 n 不一定只用于更快完成同一个模型，也可以用于同时间运行更大的模型。

### 中文释义

阿姆达尔强调固定问题的强扩展，古斯塔夫森强调随资源增加而扩大问题规模的弱扩展。两者不是互相矛盾，而是回答不同的工程问题。

### English Explanation

Amdahl's law fixes the input size and quantifies the speedup limit as processor count grows. Gustafson's law gives a complementary view: additional processors can be used to process a larger input in the same time.

### 概念解析与拓展

- **Gustafson's law / 古斯塔夫森定律**：从可扩大的问题规模角度分析并行系统收益。
- **Fixed-size scaling / 固定规模扩展**：问题不变，只增加资源。
- **Scaled-size scaling / 规模扩展**：资源增加的同时处理更大的问题。

选择使用哪条定律取决于任务目标：实时服务常关心固定输入延迟，科学模拟和批处理常关心同一时间能处理多大问题。

### 自测问题 / Self-check

**Q1 中文：** 古斯塔夫森定律与阿姆达尔定律的视角有什么不同？
**答：** 阿姆达尔固定输入看延迟下降，古斯塔夫森允许输入变大，看同一时间可完成的工作量增加。
**Q1 English:** How does Gustafson's perspective differ from Amdahl's?
**Answer:** Amdahl fixes the input and studies latency reduction; Gustafson allows the input to grow and studies more work completed in the same time.

## 第 14 页：古斯塔夫森定律：例子与练习

Source ID: `src-401b272e1225-pdf_page-00014`

![PDF page 14](../assets/pages/page_014.jpg)

### 原文 / Original Text

```text
Gustafson’s Law: Example and Exercise

Example:
I use 𝑛 processors to run a Climate prediction model. 
By increasing 𝑛 to 𝑛’, I can either:
- Run the same model in slightly less time, or 
- Run a bigger model in the same time

𝑆𝑠𝑐𝑎𝑙𝑒𝑑 𝑛 = 𝛼 + 𝑛 − 𝛼𝑛

Quick exercise 
For 𝛼 = 50%, calculate the achievable scaled 
speedup for  n = 4, 8, 16
Comment on those figures
```

### 完整中文翻译

气候预测模型使用 n 个处理器时，把 n 增加到 n' 有两种选择：运行同一个模型并稍微缩短时间，或者在相同时间运行更大的模型。课件给出缩放加速比 S_scaled(n)=α+n-αn，并要求对 α=50%、n=4、8、16 计算缩放加速比并评论。

### 中文释义

与阿姆达尔固定输入的结果相比，古斯塔夫森模型允许并行部分随处理器数量扩大，因此对大规模科学计算更乐观。

### English Explanation

For a climate-prediction model, increasing processors can either run the same model faster or run a larger model in the same time. The slide gives S_scaled(n)=α+n-αn and asks for α=50% with n=4, 8, and 16.

### 概念解析与拓展

- **Scaled speedup / 缩放加速比**：在相同时间内可以处理更大问题的相对规模。
- **Climate model / 气候模型**：需要大量计算资源进行模拟的科学计算任务。
- **Weak scaling / 弱扩展**：随着资源增加，问题规模也增加并保持目标时间。

对 α=0.5，S_scaled(4)=2.5，S_scaled(8)=4.5，S_scaled(16)=8.5。这里的增长反映的是可处理问题规模，而不是固定输入的延迟加速。

### 自测问题 / Self-check

**Q1 中文：** α=50%、n=8 时缩放加速比是多少？
**答：** S_scaled=0.5+8-0.5×8=4.5。
**Q1 English:** For α=50% and n=8, what is the scaled speedup?
**Answer:** S_scaled=0.5+8-0.5×8=4.5.

## 第 15 页：易并行计算

Source ID: `src-401b272e1225-pdf_page-00015`

![PDF page 15](../assets/pages/page_015.jpg)

### 原文 / Original Text

```text
Embarrassingly Parallel Computation

This is the ideal case where 𝛼 = 0:

The input data can be partitioned into independent subsets such that:

1. Each subset can be processed in isolation — no processor needs any result from another processor's 

subset to do its own work

2. The final result is obtained by combining the per-subset outputs, and that combination step is cheap 

relative to the processing

𝑆 𝑛 = 𝑛

Serial section at the end
```

### 完整中文翻译

易并行是 α=0 的理想情形。输入数据可以划分成相互独立的子集：每个子集可以单独处理，不需要读取其他处理器子集的结果；最后把各子集输出组合起来，而且组合开销相对于处理本身很小。此时 S_n=n。课件同时提醒，末尾的串行组合步骤仍可能成为限制。

### 中文释义

真正易并行不仅要求主体计算独立，还要求最终合并足够便宜。很多看似独立的任务最后都需要全局排序、全局去重或全局统计，这会重新引入瓶颈。

### English Explanation

Embarrassingly parallel computation is the ideal α=0 case. Independent input subsets can be processed in isolation, and their outputs can be combined cheaply; then S_n=n, although a final serial section may still be a bottleneck.

### 概念解析与拓展

- **Independent subset / 独立子集**：可以不依赖其他处理器中间结果的输入部分。
- **Combination step / 组合步骤**：把各个子任务结果汇总成最终结果。
- **α=0 / α=0**：没有串行计算部分的理想状态。

判断易并行性时要检查最终输出是否需要全局信息。map 往往易并行，而全局 sort、median 和 distinct 往往需要额外归约或 shuffle。

### 自测问题 / Self-check

**Q1 中文：** 易并行任务需要满足哪两个条件？
**答：** 子集可独立处理，且最终结果的组合相对于主体处理开销很小。
**Q1 English:** What two conditions define an embarrassingly parallel task?
**Answer:** Subsets can be processed independently, and combining their outputs is cheap relative to the main processing.

## 第 16 页：数据工程中的易并行示例

Source ID: `src-401b272e1225-pdf_page-00016`

![PDF page 16](../assets/pages/page_016.jpg)

### 原文 / Original Text

```text
Examples Relevant to Data Engineering

Task

Why it is embarrassingly parallel

Applying a transformation to every row of a 
DataFrame (.map, .withColumn)

Each row is processed independently; no row 
needs any other row's value

Computing per-partition statistics

Each partition is self-contained

Training separate models on different data folds 
(cross-validation)

Each fold is independent

Compressing or encoding a collection of files

Each file is independent

Applying a filter predicate to a large dataset

Each row is tested independently
```

### 完整中文翻译

表格列出数据工程中的易并行任务。对 DataFrame 每一行应用变换（如 .map、.withColumn）时，每行独立处理；计算每个分区的统计量时，每个分区自包含；在交叉验证中对不同数据折训练独立模型；压缩或编码文件集合时，每个文件独立；对大数据集应用过滤谓词时，每行可以独立测试。

### 中文释义

这些任务的共同点是输入可以按行、分区、折或文件拆开，处理阶段无需跨分区读取结果。它们很适合 map 阶段，但后续若需要全局聚合，仍需分析组合成本。

### English Explanation

Examples include row-wise DataFrame transformations, per-partition statistics, training models on independent cross-validation folds, compressing independent files, and applying an independent filter predicate to each row.

### 概念解析与拓展

- **DataFrame transformation / DataFrame 变换**：对表中每行或每列应用计算规则。
- **Partition / 分区**：分布式数据集的一块局部数据。
- **Cross-validation fold / 交叉验证折**：用于独立训练/验证的一份数据子集。

`.map` 和 `.withColumn` 适合逐行处理，但 `groupBy`、`join`、全局排序等操作通常需要按键重新分区并产生通信。

### 自测问题 / Self-check

**Q1 中文：** 为什么对每行应用过滤谓词通常容易并行？
**答：** 每行只需要检查自己的值，不依赖其他行的结果。
**Q1 English:** Why is applying a filter predicate to each row usually easy to parallelise?
**Answer:** Each row can be tested using its own values without depending on other rows.

## 第 17 页：最终串行部分可能成为瓶颈

Source ID: `src-401b272e1225-pdf_page-00017`

![PDF page 17](../assets/pages/page_017.jpg)

### 原文 / Original Text

```text
The final serial section can be a bottleneck

Consider computing the median over a large set of 𝑁 records (eg median taxi fare) using 𝑛 processors

Each worker processes 𝑁/𝑛 records and produces a sorted list of  𝑁/𝑛 values

Sorting each list of 𝑁/𝑛 elements requires 𝑂 𝑁/𝑛 log 𝑁 /𝑛  steps
This cost is only counted once, since they all occur in parallel

To find the median, these lists must then be merged (why?).

Merging 𝑛 sorted lists of 𝑁/𝑛 elements each requires 𝑂 𝑛 ⋅ 𝑁/𝑛 log 𝑛 = 𝑂 𝑁 log 𝑛  steps

In total, the cost when using 𝑛 processors is 𝑂 𝑁/𝑛 log 𝑁 /𝑛  + 𝑂 𝑁 log 𝑛

Using one single processor, the cost is sorting + scanning: 𝑂 𝑁 log N + 𝑂 𝑁

Thus, there is no real advantage in this case in using 𝑛 > 1 processors
```

### 完整中文翻译

课件用 N 条记录的中位数计算说明最终串行瓶颈。n 个处理器各自处理 N/n 条记录并排序，每个局部排序成本为 O((N/n) log(N/n))，这些排序可并行。为了得到全局中位数，必须合并 n 个有序列表；合并成本为 O(N log n)。总体成本为 O((N/n) log(N/n))+O(N log n)，而单处理器排序并扫描成本约为 O(N log N)+O(N)。因此 n>1 不一定有真正优势。

### 中文释义

局部工作很容易并行，不代表全局结果就便宜。中位数、全局排序和全局去重需要把局部结果重新组合，合并过程可能抵消前面的并行收益。

### English Explanation

The median example shows a serial bottleneck. Local sorting is parallel, but obtaining the global median requires merging n sorted lists at O(N log n). The total cost may offer little advantage over sorting and scanning on one processor.

### 概念解析与拓展

- **Global median / 全局中位数**：需要考虑所有记录排序位置的统计量。
- **Merge / 合并**：把多个局部有序结果整合成全局有序关系。
- **Asymptotic cost / 渐近成本**：用大 O 表示输入规模增长时的主要计算量。

分布式系统常用近似分位数、采样或分层摘要来降低全局合并成本。精确统计与近似统计之间要根据任务要求取舍。

### 自测问题 / Self-check

**Q1 中文：** 为什么局部排序并行后仍可能没有收益？
**答：** 因为计算全局中位数还要合并所有局部有序列表，合并通信和计算成本可能成为主要瓶颈。
**Q1 English:** Why may parallel local sorting still provide little benefit?
**Answer:** The global median still requires merging all local sorted lists, and merge communication and computation can become the main bottleneck.

## 第 18 页：数据分区与负载均衡

Source ID: `src-401b272e1225-pdf_page-00018`

![PDF page 18](../assets/pages/page_018.jpg)

### 原文 / Original Text

```text
Data partition and Load balancing

The third cause of loss of performance is workloads that are not balanced across processors

This happens when some data partitions are much larger than others

A good partition is one where every worker gets roughly the same amount of work
A skewed partition where one worker gets disproportionately more data is the most common cause of jobs 
that are 99% complete and then
stall — the other workers are just idle waiting for the slowest worker to finish
- Remember that we measure wall-clock time
```

### 完整中文翻译

第三个性能损失原因是不同处理器之间的工作负载不均衡。当某些数据分区远大于其他分区时，就会出现这种情况。好的分区让每个 worker 获得大致相同的工作量；偏斜分区会让一个 worker 获得过多数据，任务完成 99% 后停滞，因为其他 worker 都在等待最慢的 worker。这里要记住衡量的是墙钟时间。

### 中文释义

负载均衡关注的是每个 worker 实际工作量，而不是分区数量是否相同。数据倾斜常来自键频率不均、范围分布不均或热点值。

### English Explanation

Load imbalance occurs when data partitions differ greatly in size. A good partition gives workers roughly equal work; a skewed partition can leave most workers idle while the slowest worker finishes.

### 概念解析与拓展

- **Load balancing / 负载均衡**：尽量让各处理器承担相近的工作量。
- **Data skew / 数据倾斜**：某些键或分区包含远多于平均值的数据。
- **Worker / 工作节点**：执行一个分布式子任务的处理单元。

诊断时要查看每个 task 的输入记录数、处理时长和 shuffle 量；只有任务数量相同并不代表负载均衡。

### 自测问题 / Self-check

**Q1 中文：** 为什么任务会在 99% 完成后停滞？
**答：** 大多数 worker 已完成，但一个数据倾斜的慢 worker 仍在处理远大于平均量的分区。
**Q1 English:** Why can a job stall at 99% completion?
**Answer:** Most workers have finished, but one slow worker is still processing a disproportionately large skewed partition.

## 第 19 页：常见分区策略

Source ID: `src-401b272e1225-pdf_page-00019`

![PDF page 19](../assets/pages/page_019.jpg)

### 原文 / Original Text

```text
Common Partitioning Strategies

Common partitioning strategies:

Strategy

How it works

Best for

Range partitioning

Rows with keys in [0, k) → partition 
1, [k, 2k) → partition 2, …

Ordered data, range queries

Hash partitioning

Partition index = hash(key) mod p

Random (round-robin)

Rows assigned cyclically or 
uniformly at random

GroupBy, joins — guarantees 
rows with the same key end up on 
the same worker

Embarrassingly parallel map 
tasks where key co-location is 
irrelevant
```

### 完整中文翻译

范围分区把键位于 [0,k) 的行放入分区 1，把 [k,2k) 的行放入分区 2，适合有序数据和范围查询。哈希分区用 partition index=hash(key) mod p，适合 GroupBy 和 join，可以保证相同键落在同一 worker。随机或轮询分区让行按循环或均匀随机方式分配，适合键共置不重要的易并行 map 任务。

### 中文释义

分区策略应匹配访问模式。范围分区利于范围查询但可能受到数据倾斜影响；哈希分区能按键共置，但热点键仍可能集中到一个分区；轮询分配均匀但不保证相同键在一起。

### English Explanation

Range partitioning assigns key intervals to partitions and suits ordered data and range queries. Hash partitioning uses hash(key) mod p and suits GroupBy and joins. Random or round-robin assignment suits embarrassingly parallel map tasks where key co-location is irrelevant.

### 概念解析与拓展

- **Range partitioning / 范围分区**：按键值区间分配数据。
- **Hash partitioning / 哈希分区**：按键哈希值对分区数取模分配数据。
- **Round-robin / 轮询分区**：按循环顺序把记录均匀分给分区。

join 通常需要相同键共置，因此会产生 shuffle；如果数据已经按键分区并保存，后续 join 可以减少通信。

### 自测问题 / Self-check

**Q1 中文：** 哪种分区策略适合 GroupBy 和 join？
**答：** 哈希分区，因为相同键会被分配到同一个 worker。
**Q1 English:** Which partitioning strategy suits GroupBy and joins?
**Answer:** Hash partitioning, because rows with the same key are sent to the same worker.

## 第 20 页：向上扩展与向外扩展

Source ID: `src-401b272e1225-pdf_page-00020`

![PDF page 20](../assets/pages/page_020.jpg)

### 原文 / Original Text

```text
Scaling up/out 

• Scaling out: “Horizontal scaling”

• Adding more nodes to a distributed system

• Scaling up:  “Vertical scaling”

• Adding more resources to a single node in a system

…or a combination of the two
```

### 完整中文翻译

向外扩展（水平扩展）是向分布式系统增加更多节点。向上扩展（垂直扩展）是给单个节点增加更多资源。两者也可以组合使用。

### 中文释义

Scale up 改变单台机器的能力，Scale out 改变机器数量。二者对应不同的成本、软件复杂度、容错方式和扩展上限。

### English Explanation

Scaling out, or horizontal scaling, adds more nodes to a distributed system. Scaling up, or vertical scaling, adds resources to a single node. The two approaches can also be combined.

### 概念解析与拓展

- **Scale up / 向上/垂直扩展**：增加单台机器的 CPU、内存、磁盘或网络资源。
- **Scale out / 向外/水平扩展**：增加机器节点并把工作分布到它们之间。
- **Node / 节点**：分布式系统中的一台机器或计算实例。

选择策略时要先看代码是否支持分布式执行。如果单机代码无法拆分，增加节点不会自动带来水平扩展收益。

### 自测问题 / Self-check

**Q1 中文：** Scale up 和 Scale out 分别增加什么？
**答：** Scale up 增加单节点资源，Scale out 增加系统中的节点数量。
**Q1 English:** What does each strategy add?
**Answer:** Scale up adds resources to one node; scale out adds more nodes to the system.

## 第 21 页：系统可扩展性

Source ID: `src-401b272e1225-pdf_page-00021`

![PDF page 21](../assets/pages/page_021.jpg)

### 原文 / Original Text

```text
System Scalability

Two complementary ways to scale a system architecture:

• Scaling out: “Horizontal scaling”

• By adding more nodes to a distributed system

• Scaling up:  “Vertical scaling”

• By adding more resources to a single node in a system

…or a combination of the two
```

### 完整中文翻译

系统架构有两种互补的扩展方式：向外扩展通过增加分布式系统的节点实现；向上扩展通过给单个节点增加资源实现。也可以把两种方式组合起来。

### 中文释义

这一页与上一页的内容相同，但强调这是系统架构层面的选择。扩展不仅是运行时参数，还会影响部署、监控、网络、数据存储和故障恢复。

### English Explanation

The architecture can scale in two complementary ways: out by adding nodes, and up by adding resources to a single node. A hybrid approach is also possible.

### 概念解析与拓展

- **System architecture / 系统架构**：计算、存储、网络和协调组件的整体组织方式。
- **Hybrid scaling / 混合扩展**：同时采用垂直扩展和水平扩展。

真正的架构决策要把性能、成本、运维、故障恢复和弹性一起考虑，而不是只比较 CPU 数量。

### 自测问题 / Self-check

**Q1 中文：** 为什么说 Scale up 和 Scale out 是互补方式？
**答：** 它们分别扩大单节点能力和节点数量，可以根据任务和系统限制单独或组合使用。
**Q1 English:** Why are scale up and scale out complementary?
**Answer:** They enlarge single-node capability and node count respectively, and can be used separately or together depending on the system.

## 第 22 页：Scale Up：向上扩展

Source ID: `src-401b272e1225-pdf_page-00022`

![PDF page 22](../assets/pages/page_022.jpg)

### 原文 / Original Text

```text
Scaling Up vs Scaling Out: Scale Up

When you need more resources, you have two main options:
Scale Up (Vertical Scaling): Replace the existing machine with one that has more resources (CPU cores, 
RAM, faster disks, faster network card)
Main Advantages: 
- No SW changes required
- No data transfers or additional overheads 
- No dedicated worlload management required
Disadvantages:
- Expensive
- Will reach a scalability limit (see above)
```

### 完整中文翻译

需要更多资源时，向上扩展是用资源更强的新机器替换现有机器，例如更多 CPU 核心、更大的 RAM、更快的磁盘和网卡。优点是不需要修改软件，不需要节点间数据传输，也不需要专门的工作负载管理。缺点是成本高，而且会达到单机可提供的扩展上限。

### 中文释义

向上扩展适合已有单线程或单机代码、数据共享频繁且分布式改造成本高的任务。它简单，但物理硬件上限和单点故障风险明显。

### English Explanation

Vertical scaling replaces the existing machine with one offering more CPU cores, RAM, faster disks, or a faster network card. It needs no software changes or inter-node transfer, but it is expensive and has a physical scalability limit.

### 概念解析与拓展

- **Vertical scaling / 垂直扩展**：提升单机配置而不增加节点数。
- **Single-node limit / 单节点上限**：单台机器可安装的最大 CPU、内存和设备能力。
- **Workload management / 工作负载管理**：把任务分配和协调到多个计算单元的机制。

如果任务需要大量共享内存，Scale up 可能更简单；如果数据量超过单机存储或计算上限，就必须考虑 Scale out。

### 自测问题 / Self-check

**Q1 中文：** 向上扩展的两个主要优点是什么？
**答：** 通常不需要修改现有软件，也没有节点间数据传输和额外的分布式协调开销。
**Q1 English:** What are two main advantages of scaling up?
**Answer:** Existing software usually needs no changes, and there is no inter-node data transfer or distributed coordination overhead.

## 第 23 页：Scale Out：向外扩展

Source ID: `src-401b272e1225-pdf_page-00023`

![PDF page 23](../assets/pages/page_023.jpg)

### 原文 / Original Text

```text
Scaling Up vs Scaling Out: Scale Out

Scale Out (Horizontal Scaling): Add more machines of the same size and distribute the work across them 
using a coordination framework such as Spark
Main Advantage: an arbitrary number of relatively cheap machines can be added incrementally

- Fits the cloud computing model very nicely (VMs allocated on demand)

Disadvantages:

- share-nothing architecture that requires a dedicated data partitioning and workload allocation 

framework (eg Spark)

- Communication overhead due to data transfers
```

### 完整中文翻译

向外扩展是增加多台同等规模的机器，并使用 Spark 等协调框架把工作分布到这些机器上。主要优点是可以逐步增加相对便宜的机器，数量理论上可以继续扩展，也很适合云计算中按需申请虚拟机。缺点是无共享架构需要专门的数据分区和工作负载分配框架，并且数据传输会带来通信开销。

### 中文释义

向外扩展的弹性更强，但软件必须适应分布式执行。Spark 不会消除通信、shuffle 和数据倾斜，只是提供处理这些问题的框架。

### English Explanation

Horizontal scaling adds machines of the same size and distributes work using a coordination framework such as Spark. It is incremental and cloud-friendly, but requires partitioning, workload allocation, and communication across a share-nothing architecture.

### 概念解析与拓展

- **Spark / Spark**：用于大规模分布式数据处理的计算框架。
- **Shuffle / Shuffle**：为重新分区或按键聚合而在节点间重分布数据。
- **Cloud elasticity / 云弹性**：按需求快速增加或移除计算资源的能力。

选择 Scale out 时要提前识别会产生 shuffle 的操作，并设计分区键、缓存和数据布局。

### 自测问题 / Self-check

**Q1 中文：** 向外扩展为什么适合云计算？
**答：** 可以按需逐步增加或移除相对便宜的虚拟机，不必一次购买更大的单机。
**Q1 English:** Why is scale out well suited to cloud computing?
**Answer:** Cloud clusters can add or remove relatively cheap virtual machines incrementally on demand.

## 第 24 页：两种扩展策略比较（一）

Source ID: `src-401b272e1225-pdf_page-00024`

![PDF page 24](../assets/pages/page_024.jpg)

### 原文 / Original Text

```text
Comparing the Two Strategies (1/2)

Dimension

Unit cost

Ceiling

Scale Up

Scale Out

Superlinear — a machine with 2× 
RAM typically costs 4–8× more

Near-linear — adding a node 
costs roughly the same per node

Hard physical limit (max 
cores/RAM per 
motherboard/chassis)

Effectively unlimited (thousands 
of nodes in cloud clusters)

High — requires a distributed 
programming model (Spark, MPI, 
etc.)

Software complexity

None — existing single-threaded 
code works as-is

Fault tolerance

Single point of failure — if the 
machine crashes, everything is 
lost

Resilient by design — failed 
nodes are replaced; tasks are 
retried
```

### 完整中文翻译

表格比较 Scale Up 和 Scale Out。单位成本方面，Scale Up 通常是超线性增长，例如 RAM 翻倍的机器可能贵 4 到 8 倍；Scale Out 增加节点的成本接近按节点线性增长。扩展上限方面，Scale Up 受主板、机箱和最大 CPU/RAM 的物理限制；Scale Out 在云集群中可以扩展到成千上万个节点。软件复杂度方面，Scale Up 可直接运行现有单线程代码，Scale Out 需要 Spark、MPI 等分布式编程模型。容错方面，Scale Up 是单点故障，Scale Out 可以替换失败节点并重试任务。

### 中文释义

Scale Out 用更多软件和运维复杂度换取更高的扩展上限与容错能力；Scale Up 用更高的单机硬件成本换取简单性。

### English Explanation

The table compares unit cost, ceiling, software complexity, and fault tolerance. Scale up can become superlinear in cost and has a physical ceiling, but existing code works as-is. Scale out can grow to many nodes, requires a distributed programming model, and can retry work on failed nodes.

### 概念解析与拓展

- **Fault tolerance / 容错**：系统在节点或组件失败时仍能继续完成任务的能力。
- **Physical ceiling / 物理上限**：单台设备可提供的最大硬件资源。
- **Distributed programming model / 分布式编程模型**：显式处理分区、协调、通信和失败的编程方式。

考试比较题可按成本、上限、软件、容错四列组织答案，避免只写‘Scale out 更快’这种没有条件的结论。

### 自测问题 / Self-check

**Q1 中文：** Scale Out 相比 Scale Up 的主要软件代价是什么？
**答：** 需要分布式编程模型、数据分区、任务协调和通信处理。
**Q1 English:** What is the main software cost of scale out?
**Answer:** It requires a distributed programming model, data partitioning, task coordination, and communication handling.

## 第 25 页：两种扩展策略比较（二）

Source ID: `src-401b272e1225-pdf_page-00025`

![PDF page 25](../assets/pages/page_025.jpg)

### 原文 / Original Text

```text
Comparing the Two Strategies (2/2)

Dimension

Scale Up

Scale Out

Data transfer overhead

Latency

Operational complexity

Elasticity

Zero inter-node communication 
— all memory is shared

Network is the bottleneck; 
shuffle operations transfer data 
between nodes

Very low (shared memory, no 
serialisation)

Higher (serialisation + network 
round-trip per shuffle)

Low — one machine to monitor 
and maintain

High — cluster management, 
networking, storage 
orchestration

Poor — provisioning a larger 
machine takes hours or days

Good — cloud clusters can add 
or remove nodes in minutes
```

### 完整中文翻译

第二张表比较数据传输开销、延迟、运维复杂度和弹性。Scale Up 共享内存，节点间通信为零，延迟很低，只有一台机器需要维护，但扩容慢，通常需要数小时或数天。Scale Out 的瓶颈是网络，shuffle 会在节点间传输数据；序列化和网络往返让延迟更高；需要管理集群、网络和存储；但云集群可以在几分钟内增加或移除节点，弹性较好。

### 中文释义

Scale Up 的优势是低通信和低运维复杂度，Scale Out 的优势是弹性和可扩展性。实际选择要结合任务延迟目标、节点故障风险和资源变化速度。

### English Explanation

The second table compares data-transfer overhead, latency, operational complexity, and elasticity. Scale up has shared memory and low latency but slow provisioning. Scale out is network-bound and operationally complex, but cloud clusters can add or remove nodes quickly.

### 概念解析与拓展

- **Serialisation / 序列化**：把内存对象转换为可传输或存储格式。
- **Operational complexity / 运维复杂度**：监控、部署、网络、存储和故障管理的复杂程度。
- **Elasticity / 弹性**：根据负载快速增加或移除资源的能力。

如果任务频繁 shuffle，Scale Out 的网络瓶颈可能超过计算收益；如果负载变化大且可分布，Scale Out 的弹性价值更明显。

### 自测问题 / Self-check

**Q1 中文：** Scale Out 的低延迟为什么更难实现？
**答：** 数据需要序列化并通过网络在节点间传输，shuffle 还会增加网络往返和等待。
**Q1 English:** Why is low latency harder with scale out?
**Answer:** Data must be serialised and transferred across the network, while shuffles add network round trips and waiting.

## 第 26 页：总结

Source ID: `src-401b272e1225-pdf_page-00026`

![PDF page 26](../assets/pages/page_026.jpg)

### 原文 / Original Text

```text
Summary
```

### 完整中文翻译

本讲总结了可扩展分布式数据处理的核心概念：大数据需要比较并行收益和管理开销；加速比和效率衡量并行性能；通信开销、串行比例和负载不均衡会限制理想加速；阿姆达尔定律分析固定输入的上限，古斯塔夫森定律分析扩大输入规模的收益；易并行任务适合分区处理，但最终串行归约仍可能成为瓶颈；最后比较了向上扩展和向外扩展。

### 中文释义

复习时可以用四个问题串起整讲：任务能否拆分？数据需要多少通信？是否存在串行或倾斜瓶颈？增加单机资源还是增加节点更划算？

### English Explanation

The lecture covered speedup and efficiency, communication overhead, serial fractions, load imbalance, Amdahl's and Gustafson's laws, embarrassingly parallel tasks, partitioning, and scale-up versus scale-out decisions.

### 概念解析与拓展

- **Performance model / 性能模型**：用时间、加速比、效率和开销解释系统表现。
- **Partitioning / 分区**：把数据分配给 worker 以支持并行处理。
- **Scaling strategy / 扩展策略**：决定增加单机资源还是增加节点。

遇到设计题，先估计串行比例和通信比例，再看数据分布是否倾斜，最后用成本、弹性和容错评价方案。

### 自测问题 / Self-check

**Q1 中文：** 本讲最重要的性能限制有哪些？
**答：** 通信开销、不可并行的串行部分、负载不均衡，以及最终全局合并的瓶颈。
**Q1 English:** What are the most important performance limits in this lecture?
**Answer:** Communication overhead, serial work, load imbalance, and bottlenecks in final global combination.

## 第 27 页：进一步阅读

Source ID: `src-401b272e1225-pdf_page-00027`

![PDF page 27](../assets/pages/page_027.jpg)

### 原文 / Original Text

```text
Further reading

Amdahl, G.M. (1967). "Validity of the single processor approach to
achieving large scale computing capabilities." Proceedings of AFIPS, pp.
483–485. https://doi.org/10.1145/1465482.1465560
Gustafson, J.L. (1988). "Reevaluating Amdahl's Law." Communications
of the ACM, 31(5), 532–533. https://doi.org/10.1145/42411.42415
Zaharia, M. et al. (2012). "Resilient Distributed Datasets: A
Fault-Tolerant Abstraction for In-Memory Cluster Computing." NSDI 2012.
https://www.usenix.org/system/files/conference/nsdi12/nsdi12-final138.pdf
Dean, J. & Ghemawat, S. (2004). "MapReduce: Simplified Data Processing
on Large Clusters." OSDI 2004.
https://research.google/pubs/pub62/
Armbrust, M. et al. (2010). "A View of Cloud Computing." Communications
of the ACM, 53(4), 50–58. https://doi.org/10.1145/1721654.1721672
```

### 完整中文翻译

本页列出进一步阅读文献：Amdahl 于 1967 年关于单处理器方法和大规模计算能力的论文；Gustafson 于 1988 年重新审视阿姆达尔定律的论文；Zaharia 等人 2012 年关于容错内存集群计算和 Resilient Distributed Datasets 的论文；Dean 与 Ghemawat 2004 年关于 MapReduce 的论文；Armbrust 等人 2010 年关于云计算的论文。页面同时给出对应的 DOI 或网页链接。

### 中文释义

这些文献分别对应本讲的性能定律、分布式容错数据集、MapReduce 编程模型和云计算背景。阅读时可把论文与课件中的公式和系统设计问题对应起来。

### English Explanation

The references include Amdahl's 1967 paper, Gustafson's 1988 paper, the 2012 Resilient Distributed Datasets paper by Zaharia et al., the 2004 MapReduce paper by Dean and Ghemawat, and a 2010 cloud-computing paper by Armbrust et al., with DOI or web links.

### 概念解析与拓展

- **Resilient Distributed Dataset / 弹性分布式数据集**：支持容错和内存计算的分布式数据抽象。
- **MapReduce / MapReduce**：把大规模处理分成映射和归约阶段的编程模型。
- **Cloud computing / 云计算**：按需提供可弹性扩展计算和存储资源的模式。

阅读顺序建议是先看 Amdahl/Gustafson 理解性能，再看 MapReduce/RDD 理解执行模型，最后联系云计算中的弹性和成本。

### 自测问题 / Self-check

**Q1 中文：** 进一步阅读分别补充了哪些主题？
**答：** 性能定律、RDD 容错抽象、MapReduce 处理模型和云计算背景。
**Q1 English:** Which themes do the further readings add?
**Answer:** Performance laws, the fault-tolerant RDD abstraction, the MapReduce processing model, and cloud-computing context.
