# Introduction to the Module and Computer Vision

课程：Computer Vision and Imaging

## 第 1 页：Introduction

Source ID: `src-ba4d35fbe29d-pdf_page-00001`

![PDF page 1](../assets/pages/page_001.jpg)

### 原文 / Original Text

```text
Introduction
to the Module

[Computer Vision and Imaging]

Jianbo Jiao

School of Computer Science
University of Birmingham

E-mail: j.jiao@bham.ac.uk
Office: MLC 140
```

### 完整中文翻译

Introduction
to the Module
[计算机视觉与成像]
Jianbo Jiao
计算机科学学院
伯明翰大学
E-mail: j.jiao@bham.ac.uk
办公室: MLC 140
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Introduction”展开。课件中的关键信息包括：Introduction；to the Module；[计算机视觉与成像]；Jianbo Jiao。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Introduction'. The slide includes: Introduction; to the Module; [Computer Vision and Imaging]; Jianbo Jiao. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Introduction”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 1 页的核心主题是什么？
**答：** 本页围绕“Introduction”展开。课件中的关键信息包括：Introduction；to the Module；[计算机视觉与成像]；Jianbo Jiao。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 1?
**Answer:** This page presents 'Introduction'. The slide includes: Introduction; to the Module; [Computer Vision and Imaging]; Jianbo Jiao. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Introduction'. The slide includes: Introduction; to the Module; [Computer Vision and Imaging]; Jianbo Jiao. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 2 页：课程安排

Source ID: `src-ba4d35fbe29d-pdf_page-00002`

![PDF page 2](../assets/pages/page_002.jpg)

### 原文 / Original Text

```text
Schedule

2 Lectures / week
□ Monday @ 9 – 11 AM
□ 2 hours session with break
1 Lab (Tutorial) / week
□ 3 slots (Weds, Thurs)
□ Varies, and groups will be assigned
Module webpage/resources
□ Canvas

2
```

### 完整中文翻译

课程安排
每周 2 次讲座
□ Monday @ 9 – 11 AM
□ 2 hours session with break
每周 1 次实验（辅导课）
□ 3 slots (Weds, Thurs)
□ Varies, and groups will be assigned
课程网页/资源
□ Canvas
2
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Schedule”展开。课件中的关键信息包括：课程安排；每周 2 次讲座；□ Monday @ 9 – 11 AM；□ 2 hours session with break。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Schedule'. The slide includes: Schedule; 2 Lectures / week; □ Monday @ 9 – 11 AM; □ 2 hours session with break. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Schedule”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 2 页的核心主题是什么？
**答：** 本页围绕“Schedule”展开。课件中的关键信息包括：课程安排；每周 2 次讲座；□ Monday @ 9 – 11 AM；□ 2 hours session with break。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 2?
**Answer:** This page presents 'Schedule'. The slide includes: Schedule; 2 Lectures / week; □ Monday @ 9 – 11 AM; □ 2 hours session with break. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Schedule'. The slide includes: Schedule; 2 Lectures / week; □ Monday @ 9 – 11 AM; □ 2 hours session with break. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 3 页：课程模块介绍 and 计算机视觉 - Page 3

Source ID: `src-ba4d35fbe29d-pdf_page-00003`

![PDF page 3](../assets/pages/page_003.jpg)

### 原文 / Original Text

```text
3
```

### 完整中文翻译

3
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“课程模块介绍 and 计算机视觉 - Page 3 - Page 3”展开。课件中的关键信息包括：3。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents '课程模块介绍 and 计算机视觉 - Page 3 - Page 3'. The slide includes: 3. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“课程模块介绍 and 计算机视觉 - Page 3 - Page 3”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 3 页的核心主题是什么？
**答：** 本页围绕“课程模块介绍 and 计算机视觉 - Page 3 - Page 3”展开。课件中的关键信息包括：3。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 3?
**Answer:** This page presents '课程模块介绍 and 计算机视觉 - Page 3 - Page 3'. The slide includes: 3. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents '课程模块介绍 and 计算机视觉 - Page 3 - Page 3'. The slide includes: 3. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 4 页：课程安排

Source ID: `src-ba4d35fbe29d-pdf_page-00004`

![PDF page 4](../assets/pages/page_004.jpg)

### 原文 / Original Text

```text
Schedule

4
```

### 完整中文翻译

课程安排
4
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Schedule”展开。课件中的关键信息包括：课程安排；4。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Schedule'. The slide includes: Schedule; 4. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Schedule”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 4 页的核心主题是什么？
**答：** 本页围绕“Schedule”展开。课件中的关键信息包括：课程安排；4。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 4?
**Answer:** This page presents 'Schedule'. The slide includes: Schedule; 4. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Schedule'. The slide includes: Schedule; 4. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 5 页：考核方式

Source ID: `src-ba4d35fbe29d-pdf_page-00005`

![PDF page 5](../assets/pages/page_005.jpg)

### 原文 / Original Text

```text
Assessment

Exam:
□ 80%
□ Date – TBA
Continuous Assignment:
□ 20%
□ Closed-book assessment (Wk9)
□

Lab sessions

5
```

### 完整中文翻译

考核方式
Exam:
□ 80%
□ Date – TBA
Continuous Assignment:
□ 20%
□ Closed-book assessment (Wk9)
□
Lab sessions
5
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Assessment”展开。课件中的关键信息包括：考核方式；Exam:；□ 80%；□ Date – TBA。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Assessment'. The slide includes: Assessment; Exam:; □ 80%; □ Date – TBA. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Assessment”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 5 页的核心主题是什么？
**答：** 本页围绕“Assessment”展开。课件中的关键信息包括：考核方式；Exam:；□ 80%；□ Date – TBA。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 5?
**Answer:** This page presents 'Assessment'. The slide includes: Assessment; Exam:; □ 80%; □ Date – TBA. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Assessment'. The slide includes: Assessment; Exam:; □ 80%; □ Date – TBA. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 6 页：实验课

Source ID: `src-ba4d35fbe29d-pdf_page-00006`

![PDF page 6](../assets/pages/page_006.jpg)

### 原文 / Original Text

```text
Labs

Submit lab reports for feedback
Does not count towards the final Module mark

All labs are Python based
See Canvas pages for self-tutorial in week 1
Lab support and exercises from week 2
□

6
```

### 完整中文翻译

实验课
Submit lab reports for feedback
Does not count towards the final Module mark
All labs are Python based
See Canvas pages for self-tutorial in week 1
Lab support and exercises from week 2
□
6
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Labs”展开。课件中的关键信息包括：实验课；Submit lab reports for feedback；Does not count towards the final Module mark；All labs are Python based。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Labs'. The slide includes: Labs; Submit lab reports for feedback; Does not count towards the final Module mark; All labs are Python based. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **MAR / 随机缺失**：缺失与其他可观测变量有关，但不直接由缺失值本身决定。

拓展复习：把“Labs”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 6 页的核心主题是什么？
**答：** 本页围绕“Labs”展开。课件中的关键信息包括：实验课；Submit lab reports for feedback；Does not count towards the final Module mark；All labs are Python based。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 6?
**Answer:** This page presents 'Labs'. The slide includes: Labs; Submit lab reports for feedback; Does not count towards the final Module mark; All labs are Python based. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：随机缺失 / MAR
**答：** 缺失与其他可观测变量有关，但不直接由缺失值本身决定。
**Q2 English:** Explain the concept on this page: MAR
**Answer:** The page focuses on MAR. This page presents 'Labs'. The slide includes: Labs; Submit lab reports for feedback; Does not count towards the final Module mark; All labs are Python based. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

## 第 7 页：Advance Notice

Source ID: `src-ba4d35fbe29d-pdf_page-00007`

![PDF page 7](../assets/pages/page_007.jpg)

### 原文 / Original Text

```text
Advance Notice

Attendance will be monitored
Lectures
□
□ And Labs

7
```

### 完整中文翻译

Advance Notice
Attendance will be monitored
Lectures
□
□ And Labs
7
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Advance Notice”展开。课件中的关键信息包括：Advance Notice；Attendance will be monitored；Lectures；□。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Advance Notice'. The slide includes: Advance Notice; Attendance will be monitored; Lectures; □. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Advance Notice”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 7 页的核心主题是什么？
**答：** 本页围绕“Advance Notice”展开。课件中的关键信息包括：Advance Notice；Attendance will be monitored；Lectures；□。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 7?
**Answer:** This page presents 'Advance Notice'. The slide includes: Advance Notice; Attendance will be monitored; Lectures; □. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Advance Notice'. The slide includes: Advance Notice; Attendance will be monitored; Lectures; □. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 8 页：Module Description

Source ID: `src-ba4d35fbe29d-pdf_page-00008`

![PDF page 8](../assets/pages/page_008.jpg)

### 原文 / Original Text

```text
Module Description

Learning Outcomes
□ Understand what Computer Vision is
□ Make informed choices about which sort of algorithms to 

apply to solve specific problems

□ Use standard vision libraries or software to construct 

working vision systems

□ Apply algorithms to simplified problems by hand
□ Discuss the advantages and drawbacks of different 
methods, explaining their working mechanisms

8
```

### 完整中文翻译

Module Description
Learning Outcomes
□ Understand what 计算机视觉 is
□ Make informed choices about which sort of algorithms to
apply to solve specific problems
□ Use standard vision libraries or software to construct
working vision systems
□ Apply algorithms to simplified problems by hand
□ Discuss the advantages and drawbacks of different
methods, explaining their working mechanisms
8
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Module Description”展开。课件中的关键信息包括：Module Description；Learning Outcomes；□ Understand what 计算机视觉 is；□ Make informed choices about which sort of algorithms to。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Module Description'. The slide includes: Module Description; Learning Outcomes; □ Understand what Computer Vision is; □ Make informed choices about which sort of algorithms to. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Module Description”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 8 页的核心主题是什么？
**答：** 本页围绕“Module Description”展开。课件中的关键信息包括：Module Description；Learning Outcomes；□ Understand what 计算机视觉 is；□ Make informed choices about which sort of algorithms to。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 8?
**Answer:** This page presents 'Module Description'. The slide includes: Module Description; Learning Outcomes; □ Understand what Computer Vision is; □ Make informed choices about which sort of algorithms to. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Module Description'. The slide includes: Module Description; Learning Outcomes; □ Understand what Computer Vision is; □ Make informed choices about which sort of algorithms to. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 9 页：计算机视觉

Source ID: `src-ba4d35fbe29d-pdf_page-00009`

![PDF page 9](../assets/pages/page_009.jpg)

### 原文 / Original Text

```text
Computer Vision 
and Imaging

Jianbo Jiao

School of Computer Science
University of Birmingham

[Computer Vision and Imaging]
```

### 完整中文翻译

计算机视觉
and Imaging
Jianbo Jiao
计算机科学学院
伯明翰大学
[计算机视觉与成像]
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Computer Vision”展开。课件中的关键信息包括：计算机视觉；and Imaging；Jianbo Jiao；计算机科学学院。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Computer Vision'. The slide includes: Computer Vision; and Imaging; Jianbo Jiao; School of Computer Science. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Computer Vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 9 页的核心主题是什么？
**答：** 本页围绕“Computer Vision”展开。课件中的关键信息包括：计算机视觉；and Imaging；Jianbo Jiao；计算机科学学院。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 9?
**Answer:** This page presents 'Computer Vision'. The slide includes: Computer Vision; and Imaging; Jianbo Jiao; School of Computer Science. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Computer Vision'. The slide includes: Computer Vision; and Imaging; Jianbo Jiao; School of Computer Science. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 10 页：什么是计算机视觉？

Source ID: `src-ba4d35fbe29d-pdf_page-00010`

![PDF page 10](../assets/pages/page_010.jpg)

### 原文 / Original Text

```text
Computer Vision?

Robot vision
Machine Vision

Human vision

10
```

### 完整中文翻译

什么是计算机视觉？
Robot vision
Machine Vision
Human vision
10
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Computer Vision?”展开。课件中的关键信息包括：什么是计算机视觉？；Robot vision；Machine Vision；Human vision。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Computer Vision?'. The slide includes: Computer Vision?; Robot vision; Machine Vision; Human vision. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Computer Vision?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 10 页的核心主题是什么？
**答：** 本页围绕“Computer Vision?”展开。课件中的关键信息包括：什么是计算机视觉？；Robot vision；Machine Vision；Human vision。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 10?
**Answer:** This page presents 'Computer Vision?'. The slide includes: Computer Vision?; Robot vision; Machine Vision; Human vision. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Computer Vision?'. The slide includes: Computer Vision?; Robot vision; Machine Vision; Human vision. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 11 页：课程模块介绍 and 计算机视觉 - Page 11

Source ID: `src-ba4d35fbe29d-pdf_page-00011`

![PDF page 11](../assets/pages/page_011.jpg)

### 原文 / Original Text

```text
11

https://xkcd.com/1080
```

### 完整中文翻译

11
参考链接：https://xkcd.com/1080
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“课程模块介绍 and 计算机视觉 - Page 11 - Page 11”展开。课件中的关键信息包括：11；参考链接：https://xkcd.com/1080。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents '课程模块介绍 and 计算机视觉 - Page 11 - Page 11'. The slide includes: 11; https://xkcd.com/1080. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“课程模块介绍 and 计算机视觉 - Page 11 - Page 11”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 11 页的核心主题是什么？
**答：** 本页围绕“课程模块介绍 and 计算机视觉 - Page 11 - Page 11”展开。课件中的关键信息包括：11；参考链接：https://xkcd.com/1080。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 11?
**Answer:** This page presents '课程模块介绍 and 计算机视觉 - Page 11 - Page 11'. The slide includes: 11; https://xkcd.com/1080. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents '课程模块介绍 and 计算机视觉 - Page 11 - Page 11'. The slide includes: 11; https://xkcd.com/1080. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 12 页：什么是计算机视觉？

Source ID: `src-ba4d35fbe29d-pdf_page-00012`

![PDF page 12](../assets/pages/page_012.jpg)

### 原文 / Original Text

```text
Computer Vision?

Robot vision
Machine Vision

12

https://xkcd.com/1444
```

### 完整中文翻译

什么是计算机视觉？
Robot vision
Machine Vision
12
参考链接：https://xkcd.com/1444
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Computer Vision?”展开。课件中的关键信息包括：什么是计算机视觉？；Robot vision；Machine Vision；12。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Computer Vision?'. The slide includes: Computer Vision?; Robot vision; Machine Vision; 12. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Computer Vision?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 12 页的核心主题是什么？
**答：** 本页围绕“Computer Vision?”展开。课件中的关键信息包括：什么是计算机视觉？；Robot vision；Machine Vision；12。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 12?
**Answer:** This page presents 'Computer Vision?'. The slide includes: Computer Vision?; Robot vision; Machine Vision; 12. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Computer Vision?'. The slide includes: Computer Vision?; Robot vision; Machine Vision; 12. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 13 页：什么是计算机视觉？

Source ID: `src-ba4d35fbe29d-pdf_page-00013`

![PDF page 13](../assets/pages/page_013.jpg)

### 原文 / Original Text

```text
Computer Vision?

Advanced?

13
```

### 完整中文翻译

什么是计算机视觉？
问题：Advanced？
13
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Computer Vision?”展开。课件中的关键信息包括：什么是计算机视觉？；问题：Advanced？；13。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Computer Vision?'. The slide includes: Computer Vision?; Advanced?; 13. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Computer Vision?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 13 页的核心主题是什么？
**答：** 本页围绕“Computer Vision?”展开。课件中的关键信息包括：什么是计算机视觉？；问题：Advanced？；13。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 13?
**Answer:** This page presents 'Computer Vision?'. The slide includes: Computer Vision?; Advanced?; 13. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Computer Vision?'. The slide includes: Computer Vision?; Advanced?; 13. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 14 页：什么是计算机视觉？

Source ID: `src-ba4d35fbe29d-pdf_page-00014`

![PDF page 14](../assets/pages/page_014.jpg)

### 原文 / Original Text

```text
Computer Vision?

Advanced?

14
```

### 完整中文翻译

什么是计算机视觉？
问题：Advanced？
14
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Computer Vision?”展开。课件中的关键信息包括：什么是计算机视觉？；问题：Advanced？；14。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Computer Vision?'. The slide includes: Computer Vision?; Advanced?; 14. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Computer Vision?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 14 页的核心主题是什么？
**答：** 本页围绕“Computer Vision?”展开。课件中的关键信息包括：什么是计算机视觉？；问题：Advanced？；14。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 14?
**Answer:** This page presents 'Computer Vision?'. The slide includes: Computer Vision?; Advanced?; 14. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Computer Vision?'. The slide includes: Computer Vision?; Advanced?; 14. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 15 页：什么是计算机视觉？

Source ID: `src-ba4d35fbe29d-pdf_page-00015`

![PDF page 15](../assets/pages/page_015.jpg)

### 原文 / Original Text

```text
Computer Vision?

Advanced?

15
```

### 完整中文翻译

什么是计算机视觉？
问题：Advanced？
15
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Computer Vision?”展开。课件中的关键信息包括：什么是计算机视觉？；问题：Advanced？；15。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Computer Vision?'. The slide includes: Computer Vision?; Advanced?; 15. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Computer Vision?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 15 页的核心主题是什么？
**答：** 本页围绕“Computer Vision?”展开。课件中的关键信息包括：什么是计算机视觉？；问题：Advanced？；15。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 15?
**Answer:** This page presents 'Computer Vision?'. The slide includes: Computer Vision?; Advanced?; 15. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Computer Vision?'. The slide includes: Computer Vision?; Advanced?; 15. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 16 页：什么是计算机视觉？

Source ID: `src-ba4d35fbe29d-pdf_page-00016`

![PDF page 16](../assets/pages/page_016.jpg)

### 原文 / Original Text

```text
Computer Vision?

CAPTCHA

"Completely Automated Public 

Turing test to tell Computers 

and Humans Apart"

16

https://xkcd.com/2228/
```

### 完整中文翻译

什么是计算机视觉？
全自动区分人和计算机的图灵测试
"Completely Automated Public
Turing test to tell Computers
and Humans Apart"
16
参考链接：https://xkcd.com/2228/
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Computer Vision?”展开。课件中的关键信息包括：什么是计算机视觉？；全自动区分人和计算机的图灵测试；"Completely Automated Public；Turing test to tell Computers。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Computer Vision?'. The slide includes: Computer Vision?; CAPTCHA; "Completely Automated Public; Turing test to tell Computers. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Computer Vision?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 16 页的核心主题是什么？
**答：** 本页围绕“Computer Vision?”展开。课件中的关键信息包括：什么是计算机视觉？；全自动区分人和计算机的图灵测试；"Completely Automated Public；Turing test to tell Computers。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 16?
**Answer:** This page presents 'Computer Vision?'. The slide includes: Computer Vision?; CAPTCHA; "Completely Automated Public; Turing test to tell Computers. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Computer Vision?'. The slide includes: Computer Vision?; CAPTCHA; "Completely Automated Public; Turing test to tell Computers. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 17 页：什么是计算机视觉？

Source ID: `src-ba4d35fbe29d-pdf_page-00017`

![PDF page 17](../assets/pages/page_017.jpg)

### 原文 / Original Text

```text
Computer Vision?

17

https://xkcd.com/2228/
```

### 完整中文翻译

什么是计算机视觉？
17
参考链接：https://xkcd.com/2228/
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Computer Vision?”展开。课件中的关键信息包括：什么是计算机视觉？；17；参考链接：https://xkcd.com/2228/。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Computer Vision?'. The slide includes: Computer Vision?; 17; https://xkcd.com/2228/. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Computer Vision?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 17 页的核心主题是什么？
**答：** 本页围绕“Computer Vision?”展开。课件中的关键信息包括：什么是计算机视觉？；17；参考链接：https://xkcd.com/2228/。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 17?
**Answer:** This page presents 'Computer Vision?'. The slide includes: Computer Vision?; 17; https://xkcd.com/2228/. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Computer Vision?'. The slide includes: Computer Vision?; 17; https://xkcd.com/2228/. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 18 页：什么是计算机视觉？

Source ID: `src-ba4d35fbe29d-pdf_page-00018`

![PDF page 18](../assets/pages/page_018.jpg)

### 原文 / Original Text

```text
Computer Vision?

18

https://youtu.be/OnTgbN3uXvw
```

### 完整中文翻译

什么是计算机视觉？
18
参考链接：https://youtu.be/OnTgbN3uXvw
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Computer Vision?”展开。课件中的关键信息包括：什么是计算机视觉？；18；参考链接：https://youtu.be/OnTgbN3uXvw。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Computer Vision?'. The slide includes: Computer Vision?; 18; https://youtu.be/OnTgbN3uXvw. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Computer Vision?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 18 页的核心主题是什么？
**答：** 本页围绕“Computer Vision?”展开。课件中的关键信息包括：什么是计算机视觉？；18；参考链接：https://youtu.be/OnTgbN3uXvw。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 18?
**Answer:** This page presents 'Computer Vision?'. The slide includes: Computer Vision?; 18; https://youtu.be/OnTgbN3uXvw. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Computer Vision?'. The slide includes: Computer Vision?; 18; https://youtu.be/OnTgbN3uXvw. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 19 页：Reference : https://images.app.goo.gl/NhwG91feT9Sv3H9R7

Source ID: `src-ba4d35fbe29d-pdf_page-00019`

![PDF page 19](../assets/pages/page_019.jpg)

### 原文 / Original Text

```text
Reference : https://images.app.goo.gl/NhwG91feT9Sv3H9R7

Reference : https://images.app.goo.gl/3Af75r96L7MFywXJ9

Reference : https://images.app.goo.gl/CtTdZ4eCg7hmGcL76

Reference : https://pxhere.com/ko/photo/695788

Reference : https://images.app.goo.gl/8ugbqynh8mahrhqZ9

Reference : https://images.app.goo.gl/TEh6T8JWLBntMU2B9

19
```

### 完整中文翻译

Reference : https://images.app.goo.gl/NhwG91feT9Sv3H9R7
Reference : https://images.app.goo.gl/3Af75r96L7MFywXJ9
Reference : https://images.app.goo.gl/CtTdZ4eCg7hmGcL76
Reference : https://pxhere.com/ko/photo/695788
Reference : https://images.app.goo.gl/8ugbqynh8mahrhqZ9
Reference : https://images.app.goo.gl/TEh6T8JWLBntMU2B9
19
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Reference : https://images.app.goo.gl/NhwG91feT9Sv3H9R7”展开。课件中的关键信息包括：Reference : https://images.app.goo.gl/NhwG91feT9Sv3H9R7；Reference : https://images.app.goo.gl/3Af75r96L7MFywXJ9；Reference : https://images.app.goo.gl/CtTdZ4eCg7hmGcL76；Reference : https://pxhere.com/ko/photo/695788。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Reference : https://images.app.goo.gl/NhwG91feT9Sv3H9R7'. The slide includes: Reference : https://images.app.goo.gl/NhwG91feT9Sv3H9R7; Reference : https://images.app.goo.gl/3Af75r96L7MFywXJ9; Reference : https://images.app.goo.gl/CtTdZ4eCg7hmGcL76; Reference : https://pxhere.com/ko/photo/695788. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Reference : https://images.app.goo.gl/NhwG91feT9Sv3H9R7”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 19 页的核心主题是什么？
**答：** 本页围绕“Reference : https://images.app.goo.gl/NhwG91feT9Sv3H9R7”展开。课件中的关键信息包括：Reference : https://images.app.goo.gl/NhwG91feT9Sv3H9R7；Reference : https://images.app.goo.gl/3Af75r96L7MFywXJ9；Reference : https://images.app.goo.gl/CtTdZ4eCg7hmGcL76；Reference : https://pxhere.com/ko/photo/695788。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 19?
**Answer:** This page presents 'Reference : https://images.app.goo.gl/NhwG91feT9Sv3H9R7'. The slide includes: Reference : https://images.app.goo.gl/NhwG91feT9Sv3H9R7; Reference : https://images.app.goo.gl/3Af75r96L7MFywXJ9; Reference : https://images.app.goo.gl/CtTdZ4eCg7hmGcL76; Reference : https://pxhere.com/ko/photo/695788. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Reference : https://images.app.goo.gl/NhwG91feT9Sv3H9R7'. The slide includes: Reference : https://images.app.goo.gl/NhwG91feT9Sv3H9R7; Reference : https://images.app.goo.gl/3Af75r96L7MFywXJ9; Reference : https://images.app.goo.gl/CtTdZ4eCg7hmGcL76; Reference : https://pxhere.com/ko/photo/695788. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 20 页：计算机视觉

Source ID: `src-ba4d35fbe29d-pdf_page-00020`

![PDF page 20](../assets/pages/page_020.jpg)

### 原文 / Original Text

```text
Computer Vision

Reference : 
https://images.app.goo.gl/ubV3CEG7n8XLagS98

“50% of our neural tissue is directly or indirectly 
related to vision, which assists in visual learning”

S.B. Sells and Richard S. Fixott, “Evaluation of Research on Effects of 
Visual Training on Visual Functions”, American Journal of Ophthalmology

Reference : https://www.pngegg.com/en/png-pvjkt

Enable machines to “see” and “understand”
the visual world as we do

20
```

### 完整中文翻译

计算机视觉
Reference :
参考链接：https://images.app.goo.gl/ubV3CEG7n8XLagS98
“50% of our neural tissue is directly or indirectly
related to vision, which assists in visual learning”
S.B. Sells and Richard S. Fixott, “Evaluation of Research on Effects of
Visual Training on Visual Functions”, American Journal of Ophthalmology
参考链接：Reference : https://www.pngegg.com/en/png-pvjkt
Enable machines to “see” and “understand”
the visual world as we do
20
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Computer Vision”展开。课件中的关键信息包括：计算机视觉；Reference :；参考链接：https://images.app.goo.gl/ubV3CEG7n8XLagS98；“50% of our neural tissue is directly or indirectly。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Computer Vision'. The slide includes: Computer Vision; Reference :; https://images.app.goo.gl/ubV3CEG7n8XLagS98; “50% of our neural tissue is directly or indirectly. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Computer Vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 20 页的核心主题是什么？
**答：** 本页围绕“Computer Vision”展开。课件中的关键信息包括：计算机视觉；Reference :；参考链接：https://images.app.goo.gl/ubV3CEG7n8XLagS98；“50% of our neural tissue is directly or indirectly。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 20?
**Answer:** This page presents 'Computer Vision'. The slide includes: Computer Vision; Reference :; https://images.app.goo.gl/ubV3CEG7n8XLagS98; “50% of our neural tissue is directly or indirectly. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Computer Vision'. The slide includes: Computer Vision; Reference :; https://images.app.goo.gl/ubV3CEG7n8XLagS98; “50% of our neural tissue is directly or indirectly. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 21 页：计算机视觉

Source ID: `src-ba4d35fbe29d-pdf_page-00021`

![PDF page 21](../assets/pages/page_021.jpg)

### 原文 / Original Text

```text
Computer Vision

Block World

Larry Roberts 1963

Reference : 
https://images.app.goo.gl/8o
TfaBHirA3AUfaB9

Reference : 
https://images.app.goo.gl/JLWX1RUKs4aKvHTC6

Reference : 
https://www.researchgate.net/publication/220695992_M
achine_Perception_of_Three-Dimensional_Solids

21

Slide credit: Hyung Jin Chang
```

### 完整中文翻译

计算机视觉
Block World
Larry Roberts 1963
Reference :
参考链接：https://images.app.goo.gl/8o
TfaBHirA3AUfaB9
Reference :
参考链接：https://images.app.goo.gl/JLWX1RUKs4aKvHTC6
Reference :
参考链接：https://www.researchgate.net/publication/220695992_M
achine_Perception_of_Three-Dimensional_Solids
21
Slide credit: Hyung Jin Chang
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Computer Vision”展开。课件中的关键信息包括：计算机视觉；Block World；Larry Roberts 1963；Reference :。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Computer Vision'. The slide includes: Computer Vision; Block World; Larry Roberts 1963; Reference :. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Computer Vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 21 页的核心主题是什么？
**答：** 本页围绕“Computer Vision”展开。课件中的关键信息包括：计算机视觉；Block World；Larry Roberts 1963；Reference :。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 21?
**Answer:** This page presents 'Computer Vision'. The slide includes: Computer Vision; Block World; Larry Roberts 1963; Reference :. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Computer Vision'. The slide includes: Computer Vision; Block World; Larry Roberts 1963; Reference :. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 22 页：计算机视觉

Source ID: `src-ba4d35fbe29d-pdf_page-00022`

![PDF page 22](../assets/pages/page_022.jpg)

### 原文 / Original Text

```text
Computer Vision

Reference : https://dspace.mit.edu/bitstream/handle/1721.1/6125/AIM-100.pdf?sequence=2&isAllowed=y

22

Slide credit: Hyung Jin Chang
```

### 完整中文翻译

计算机视觉
Reference : https://dspace.mit.edu/bitstream/handle/1721.1/6125/AIM-100.pdf?sequence=2&isAllowed=y
22
Slide credit: Hyung Jin Chang
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Computer Vision”展开。课件中的关键信息包括：计算机视觉；Reference : https://dspace.mit.edu/bitstream/handle/1721.1/6125/AIM-100.pdf?sequence=2&isAllowed=y；22；Slide credit: Hyung Jin Chang。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Computer Vision'. The slide includes: Computer Vision; Reference : https://dspace.mit.edu/bitstream/handle/1721.1/6125/AIM-100.pdf?sequence=2&isAllowed=y; 22; Slide credit: Hyung Jin Chang. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Computer Vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 22 页的核心主题是什么？
**答：** 本页围绕“Computer Vision”展开。课件中的关键信息包括：计算机视觉；Reference : https://dspace.mit.edu/bitstream/handle/1721.1/6125/AIM-100.pdf?sequence=2&isAllowed=y；22；Slide credit: Hyung Jin Chang。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 22?
**Answer:** This page presents 'Computer Vision'. The slide includes: Computer Vision; Reference : https://dspace.mit.edu/bitstream/handle/1721.1/6125/AIM-100.pdf?sequence=2&isAllowed=y; 22; Slide credit: Hyung Jin Chang. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Computer Vision'. The slide includes: Computer Vision; Reference : https://dspace.mit.edu/bitstream/handle/1721.1/6125/AIM-100.pdf?sequence=2&isAllowed=y; 22; Slide credit: Hyung Jin Chang. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 23 页：计算机视觉

Source ID: `src-ba4d35fbe29d-pdf_page-00023`

![PDF page 23](../assets/pages/page_023.jpg)

### 原文 / Original Text

```text
Computer Vision

David Marr, 1970s

Reference : https://dspace.mit.edu/bitstream/handle/1721.1/6125/AIM-100.pdf?sequence=2&isAllowed=y

Reference : https://images.app.goo.gl/okGikV8SHgMkn9Y19

23

Slide credit: Hyung Jin Chang
```

### 完整中文翻译

计算机视觉
David Marr, 1970s
Reference : https://dspace.mit.edu/bitstream/handle/1721.1/6125/AIM-100.pdf?sequence=2&isAllowed=y
Reference : https://images.app.goo.gl/okGikV8SHgMkn9Y19
23
Slide credit: Hyung Jin Chang
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Computer Vision”展开。课件中的关键信息包括：计算机视觉；David Marr, 1970s；Reference : https://dspace.mit.edu/bitstream/handle/1721.1/6125/AIM-100.pdf?sequence=2&isAllowed=y；Reference : https://images.app.goo.gl/okGikV8SHgMkn9Y19。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Computer Vision'. The slide includes: Computer Vision; David Marr, 1970s; Reference : https://dspace.mit.edu/bitstream/handle/1721.1/6125/AIM-100.pdf?sequence=2&isAllowed=y; Reference : https://images.app.goo.gl/okGikV8SHgMkn9Y19. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **MAR / 随机缺失**：缺失与其他可观测变量有关，但不直接由缺失值本身决定。
- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Computer Vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 23 页的核心主题是什么？
**答：** 本页围绕“Computer Vision”展开。课件中的关键信息包括：计算机视觉；David Marr, 1970s；Reference : https://dspace.mit.edu/bitstream/handle/1721.1/6125/AIM-100.pdf?sequence=2&isAllowed=y；Reference : https://images.app.goo.gl/okGikV8SHgMkn9Y19。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 23?
**Answer:** This page presents 'Computer Vision'. The slide includes: Computer Vision; David Marr, 1970s; Reference : https://dspace.mit.edu/bitstream/handle/1721.1/6125/AIM-100.pdf?sequence=2&isAllowed=y; Reference : https://images.app.goo.gl/okGikV8SHgMkn9Y19. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：随机缺失 / MAR
**答：** 缺失与其他可观测变量有关，但不直接由缺失值本身决定。
**Q2 English:** Explain the concept on this page: MAR
**Answer:** The page focuses on MAR. This page presents 'Computer Vision'. The slide includes: Computer Vision; David Marr, 1970s; Reference : https://dspace.mit.edu/bitstream/handle/1721.1/6125/AIM-100.pdf?sequence=2&isAllowed=y; Reference : https://images.app.goo.gl/okGikV8SHgMkn9Y19. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

## 第 24 页：计算机视觉

Source ID: `src-ba4d35fbe29d-pdf_page-00024`

![PDF page 24](../assets/pages/page_024.jpg)

### 原文 / Original Text

```text
Computer Vision

24

Slide credit: Fei-Fei Li
```

### 完整中文翻译

计算机视觉
24
Slide credit: Fei-Fei Li
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Computer Vision”展开。课件中的关键信息包括：计算机视觉；24；Slide credit: Fei-Fei Li。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Computer Vision'. The slide includes: Computer Vision; 24; Slide credit: Fei-Fei Li. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Computer Vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 24 页的核心主题是什么？
**答：** 本页围绕“Computer Vision”展开。课件中的关键信息包括：计算机视觉；24；Slide credit: Fei-Fei Li。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 24?
**Answer:** This page presents 'Computer Vision'. The slide includes: Computer Vision; 24; Slide credit: Fei-Fei Li. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Computer Vision'. The slide includes: Computer Vision; 24; Slide credit: Fei-Fei Li. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 25 页：Street scene

Source ID: `src-ba4d35fbe29d-pdf_page-00025`

![PDF page 25](../assets/pages/page_025.jpg)

### 原文 / Original Text

```text
Street scene

SVM

kNN

K-means
clustering

SIFT

SURF

Deep Learning

Bus

Pedestrian

category

Plants

20m

5m

depth

25
```

### 完整中文翻译

Street scene
SVM
K 近邻
K-means
聚类
SIFT
SURF
深度学习
Bus
Pedestrian
category
Plants
20m
5m
depth
25
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Street scene”展开。课件中的关键信息包括：Street scene；SVM；K 近邻；K-means。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Street scene'. The slide includes: Street scene; SVM; kNN; K-means. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“Street scene”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 25 页的核心主题是什么？
**答：** 本页围绕“Street scene”展开。课件中的关键信息包括：Street scene；SVM；K 近邻；K-means。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 25?
**Answer:** This page presents 'Street scene'. The slide includes: Street scene; SVM; kNN; K-means. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：深度学习 / deep learning
**答：** 用多层神经网络从数据中学习表示和映射，现代视觉任务常用。
**Q2 English:** Explain the concept on this page: deep learning
**Answer:** The page focuses on deep learning. This page presents 'Street scene'. The slide includes: Street scene; SVM; kNN; K-means. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

## 第 26 页：问题：Why is Vision Difficult？

Source ID: `src-ba4d35fbe29d-pdf_page-00026`

![PDF page 26](../assets/pages/page_026.jpg)

### 原文 / Original Text

```text
Why is Vision Difficult?

26
```

### 完整中文翻译

问题：Why is Vision Difficult？
26
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Why is Vision Difficult?”展开。课件中的关键信息包括：问题：Why is Vision Difficult？；26。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Why is Vision Difficult?'. The slide includes: Why is Vision Difficult?; 26. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Why is Vision Difficult?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 26 页的核心主题是什么？
**答：** 本页围绕“Why is Vision Difficult?”展开。课件中的关键信息包括：问题：Why is Vision Difficult？；26。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 26?
**Answer:** This page presents 'Why is Vision Difficult?'. The slide includes: Why is Vision Difficult?; 26. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Why is Vision Difficult?'. The slide includes: Why is Vision Difficult?; 26. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 27 页：课程模块介绍 and 计算机视觉 - Page 27

Source ID: `src-ba4d35fbe29d-pdf_page-00027`

![PDF page 27](../assets/pages/page_027.jpg)

### 原文 / Original Text

```text
27
```

### 完整中文翻译

27
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“课程模块介绍 and 计算机视觉 - Page 27 - Page 27”展开。课件中的关键信息包括：27。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents '课程模块介绍 and 计算机视觉 - Page 27 - Page 27'. The slide includes: 27. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“课程模块介绍 and 计算机视觉 - Page 27 - Page 27”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 27 页的核心主题是什么？
**答：** 本页围绕“课程模块介绍 and 计算机视觉 - Page 27 - Page 27”展开。课件中的关键信息包括：27。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 27?
**Answer:** This page presents '课程模块介绍 and 计算机视觉 - Page 27 - Page 27'. The slide includes: 27. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents '课程模块介绍 and 计算机视觉 - Page 27 - Page 27'. The slide includes: 27. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 28 页：课程模块介绍 and 计算机视觉 - Page 28

Source ID: `src-ba4d35fbe29d-pdf_page-00028`

![PDF page 28](../assets/pages/page_028.jpg)

### 原文 / Original Text

```text
28

https://youtu.be/pNe6fsaCVtI
```

### 完整中文翻译

28
参考链接：https://youtu.be/pNe6fsaCVtI
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“课程模块介绍 and 计算机视觉 - Page 28 - Page 28”展开。课件中的关键信息包括：28；参考链接：https://youtu.be/pNe6fsaCVtI。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents '课程模块介绍 and 计算机视觉 - Page 28 - Page 28'. The slide includes: 28; https://youtu.be/pNe6fsaCVtI. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“课程模块介绍 and 计算机视觉 - Page 28 - Page 28”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 28 页的核心主题是什么？
**答：** 本页围绕“课程模块介绍 and 计算机视觉 - Page 28 - Page 28”展开。课件中的关键信息包括：28；参考链接：https://youtu.be/pNe6fsaCVtI。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 28?
**Answer:** This page presents '课程模块介绍 and 计算机视觉 - Page 28 - Page 28'. The slide includes: 28; https://youtu.be/pNe6fsaCVtI. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents '课程模块介绍 and 计算机视觉 - Page 28 - Page 28'. The slide includes: 28; https://youtu.be/pNe6fsaCVtI. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 29 页：Image credit: Bev Doolittle

Source ID: `src-ba4d35fbe29d-pdf_page-00029`

![PDF page 29](../assets/pages/page_029.jpg)

### 原文 / Original Text

```text
29

Image credit: Bev Doolittle
```

### 完整中文翻译

29
Image credit: Bev Doolittle
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image credit: Bev Doolittle”展开。课件中的关键信息包括：29；Image credit: Bev Doolittle。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image credit: Bev Doolittle'. The slide includes: 29; Image credit: Bev Doolittle. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Image credit: Bev Doolittle”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 29 页的核心主题是什么？
**答：** 本页围绕“Image credit: Bev Doolittle”展开。课件中的关键信息包括：29；Image credit: Bev Doolittle。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 29?
**Answer:** This page presents 'Image credit: Bev Doolittle'. The slide includes: 29; Image credit: Bev Doolittle. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Image credit: Bev Doolittle'. The slide includes: 29; Image credit: Bev Doolittle. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 30 页：Image credit: Bev Doolittle

Source ID: `src-ba4d35fbe29d-pdf_page-00030`

![PDF page 30](../assets/pages/page_030.jpg)

### 原文 / Original Text

```text
30

Image credit: Bev Doolittle
```

### 完整中文翻译

30
Image credit: Bev Doolittle
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image credit: Bev Doolittle”展开。课件中的关键信息包括：30；Image credit: Bev Doolittle。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image credit: Bev Doolittle'. The slide includes: 30; Image credit: Bev Doolittle. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Image credit: Bev Doolittle”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 30 页的核心主题是什么？
**答：** 本页围绕“Image credit: Bev Doolittle”展开。课件中的关键信息包括：30；Image credit: Bev Doolittle。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 30?
**Answer:** This page presents 'Image credit: Bev Doolittle'. The slide includes: 30; Image credit: Bev Doolittle. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Image credit: Bev Doolittle'. The slide includes: 30; Image credit: Bev Doolittle. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 31 页：Image credit: Bev Doolittle

Source ID: `src-ba4d35fbe29d-pdf_page-00031`

![PDF page 31](../assets/pages/page_031.jpg)

### 原文 / Original Text

```text
31

Image credit: Bev Doolittle
```

### 完整中文翻译

31
Image credit: Bev Doolittle
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image credit: Bev Doolittle”展开。课件中的关键信息包括：31；Image credit: Bev Doolittle。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image credit: Bev Doolittle'. The slide includes: 31; Image credit: Bev Doolittle. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Image credit: Bev Doolittle”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 31 页的核心主题是什么？
**答：** 本页围绕“Image credit: Bev Doolittle”展开。课件中的关键信息包括：31；Image credit: Bev Doolittle。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 31?
**Answer:** This page presents 'Image credit: Bev Doolittle'. The slide includes: 31; Image credit: Bev Doolittle. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Image credit: Bev Doolittle'. The slide includes: 31; Image credit: Bev Doolittle. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 32 页：Image credit: Bev Doolittle

Source ID: `src-ba4d35fbe29d-pdf_page-00032`

![PDF page 32](../assets/pages/page_032.jpg)

### 原文 / Original Text

```text
32

Image credit: Bev Doolittle
```

### 完整中文翻译

32
Image credit: Bev Doolittle
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image credit: Bev Doolittle”展开。课件中的关键信息包括：32；Image credit: Bev Doolittle。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image credit: Bev Doolittle'. The slide includes: 32; Image credit: Bev Doolittle. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Image credit: Bev Doolittle”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 32 页的核心主题是什么？
**答：** 本页围绕“Image credit: Bev Doolittle”展开。课件中的关键信息包括：32；Image credit: Bev Doolittle。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 32?
**Answer:** This page presents 'Image credit: Bev Doolittle'. The slide includes: 32; Image credit: Bev Doolittle. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Image credit: Bev Doolittle'. The slide includes: 32; Image credit: Bev Doolittle. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 33 页：课程模块介绍 and 计算机视觉 - Page 33

Source ID: `src-ba4d35fbe29d-pdf_page-00033`

![PDF page 33](../assets/pages/page_033.jpg)

### 原文 / Original Text

```text
33

https://en.wikipedia.org/wiki/Optical_illusion
```

### 完整中文翻译

33
参考链接：https://en.wikipedia.org/wiki/Optical_illusion
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“课程模块介绍 and 计算机视觉 - Page 33 - Page 33”展开。课件中的关键信息包括：33；参考链接：https://en.wikipedia.org/wiki/Optical_illusion。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents '课程模块介绍 and 计算机视觉 - Page 33 - Page 33'. The slide includes: 33; https://en.wikipedia.org/wiki/Optical_illusion. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“课程模块介绍 and 计算机视觉 - Page 33 - Page 33”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 33 页的核心主题是什么？
**答：** 本页围绕“课程模块介绍 and 计算机视觉 - Page 33 - Page 33”展开。课件中的关键信息包括：33；参考链接：https://en.wikipedia.org/wiki/Optical_illusion。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 33?
**Answer:** This page presents '课程模块介绍 and 计算机视觉 - Page 33 - Page 33'. The slide includes: 33; https://en.wikipedia.org/wiki/Optical_illusion. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents '课程模块介绍 and 计算机视觉 - Page 33 - Page 33'. The slide includes: 33; https://en.wikipedia.org/wiki/Optical_illusion. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 34 页：课程模块介绍 and 计算机视觉 - Page 34

Source ID: `src-ba4d35fbe29d-pdf_page-00034`

![PDF page 34](../assets/pages/page_034.jpg)

### 原文 / Original Text

```text
34

https://en.wikipedia.org/wiki/Optical_illusion
```

### 完整中文翻译

34
参考链接：https://en.wikipedia.org/wiki/Optical_illusion
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“课程模块介绍 and 计算机视觉 - Page 34 - Page 34”展开。课件中的关键信息包括：34；参考链接：https://en.wikipedia.org/wiki/Optical_illusion。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents '课程模块介绍 and 计算机视觉 - Page 34 - Page 34'. The slide includes: 34; https://en.wikipedia.org/wiki/Optical_illusion. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“课程模块介绍 and 计算机视觉 - Page 34 - Page 34”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 34 页的核心主题是什么？
**答：** 本页围绕“课程模块介绍 and 计算机视觉 - Page 34 - Page 34”展开。课件中的关键信息包括：34；参考链接：https://en.wikipedia.org/wiki/Optical_illusion。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 34?
**Answer:** This page presents '课程模块介绍 and 计算机视觉 - Page 34 - Page 34'. The slide includes: 34; https://en.wikipedia.org/wiki/Optical_illusion. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents '课程模块介绍 and 计算机视觉 - Page 34 - Page 34'. The slide includes: 34; https://en.wikipedia.org/wiki/Optical_illusion. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 35 页：Illumination

Source ID: `src-ba4d35fbe29d-pdf_page-00035`

![PDF page 35](../assets/pages/page_035.jpg)

### 原文 / Original Text

```text
Illumination

Object pose

Clutter

Occlusions

Intra-class appearance

Viewpoint

Slide credit: Kristen Grauman
```

### 完整中文翻译

Illumination
Object pose
Clutter
Occlusions
Intra-class appearance
Viewpoint
Slide credit: Kristen Grauman
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Illumination”展开。课件中的关键信息包括：Illumination；Object pose；Clutter；Occlusions。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Illumination'. The slide includes: Illumination; Object pose; Clutter; Occlusions. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Illumination”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 35 页的核心主题是什么？
**答：** 本页围绕“Illumination”展开。课件中的关键信息包括：Illumination；Object pose；Clutter；Occlusions。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 35?
**Answer:** This page presents 'Illumination'. The slide includes: Illumination; Object pose; Clutter; Occlusions. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Illumination'. The slide includes: Illumination; Object pose; Clutter; Occlusions. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 36 页：Slide credit: Svetlana Lazebnik

Source ID: `src-ba4d35fbe29d-pdf_page-00036`

![PDF page 36](../assets/pages/page_036.jpg)

### 原文 / Original Text

```text
Slide credit: Svetlana Lazebnik
```

### 完整中文翻译

Slide credit: Svetlana Lazebnik
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit: Svetlana Lazebnik”展开。课件中的关键信息包括：Slide credit: Svetlana Lazebnik。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit: Svetlana Lazebnik'. The slide includes: Slide credit: Svetlana Lazebnik. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit: Svetlana Lazebnik”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 36 页的核心主题是什么？
**答：** 本页围绕“Slide credit: Svetlana Lazebnik”展开。课件中的关键信息包括：Slide credit: Svetlana Lazebnik。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 36?
**Answer:** This page presents 'Slide credit: Svetlana Lazebnik'. The slide includes: Slide credit: Svetlana Lazebnik. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit: Svetlana Lazebnik'. The slide includes: Slide credit: Svetlana Lazebnik. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 37 页：Slide credit: Fei-Fei, Fergus, Torralba

Source ID: `src-ba4d35fbe29d-pdf_page-00037`

![PDF page 37](../assets/pages/page_037.jpg)

### 原文 / Original Text

```text
Slide credit: Fei-Fei, Fergus, Torralba
```

### 完整中文翻译

Slide credit: Fei-Fei, Fergus, Torralba
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit: Fei-Fei, Fergus, Torralba”展开。课件中的关键信息包括：Slide credit: Fei-Fei, Fergus, Torralba。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit: Fei-Fei, Fergus, Torralba'. The slide includes: Slide credit: Fei-Fei, Fergus, Torralba. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit: Fei-Fei, Fergus, Torralba”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 37 页的核心主题是什么？
**答：** 本页围绕“Slide credit: Fei-Fei, Fergus, Torralba”展开。课件中的关键信息包括：Slide credit: Fei-Fei, Fergus, Torralba。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 37?
**Answer:** This page presents 'Slide credit: Fei-Fei, Fergus, Torralba'. The slide includes: Slide credit: Fei-Fei, Fergus, Torralba. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit: Fei-Fei, Fergus, Torralba'. The slide includes: Slide credit: Fei-Fei, Fergus, Torralba. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 38 页：Slide credit: Fei-Fei, Fergus, Torralba

Source ID: `src-ba4d35fbe29d-pdf_page-00038`

![PDF page 38](../assets/pages/page_038.jpg)

### 原文 / Original Text

```text
Slide credit: Fei-Fei, Fergus, Torralba
```

### 完整中文翻译

Slide credit: Fei-Fei, Fergus, Torralba
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit: Fei-Fei, Fergus, Torralba”展开。课件中的关键信息包括：Slide credit: Fei-Fei, Fergus, Torralba。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit: Fei-Fei, Fergus, Torralba'. The slide includes: Slide credit: Fei-Fei, Fergus, Torralba. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit: Fei-Fei, Fergus, Torralba”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 38 页的核心主题是什么？
**答：** 本页围绕“Slide credit: Fei-Fei, Fergus, Torralba”展开。课件中的关键信息包括：Slide credit: Fei-Fei, Fergus, Torralba。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 38?
**Answer:** This page presents 'Slide credit: Fei-Fei, Fergus, Torralba'. The slide includes: Slide credit: Fei-Fei, Fergus, Torralba. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit: Fei-Fei, Fergus, Torralba'. The slide includes: Slide credit: Fei-Fei, Fergus, Torralba. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 39 页：提纲

Source ID: `src-ba4d35fbe29d-pdf_page-00039`

![PDF page 39](../assets/pages/page_039.jpg)

### 原文 / Original Text

```text
Outline

What is?
Why?
How to?

39
```

### 完整中文翻译

提纲
问题：What is？
问题：Why？
问题：How to？
39
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Outline”展开。课件中的关键信息包括：提纲；问题：What is？；问题：Why？；问题：How to？。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Outline'. The slide includes: Outline; What is?; Why?; How to?. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Outline”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 39 页的核心主题是什么？
**答：** 本页围绕“Outline”展开。课件中的关键信息包括：提纲；问题：What is？；问题：Why？；问题：How to？。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 39?
**Answer:** This page presents 'Outline'. The slide includes: Outline; What is?; Why?; How to?. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Outline'. The slide includes: Outline; What is?; Why?; How to?. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 40 页：提纲

Source ID: `src-ba4d35fbe29d-pdf_page-00040`

![PDF page 40](../assets/pages/page_040.jpg)

### 原文 / Original Text

```text
Outline

Acknowledgement

Course materials are inherited/borrowed
from or inspired by the courses given by
other great researchers in the Computer
Vision community:

Introduction to CV and ML4CV
Feature detection and DL
Low-level vision
Image Registration and Segmentation
Dimensionality Reduction and its Link to DL
High-level vision
Motion and video
Self-supervised learning and Multi-modal Learning
Generative models

o Richard Szeliski
o Geoffrey Hinton
o Yann LeCun
o Alexei A. Efros
o Fei-Fei Li
o Samuel Albanie
o Been Kim
o Hamid Dehghani
o Hyung Jin Chang
o Ales Leonardis
o etc.

40
```

### 完整中文翻译

提纲
Acknowledgement
Course materials are inherited/borrowed
from or inspired by the courses given by
other great researchers in the Computer
Vision community:
Introduction to CV and 机器学习4CV
特征 检测 and DL
Low-level vision
Image Registration and 分割
Dimensionality Reduction and its Link to DL
High-level vision
Motion and video
Self-监督学习 and Multi-modal Learning
Generative models
o Richard Szeliski
o Geoffrey Hinton
o Yann LeCun
o Alexei A. Efros
o Fei-Fei Li
o Samuel Albanie
o Been Kim
o Hamid Dehghani
o Hyung Jin Chang
o Ales Leonardis
o etc.
40
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Outline”展开。课件中的关键信息包括：提纲；Acknowledgement；Course materials are inherited/borrowed；from or inspired by the courses given by。复习时先抓住检测：同时判断目标类别与位置，通常输出边界框。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Outline'. The slide includes: Outline; Acknowledgement; Course materials are inherited/borrowed; from or inspired by the courses given by. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。
- **segmentation / 分割**：为像素或区域分配类别/实例标签。

拓展复习：把“Outline”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 40 页的核心主题是什么？
**答：** 本页围绕“Outline”展开。课件中的关键信息包括：提纲；Acknowledgement；Course materials are inherited/borrowed；from or inspired by the courses given by。复习时先抓住检测：同时判断目标类别与位置，通常输出边界框。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 40?
**Answer:** This page presents 'Outline'. The slide includes: Outline; Acknowledgement; Course materials are inherited/borrowed; from or inspired by the courses given by. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：检测 / detection
**答：** 同时判断目标类别与位置，通常输出边界框。
**Q2 English:** Explain the concept on this page: detection
**Answer:** The page focuses on detection. This page presents 'Outline'. The slide includes: Outline; Acknowledgement; Course materials are inherited/borrowed; from or inspired by the courses given by. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

## 第 41 页：提纲

Source ID: `src-ba4d35fbe29d-pdf_page-00041`

![PDF page 41](../assets/pages/page_041.jpg)

### 原文 / Original Text

```text
Outline

Acknowledgement

Course materials are inherited/borrowed
from or inspired by the courses given by
other great researchers in the Computer
Vision community:

Introduction to CV and ML4CV
Feature detection and DL
Low-level vision
Image Registration and Segmentation
Dimensionality Reduction and its Link to DL
High-level vision
Motion and video
Self-supervised learning and Multi-modal Learning
Generative models

o Richard Szeliski
o Geoffrey Hinton
o Yann LeCun
o Alexei A. Efros
o Fei-Fei Li
o Samuel Albanie
o Been Kim
o Hamid Dehghani
o Hyung Jin Chang
o Ales Leonardis
o etc.

https://szeliski.org/Book

https://www.deeplearningbook.org/

41
```

### 完整中文翻译

提纲
Acknowledgement
Course materials are inherited/borrowed
from or inspired by the courses given by
other great researchers in the Computer
Vision community:
Introduction to CV and 机器学习4CV
特征 检测 and DL
Low-level vision
Image Registration and 分割
Dimensionality Reduction and its Link to DL
High-level vision
Motion and video
Self-监督学习 and Multi-modal Learning
Generative models
o Richard Szeliski
o Geoffrey Hinton
o Yann LeCun
o Alexei A. Efros
o Fei-Fei Li
o Samuel Albanie
o Been Kim
o Hamid Dehghani
o Hyung Jin Chang
o Ales Leonardis
o etc.
参考链接：https://szeliski.org/Book
参考链接：https://www.deeplearningbook.org/
41
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Outline”展开。课件中的关键信息包括：提纲；Acknowledgement；Course materials are inherited/borrowed；from or inspired by the courses given by。复习时先抓住检测：同时判断目标类别与位置，通常输出边界框。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Outline'. The slide includes: Outline; Acknowledgement; Course materials are inherited/borrowed; from or inspired by the courses given by. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。
- **segmentation / 分割**：为像素或区域分配类别/实例标签。

拓展复习：把“Outline”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 41 页的核心主题是什么？
**答：** 本页围绕“Outline”展开。课件中的关键信息包括：提纲；Acknowledgement；Course materials are inherited/borrowed；from or inspired by the courses given by。复习时先抓住检测：同时判断目标类别与位置，通常输出边界框。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 41?
**Answer:** This page presents 'Outline'. The slide includes: Outline; Acknowledgement; Course materials are inherited/borrowed; from or inspired by the courses given by. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：检测 / detection
**答：** 同时判断目标类别与位置，通常输出边界框。
**Q2 English:** Explain the concept on this page: detection
**Answer:** The page focuses on detection. This page presents 'Outline'. The slide includes: Outline; Acknowledgement; Course materials are inherited/borrowed; from or inspired by the courses given by. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

## 第 42 页：The techniques should be

Source ID: `src-ba4d35fbe29d-pdf_page-00042`

![PDF page 42](../assets/pages/page_042.jpg)

### 原文 / Original Text

```text
The techniques should be
used for Good, instead of
the other side of the coin.

42
```

### 完整中文翻译

The techniques should be
used for Good, instead of
the other side of the coin.
42
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“The techniques should be”展开。课件中的关键信息包括：The techniques should be；used for Good, instead of；the other side of the coin.；42。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'The techniques should be'. The slide includes: The techniques should be; used for Good, instead of; the other side of the coin.; 42. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“The techniques should be”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 42 页的核心主题是什么？
**答：** 本页围绕“The techniques should be”展开。课件中的关键信息包括：The techniques should be；used for Good, instead of；the other side of the coin.；42。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 42?
**Answer:** This page presents 'The techniques should be'. The slide includes: The techniques should be; used for Good, instead of; the other side of the coin.; 42. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'The techniques should be'. The slide includes: The techniques should be; used for Good, instead of; the other side of the coin.; 42. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 43 页：Digital image

Source ID: `src-ba4d35fbe29d-pdf_page-00043`

![PDF page 43](../assets/pages/page_043.jpg)

### 原文 / Original Text

```text
Digital image

43
```

### 完整中文翻译

Digital image
43
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Digital image”展开。课件中的关键信息包括：Digital image；43。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Digital image'. The slide includes: Digital image; 43. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Digital image”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 43 页的核心主题是什么？
**答：** 本页围绕“Digital image”展开。课件中的关键信息包括：Digital image；43。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 43?
**Answer:** This page presents 'Digital image'. The slide includes: Digital image; 43. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Digital image'. The slide includes: Digital image; 43. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 44 页：问题：How digital image is formed？

Source ID: `src-ba4d35fbe29d-pdf_page-00044`

![PDF page 44](../assets/pages/page_044.jpg)

### 原文 / Original Text

```text
How digital image is formed?

44
```

### 完整中文翻译

问题：How digital image is formed？
44
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“How digital image is formed?”展开。课件中的关键信息包括：问题：How digital image is formed？；44。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; 44. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“How digital image is formed?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 44 页的核心主题是什么？
**答：** 本页围绕“How digital image is formed?”展开。课件中的关键信息包括：问题：How digital image is formed？；44。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 44?
**Answer:** This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; 44. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; 44. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 45 页：问题：How digital image is formed？

Source ID: `src-ba4d35fbe29d-pdf_page-00045`

![PDF page 45](../assets/pages/page_045.jpg)

### 原文 / Original Text

```text
How digital image is formed?

Kylberg, G. (2014). Automatic virus identification using TEM: Image segmentation and texture analysis (Doctoral dissertation, Acta Universitatis Upsaliensis).
Image Formation and Pinhole Model of the Camera

45
```

### 完整中文翻译

问题：How digital image is formed？
Kylberg, G. (2014). Automatic virus identification using TEM: Image 分割 and texture analysis (Doctoral dissertation, Acta Universitatis Upsaliensis).
图像形成 and Pinhole Model of the Camera
45
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“How digital image is formed?”展开。课件中的关键信息包括：问题：How digital image is formed？；Kylberg, G. (2014). Automatic virus identification using TEM: Image 分割 and texture analysis (Doctoral dissertation, Acta Universitatis Upsaliensis).；图像形成 and Pinhole Model of the Camera；45。复习时先抓住分割：为像素或区域分配类别/实例标签。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; Kylberg, G. (2014). Automatic virus identification using TEM: Image segmentation and texture analysis (Doctoral dissertation, Acta Universitatis Upsaliensis).; Image Formation and Pinhole Model of the Camera; 45. The revision focus is segmentation; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **segmentation / 分割**：为像素或区域分配类别/实例标签。

拓展复习：把“How digital image is formed?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 45 页的核心主题是什么？
**答：** 本页围绕“How digital image is formed?”展开。课件中的关键信息包括：问题：How digital image is formed？；Kylberg, G. (2014). Automatic virus identification using TEM: Image 分割 and texture analysis (Doctoral dissertation, Acta Universitatis Upsaliensis).；图像形成 and Pinhole Model of the Camera；45。复习时先抓住分割：为像素或区域分配类别/实例标签。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 45?
**Answer:** This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; Kylberg, G. (2014). Automatic virus identification using TEM: Image segmentation and texture analysis (Doctoral dissertation, Acta Universitatis Upsaliensis).; Image Formation and Pinhole Model of the Camera; 45. The revision focus is segmentation; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：分割 / segmentation
**答：** 为像素或区域分配类别/实例标签。
**Q2 English:** Explain the concept on this page: segmentation
**Answer:** The page focuses on segmentation. This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; Kylberg, G. (2014). Automatic virus identification using TEM: Image segmentation and texture analysis (Doctoral dissertation, Acta Universitatis Upsaliensis).; Image Formation and Pinhole Model of the Camera; 45. The revision focus is segmentation; connect its definition, evidence, and use to the examples on the page.

## 第 46 页：问题：How digital image is formed？

Source ID: `src-ba4d35fbe29d-pdf_page-00046`

![PDF page 46](../assets/pages/page_046.jpg)

### 原文 / Original Text

```text
How digital image is formed?

46
```

### 完整中文翻译

问题：How digital image is formed？
46
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“How digital image is formed?”展开。课件中的关键信息包括：问题：How digital image is formed？；46。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; 46. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“How digital image is formed?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 46 页的核心主题是什么？
**答：** 本页围绕“How digital image is formed?”展开。课件中的关键信息包括：问题：How digital image is formed？；46。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 46?
**Answer:** This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; 46. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; 46. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 47 页：问题：How digital image is formed？

Source ID: `src-ba4d35fbe29d-pdf_page-00047`

![PDF page 47](../assets/pages/page_047.jpg)

### 原文 / Original Text

```text
How digital image is formed?

Dimension

0-D

1-D

2-dimensional function

Pixel value = f(x, y)

2-D

n-D …

3-D

47
```

### 完整中文翻译

问题：How digital image is formed？
Dimension
0-D
1-D
2-dimensional function
Pixel value = f(x, y)
2-D
n-D …
3-D
47
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“How digital image is formed?”展开。课件中的关键信息包括：问题：How digital image is formed？；Dimension；0-D；1-D。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; Dimension; 0-D; 1-D. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“How digital image is formed?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 47 页的核心主题是什么？
**答：** 本页围绕“How digital image is formed?”展开。课件中的关键信息包括：问题：How digital image is formed？；Dimension；0-D；1-D。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 47?
**Answer:** This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; Dimension; 0-D; 1-D. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; Dimension; 0-D; 1-D. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 48 页：问题：How digital image is formed？

Source ID: `src-ba4d35fbe29d-pdf_page-00048`

![PDF page 48](../assets/pages/page_048.jpg)

### 原文 / Original Text

```text
How digital image is formed?

Grayscale image

Colour image

f(x, y)

f(x, y, c)

f(R, G, B)

48

https://en.wikipedia.org/wiki/Grayscale; https://en.wikipedia.org/wiki/RGB_color_spaces
```

### 完整中文翻译

问题：How digital image is formed？
Grayscale image
Colour image
f(x, y)
f(x, y, c)
f(R, G, B)
48
参考链接：https://en.wikipedia.org/wiki/Grayscale; https://en.wikipedia.org/wiki/RGB_color_spaces
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“How digital image is formed?”展开。课件中的关键信息包括：问题：How digital image is formed？；Grayscale image；Colour image；f(x, y)。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; Grayscale image; Colour image; f(x, y). The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“How digital image is formed?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 48 页的核心主题是什么？
**答：** 本页围绕“How digital image is formed?”展开。课件中的关键信息包括：问题：How digital image is formed？；Grayscale image；Colour image；f(x, y)。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 48?
**Answer:** This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; Grayscale image; Colour image; f(x, y). The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; Grayscale image; Colour image; f(x, y). The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 49 页：问题：How digital image is formed？

Source ID: `src-ba4d35fbe29d-pdf_page-00049`

![PDF page 49](../assets/pages/page_049.jpg)

### 原文 / Original Text

```text
How digital image is formed?

Colour space

49
```

### 完整中文翻译

问题：How digital image is formed？
Colour space
49
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“How digital image is formed?”展开。课件中的关键信息包括：问题：How digital image is formed？；Colour space；49。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; Colour space; 49. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“How digital image is formed?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 49 页的核心主题是什么？
**答：** 本页围绕“How digital image is formed?”展开。课件中的关键信息包括：问题：How digital image is formed？；Colour space；49。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 49?
**Answer:** This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; Colour space; 49. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'How digital image is formed?'. The slide includes: How digital image is formed?; Colour space; 49. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 50 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00050`

![PDF page 50](../assets/pages/page_050.jpg)

### 原文 / Original Text

```text
Image processing

50

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.
```

### 完整中文翻译

图像处理
50
Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；50；Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; 50; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 50 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；50；Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 50?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; 50; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Image processing'. The slide includes: Image processing; 50; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 51 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00051`

![PDF page 51](../assets/pages/page_051.jpg)

### 原文 / Original Text

```text
Image processing

Colour histogram

Image filtering

Transformations

Low-level tasks

□

□

□

□

□

□

Denoising

Super-resolution

De-blurring

Image matting

Inpainting

Etc.

51

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.
```

### 完整中文翻译

图像处理
Colour histogram
图像滤波
Transformations
Low-level tasks
□
□
□
□
□
□
去噪
超分辨率
De-blurring
Image matting
图像修复
Etc.
51
Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Colour histogram；图像滤波；Transformations。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Colour histogram; Image filtering; Transformations. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
- **denoising / 图像去噪**：从含噪观测中恢复潜在干净图像，是典型低层视觉问题。
- **super-resolution / 超分辨率**：从低分辨率图像恢复更高分辨率细节。
- **inpainting / 图像修复**：补全图像中缺失或被遮挡的区域。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 51 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Colour histogram；图像滤波；Transformations。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 51?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Colour histogram; Image filtering; Transformations. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Image processing'. The slide includes: Image processing; Colour histogram; Image filtering; Transformations. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 52 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00052`

![PDF page 52](../assets/pages/page_052.jpg)

### 原文 / Original Text

```text
Image processing

Colour histogram analysis and equalisation

52

https://sg.canon/en/support/8200330600
```

### 完整中文翻译

图像处理
Colour histogram analysis and equalisation
52
参考链接：https://sg.canon/en/support/8200330600
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Colour histogram analysis and equalisation；52；参考链接：https://sg.canon/en/support/8200330600。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Colour histogram analysis and equalisation; 52; https://sg.canon/en/support/8200330600. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 52 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Colour histogram analysis and equalisation；52；参考链接：https://sg.canon/en/support/8200330600。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 52?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Colour histogram analysis and equalisation; 52; https://sg.canon/en/support/8200330600. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Image processing'. The slide includes: Image processing; Colour histogram analysis and equalisation; 52; https://sg.canon/en/support/8200330600. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 53 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00053`

![PDF page 53](../assets/pages/page_053.jpg)

### 原文 / Original Text

```text
Image processing

Colour histogram analysis and equalisation

53

https://www.pixelmator.com/support/guide/pixelmator-pro/689/
```

### 完整中文翻译

图像处理
Colour histogram analysis and equalisation
53
参考链接：https://www.pixelmator.com/support/guide/pixelmator-pro/689/
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Colour histogram analysis and equalisation；53；参考链接：https://www.pixelmator.com/support/guide/pixelmator-pro/689/。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Colour histogram analysis and equalisation; 53; https://www.pixelmator.com/support/guide/pixelmator-pro/689/. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 53 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Colour histogram analysis and equalisation；53；参考链接：https://www.pixelmator.com/support/guide/pixelmator-pro/689/。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 53?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Colour histogram analysis and equalisation; 53; https://www.pixelmator.com/support/guide/pixelmator-pro/689/. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Image processing'. The slide includes: Image processing; Colour histogram analysis and equalisation; 53; https://www.pixelmator.com/support/guide/pixelmator-pro/689/. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 54 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00054`

![PDF page 54](../assets/pages/page_054.jpg)

### 原文 / Original Text

```text
Image processing

Colour histogram analysis and equalisation

54

https://www.pixelmator.com/support/guide/pixelmator-pro/689/
```

### 完整中文翻译

图像处理
Colour histogram analysis and equalisation
54
参考链接：https://www.pixelmator.com/support/guide/pixelmator-pro/689/
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Colour histogram analysis and equalisation；54；参考链接：https://www.pixelmator.com/support/guide/pixelmator-pro/689/。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Colour histogram analysis and equalisation; 54; https://www.pixelmator.com/support/guide/pixelmator-pro/689/. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 54 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Colour histogram analysis and equalisation；54；参考链接：https://www.pixelmator.com/support/guide/pixelmator-pro/689/。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 54?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Colour histogram analysis and equalisation; 54; https://www.pixelmator.com/support/guide/pixelmator-pro/689/. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Image processing'. The slide includes: Image processing; Colour histogram analysis and equalisation; 54; https://www.pixelmator.com/support/guide/pixelmator-pro/689/. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 55 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00055`

![PDF page 55](../assets/pages/page_055.jpg)

### 原文 / Original Text

```text
Image processing

Colour histogram analysis and equalisation

55

https://mathr.co.uk/blog/2010-12-15_histogram_equalization.html
```

### 完整中文翻译

图像处理
Colour histogram analysis and equalisation
55
参考链接：https://mathr.co.uk/blog/2010-12-15_histogram_equalization.html
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Colour histogram analysis and equalisation；55；参考链接：https://mathr.co.uk/blog/2010-12-15_histogram_equalization.html。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Colour histogram analysis and equalisation; 55; https://mathr.co.uk/blog/2010-12-15_histogram_equalization.html. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 55 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Colour histogram analysis and equalisation；55；参考链接：https://mathr.co.uk/blog/2010-12-15_histogram_equalization.html。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 55?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Colour histogram analysis and equalisation; 55; https://mathr.co.uk/blog/2010-12-15_histogram_equalization.html. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Image processing'. The slide includes: Image processing; Colour histogram analysis and equalisation; 55; https://mathr.co.uk/blog/2010-12-15_histogram_equalization.html. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 56 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00056`

![PDF page 56](../assets/pages/page_056.jpg)

### 原文 / Original Text

```text
Image processing

Image filtering

56

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.
```

### 完整中文翻译

图像处理
图像滤波
56
Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；图像滤波；56；Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Image filtering; 56; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 56 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；图像滤波；56；Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 56?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Image filtering; 56; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Image processing'. The slide includes: Image processing; Image filtering; 56; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 57 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00057`

![PDF page 57](../assets/pages/page_057.jpg)

### 原文 / Original Text

```text
Image processing

Transformations – Geometric transform

He, K., Sun, J., & Tang, X. (2012). Guided image filtering. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.

57
```

### 完整中文翻译

图像处理
Transformations – Geometric transform
He, K., Sun, J., & Tang, X. (2012). Guided 图像滤波. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.
57
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Transformations – Geometric transform；He, K., Sun, J., & Tang, X. (2012). Guided 图像滤波. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.；57。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Transformations – Geometric transform; He, K., Sun, J., & Tang, X. (2012). Guided image filtering. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.; 57. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 57 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Transformations – Geometric transform；He, K., Sun, J., & Tang, X. (2012). Guided 图像滤波. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.；57。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 57?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Transformations – Geometric transform; He, K., Sun, J., & Tang, X. (2012). Guided image filtering. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.; 57. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Image processing'. The slide includes: Image processing; Transformations – Geometric transform; He, K., Sun, J., & Tang, X. (2012). Guided image filtering. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.; 57. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 58 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00058`

![PDF page 58](../assets/pages/page_058.jpg)

### 原文 / Original Text

```text
Image processing

Transformations – Geometric transform

He, K., Sun, J., & Tang, X. (2012). Guided image filtering. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.

58
```

### 完整中文翻译

图像处理
Transformations – Geometric transform
He, K., Sun, J., & Tang, X. (2012). Guided 图像滤波. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.
58
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Transformations – Geometric transform；He, K., Sun, J., & Tang, X. (2012). Guided 图像滤波. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.；58。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Transformations – Geometric transform; He, K., Sun, J., & Tang, X. (2012). Guided image filtering. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.; 58. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 58 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Transformations – Geometric transform；He, K., Sun, J., & Tang, X. (2012). Guided 图像滤波. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.；58。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 58?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Transformations – Geometric transform; He, K., Sun, J., & Tang, X. (2012). Guided image filtering. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.; 58. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Image processing'. The slide includes: Image processing; Transformations – Geometric transform; He, K., Sun, J., & Tang, X. (2012). Guided image filtering. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.; 58. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 59 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00059`

![PDF page 59](../assets/pages/page_059.jpg)

### 原文 / Original Text

```text
Image processing
Low-level tasks – image denoising

Mara, M., McGuire, M., Bitterli, B., & Jarosz, W. (2017). An efficient denoising algorithm for global illumination. High Performance Graphics, 10, 3105762-3105774.

59
```

### 完整中文翻译

图像处理
Low-level tasks – image 去噪
Mara, M., McGuire, M., Bitterli, B., & Jarosz, W. (2017). An efficient 去噪 algorithm for global illumination. High Performance Graphics, 10, 3105762-3105774.
59
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image 去噪；Mara, M., McGuire, M., Bitterli, B., & Jarosz, W. (2017). An efficient 去噪 algorithm for global illumination. High Performance Graphics, 10, 3105762-3105774.；59。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image denoising; Mara, M., McGuire, M., Bitterli, B., & Jarosz, W. (2017). An efficient denoising algorithm for global illumination. High Performance Graphics, 10, 3105762-3105774.; 59. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **MAR / 随机缺失**：缺失与其他可观测变量有关，但不直接由缺失值本身决定。
- **denoising / 图像去噪**：从含噪观测中恢复潜在干净图像，是典型低层视觉问题。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 59 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image 去噪；Mara, M., McGuire, M., Bitterli, B., & Jarosz, W. (2017). An efficient 去噪 algorithm for global illumination. High Performance Graphics, 10, 3105762-3105774.；59。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 59?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image denoising; Mara, M., McGuire, M., Bitterli, B., & Jarosz, W. (2017). An efficient denoising algorithm for global illumination. High Performance Graphics, 10, 3105762-3105774.; 59. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：随机缺失 / MAR
**答：** 缺失与其他可观测变量有关，但不直接由缺失值本身决定。
**Q2 English:** Explain the concept on this page: MAR
**Answer:** The page focuses on MAR. This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image denoising; Mara, M., McGuire, M., Bitterli, B., & Jarosz, W. (2017). An efficient denoising algorithm for global illumination. High Performance Graphics, 10, 3105762-3105774.; 59. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

## 第 60 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00060`

![PDF page 60](../assets/pages/page_060.jpg)

### 原文 / Original Text

```text
Image processing
Low-level tasks – image denoising

Image denoising is the process of removing noise from images

𝐼’ = 𝐼! + 𝑛

Observation, i.e. 
noisy image

noise

Latent clean image

ill-posed

60
```

### 完整中文翻译

图像处理
Low-level tasks – image 去噪
Image 去噪 is the process of removing noise from images
𝐼’ = 𝐼! + 𝑛
Observation, i.e.
noisy image
noise
Latent clean image
ill-posed
60
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image 去噪；Image 去噪 is the process of removing noise from images；𝐼’ = 𝐼! + 𝑛。复习时先抓住图像去噪：从含噪观测中恢复潜在干净图像，是典型低层视觉问题。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image denoising; Image denoising is the process of removing noise from images; 𝐼’ = 𝐼! + 𝑛. The revision focus is denoising; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **denoising / 图像去噪**：从含噪观测中恢复潜在干净图像，是典型低层视觉问题。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 60 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image 去噪；Image 去噪 is the process of removing noise from images；𝐼’ = 𝐼! + 𝑛。复习时先抓住图像去噪：从含噪观测中恢复潜在干净图像，是典型低层视觉问题。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 60?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image denoising; Image denoising is the process of removing noise from images; 𝐼’ = 𝐼! + 𝑛. The revision focus is denoising; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：图像去噪 / denoising
**答：** 从含噪观测中恢复潜在干净图像，是典型低层视觉问题。
**Q2 English:** Explain the concept on this page: denoising
**Answer:** The page focuses on denoising. This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image denoising; Image denoising is the process of removing noise from images; 𝐼’ = 𝐼! + 𝑛. The revision focus is denoising; connect its definition, evidence, and use to the examples on the page.

## 第 61 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00061`

![PDF page 61](../assets/pages/page_061.jpg)

### 原文 / Original Text

```text
Image processing

Low-level tasks – image super-resolution (SR)

He, K., Sun, J., & Tang, X. (2012). Guided image filtering. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.

61
```

### 完整中文翻译

图像处理
Low-level tasks – image 超分辨率 (SR)
He, K., Sun, J., & Tang, X. (2012). Guided 图像滤波. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.
61
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image 超分辨率 (SR)；He, K., Sun, J., & Tang, X. (2012). Guided 图像滤波. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.；61。复习时先抓住超分辨率：从低分辨率图像恢复更高分辨率细节。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image super-resolution (SR); He, K., Sun, J., & Tang, X. (2012). Guided image filtering. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.; 61. The revision focus is super-resolution; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **super-resolution / 超分辨率**：从低分辨率图像恢复更高分辨率细节。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 61 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image 超分辨率 (SR)；He, K., Sun, J., & Tang, X. (2012). Guided 图像滤波. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.；61。复习时先抓住超分辨率：从低分辨率图像恢复更高分辨率细节。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 61?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image super-resolution (SR); He, K., Sun, J., & Tang, X. (2012). Guided image filtering. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.; 61. The revision focus is super-resolution; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：超分辨率 / super-resolution
**答：** 从低分辨率图像恢复更高分辨率细节。
**Q2 English:** Explain the concept on this page: super-resolution
**Answer:** The page focuses on super-resolution. This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image super-resolution (SR); He, K., Sun, J., & Tang, X. (2012). Guided image filtering. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.; 61. The revision focus is super-resolution; connect its definition, evidence, and use to the examples on the page.

## 第 62 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00062`

![PDF page 62](../assets/pages/page_062.jpg)

### 原文 / Original Text

```text
Image processing

Low-level tasks – image super-resolution (SR)

Lai, Wei-Sheng, et al. "Fast and accurate image super-resolution with deep laplacian pyramid networks." IEEE transactions on pattern analysis and machine intelligence 41.11 (2018): 2599-2613.

62
```

### 完整中文翻译

图像处理
Low-level tasks – image 超分辨率 (SR)
Lai, Wei-Sheng, et al. "Fast and accurate image 超分辨率 with deep laplacian pyramid networks." IEEE transactions on pattern analysis and machine intelligence 41.11 (2018): 2599-2613.
62
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image 超分辨率 (SR)；Lai, Wei-Sheng, et al. "Fast and accurate image 超分辨率 with deep laplacian pyramid networks." IEEE transactions on pattern analysis and machine intelligence 41.11 (2018): 2599-2613.；62。复习时先抓住超分辨率：从低分辨率图像恢复更高分辨率细节。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image super-resolution (SR); Lai, Wei-Sheng, et al. "Fast and accurate image super-resolution with deep laplacian pyramid networks." IEEE transactions on pattern analysis and machine intelligence 41.11 (2018): 2599-2613.; 62. The revision focus is super-resolution; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **super-resolution / 超分辨率**：从低分辨率图像恢复更高分辨率细节。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 62 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image 超分辨率 (SR)；Lai, Wei-Sheng, et al. "Fast and accurate image 超分辨率 with deep laplacian pyramid networks." IEEE transactions on pattern analysis and machine intelligence 41.11 (2018): 2599-2613.；62。复习时先抓住超分辨率：从低分辨率图像恢复更高分辨率细节。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 62?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image super-resolution (SR); Lai, Wei-Sheng, et al. "Fast and accurate image super-resolution with deep laplacian pyramid networks." IEEE transactions on pattern analysis and machine intelligence 41.11 (2018): 2599-2613.; 62. The revision focus is super-resolution; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：超分辨率 / super-resolution
**答：** 从低分辨率图像恢复更高分辨率细节。
**Q2 English:** Explain the concept on this page: super-resolution
**Answer:** The page focuses on super-resolution. This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image super-resolution (SR); Lai, Wei-Sheng, et al. "Fast and accurate image super-resolution with deep laplacian pyramid networks." IEEE transactions on pattern analysis and machine intelligence 41.11 (2018): 2599-2613.; 62. The revision focus is super-resolution; connect its definition, evidence, and use to the examples on the page.

## 第 63 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00063`

![PDF page 63](../assets/pages/page_063.jpg)

### 原文 / Original Text

```text
Image processing

Low-level tasks – image super-resolution (SR)

Grant-Jacob, James A., et al. "A neural lens for super-resolution biological imaging." Journal of Physics Communications 3.6 (2019): 065004.

63
```

### 完整中文翻译

图像处理
Low-level tasks – image 超分辨率 (SR)
Grant-Jacob, James A., et al. "A neural lens for 超分辨率 biological imaging." Journal of Physics Communications 3.6 (2019): 065004.
63
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image 超分辨率 (SR)；Grant-Jacob, James A., et al. "A neural lens for 超分辨率 biological imaging." Journal of Physics Communications 3.6 (2019): 065004.；63。复习时先抓住超分辨率：从低分辨率图像恢复更高分辨率细节。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image super-resolution (SR); Grant-Jacob, James A., et al. "A neural lens for super-resolution biological imaging." Journal of Physics Communications 3.6 (2019): 065004.; 63. The revision focus is super-resolution; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **super-resolution / 超分辨率**：从低分辨率图像恢复更高分辨率细节。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 63 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image 超分辨率 (SR)；Grant-Jacob, James A., et al. "A neural lens for 超分辨率 biological imaging." Journal of Physics Communications 3.6 (2019): 065004.；63。复习时先抓住超分辨率：从低分辨率图像恢复更高分辨率细节。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 63?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image super-resolution (SR); Grant-Jacob, James A., et al. "A neural lens for super-resolution biological imaging." Journal of Physics Communications 3.6 (2019): 065004.; 63. The revision focus is super-resolution; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：超分辨率 / super-resolution
**答：** 从低分辨率图像恢复更高分辨率细节。
**Q2 English:** Explain the concept on this page: super-resolution
**Answer:** The page focuses on super-resolution. This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image super-resolution (SR); Grant-Jacob, James A., et al. "A neural lens for super-resolution biological imaging." Journal of Physics Communications 3.6 (2019): 065004.; 63. The revision focus is super-resolution; connect its definition, evidence, and use to the examples on the page.

## 第 64 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00064`

![PDF page 64](../assets/pages/page_064.jpg)

### 原文 / Original Text

```text
Image processing
Low-level tasks – image de-blur

• Shaky camera

• Wrong focus

• Etc.

64

https://knowtechie.com/deblur-photos-online-ease/
```

### 完整中文翻译

图像处理
Low-level tasks – image de-blur
• Shaky camera
• Wrong focus
• Etc.
64
参考链接：https://knowtechie.com/deblur-photos-online-ease/
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image de-blur；• Shaky camera；• Wrong focus。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image de-blur; • Shaky camera; • Wrong focus. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 64 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image de-blur；• Shaky camera；• Wrong focus。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 64?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image de-blur; • Shaky camera; • Wrong focus. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image de-blur; • Shaky camera; • Wrong focus. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 65 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00065`

![PDF page 65](../assets/pages/page_065.jpg)

### 原文 / Original Text

```text
Image processing
Low-level tasks – image matting

https://www.befunky.com/learn/automatic-background-remover/; https://www.youtube.com/watch?v=rUo0wuVyefU

65
```

### 完整中文翻译

图像处理
Low-level tasks – image matting
参考链接：https://www.befunky.com/learn/automatic-background-remover/; https://www.youtube.com/watch?v=rUo0wuVyefU
65
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image matting；参考链接：https://www.befunky.com/learn/automatic-background-remover/; https://www.youtube.com/watch?v=rUo0wuVyefU；65。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image matting; https://www.befunky.com/learn/automatic-background-remover/; https://www.youtube.com/watch?v=rUo0wuVyefU; 65. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 65 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image matting；参考链接：https://www.befunky.com/learn/automatic-background-remover/; https://www.youtube.com/watch?v=rUo0wuVyefU；65。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 65?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image matting; https://www.befunky.com/learn/automatic-background-remover/; https://www.youtube.com/watch?v=rUo0wuVyefU; 65. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image matting; https://www.befunky.com/learn/automatic-background-remover/; https://www.youtube.com/watch?v=rUo0wuVyefU; 65. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 66 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00066`

![PDF page 66](../assets/pages/page_066.jpg)

### 原文 / Original Text

```text
Image processing
Low-level tasks – image matting

https://www.befunky.com/learn/automatic-background-remover/; https://www.youtube.com/watch?v=rUo0wuVyefU

66
```

### 完整中文翻译

图像处理
Low-level tasks – image matting
参考链接：https://www.befunky.com/learn/automatic-background-remover/; https://www.youtube.com/watch?v=rUo0wuVyefU
66
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image matting；参考链接：https://www.befunky.com/learn/automatic-background-remover/; https://www.youtube.com/watch?v=rUo0wuVyefU；66。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image matting; https://www.befunky.com/learn/automatic-background-remover/; https://www.youtube.com/watch?v=rUo0wuVyefU; 66. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 66 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image matting；参考链接：https://www.befunky.com/learn/automatic-background-remover/; https://www.youtube.com/watch?v=rUo0wuVyefU；66。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 66?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image matting; https://www.befunky.com/learn/automatic-background-remover/; https://www.youtube.com/watch?v=rUo0wuVyefU; 66. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image matting; https://www.befunky.com/learn/automatic-background-remover/; https://www.youtube.com/watch?v=rUo0wuVyefU; 66. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 67 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00067`

![PDF page 67](../assets/pages/page_067.jpg)

### 原文 / Original Text

```text
Image processing
Low-level tasks – image inpainting

Liu, Guilin, et al. "Image inpainting for irregular holes using partial convolutions." Proceedings of the European conference on computer vision (ECCV). 2018.

67
```

### 完整中文翻译

图像处理
Low-level tasks – image 图像修复
Liu, Guilin, et al. "Image 图像修复 for irregular holes using partial convolutions." Proceedings of the European conference on 计算机视觉 (ECCV). 2018.
67
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image 图像修复；Liu, Guilin, et al. "Image 图像修复 for irregular holes using partial convolutions." Proceedings of the European conference on 计算机视觉 (ECCV). 2018.；67。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image inpainting; Liu, Guilin, et al. "Image inpainting for irregular holes using partial convolutions." Proceedings of the European conference on computer vision (ECCV). 2018.; 67. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
- **inpainting / 图像修复**：补全图像中缺失或被遮挡的区域。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 67 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image 图像修复；Liu, Guilin, et al. "Image 图像修复 for irregular holes using partial convolutions." Proceedings of the European conference on 计算机视觉 (ECCV). 2018.；67。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 67?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image inpainting; Liu, Guilin, et al. "Image inpainting for irregular holes using partial convolutions." Proceedings of the European conference on computer vision (ECCV). 2018.; 67. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image inpainting; Liu, Guilin, et al. "Image inpainting for irregular holes using partial convolutions." Proceedings of the European conference on computer vision (ECCV). 2018.; 67. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 68 页：图像处理

Source ID: `src-ba4d35fbe29d-pdf_page-00068`

![PDF page 68](../assets/pages/page_068.jpg)

### 原文 / Original Text

```text
Image processing
Low-level tasks – image inpainting

Huang, Jia-Bin, et al. "Temporally coherent completion of dynamic video." ACM Transactions on Graphics (TOG) 35.6 (2016): 1-11.

68
```

### 完整中文翻译

图像处理
Low-level tasks – image 图像修复
Huang, Jia-Bin, et al. "Temporally coherent completion of dynamic video." ACM Transactions on Graphics (TOG) 35.6 (2016): 1-11.
68
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image 图像修复；Huang, Jia-Bin, et al. "Temporally coherent completion of dynamic video." ACM Transactions on Graphics (TOG) 35.6 (2016): 1-11.；68。复习时先抓住图像修复：补全图像中缺失或被遮挡的区域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image inpainting; Huang, Jia-Bin, et al. "Temporally coherent completion of dynamic video." ACM Transactions on Graphics (TOG) 35.6 (2016): 1-11.; 68. The revision focus is inpainting; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **inpainting / 图像修复**：补全图像中缺失或被遮挡的区域。

拓展复习：把“Image processing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 68 页的核心主题是什么？
**答：** 本页围绕“Image processing”展开。课件中的关键信息包括：图像处理；Low-level tasks – image 图像修复；Huang, Jia-Bin, et al. "Temporally coherent completion of dynamic video." ACM Transactions on Graphics (TOG) 35.6 (2016): 1-11.；68。复习时先抓住图像修复：补全图像中缺失或被遮挡的区域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 68?
**Answer:** This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image inpainting; Huang, Jia-Bin, et al. "Temporally coherent completion of dynamic video." ACM Transactions on Graphics (TOG) 35.6 (2016): 1-11.; 68. The revision focus is inpainting; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：图像修复 / inpainting
**答：** 补全图像中缺失或被遮挡的区域。
**Q2 English:** Explain the concept on this page: inpainting
**Answer:** The page focuses on inpainting. This page presents 'Image processing'. The slide includes: Image processing; Low-level tasks – image inpainting; Huang, Jia-Bin, et al. "Temporally coherent completion of dynamic video." ACM Transactions on Graphics (TOG) 35.6 (2016): 1-11.; 68. The revision focus is inpainting; connect its definition, evidence, and use to the examples on the page.

## 第 69 页：机器学习?

Source ID: `src-ba4d35fbe29d-pdf_page-00069`

![PDF page 69](../assets/pages/page_069.jpg)

### 原文 / Original Text

```text
Machine Learning?

Deep Learning?

What?

How?

69

https://xkcd.com/1838
```

### 完整中文翻译

机器学习?
深度学习?
问题：What？
问题：How？
69
参考链接：https://xkcd.com/1838
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine Learning?”展开。课件中的关键信息包括：机器学习?；深度学习?；问题：What？；问题：How？。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine Learning?'. The slide includes: Machine Learning?; Deep Learning?; What?; How?. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“Machine Learning?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 69 页的核心主题是什么？
**答：** 本页围绕“Machine Learning?”展开。课件中的关键信息包括：机器学习?；深度学习?；问题：What？；问题：How？。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 69?
**Answer:** This page presents 'Machine Learning?'. The slide includes: Machine Learning?; Deep Learning?; What?; How?. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：深度学习 / deep learning
**答：** 用多层神经网络从数据中学习表示和映射，现代视觉任务常用。
**Q2 English:** Explain the concept on this page: deep learning
**Answer:** The page focuses on deep learning. This page presents 'Machine Learning?'. The slide includes: Machine Learning?; Deep Learning?; What?; How?. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

## 第 70 页：机器学习

Source ID: `src-ba4d35fbe29d-pdf_page-00070`

![PDF page 70](../assets/pages/page_070.jpg)

### 原文 / Original Text

```text
Machine learning

70

https://youtu.be/PeMlggyqz0Y
```

### 完整中文翻译

机器学习
70
参考链接：https://youtu.be/PeMlggyqz0Y
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning”展开。课件中的关键信息包括：机器学习；70；参考链接：https://youtu.be/PeMlggyqz0Y。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning'. The slide includes: Machine learning; 70; https://youtu.be/PeMlggyqz0Y. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 70 页的核心主题是什么？
**答：** 本页围绕“Machine learning”展开。课件中的关键信息包括：机器学习；70；参考链接：https://youtu.be/PeMlggyqz0Y。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 70?
**Answer:** This page presents 'Machine learning'. The slide includes: Machine learning; 70; https://youtu.be/PeMlggyqz0Y. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning'. The slide includes: Machine learning; 70; https://youtu.be/PeMlggyqz0Y. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 71 页：机器学习 – categories

Source ID: `src-ba4d35fbe29d-pdf_page-00071`

![PDF page 71](../assets/pages/page_071.jpg)

### 原文 / Original Text

```text
Machine learning – categories

Supervised learning

Ø Labeled data

Ø Predict outcome/future

Classification
predict categorical 
class labels
e.g. the handwritten 
digit (multi-class)

Regression
Prediction of continuous 
outcomes
e.g. students’ grade scores

71
```

### 完整中文翻译

机器学习 – categories
监督学习
Ø Labeled data
Ø Predict outcome/future
分类
predict categorical
class labels
e.g. the handwritten
digit (multi-class)
回归
Prediction of continuous
outcomes
e.g. students’ grade scores
71
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – categories”展开。课件中的关键信息包括：机器学习 – categories；监督学习；Ø Labeled data；Ø Predict outcome/future。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – categories'. The slide includes: Machine learning – categories; Supervised learning; Ø Labeled data; Ø Predict outcome/future. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。

拓展复习：把“Machine learning – categories”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 71 页的核心主题是什么？
**答：** 本页围绕“Machine learning – categories”展开。课件中的关键信息包括：机器学习 – categories；监督学习；Ø Labeled data；Ø Predict outcome/future。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 71?
**Answer:** This page presents 'Machine learning – categories'. The slide includes: Machine learning – categories; Supervised learning; Ø Labeled data; Ø Predict outcome/future. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：分类 / classification
**答：** 预测离散类别标签，例如图像类别或手写数字。
**Q2 English:** Explain the concept on this page: classification
**Answer:** The page focuses on classification. This page presents 'Machine learning – categories'. The slide includes: Machine learning – categories; Supervised learning; Ø Labeled data; Ø Predict outcome/future. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

## 第 72 页：机器学习 – categories

Source ID: `src-ba4d35fbe29d-pdf_page-00072`

![PDF page 72](../assets/pages/page_072.jpg)

### 原文 / Original Text

```text
Machine learning – categories

Unsupervised learning

Ø No labels/targets

Ø Find hidden structure/insights in data

Dimensionality Reduction
reduce data sparsity
-
reduce computational cost
-

Clustering
Objectives within a cluster 
share a degree of similarity. 
e.g. product recommendation

72
```

### 完整中文翻译

机器学习 – categories
无监督学习
Ø No labels/targets
Ø Find hidden structure/insights in data
Dimensionality Reduction
reduce data sparsity
-
reduce computational cost
-
聚类
Objectives within a cluster
share a degree of similarity.
e.g. product recommendation
72
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – categories”展开。课件中的关键信息包括：机器学习 – categories；无监督学习；Ø No labels/targets；Ø Find hidden structure/insights in data。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – categories'. The slide includes: Machine learning – categories; Unsupervised learning; Ø No labels/targets; Ø Find hidden structure/insights in data. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – categories”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 72 页的核心主题是什么？
**答：** 本页围绕“Machine learning – categories”展开。课件中的关键信息包括：机器学习 – categories；无监督学习；Ø No labels/targets；Ø Find hidden structure/insights in data。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 72?
**Answer:** This page presents 'Machine learning – categories'. The slide includes: Machine learning – categories; Unsupervised learning; Ø No labels/targets; Ø Find hidden structure/insights in data. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – categories'. The slide includes: Machine learning – categories; Unsupervised learning; Ø No labels/targets; Ø Find hidden structure/insights in data. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 73 页：机器学习 – categories

Source ID: `src-ba4d35fbe29d-pdf_page-00073`

![PDF page 73](../assets/pages/page_073.jpg)

### 原文 / Original Text

```text
Machine learning – categories

Reinforcement learning

Ø Decision process

Ø Reward system

Ø Learn series of actions

Ø Applications: chess, video games, some robots, self-driving cars

73
```

### 完整中文翻译

机器学习 – categories
强化学习
Ø Decision process
Ø Reward system
Ø Learn series of actions
Ø Applications: chess, video games, some robots, self-driving cars
73
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – categories”展开。课件中的关键信息包括：机器学习 – categories；强化学习；Ø Decision process；Ø Reward system。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – categories'. The slide includes: Machine learning – categories; Reinforcement learning; Ø Decision process; Ø Reward system. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – categories”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 73 页的核心主题是什么？
**答：** 本页围绕“Machine learning – categories”展开。课件中的关键信息包括：机器学习 – categories；强化学习；Ø Decision process；Ø Reward system。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 73?
**Answer:** This page presents 'Machine learning – categories'. The slide includes: Machine learning – categories; Reinforcement learning; Ø Decision process; Ø Reward system. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – categories'. The slide includes: Machine learning – categories; Reinforcement learning; Ø Decision process; Ø Reward system. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 74 页：机器学习 – categories

Source ID: `src-ba4d35fbe29d-pdf_page-00074`

![PDF page 74](../assets/pages/page_074.jpg)

### 原文 / Original Text

```text
Machine learning – categories

Supervised learning

Unsupervised learning

Reinforcement learning

74
```

### 完整中文翻译

机器学习 – categories
监督学习
无监督学习
强化学习
74
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – categories”展开。课件中的关键信息包括：机器学习 – categories；监督学习；无监督学习；强化学习。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – categories'. The slide includes: Machine learning – categories; Supervised learning; Unsupervised learning; Reinforcement learning. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – categories”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 74 页的核心主题是什么？
**答：** 本页围绕“Machine learning – categories”展开。课件中的关键信息包括：机器学习 – categories；监督学习；无监督学习；强化学习。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 74?
**Answer:** This page presents 'Machine learning – categories'. The slide includes: Machine learning – categories; Supervised learning; Unsupervised learning; Reinforcement learning. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – categories'. The slide includes: Machine learning – categories; Supervised learning; Unsupervised learning; Reinforcement learning. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 75 页：机器学习 – 监督学习

Source ID: `src-ba4d35fbe29d-pdf_page-00075`

![PDF page 75](../assets/pages/page_075.jpg)

### 原文 / Original Text

```text
Machine learning – supervised learning

Classification
predict categorical class labels

e.g. the handwritten digit (multi-
class)

75
```

### 完整中文翻译

机器学习 – 监督学习
分类
predict categorical class labels
e.g. the handwritten digit (multi-
class)
75
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；分类；predict categorical class labels；e.g. the handwritten digit (multi-。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; Classification; predict categorical class labels; e.g. the handwritten digit (multi-. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。

拓展复习：把“Machine learning – supervised learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 75 页的核心主题是什么？
**答：** 本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；分类；predict categorical class labels；e.g. the handwritten digit (multi-。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 75?
**Answer:** This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; Classification; predict categorical class labels; e.g. the handwritten digit (multi-. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：分类 / classification
**答：** 预测离散类别标签，例如图像类别或手写数字。
**Q2 English:** Explain the concept on this page: classification
**Answer:** The page focuses on classification. This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; Classification; predict categorical class labels; e.g. the handwritten digit (multi-. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

## 第 76 页：机器学习 – 监督学习

Source ID: `src-ba4d35fbe29d-pdf_page-00076`

![PDF page 76](../assets/pages/page_076.jpg)

### 原文 / Original Text

```text
Machine learning – supervised learning

https://medium.com/analytics-vidhya/logistic-regression-from-scratch-multi-classification-with-onevsall-d5c2acf0c37c

76
```

### 完整中文翻译

机器学习 – 监督学习
参考链接：https://medium.com/analytics-vidhya/logistic-regression-from-scratch-multi-classification-with-onevsall-d5c2acf0c37c
76
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；参考链接：https://medium.com/analytics-vidhya/logistic-regression-from-scratch-multi-classification-with-onevsall-d5c2acf0c37c；76。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; https://medium.com/analytics-vidhya/logistic-regression-from-scratch-multi-classification-with-onevsall-d5c2acf0c37c; 76. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。

拓展复习：把“Machine learning – supervised learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 76 页的核心主题是什么？
**答：** 本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；参考链接：https://medium.com/analytics-vidhya/logistic-regression-from-scratch-multi-classification-with-onevsall-d5c2acf0c37c；76。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 76?
**Answer:** This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; https://medium.com/analytics-vidhya/logistic-regression-from-scratch-multi-classification-with-onevsall-d5c2acf0c37c; 76. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：分类 / classification
**答：** 预测离散类别标签，例如图像类别或手写数字。
**Q2 English:** Explain the concept on this page: classification
**Answer:** The page focuses on classification. This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; https://medium.com/analytics-vidhya/logistic-regression-from-scratch-multi-classification-with-onevsall-d5c2acf0c37c; 76. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

## 第 77 页：机器学习 – 监督学习

Source ID: `src-ba4d35fbe29d-pdf_page-00077`

![PDF page 77](../assets/pages/page_077.jpg)

### 原文 / Original Text

```text
Machine learning – supervised learning

Regression
Prediction of continuous outcomes

e.g. students’ grade scores

77
```

### 完整中文翻译

机器学习 – 监督学习
回归
Prediction of continuous outcomes
e.g. students’ grade scores
77
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；回归；Prediction of continuous outcomes；e.g. students’ grade scores。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; Regression; Prediction of continuous outcomes; e.g. students’ grade scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – supervised learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 77 页的核心主题是什么？
**答：** 本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；回归；Prediction of continuous outcomes；e.g. students’ grade scores。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 77?
**Answer:** This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; Regression; Prediction of continuous outcomes; e.g. students’ grade scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; Regression; Prediction of continuous outcomes; e.g. students’ grade scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 78 页：机器学习 – 监督学习

Source ID: `src-ba4d35fbe29d-pdf_page-00078`

![PDF page 78](../assets/pages/page_078.jpg)

### 原文 / Original Text

```text
Machine learning – supervised learning

78

https://youtu.be/CtsRRUddV2s
```

### 完整中文翻译

机器学习 – 监督学习
78
参考链接：https://youtu.be/CtsRRUddV2s
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；78；参考链接：https://youtu.be/CtsRRUddV2s。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 78; https://youtu.be/CtsRRUddV2s. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – supervised learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 78 页的核心主题是什么？
**答：** 本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；78；参考链接：https://youtu.be/CtsRRUddV2s。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 78?
**Answer:** This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 78; https://youtu.be/CtsRRUddV2s. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 78; https://youtu.be/CtsRRUddV2s. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 79 页：机器学习 – 监督学习

Source ID: `src-ba4d35fbe29d-pdf_page-00079`

![PDF page 79](../assets/pages/page_079.jpg)

### 原文 / Original Text

```text
Machine learning – supervised learning

79

Google finance
```

### 完整中文翻译

机器学习 – 监督学习
79
Google finance
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；79；Google finance。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 79; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – supervised learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 79 页的核心主题是什么？
**答：** 本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；79；Google finance。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 79?
**Answer:** This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 79; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 79; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 80 页：机器学习 – 监督学习

Source ID: `src-ba4d35fbe29d-pdf_page-00080`

![PDF page 80](../assets/pages/page_080.jpg)

### 原文 / Original Text

```text
Machine learning – supervised learning

80

Google finance
```

### 完整中文翻译

机器学习 – 监督学习
80
Google finance
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；80；Google finance。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 80; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – supervised learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 80 页的核心主题是什么？
**答：** 本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；80；Google finance。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 80?
**Answer:** This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 80; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 80; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 81 页：机器学习 – 监督学习

Source ID: `src-ba4d35fbe29d-pdf_page-00081`

![PDF page 81](../assets/pages/page_081.jpg)

### 原文 / Original Text

```text
Machine learning – supervised learning

81

Google finance
```

### 完整中文翻译

机器学习 – 监督学习
81
Google finance
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；81；Google finance。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 81; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – supervised learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 81 页的核心主题是什么？
**答：** 本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；81；Google finance。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 81?
**Answer:** This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 81; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 81; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 82 页：机器学习 – 监督学习

Source ID: `src-ba4d35fbe29d-pdf_page-00082`

![PDF page 82](../assets/pages/page_082.jpg)

### 原文 / Original Text

```text
Machine learning – supervised learning

82

Google finance
```

### 完整中文翻译

机器学习 – 监督学习
82
Google finance
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；82；Google finance。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 82; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – supervised learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 82 页的核心主题是什么？
**答：** 本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；82；Google finance。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 82?
**Answer:** This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 82; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 82; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 83 页：机器学习 – 监督学习

Source ID: `src-ba4d35fbe29d-pdf_page-00083`

![PDF page 83](../assets/pages/page_083.jpg)

### 原文 / Original Text

```text
Machine learning – supervised learning

83

https://gbhat.com/machine_learning/polynomial_regression_2.html
```

### 完整中文翻译

机器学习 – 监督学习
83
参考链接：https://gbhat.com/machine_learning/polynomial_regression_2.html
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；83；参考链接：https://gbhat.com/machine_learning/polynomial_regression_2.html。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 83; https://gbhat.com/machine_learning/polynomial_regression_2.html. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – supervised learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 83 页的核心主题是什么？
**答：** 本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；83；参考链接：https://gbhat.com/machine_learning/polynomial_regression_2.html。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 83?
**Answer:** This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 83; https://gbhat.com/machine_learning/polynomial_regression_2.html. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 83; https://gbhat.com/machine_learning/polynomial_regression_2.html. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 84 页：机器学习 – 监督学习

Source ID: `src-ba4d35fbe29d-pdf_page-00084`

![PDF page 84](../assets/pages/page_084.jpg)

### 原文 / Original Text

```text
Machine learning – supervised learning

84

https://builtin.com/data-science/regression-machine-learning
```

### 完整中文翻译

机器学习 – 监督学习
84
参考链接：https://builtin.com/data-science/regression-machine-learning
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；84；参考链接：https://builtin.com/data-science/regression-machine-learning。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 84; https://builtin.com/data-science/regression-machine-learning. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – supervised learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 84 页的核心主题是什么？
**答：** 本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；84；参考链接：https://builtin.com/data-science/regression-machine-learning。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 84?
**Answer:** This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 84; https://builtin.com/data-science/regression-machine-learning. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 84; https://builtin.com/data-science/regression-machine-learning. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 85 页：机器学习 – 监督学习

Source ID: `src-ba4d35fbe29d-pdf_page-00085`

![PDF page 85](../assets/pages/page_085.jpg)

### 原文 / Original Text

```text
Machine learning – supervised learning

85

Google finance
```

### 完整中文翻译

机器学习 – 监督学习
85
Google finance
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；85；Google finance。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 85; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – supervised learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 85 页的核心主题是什么？
**答：** 本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；85；Google finance。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 85?
**Answer:** This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 85; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 85; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 86 页：机器学习 – 监督学习

Source ID: `src-ba4d35fbe29d-pdf_page-00086`

![PDF page 86](../assets/pages/page_086.jpg)

### 原文 / Original Text

```text
Machine learning – supervised learning

86

Google finance
```

### 完整中文翻译

机器学习 – 监督学习
86
Google finance
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；86；Google finance。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 86; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – supervised learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 86 页的核心主题是什么？
**答：** 本页围绕“Machine learning – supervised learning”展开。课件中的关键信息包括：机器学习 – 监督学习；86；Google finance。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 86?
**Answer:** This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 86; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – supervised learning'. The slide includes: Machine learning – supervised learning; 86; Google finance. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 87 页：机器学习 – 无监督学习

Source ID: `src-ba4d35fbe29d-pdf_page-00087`

![PDF page 87](../assets/pages/page_087.jpg)

### 原文 / Original Text

```text
Machine learning – unsupervised learning

87
```

### 完整中文翻译

机器学习 – 无监督学习
87
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – unsupervised learning”展开。课件中的关键信息包括：机器学习 – 无监督学习；87。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – unsupervised learning'. The slide includes: Machine learning – unsupervised learning; 87. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – unsupervised learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 87 页的核心主题是什么？
**答：** 本页围绕“Machine learning – unsupervised learning”展开。课件中的关键信息包括：机器学习 – 无监督学习；87。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 87?
**Answer:** This page presents 'Machine learning – unsupervised learning'. The slide includes: Machine learning – unsupervised learning; 87. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – unsupervised learning'. The slide includes: Machine learning – unsupervised learning; 87. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 88 页：机器学习 – 无监督学习

Source ID: `src-ba4d35fbe29d-pdf_page-00088`

![PDF page 88](../assets/pages/page_088.jpg)

### 原文 / Original Text

```text
Machine learning – unsupervised learning

https://towardsdatascience.com/supervised-vs-unsupervised-learning-in-2-minutes-72dad148f242

88
```

### 完整中文翻译

机器学习 – 无监督学习
参考链接：https://towardsdatascience.com/supervised-vs-unsupervised-learning-in-2-minutes-72dad148f242
88
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – unsupervised learning”展开。课件中的关键信息包括：机器学习 – 无监督学习；参考链接：https://towardsdatascience.com/supervised-vs-unsupervised-learning-in-2-minutes-72dad148f242；88。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – unsupervised learning'. The slide includes: Machine learning – unsupervised learning; https://towardsdatascience.com/supervised-vs-unsupervised-learning-in-2-minutes-72dad148f242; 88. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – unsupervised learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 88 页的核心主题是什么？
**答：** 本页围绕“Machine learning – unsupervised learning”展开。课件中的关键信息包括：机器学习 – 无监督学习；参考链接：https://towardsdatascience.com/supervised-vs-unsupervised-learning-in-2-minutes-72dad148f242；88。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 88?
**Answer:** This page presents 'Machine learning – unsupervised learning'. The slide includes: Machine learning – unsupervised learning; https://towardsdatascience.com/supervised-vs-unsupervised-learning-in-2-minutes-72dad148f242; 88. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – unsupervised learning'. The slide includes: Machine learning – unsupervised learning; https://towardsdatascience.com/supervised-vs-unsupervised-learning-in-2-minutes-72dad148f242; 88. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 89 页：机器学习 – 强化学习

Source ID: `src-ba4d35fbe29d-pdf_page-00089`

![PDF page 89](../assets/pages/page_089.jpg)

### 原文 / Original Text

```text
Machine learning – reinforcement learning

89

https://rubikscode.net/2019/06/24/introduction-to-q-learning-with-python-and-open-ai-gym/
```

### 完整中文翻译

机器学习 – 强化学习
89
参考链接：https://rubikscode.net/2019/06/24/introduction-to-q-learning-with-python-and-open-ai-gym/
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – reinforcement learning”展开。课件中的关键信息包括：机器学习 – 强化学习；89；参考链接：https://rubikscode.net/2019/06/24/introduction-to-q-learning-with-python-and-open-ai-gym/。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – reinforcement learning'. The slide includes: Machine learning – reinforcement learning; 89; https://rubikscode.net/2019/06/24/introduction-to-q-learning-with-python-and-open-ai-gym/. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – reinforcement learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 89 页的核心主题是什么？
**答：** 本页围绕“Machine learning – reinforcement learning”展开。课件中的关键信息包括：机器学习 – 强化学习；89；参考链接：https://rubikscode.net/2019/06/24/introduction-to-q-learning-with-python-and-open-ai-gym/。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 89?
**Answer:** This page presents 'Machine learning – reinforcement learning'. The slide includes: Machine learning – reinforcement learning; 89; https://rubikscode.net/2019/06/24/introduction-to-q-learning-with-python-and-open-ai-gym/. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – reinforcement learning'. The slide includes: Machine learning – reinforcement learning; 89; https://rubikscode.net/2019/06/24/introduction-to-q-learning-with-python-and-open-ai-gym/. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 90 页：机器学习 – 强化学习

Source ID: `src-ba4d35fbe29d-pdf_page-00090`

![PDF page 90](../assets/pages/page_090.jpg)

### 原文 / Original Text

```text
Machine learning – reinforcement learning

Initial

After 15 minutes

After 30 minutes

90

https://deepsense.ai/what-is-reinforcement-learning-the-complete-guide/
```

### 完整中文翻译

机器学习 – 强化学习
Initial
After 15 minutes
After 30 minutes
90
参考链接：https://deepsense.ai/what-is-reinforcement-learning-the-complete-guide/
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – reinforcement learning”展开。课件中的关键信息包括：机器学习 – 强化学习；Initial；After 15 minutes；After 30 minutes。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – reinforcement learning'. The slide includes: Machine learning – reinforcement learning; Initial; After 15 minutes; After 30 minutes. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – reinforcement learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 90 页的核心主题是什么？
**答：** 本页围绕“Machine learning – reinforcement learning”展开。课件中的关键信息包括：机器学习 – 强化学习；Initial；After 15 minutes；After 30 minutes。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 90?
**Answer:** This page presents 'Machine learning – reinforcement learning'. The slide includes: Machine learning – reinforcement learning; Initial; After 15 minutes; After 30 minutes. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – reinforcement learning'. The slide includes: Machine learning – reinforcement learning; Initial; After 15 minutes; After 30 minutes. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 91 页：机器学习 – 强化学习

Source ID: `src-ba4d35fbe29d-pdf_page-00091`

![PDF page 91](../assets/pages/page_091.jpg)

### 原文 / Original Text

```text
Machine learning – reinforcement learning

91

https://youtu.be/WXuK6gekU1Y?t=2841
```

### 完整中文翻译

机器学习 – 强化学习
91
参考链接：https://youtu.be/WXuK6gekU1Y?t=2841
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Machine learning – reinforcement learning”展开。课件中的关键信息包括：机器学习 – 强化学习；91；参考链接：https://youtu.be/WXuK6gekU1Y?t=2841。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Machine learning – reinforcement learning'. The slide includes: Machine learning – reinforcement learning; 91; https://youtu.be/WXuK6gekU1Y?t=2841. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Machine learning – reinforcement learning”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 91 页的核心主题是什么？
**答：** 本页围绕“Machine learning – reinforcement learning”展开。课件中的关键信息包括：机器学习 – 强化学习；91；参考链接：https://youtu.be/WXuK6gekU1Y?t=2841。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 91?
**Answer:** This page presents 'Machine learning – reinforcement learning'. The slide includes: Machine learning – reinforcement learning; 91; https://youtu.be/WXuK6gekU1Y?t=2841. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Machine learning – reinforcement learning'. The slide includes: Machine learning – reinforcement learning; 91; https://youtu.be/WXuK6gekU1Y?t=2841. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 92 页：What is 深度学习?

Source ID: `src-ba4d35fbe29d-pdf_page-00092`

![PDF page 92](../assets/pages/page_092.jpg)

### 原文 / Original Text

```text
What is deep learning?
02
01

Classification

Detection

03

Matting

04

Alpha GO

05

AlphaFold

06

Healthcare

https://becominghuman.ai/building-an-image-classifier-using-deep-learning-in-python-totally-from-a-beginners-perspective-be8dbaf22dd8
https://towardsdatascience.com/deep-learning-method-for-object-detection-r-cnn-explained-ecdadd751d22?gi=51e5dd227143
https://www.befunky.com/learn/automatic-background-remover/, https://deepmind.com/research/case-studies/alphago-the-story-so-far

https://deepmind.com/blog/article/alphafold-a-solution-to-a-50-year-old-grand-challenge-in-biology,
https://stanfordmlgroup.github.io/projects/chexnet/

…

92
```

### 完整中文翻译

What is 深度学习?
02
01
分类
检测
03
Matting
04
Alpha GO
05
AlphaFold
06
Healthcare
参考链接：https://becominghuman.ai/building-an-image-classifier-using-deep-learning-in-python-totally-from-a-beginners-perspective-be8dbaf22dd8
参考链接：https://towardsdatascience.com/deep-learning-method-for-object-detection-r-cnn-explained-ecdadd751d22?gi=51e5dd227143
参考链接：https://www.befunky.com/learn/automatic-background-remover/, https://deepmind.com/research/case-studies/alphago-the-story-so-far
参考链接：https://deepmind.com/blog/article/alphafold-a-solution-to-a-50-year-old-grand-challenge-in-biology,
参考链接：https://stanfordmlgroup.github.io/projects/chexnet/
…
92
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“What is deep learning?”展开。课件中的关键信息包括：What is 深度学习?；02；01；分类。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'What is deep learning?'. The slide includes: What is deep learning?; 02; 01; Classification. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。
- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。
- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“What is deep learning?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 92 页的核心主题是什么？
**答：** 本页围绕“What is deep learning?”展开。课件中的关键信息包括：What is 深度学习?；02；01；分类。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 92?
**Answer:** This page presents 'What is deep learning?'. The slide includes: What is deep learning?; 02; 01; Classification. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：分类 / classification
**答：** 预测离散类别标签，例如图像类别或手写数字。
**Q2 English:** Explain the concept on this page: classification
**Answer:** The page focuses on classification. This page presents 'What is deep learning?'. The slide includes: What is deep learning?; 02; 01; Classification. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

## 第 93 页：What is 深度学习?

Source ID: `src-ba4d35fbe29d-pdf_page-00093`

![PDF page 93](../assets/pages/page_093.jpg)

### 原文 / Original Text

```text
What is deep learning?
02
01

Classification

Detection

03

Matting

04

Alpha GO

05

AlphaFold

06

Healthcare

https://becominghuman.ai/building-an-image-classifier-using-deep-learning-in-python-totally-from-a-beginners-perspective-be8dbaf22dd8
https://towardsdatascience.com/deep-learning-method-for-object-detection-r-cnn-explained-ecdadd751d22?gi=51e5dd227143
https://www.befunky.com/learn/automatic-background-remover/, https://deepmind.com/research/case-studies/alphago-the-story-so-far

https://deepmind.com/blog/article/alphafold-a-solution-to-a-50-year-old-grand-challenge-in-biology,
https://stanfordmlgroup.github.io/projects/chexnet/

…

93
```

### 完整中文翻译

What is 深度学习?
02
01
分类
检测
03
Matting
04
Alpha GO
05
AlphaFold
06
Healthcare
参考链接：https://becominghuman.ai/building-an-image-classifier-using-deep-learning-in-python-totally-from-a-beginners-perspective-be8dbaf22dd8
参考链接：https://towardsdatascience.com/deep-learning-method-for-object-detection-r-cnn-explained-ecdadd751d22?gi=51e5dd227143
参考链接：https://www.befunky.com/learn/automatic-background-remover/, https://deepmind.com/research/case-studies/alphago-the-story-so-far
参考链接：https://deepmind.com/blog/article/alphafold-a-solution-to-a-50-year-old-grand-challenge-in-biology,
参考链接：https://stanfordmlgroup.github.io/projects/chexnet/
…
93
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“What is deep learning?”展开。课件中的关键信息包括：What is 深度学习?；02；01；分类。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'What is deep learning?'. The slide includes: What is deep learning?; 02; 01; Classification. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。
- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。
- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“What is deep learning?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 93 页的核心主题是什么？
**答：** 本页围绕“What is deep learning?”展开。课件中的关键信息包括：What is 深度学习?；02；01；分类。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 93?
**Answer:** This page presents 'What is deep learning?'. The slide includes: What is deep learning?; 02; 01; Classification. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：分类 / classification
**答：** 预测离散类别标签，例如图像类别或手写数字。
**Q2 English:** Explain the concept on this page: classification
**Answer:** The page focuses on classification. This page presents 'What is deep learning?'. The slide includes: What is deep learning?; 02; 01; Classification. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

## 第 94 页：What is 深度学习?

Source ID: `src-ba4d35fbe29d-pdf_page-00094`

![PDF page 94](../assets/pages/page_094.jpg)

### 原文 / Original Text

```text
What is deep learning?
02
01

Classification

Detection

03

Matting

𝑓!(𝑥) = 𝑦

AlphaFold

05

06

Healthcare

…

04

Alpha GO

Prompt: Animated scene features a close-up of a short fluffy monster kneeling beside a melting red candle. The art style is 3D and 
realistic, with a focus on lighting and texture. The mood of the painting is one of wonder and curiosity, as the monster gazes at the flame 
with wide eyes and open mouth. Its pose and expression convey a sense of innocence and playfulness, as if it is exploring the world 
around it for the first time. The use of warm colors and dramatic lighting further enhances the cozy atmosphere of the image.

94
```

### 完整中文翻译

What is 深度学习?
02
01
分类
检测
03
Matting
𝑓!(𝑥) = 𝑦
AlphaFold
05
06
Healthcare
…
04
Alpha GO
Prompt: Animated scene features a close-up of a short fluffy monster kneeling beside a melting red candle. The art style is 3D and
realistic, with a focus on lighting and texture. The mood of the painting is one of wonder and curiosity, as the monster gazes at the flame
with wide eyes and open mouth. Its pose and expression convey a sense of innocence and playfulness, as if it is exploring the world
around it for the first time. The use of warm colors and dramatic lighting further enhances the cozy atmosphere of the image.
94
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“What is deep learning?”展开。课件中的关键信息包括：What is 深度学习?；02；01；分类。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'What is deep learning?'. The slide includes: What is deep learning?; 02; 01; Classification. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。
- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。
- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“What is deep learning?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 94 页的核心主题是什么？
**答：** 本页围绕“What is deep learning?”展开。课件中的关键信息包括：What is 深度学习?；02；01；分类。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 94?
**Answer:** This page presents 'What is deep learning?'. The slide includes: What is deep learning?; 02; 01; Classification. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：分类 / classification
**答：** 预测离散类别标签，例如图像类别或手写数字。
**Q2 English:** Explain the concept on this page: classification
**Answer:** The page focuses on classification. This page presents 'What is deep learning?'. The slide includes: What is deep learning?; 02; 01; Classification. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

## 第 95 页：面向计算机视觉的深度学习

Source ID: `src-ba4d35fbe29d-pdf_page-00095`

![PDF page 95](../assets/pages/page_095.jpg)

### 原文 / Original Text

```text
Deep learning for computer vision
𝑓"(𝑥) = 𝑦

95
```

### 完整中文翻译

面向计算机视觉的深度学习
𝑓"(𝑥) = 𝑦
95
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Deep learning for computer vision”展开。课件中的关键信息包括：面向计算机视觉的深度学习；𝑓"(𝑥) = 𝑦；95。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Deep learning for computer vision'. The slide includes: Deep learning for computer vision; 𝑓"(𝑥) = 𝑦; 95. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“Deep learning for computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 95 页的核心主题是什么？
**答：** 本页围绕“Deep learning for computer vision”展开。课件中的关键信息包括：面向计算机视觉的深度学习；𝑓"(𝑥) = 𝑦；95。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 95?
**Answer:** This page presents 'Deep learning for computer vision'. The slide includes: Deep learning for computer vision; 𝑓"(𝑥) = 𝑦; 95. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Deep learning for computer vision'. The slide includes: Deep learning for computer vision; 𝑓"(𝑥) = 𝑦; 95. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 96 页：计算机视觉应用

Source ID: `src-ba4d35fbe29d-pdf_page-00096`

![PDF page 96](../assets/pages/page_096.jpg)

### 原文 / Original Text

```text
Application to computer vision

Classification

Detection

Segmentation

Slide credit:

Low-level vision

3D vision

Vision + X

https://becominghuman.ai/building-an-image-classifier-using-deep-learning-in-python-totally-from-a-beginners-perspective-be8dbaf22dd8
https://towardsdatascience.com/deep-learning-method-for-object-detection-r-cnn-explained-ecdadd751d22?gi=51e5dd227143

https://www.befunky.com/learn/automatic-background-remover/, https://deepmind.com/research/case-studies/alphago-the-story-so-far
[J. Jiao et al. CVPR 2019], [Shubham Tulsiani 16-889: Learning for 3D Vision] [JB. Alayrac et al. NeurIPS 2020]

96
```

### 完整中文翻译

计算机视觉应用
分类
检测
分割
Slide credit:
Low-level vision
3D vision
Vision + X
参考链接：https://becominghuman.ai/building-an-image-classifier-using-deep-learning-in-python-totally-from-a-beginners-perspective-be8dbaf22dd8
参考链接：https://towardsdatascience.com/deep-learning-method-for-object-detection-r-cnn-explained-ecdadd751d22?gi=51e5dd227143
参考链接：https://www.befunky.com/learn/automatic-background-remover/, https://deepmind.com/research/case-studies/alphago-the-story-so-far
[J. Jiao et al. CVPR 2019], [Shubham Tulsiani 16-889: Learning for 3D Vision] [JB. Alayrac et al. NeurIPS 2020]
96
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；分类；检测；分割。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Classification; Detection; Segmentation. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。
- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。
- **segmentation / 分割**：为像素或区域分配类别/实例标签。

拓展复习：把“Application to computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 96 页的核心主题是什么？
**答：** 本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；分类；检测；分割。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 96?
**Answer:** This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Classification; Detection; Segmentation. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Classification; Detection; Segmentation. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 97 页：计算机视觉应用

Source ID: `src-ba4d35fbe29d-pdf_page-00097`

![PDF page 97](../assets/pages/page_097.jpg)

### 原文 / Original Text

```text
Application to computer vision

Classification

Slide credit:

97

Slide credit: Samuel Albanie
```

### 完整中文翻译

计算机视觉应用
分类
Slide credit:
97
Slide credit: Samuel Albanie
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；分类；Slide credit:；97。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Classification; Slide credit:; 97. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。

拓展复习：把“Application to computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 97 页的核心主题是什么？
**答：** 本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；分类；Slide credit:；97。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 97?
**Answer:** This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Classification; Slide credit:; 97. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Classification; Slide credit:; 97. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 98 页：计算机视觉应用

Source ID: `src-ba4d35fbe29d-pdf_page-00098`

![PDF page 98](../assets/pages/page_098.jpg)

### 原文 / Original Text

```text
Application to computer vision

Detection

Localisation

Recognition

https://towardsdatascience.com/deep-learning-method-for-object-detection-r-cnn-explained-ecdadd751d22?gi=51e5dd227143

98
```

### 完整中文翻译

计算机视觉应用
检测
Localisation
Recognition
参考链接：https://towardsdatascience.com/deep-learning-method-for-object-detection-r-cnn-explained-ecdadd751d22?gi=51e5dd227143
98
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；检测；Localisation；Recognition。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Detection; Localisation; Recognition. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。

拓展复习：把“Application to computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 98 页的核心主题是什么？
**答：** 本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；检测；Localisation；Recognition。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 98?
**Answer:** This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Detection; Localisation; Recognition. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Detection; Localisation; Recognition. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 99 页：计算机视觉应用

Source ID: `src-ba4d35fbe29d-pdf_page-00099`

![PDF page 99](../assets/pages/page_099.jpg)

### 原文 / Original Text

```text
Application to computer vision

Detection

(x, y)

W

H

Deep Neural
Network

Cat: (x, y, w, h)

Deep Neural
Network

Penguin: (x1, y1, w1, h1)
Penguin: (x2, y2, w2, h2)
…

99

Image courtesy: Sonsedska/Getty Images/iStockphoto; Laurie Goodman
```

### 完整中文翻译

计算机视觉应用
检测
(x, y)
W
H
Deep Neural
Network
Cat: (x, y, w, h)
Deep Neural
Network
Penguin: (x1, y1, w1, h1)
Penguin: (x2, y2, w2, h2)
…
99
Image courtesy: Sonsedska/Getty Images/iStockphoto; Laurie Goodman
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；检测；(x, y)；W。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Detection; (x, y); W. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。

拓展复习：把“Application to computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 99 页的核心主题是什么？
**答：** 本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；检测；(x, y)；W。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 99?
**Answer:** This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Detection; (x, y); W. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Detection; (x, y); W. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 100 页：计算机视觉应用

Source ID: `src-ba4d35fbe29d-pdf_page-00100`

![PDF page 100](../assets/pages/page_100.jpg)

### 原文 / Original Text

```text
Application to computer vision

Segmentation

Slide credit:

100

Image credit: Fei-Fei Li et al. CS231n lecture
```

### 完整中文翻译

计算机视觉应用
分割
Slide credit:
100
Image credit: Fei-Fei Li et al. CS231n lecture
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；分割；Slide credit:；100。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Segmentation; Slide credit:; 100. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
- **segmentation / 分割**：为像素或区域分配类别/实例标签。

拓展复习：把“Application to computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 100 页的核心主题是什么？
**答：** 本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；分割；Slide credit:；100。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 100?
**Answer:** This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Segmentation; Slide credit:; 100. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Segmentation; Slide credit:; 100. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 101 页：计算机视觉应用

Source ID: `src-ba4d35fbe29d-pdf_page-00101`

![PDF page 101](../assets/pages/page_101.jpg)

### 原文 / Original Text

```text
Application to computer vision

Segmentation

Panoptic segmentation

Slide credit:

https://youtu.be/U9PAcWMX3LA

101
```

### 完整中文翻译

计算机视觉应用
分割
Panoptic 分割
Slide credit:
参考链接：https://youtu.be/U9PAcWMX3LA
101
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；分割；Panoptic 分割；Slide credit:。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Segmentation; Panoptic segmentation; Slide credit:. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
- **segmentation / 分割**：为像素或区域分配类别/实例标签。

拓展复习：把“Application to computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 101 页的核心主题是什么？
**答：** 本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；分割；Panoptic 分割；Slide credit:。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 101?
**Answer:** This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Segmentation; Panoptic segmentation; Slide credit:. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Segmentation; Panoptic segmentation; Slide credit:. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 102 页：计算机视觉应用

Source ID: `src-ba4d35fbe29d-pdf_page-00102`

![PDF page 102](../assets/pages/page_102.jpg)

### 原文 / Original Text

```text
Application to computer vision

Slide credit:

Low-level vision

Image denoising

Super-resolution

Inpainting

De-blur

colourisation

https://www.befunky.com/learn/automatic-background-remover/

Visual matting

…

102
```

### 完整中文翻译

计算机视觉应用
Slide credit:
Low-level vision
Image 去噪
超分辨率
图像修复
De-blur
colourisation
参考链接：https://www.befunky.com/learn/automatic-background-remover/
Visual matting
…
102
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；Slide credit:；Low-level vision；Image 去噪。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Slide credit:; Low-level vision; Image denoising. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
- **denoising / 图像去噪**：从含噪观测中恢复潜在干净图像，是典型低层视觉问题。
- **super-resolution / 超分辨率**：从低分辨率图像恢复更高分辨率细节。
- **inpainting / 图像修复**：补全图像中缺失或被遮挡的区域。

拓展复习：把“Application to computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 102 页的核心主题是什么？
**答：** 本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；Slide credit:；Low-level vision；Image 去噪。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 102?
**Answer:** This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Slide credit:; Low-level vision; Image denoising. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Slide credit:; Low-level vision; Image denoising. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 103 页：计算机视觉应用

Source ID: `src-ba4d35fbe29d-pdf_page-00103`

![PDF page 103](../assets/pages/page_103.jpg)

### 原文 / Original Text

```text
Application to computer vision

Low-level vision

Super-resolution

Slide credit:

Lai, Wei-Sheng, et al. "Fast and accurate image super-resolution with deep laplacian pyramid networks." IEEE transactions on pattern analysis and machine intelligence 41.11 (2018): 2599-2613.

103
```

### 完整中文翻译

计算机视觉应用
Low-level vision
超分辨率
Slide credit:
Lai, Wei-Sheng, et al. "Fast and accurate image 超分辨率 with deep laplacian pyramid networks." IEEE transactions on pattern analysis and machine intelligence 41.11 (2018): 2599-2613.
103
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；Low-level vision；超分辨率；Slide credit:。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Low-level vision; Super-resolution; Slide credit:. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
- **super-resolution / 超分辨率**：从低分辨率图像恢复更高分辨率细节。

拓展复习：把“Application to computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 103 页的核心主题是什么？
**答：** 本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；Low-level vision；超分辨率；Slide credit:。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 103?
**Answer:** This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Low-level vision; Super-resolution; Slide credit:. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Low-level vision; Super-resolution; Slide credit:. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 104 页：计算机视觉应用

Source ID: `src-ba4d35fbe29d-pdf_page-00104`

![PDF page 104](../assets/pages/page_104.jpg)

### 原文 / Original Text

```text
Application to computer vision

Low-level vision

Super-resolution

Slide credit:

https://youtu.be/ONZcjs1Pjmk?t=198

104

Wu, Hao-Yu, et al. "Eulerian video magnification for revealing subtle changes in the world." ACM transactions on graphics (TOG) 31.4 (2012): 1-8.
```

### 完整中文翻译

计算机视觉应用
Low-level vision
超分辨率
Slide credit:
参考链接：https://youtu.be/ONZcjs1Pjmk?t=198
104
Wu, Hao-Yu, et al. "Eulerian video magnification for revealing subtle changes in the world." ACM transactions on graphics (TOG) 31.4 (2012): 1-8.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；Low-level vision；超分辨率；Slide credit:。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Low-level vision; Super-resolution; Slide credit:. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
- **super-resolution / 超分辨率**：从低分辨率图像恢复更高分辨率细节。

拓展复习：把“Application to computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 104 页的核心主题是什么？
**答：** 本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；Low-level vision；超分辨率；Slide credit:。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 104?
**Answer:** This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Low-level vision; Super-resolution; Slide credit:. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Low-level vision; Super-resolution; Slide credit:. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 105 页：计算机视觉应用

Source ID: `src-ba4d35fbe29d-pdf_page-00105`

![PDF page 105](../assets/pages/page_105.jpg)

### 原文 / Original Text

```text
Application to computer vision

3D vision

Slide credit:

Shubham Tulsiani, 16-889: Learning for 3D Vision, Carnegie Mellon University

105
```

### 完整中文翻译

计算机视觉应用
3D vision
Slide credit:
Shubham Tulsiani, 16-889: Learning for 3D Vision, Carnegie Mellon University
105
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；3D vision；Slide credit:；Shubham Tulsiani, 16-889: Learning for 3D Vision, Carnegie Mellon University。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Application to computer vision'. The slide includes: Application to computer vision; 3D vision; Slide credit:; Shubham Tulsiani, 16-889: Learning for 3D Vision, Carnegie Mellon University. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Application to computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 105 页的核心主题是什么？
**答：** 本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；3D vision；Slide credit:；Shubham Tulsiani, 16-889: Learning for 3D Vision, Carnegie Mellon University。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 105?
**Answer:** This page presents 'Application to computer vision'. The slide includes: Application to computer vision; 3D vision; Slide credit:; Shubham Tulsiani, 16-889: Learning for 3D Vision, Carnegie Mellon University. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Application to computer vision'. The slide includes: Application to computer vision; 3D vision; Slide credit:; Shubham Tulsiani, 16-889: Learning for 3D Vision, Carnegie Mellon University. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 106 页：计算机视觉应用

Source ID: `src-ba4d35fbe29d-pdf_page-00106`

![PDF page 106](../assets/pages/page_106.jpg)

### 原文 / Original Text

```text
Application to computer vision

3D vision

Neural Radiance Field

Slide credit:

Mildenhall, B., et al. "Representing scenes as neural radiance fields for view synthesis." Proc. of European Conference on Computer Vision, Virtual. 2020.

106
```

### 完整中文翻译

计算机视觉应用
3D vision
Neural Radiance Field
Slide credit:
Mildenhall, B., et al. "Representing scenes as neural radiance fields for view synthesis." Proc. of European Conference on 计算机视觉, Virtual. 2020.
106
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；3D vision；Neural Radiance Field；Slide credit:。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Application to computer vision'. The slide includes: Application to computer vision; 3D vision; Neural Radiance Field; Slide credit:. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Application to computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 106 页的核心主题是什么？
**答：** 本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；3D vision；Neural Radiance Field；Slide credit:。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 106?
**Answer:** This page presents 'Application to computer vision'. The slide includes: Application to computer vision; 3D vision; Neural Radiance Field; Slide credit:. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Application to computer vision'. The slide includes: Application to computer vision; 3D vision; Neural Radiance Field; Slide credit:. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 107 页：计算机视觉应用

Source ID: `src-ba4d35fbe29d-pdf_page-00107`

![PDF page 107](../assets/pages/page_107.jpg)

### 原文 / Original Text

```text
Application to computer vision

3D vision

3D Gaussian Splatting

Slide credit:

107

https://youtu.be/Tnij_xHEnXc
```

### 完整中文翻译

计算机视觉应用
3D vision
3D Gaussian Splatting
Slide credit:
107
参考链接：https://youtu.be/Tnij_xHEnXc
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；3D vision；3D Gaussian Splatting；Slide credit:。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Application to computer vision'. The slide includes: Application to computer vision; 3D vision; 3D Gaussian Splatting; Slide credit:. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Application to computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 107 页的核心主题是什么？
**答：** 本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；3D vision；3D Gaussian Splatting；Slide credit:。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 107?
**Answer:** This page presents 'Application to computer vision'. The slide includes: Application to computer vision; 3D vision; 3D Gaussian Splatting; Slide credit:. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Application to computer vision'. The slide includes: Application to computer vision; 3D vision; 3D Gaussian Splatting; Slide credit:. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 108 页：计算机视觉应用

Source ID: `src-ba4d35fbe29d-pdf_page-00108`

![PDF page 108](../assets/pages/page_108.jpg)

### 原文 / Original Text

```text
Application to computer vision

Vision + X

Slide credit:

[Alayrac, Jean-Baptiste, et al. "Self-supervised multimodal versatile networks." Advances in Neural Information Processing Systems 33 (2020): 25-37.]

108
```

### 完整中文翻译

计算机视觉应用
Vision + X
Slide credit:
[Alayrac, Jean-Baptiste, et al. "Self-supervised multimodal versatile networks." Advances in Neural Information Processing Systems 33 (2020): 25-37.]
108
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；Vision + X；Slide credit:；[Alayrac, Jean-Baptiste, et al. "Self-supervised multimodal versatile networks." Advances in Neural Information Processing Systems 33 (2020): 25-37.]。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Vision + X; Slide credit:; [Alayrac, Jean-Baptiste, et al. "Self-supervised multimodal versatile networks." Advances in Neural Information Processing Systems 33 (2020): 25-37.]. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Application to computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 108 页的核心主题是什么？
**答：** 本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；Vision + X；Slide credit:；[Alayrac, Jean-Baptiste, et al. "Self-supervised multimodal versatile networks." Advances in Neural Information Processing Systems 33 (2020): 25-37.]。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 108?
**Answer:** This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Vision + X; Slide credit:; [Alayrac, Jean-Baptiste, et al. "Self-supervised multimodal versatile networks." Advances in Neural Information Processing Systems 33 (2020): 25-37.]. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Vision + X; Slide credit:; [Alayrac, Jean-Baptiste, et al. "Self-supervised multimodal versatile networks." Advances in Neural Information Processing Systems 33 (2020): 25-37.]. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 109 页：计算机视觉应用

Source ID: `src-ba4d35fbe29d-pdf_page-00109`

![PDF page 109](../assets/pages/page_109.jpg)

### 原文 / Original Text

```text
Application to computer vision

Vision + X

X = language

https://openai.com/dall-e-2/

Slide credit:

109
```

### 完整中文翻译

计算机视觉应用
Vision + X
X = language
参考链接：https://openai.com/dall-e-2/
Slide credit:
109
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；Vision + X；X = language；参考链接：https://openai.com/dall-e-2/。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Vision + X; X = language; https://openai.com/dall-e-2/. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Application to computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 109 页的核心主题是什么？
**答：** 本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；Vision + X；X = language；参考链接：https://openai.com/dall-e-2/。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 109?
**Answer:** This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Vision + X; X = language; https://openai.com/dall-e-2/. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Vision + X; X = language; https://openai.com/dall-e-2/. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 110 页：计算机视觉应用

Source ID: `src-ba4d35fbe29d-pdf_page-00110`

![PDF page 110](../assets/pages/page_110.jpg)

### 原文 / Original Text

```text
Application to computer vision

Vision + X

X = language

https://openai.com/dall-e-3/

Slide credit:

110
```

### 完整中文翻译

计算机视觉应用
Vision + X
X = language
参考链接：https://openai.com/dall-e-3/
Slide credit:
110
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；Vision + X；X = language；参考链接：https://openai.com/dall-e-3/。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Vision + X; X = language; https://openai.com/dall-e-3/. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Application to computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 110 页的核心主题是什么？
**答：** 本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；Vision + X；X = language；参考链接：https://openai.com/dall-e-3/。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 110?
**Answer:** This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Vision + X; X = language; https://openai.com/dall-e-3/. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Vision + X; X = language; https://openai.com/dall-e-3/. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 111 页：计算机视觉应用

Source ID: `src-ba4d35fbe29d-pdf_page-00111`

![PDF page 111](../assets/pages/page_111.jpg)

### 原文 / Original Text

```text
Application to computer vision

Vision + X

X = language

https://openai.com/sora/

Slide credit:

111
```

### 完整中文翻译

计算机视觉应用
Vision + X
X = language
参考链接：https://openai.com/sora/
Slide credit:
111
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；Vision + X；X = language；参考链接：https://openai.com/sora/。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Vision + X; X = language; https://openai.com/sora/. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Application to computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 111 页的核心主题是什么？
**答：** 本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；Vision + X；X = language；参考链接：https://openai.com/sora/。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 111?
**Answer:** This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Vision + X; X = language; https://openai.com/sora/. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Vision + X; X = language; https://openai.com/sora/. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 112 页：Top conferences and journals

Source ID: `src-ba4d35fbe29d-pdf_page-00112`

![PDF page 112](../assets/pages/page_112.jpg)

### 原文 / Original Text

```text
Top conferences and journals

Conferences

• CVPR (International Conference on Computer Vision

and Pattern Recognition)

•

ICCV (International Conference on Computer Vision)

• ECCV (European Conference on Computer Vision)

113
```

### 完整中文翻译

Top conferences and journals
Conferences
• CVPR (International Conference on 计算机视觉
and Pattern Recognition)
•
ICCV (International Conference on 计算机视觉)
• ECCV (European Conference on 计算机视觉)
113
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Top conferences and journals”展开。课件中的关键信息包括：Top conferences and journals；Conferences；• CVPR (International Conference on 计算机视觉；and Pattern Recognition)。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Top conferences and journals'. The slide includes: Top conferences and journals; Conferences; • CVPR (International Conference on Computer Vision; and Pattern Recognition). The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Top conferences and journals”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 112 页的核心主题是什么？
**答：** 本页围绕“Top conferences and journals”展开。课件中的关键信息包括：Top conferences and journals；Conferences；• CVPR (International Conference on 计算机视觉；and Pattern Recognition)。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 112?
**Answer:** This page presents 'Top conferences and journals'. The slide includes: Top conferences and journals; Conferences; • CVPR (International Conference on Computer Vision; and Pattern Recognition). The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Top conferences and journals'. The slide includes: Top conferences and journals; Conferences; • CVPR (International Conference on Computer Vision; and Pattern Recognition). The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 113 页：Top conferences and journals

Source ID: `src-ba4d35fbe29d-pdf_page-00113`

![PDF page 113](../assets/pages/page_113.jpg)

### 原文 / Original Text

```text
Top conferences and journals

Conferences

• CVPR 2024

114
```

### 完整中文翻译

Top conferences and journals
Conferences
• CVPR 2024
114
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Top conferences and journals”展开。课件中的关键信息包括：Top conferences and journals；Conferences；• CVPR 2024；114。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Top conferences and journals'. The slide includes: Top conferences and journals; Conferences; • CVPR 2024; 114. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Top conferences and journals”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 113 页的核心主题是什么？
**答：** 本页围绕“Top conferences and journals”展开。课件中的关键信息包括：Top conferences and journals；Conferences；• CVPR 2024；114。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 113?
**Answer:** This page presents 'Top conferences and journals'. The slide includes: Top conferences and journals; Conferences; • CVPR 2024; 114. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Top conferences and journals'. The slide includes: Top conferences and journals; Conferences; • CVPR 2024; 114. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 114 页：Top conferences and journals

Source ID: `src-ba4d35fbe29d-pdf_page-00114`

![PDF page 114](../assets/pages/page_114.jpg)

### 原文 / Original Text

```text
Top conferences and journals

Conferences

•

ICCV 2025

115
```

### 完整中文翻译

Top conferences and journals
Conferences
•
ICCV 2025
115
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Top conferences and journals”展开。课件中的关键信息包括：Top conferences and journals；Conferences；•；ICCV 2025。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Top conferences and journals'. The slide includes: Top conferences and journals; Conferences; •; ICCV 2025. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Top conferences and journals”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 114 页的核心主题是什么？
**答：** 本页围绕“Top conferences and journals”展开。课件中的关键信息包括：Top conferences and journals；Conferences；•；ICCV 2025。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 114?
**Answer:** This page presents 'Top conferences and journals'. The slide includes: Top conferences and journals; Conferences; •; ICCV 2025. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Top conferences and journals'. The slide includes: Top conferences and journals; Conferences; •; ICCV 2025. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 115 页：Top conferences and journals

Source ID: `src-ba4d35fbe29d-pdf_page-00115`

![PDF page 115](../assets/pages/page_115.jpg)

### 原文 / Original Text

```text
Top conferences and journals

Conferences

• ECCV 2026

116
```

### 完整中文翻译

Top conferences and journals
Conferences
• ECCV 2026
116
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Top conferences and journals”展开。课件中的关键信息包括：Top conferences and journals；Conferences；• ECCV 2026；116。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Top conferences and journals'. The slide includes: Top conferences and journals; Conferences; • ECCV 2026; 116. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Top conferences and journals”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 115 页的核心主题是什么？
**答：** 本页围绕“Top conferences and journals”展开。课件中的关键信息包括：Top conferences and journals；Conferences；• ECCV 2026；116。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 115?
**Answer:** This page presents 'Top conferences and journals'. The slide includes: Top conferences and journals; Conferences; • ECCV 2026; 116. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Top conferences and journals'. The slide includes: Top conferences and journals; Conferences; • ECCV 2026; 116. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 116 页：Top conferences and journals

Source ID: `src-ba4d35fbe29d-pdf_page-00116`

![PDF page 116](../assets/pages/page_116.jpg)

### 原文 / Original Text

```text
Top conferences and journals

Journals

•

IEEE T-PAMI (Transactions on Pattern Recognition and
Machine Intelligence)

• Springer IJCV (International Journal on Computer Vision)

• TMLR (Transactions on Machine Learning Research)📝📢

•

IEEE T-CSVT 📝📢

• Springer TVCJ 📝📢

117
```

### 完整中文翻译

Top conferences and journals
Journals
•
IEEE T-PAMI (Transactions on Pattern Recognition and
Machine Intelligence)
• Springer IJCV (International Journal on 计算机视觉)
• TMLR (Transactions on 机器学习 Research)📝📢
•
IEEE T-CSVT 📝📢
• Springer TVCJ 📝📢
117
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Top conferences and journals”展开。课件中的关键信息包括：Top conferences and journals；Journals；•；IEEE T-PAMI (Transactions on Pattern Recognition and。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Top conferences and journals'. The slide includes: Top conferences and journals; Journals; •; IEEE T-PAMI (Transactions on Pattern Recognition and. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Top conferences and journals”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 116 页的核心主题是什么？
**答：** 本页围绕“Top conferences and journals”展开。课件中的关键信息包括：Top conferences and journals；Journals；•；IEEE T-PAMI (Transactions on Pattern Recognition and。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 116?
**Answer:** This page presents 'Top conferences and journals'. The slide includes: Top conferences and journals; Journals; •; IEEE T-PAMI (Transactions on Pattern Recognition and. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Top conferences and journals'. The slide includes: Top conferences and journals; Journals; •; IEEE T-PAMI (Transactions on Pattern Recognition and. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 117 页：总结

Source ID: `src-ba4d35fbe29d-pdf_page-00117`

![PDF page 117](../assets/pages/page_117.jpg)

### 原文 / Original Text

```text
Summary

Computer Vision
□ Basics
□ What it can do

Machine learning
□ Basics
□ Deep learning in computer vision
```

### 完整中文翻译

总结
计算机视觉
□ Basics
□ What it can do
机器学习
□ Basics
□ 深度学习 in 计算机视觉
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Summary”展开。课件中的关键信息包括：总结；计算机视觉；□ Basics；□ What it can do。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Summary'. The slide includes: Summary; Computer Vision; □ Basics; □ What it can do. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **MAR / 随机缺失**：缺失与其他可观测变量有关，但不直接由缺失值本身决定。
- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“Summary”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 117 页的核心主题是什么？
**答：** 本页围绕“Summary”展开。课件中的关键信息包括：总结；计算机视觉；□ Basics；□ What it can do。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 117?
**Answer:** This page presents 'Summary'. The slide includes: Summary; Computer Vision; □ Basics; □ What it can do. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：随机缺失 / MAR
**答：** 缺失与其他可观测变量有关，但不直接由缺失值本身决定。
**Q2 English:** Explain the concept on this page: MAR
**Answer:** The page focuses on MAR. This page presents 'Summary'. The slide includes: Summary; Computer Vision; □ Basics; □ What it can do. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

## 第 118 页：Q & A

Source ID: `src-ba4d35fbe29d-pdf_page-00118`

![PDF page 118](../assets/pages/page_118.jpg)

### 原文 / Original Text

```text
Q & A
```

### 完整中文翻译

Q & A
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Q & A”展开。课件中的关键信息包括：Q & A。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Q & A'. The slide includes: Q & A. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Q & A”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 118 页的核心主题是什么？
**答：** 本页围绕“Q & A”展开。课件中的关键信息包括：Q & A。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 118?
**Answer:** This page presents 'Q & A'. The slide includes: Q & A. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Q & A'. The slide includes: Q & A. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.
