# 覆盖审计

- PDF 页 1：covered - src-2f6570f71ed0-pdf_page-00001
- PDF 页 2：covered - src-2f6570f71ed0-pdf_page-00002
- PDF 页 3：covered - src-2f6570f71ed0-pdf_page-00003
- PDF 页 4：covered - src-2f6570f71ed0-pdf_page-00004
- PDF 页 5：covered - src-2f6570f71ed0-pdf_page-00005
- PDF 页 6：covered - src-2f6570f71ed0-pdf_page-00006
- PDF 页 7：covered - src-2f6570f71ed0-pdf_page-00007
- PDF 页 8：covered - src-2f6570f71ed0-pdf_page-00008
- PDF 页 9：covered - src-2f6570f71ed0-pdf_page-00009
- PDF 页 10：covered - src-2f6570f71ed0-pdf_page-00010
- PDF 页 11：covered - src-2f6570f71ed0-pdf_page-00011
- PDF 页 12：covered - src-2f6570f71ed0-pdf_page-00012
- PDF 页 13：covered - src-2f6570f71ed0-pdf_page-00013
- PDF 页 14：covered - src-2f6570f71ed0-pdf_page-00014