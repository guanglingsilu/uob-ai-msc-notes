# 来源：W02_L04_Perception_Attention_and_Feedback.pdf

<!-- SOURCE: W02_L04_Perception_Attention_and_Feedback.pdf -->

<!-- PDF 页 1 -->

Perception, Attention and 
Feedback

Intelligent Interactive Systems  ·  Week 2  ·  Lecture 04
University of Birmingham

Feedback works only when a person can notice and 
interpret it.

• We will examine how perception and attention shape what 

people notice when an intelligent system communicates.

• We will use signal detection, cue integration and feedback 

timing to choose a cue, a channel and a response.

Course-own diagram. Five cues competing for one 
person.

<!-- PDF 页 2 -->

Watch the video.

Follow the counting task while you watch.

• Count the passes made by 

the team in white.

• Keep your answer to yourself until the video 
ends, then follow the lecturer’s discussion.

<!-- PDF 页 3 -->

Count the passes

Lecture 04 · Hook

A visible event can be missed when 
attention is elsewhere.

• In Simons and Chabris (1999), observers 
counted passes while an unexpected event 
occurred. Roughly half missed it across the 
study’s conditions.

• This is sustained inattentional blindness: an 
unexpected, visible event can escape notice 
during another task.

• For Interaction 1, predict what fraction of drivers 
notice a dashboard icon at a busy junction. Write 
a number; revisit it in five minutes.

After Simons and Chabris (1999). Original film frame retained: ©1999 Daniel J. Simons; adjacent 
schematic is course-created.

<!-- PDF 页 4 -->

The feedback arrow, taken seriously

Lecture 04 · Central question

The feedback arrow must reach a person who is already doing something.

• Lecture 02’s feedback arrow connects a 

system’s message to a person. Today we ask 
what makes that message arrive.

• Ask whether the cue will be noticed, compete 

with the task, or be wrong, and how it combines 
with other senses.

• Then ask how quickly and precisely people can 

perceive it, and when and how to acknowledge
their actions.

Course-own diagram. The reduced loop and the six questions the lecture answers.

<!-- PDF 页 5 -->

Selective attention: one narrow channel

Lecture 04 · Attention

Selective attention limits which inputs receive sustained processing.

• Selective attention means prioritising some 
inputs over others. Broadbent’s filter model 
(1958) pictured many inputs competing for a 
narrow processing channel.

• Later work revised that model: some unattended 
information can still be processed, so the filter is 
a teaching simplification.

• For design, ask whether a cue reaches the 

person’s current attention or captures it at an 
acceptable disruption cost.

Course-own diagram after Broadbent (1958).

<!-- PDF 页 6 -->

Inattentional blindness as a design problem

Lecture 04 · Attention

Design for the person’s current task, not visibility alone.

• Inattentional blindness helps explain why a 
static dashboard icon or peripheral colour 
change can be missed during demanding work.

• Abrupt onset, motion, changes in the attended 

channel, and meaningful cues can attract 
attention, but they also interrupt the task.

• Revisit your prediction: a sound may also 

compete with speech. Treat the icon as a design 
risk, not a measured detection rate.

Course-own table. The prediction from the hook, revisited.

<!-- PDF 页 7 -->

Multiple resources: use a free channel

Lecture 04 · Attention

Tasks interfere less when they draw on different resources.

• Multiple-resource theory distinguishes 

modality, code and processing stage (Wickens, 
2002). In plain terms, tasks can compete for 
different kinds of attention.

• Driving and a dashboard map both demand 

visual and spatial resources. Spoken 
directions use auditory and verbal resources, 
which can reduce interference.

• A different channel still has a cost: typing code 
and hearing speech can compete for verbal 
resources.

After Wickens (2002); simplified teaching model. Current links: sensing Week 7, XR Weeks 8–9.

<!-- PDF 页 8 -->

Three perceptual limits every system runs into

Lecture 04 · Perceptual limits

Perceptual limits create concrete constraints for interface design.

• Latency is the delay between an action and its 
visible effect. Short delays matter especially in 
head-mounted displays (LaValle, 2017).

• Resolution falls away from the fovea, the small 
region of sharp central vision. Fine detail and 
subtle colour differences are harder to see 
peripherally.

• Change blindness means missing a change 

across a visual disruption, as the flicker paradigm 
demonstrates (Rensink, O’Regan and Clark, 
1997).

LaValle (2017), chapters 5–6; Rensink, O’Regan and Clark (1997). Current XR teaching is Week 8; the 
original image says Week 7.

<!-- PDF 页 9 -->

Change blindness

Watch the room closely for anything that changes.

• List each change you spot; 

• Afterwards, what you missed is change 

keep it to yourself.

blindness (Rensink et al., 1997).

<!-- PDF 页 10 -->

Signal detection: four outcomes, two quantities

Lecture 04 · Signal detection

Separate the quality of the evidence from the decision to warn.

• Signal detection theory distinguishes hit, miss, 
false alarm and correct rejection: compare the 
warning decision with whether a hazard exists 
(Green and Swets, 1966).

• Sensitivity (d′) describes how well the evidence 
separates hazard from no hazard. Sensor and 
model performance can affect that separation.

• The criterion is the decision threshold. With 

sensitivity fixed, moving it trades misses against 
false alarms rather than reducing both.

Course-own diagram after Green and Swets (1966).

<!-- PDF 页 11 -->

The same evidence, two criteria

Lecture 04 · Signal detection

Changing the criterion changes the errors, not the underlying evidence.

• The same overlapping hazard and no-hazard 

distributions appear in both panels. Their shape 
is illustrative, not measured.

• A cautious criterion gives fewer false alarms 

but more misses. An eager criterion gives fewer 
misses but more false alarms.

• Improving the sensor or model can improve 
sensitivity. Moving the decision line alone 
cannot separate the distributions.

Course-own schematic; the curves are illustrative, not measured.

<!-- PDF 页 12 -->

A collision warning at three criteria

Lecture 04 · Worked example

A higher hit rate can bring a costly increase in false alarms.

• These invented teaching numbers use the 

same sensor at cautious, balanced and eager 
criteria. They are not observations of a real 
warning system.

• Moving from cautious to eager gains 18 hits per 
100 hazards while false alarms rise from 2 to 60 
per 100 driving hours, a thirtyfold increase.

• Judge both error costs: frequent false alarms can 
make drivers less willing to respond, reducing the 
warning’s practical benefit.

Invented teaching data; the behavioural interpretations are hypotheses, not measured outcomes.

<!-- PDF 页 13 -->

Cry wolf: what false alarms do over time

Lecture 04 · Worked example

Repeated false alarms can weaken responses to later warnings.

• The cry-wolf effect describes reduced 

responsiveness when alarms prove unreliable 
(Breznitz, 1984). People learn what a warning is 
worth attending to.

• The two curves show a qualitative tendency, 
not measured data or a guaranteed decrease 
after every false alarm.

• Evaluate the system’s hit rate alongside 

people’s responses over time. A false alarm 
can affect the usefulness of future warnings.

After Breznitz (1984). Qualitative schematic, not data or a deterministic response law.

<!-- PDF 页 14 -->

Every threshold is a criterion

Lecture 04 · Application

A threshold makes a decision whose errors have human costs.

• Wake words, classifier confidence cut-offs 
and retrieval scores all determine whether 
evidence is sufficient for a response.

• Planning/action adds act, ask or wait; feedback
adds warn or stay quiet. Define the event being 
detected before naming a miss or false alarm.

• For each threshold, distinguish sensitivity from 
criterion and explain whose costs justify the 
setting, as you will in sensing and evaluation.

Course applications: define the detected event before classifying errors. Current links: sensing Week 7; 
evaluation Week 10.

<!-- PDF 页 15 -->

Your turn: set the criterion for three systems

Lecture 04 · Interaction 2

Set each criterion by comparing the cost of both errors.

• For A, a smoke alarm in a student kitchen, 

compare a missed fire with nuisance alarms and 
their consequences.

• For B, a spelling suggestion, compare an 

unnoticed typo with an unnecessary underline. 
For C, consider an agent asking ‘are you sure?’
before a risky email.

• Take two minutes to place A, B and C on the 

cautious-to-eager scale. Write one sentence per 
system justifying the two costs.

Course-own worksheet.

<!-- PDF 页 16 -->

Cue integration: weighting by reliability

Lecture 04 · Cue integration

In cue integration, more reliable evidence can receive more weight.

• Cue integration means combining sensory 

estimates. Ernst and Banks (2002) found near-
optimal weighting when people judged ridge 
height using sight and touch.

EO1

• In their experiment, the more reliable cue
received more weight, and the combined 
estimate was more precise than either cue alone.

• This connects to sensor fusion. Applying the 

idea to trust in warnings is a design analogy, not 
a universal formula established by that 
experiment.

After Ernst and Banks (2002). Warning-trust extension is an analogy. Sensor fusion is in Week 7; the 
original image says Week 6.

<!-- PDF 页 17 -->

Slide 16

EO1 

You can mention much of our Haptics research, where Visual input is used to modify the haptic rendering.
Eyal Ofek, 2026-09-23T15:42:22.914

<!-- PDF 页 18 -->

Feedback timing: three thresholds

Lecture 04 · Feedback

Acknowledge the action before a slow response leaves people uncertain.

• The approximate 0.1 s, 1 s and 10 s guidelines
describe immediate response, continued flow 
and the limit of sustained attention (Miller, 1968; 
Nielsen, 1993).

• If a model call takes longer, show ‘working on 

it’, a typing indicator or a partial result before the 
final answer.

• Feedback tells people what their action caused 

(Norman, 2013). Silence or a late 
acknowledgement can leave them uncertain or 
attending elsewhere.

Approximate response-time guidelines: Miller (1968); Nielsen (1993). Feedback: Norman (2013).

<!-- PDF 页 19 -->

Feedback modality: which channel?

Lecture 04 · Feedback

Choose a feedback modality that fits the task and the person.

• Foveal visual feedback carries detail where 
people are looking. Peripheral changes can 
attract attention, but small static cues are easier 
to miss.

• Non-speech sound can acknowledge quickly 

but competes with other sounds. Speech carries 
meaning and competes with verbal tasks.

• Haptic feedback uses touch for discreet 

confirmation when the device is in contact. 
Combine channel choice with error costs and 
timely feedback (Norman, 2013).

Course-own table. Multiple resources, signal detection and timing combined into a channel choice.

<!-- PDF 页 20 -->

The cost of a late or missing acknowledgement

Lecture 04 · Feedback

Prompt acknowledgement can reduce uncertainty and repeated requests.

• In this hypothetical receipt-filing example, one 
route acknowledges within a second; the other 
remains silent for six seconds.

• During silence, the person wonders ‘did it hear 

me?’, repeats the request and receives a 
duplicate filing. The model’s answer was not the 
cause.

• An early acknowledgement can reduce that risk. 
It does not, by itself, guarantee that the system 
prevents every duplicate action.

Hypothetical timelines. Original plotted positions conflict with the stated timings; the replacement 
follows the narration.

<!-- PDF 页 21 -->

Phase 1: your channel and the cost of a miss

Lecture 04 · Project connection

Specify one important cue and justify how it reaches the user.

• Write six lines: name the message and channel, 
then describe the person’s current task and the 
resources it uses.

• Describe the cost of a miss and the cost of a 

false alarm. Then choose cautious, balanced or 
eager and explain why.

• Spend ten minutes on this unmarked task and 
bring it to Lab 2. It develops Phase 1’s ‘user 
experiences’ slot and your feedback layer.

Six-line unmarked task, ten-minute target. Bring the completed worksheet to Lab 2.

<!-- PDF 页 22 -->

What a person can notice, and how fast

Lecture 04 · Synthesis and bridge

A useful cue must reach attention, support judgement and arrive in time.

• Attention and resources determine whether a 
cue is noticed and how much it competes with 
the current task.

• Detection and integration connect error costs 
with the reliability of the available evidence. 
Repeated false alarms can change responses.

• Give timely feedback, then ask what the person 
can hold in mind. Lecture 05 follows with working 
memory, cognitive load and mental models.

Five principles, followed by Lecture 05. Current warnings/evaluation links are L25/L26, replacing the 
original L31/L32.

<!-- PDF 页 23 -->

References and further reading

Lecture 04 · References

Broadbent, D. E. (1958). Perception and Communication. Pergamon Press.

Simons, D. J., & Chabris, C. F. (1999). Gorillas in our midst: sustained inattentional blindness for dynamic events. 
Perception, 28(9), 1059–1074.

Wickens, C. D. (2002). Multiple resources and performance prediction. Theoretical Issues in Ergonomics Science, 3(2), 
159–177.

Green, D. M., & Swets, J. A. (1966). Signal Detection Theory and Psychophysics. Wiley.

Breznitz, S. (1984). Cry Wolf: The Psychology of False Alarms. Lawrence Erlbaum.

Ernst, M. O., & Banks, M. S. (2002). Humans integrate visual and haptic information in a statistically optimal fashion. 
Nature, 415, 429–433.

Rensink, R. A., O'Regan, J. K., & Clark, J. J. (1997). To see or not to see: the need for attention to perceive changes in 
scenes. Psychological Science, 8(5), 368–373.

Miller, R. B. (1968). Response time in man-computer conversational transactions. AFIPS Fall Joint Computer 
Conference, 267–277.   ·   Nielsen, J. (1993). Usability Engineering. Academic Press.

Norman, D. A. (2013). The Design of Everyday Things (revised and expanded edition). Basic Books, chapter 2.   ·   
LaValle, S. M. (2017). Virtual Reality, chapters 5–6 (previewed).

Full list with verification notes: W02_L04_references.md

Course-own diagram. The sources grouped by what they support.

Use the primary sources to examine the mechanisms 
behind each design rule.

• Start with Simons and Chabris 

(1999) and an introduction to signal 
detection theory.

• The bibliography retains the lecture’s 
sources. W02_L04_references.md
records the verification notes.
