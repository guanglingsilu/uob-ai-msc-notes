# Data Warehouse, Data Lake, Lakehouse

课程：Data-Intensive Artificial Intelligence

## 第 1 页：数据仓库、数据湖与湖仓

Source ID: `src-10cd2be200cb-pdf_page-00001`

![PDF page 1](../assets/pages/page_001.jpg)

### 原文 / Original Text

```text
Data warehouse, data lake, lakehouse

Prof. Paolo Missier
School of Computer Science
University of Birmingham, UK

Data-intensive AI
2026/27 Sem 1
```

### 完整中文翻译

数据仓库、数据湖与湖仓
教授 Paolo Missier
计算机科学学院
伯明翰大学, UK
数据密集型人工智能
2026/27 Sem 1

### 中文释义

本页围绕“Data warehouse, data lake, lakehouse”展开。课件中的关键信息包括：数据仓库、数据湖与湖仓；教授 Paolo Missier；计算机科学学院；伯明翰大学, UK。复习时先抓住数据仓库：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data warehouse, data lake, lakehouse'. The slide includes: Data warehouse, data lake, lakehouse; Prof. Paolo Missier; School of Computer Science; University of Birmingham, UK. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data warehouse / 数据仓库**：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。
- **Data lake / 数据湖**：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
- **Lakehouse / 湖仓一体**：在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。

拓展复习：把“Data warehouse, data lake, lakehouse”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 1 页的核心主题是什么？
**答：** 本页围绕“Data warehouse, data lake, lakehouse”展开。课件中的关键信息包括：数据仓库、数据湖与湖仓；教授 Paolo Missier；计算机科学学院；伯明翰大学, UK。复习时先抓住数据仓库：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 1?
**Answer:** This page presents 'Data warehouse, data lake, lakehouse'. The slide includes: Data warehouse, data lake, lakehouse; Prof. Paolo Missier; School of Computer Science; University of Birmingham, UK. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据仓库 / Data warehouse
**答：** 面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。
**Q2 English:** Explain the concept on this page: Data warehouse
**Answer:** The page focuses on Data warehouse. This page presents 'Data warehouse, data lake, lakehouse'. The slide includes: Data warehouse, data lake, lakehouse; Prof. Paolo Missier; School of Computer Science; University of Birmingham, UK. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

## 第 2 页：本讲内容

Source ID: `src-10cd2be200cb-pdf_page-00002`

![PDF page 2](../assets/pages/page_002.jpg)

### 原文 / Original Text

```text
In this lecture

Data warehouses: ACID-compliant storage optimised for analytics from the ‘80s
Data lakes: storage for structured, semi-structured, and unstructured data

open table formats (Delta Lake, Iceberg, Hudi)

The Medallion architecture: from raw data to an ML-ready training set

Introducing the NYC Taxi dataset

Dataset integration: table unions, joins. What can go wrong?
```

### 完整中文翻译

本讲内容
数据仓库: ACID 事务特性-compliant storage optimised for analytics from the ‘80s
数据湖: storage for structured, semi-structured, and unstructured data
开放表格式 (Delta Lake 湖仓存储层, Iceberg, Hudi)
奖牌架构 分层架构: from raw data to an 机器学习-ready training set
Introducing the NYC Taxi dataset
问题：Dataset integration: table unions, joins. What can go wrong？

### 中文释义

本页围绕“In this lecture”展开。课件中的关键信息包括：本讲内容；数据仓库: ACID 事务特性-compliant storage optimised for analytics from the ‘80s；数据湖: storage for structured, semi-structured, and unstructured data；开放表格式 (Delta Lake 湖仓存储层, Iceberg, Hudi)。复习时先抓住数据仓库：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'In this lecture'. The slide includes: In this lecture; Data warehouses: ACID-compliant storage optimised for analytics from the ‘80s; Data lakes: storage for structured, semi-structured, and unstructured data; open table formats (Delta Lake, Iceberg, Hudi). The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data warehouse / 数据仓库**：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。
- **Data lake / 数据湖**：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
- **Medallion / 奖牌架构**：把数据从 Landing/Bronze 的原始层逐步提升到 Silver 的清洗整合层和 Gold 的可训练/可服务层。
- **Delta Lake / Delta Lake**：Databricks 发起的开放湖仓存储框架，在 Parquet 文件上添加事务日志、更新删除和 ACID 能力。
- **ACID / ACID**：原子性、一致性、隔离性、持久性，用于保证事务操作可靠完成。

拓展复习：把“In this lecture”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 2 页的核心主题是什么？
**答：** 本页围绕“In this lecture”展开。课件中的关键信息包括：本讲内容；数据仓库: ACID 事务特性-compliant storage optimised for analytics from the ‘80s；数据湖: storage for structured, semi-structured, and unstructured data；开放表格式 (Delta Lake 湖仓存储层, Iceberg, Hudi)。复习时先抓住数据仓库：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 2?
**Answer:** This page presents 'In this lecture'. The slide includes: In this lecture; Data warehouses: ACID-compliant storage optimised for analytics from the ‘80s; Data lakes: storage for structured, semi-structured, and unstructured data; open table formats (Delta Lake, Iceberg, Hudi). The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据仓库 / Data warehouse
**答：** 面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。
**Q2 English:** Explain the concept on this page: Data warehouse
**Answer:** The page focuses on Data warehouse. This page presents 'In this lecture'. The slide includes: In this lecture; Data warehouses: ACID-compliant storage optimised for analytics from the ‘80s; Data lakes: storage for structured, semi-structured, and unstructured data; open table formats (Delta Lake, Iceberg, Hudi). The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

## 第 3 页：数据仓库

Source ID: `src-10cd2be200cb-pdf_page-00003`

![PDF page 3](../assets/pages/page_003.jpg)

### 原文 / Original Text

```text
Data Warehouses

Persistent storage for structured data, processed to optimize data analytics workloads

- Structured data (tables)
- Data flow from operational systems to decision support
- On premise or cloud-hosted

Image Credit: https://gem-corp.tech/big-data/etl-in-data-warehouse-the-definitive-guide/
```

### 完整中文翻译

数据仓库
Persistent storage for structured data, processed to optimize data analytics workloads
- Structured data (tables)
- 数据从运营系统流向决策支持系统
- On premise or cloud-hosted
Image Credit: https://gem-corp.tech/big-data/etl-in-data-warehouse-the-definitive-guide/

### 中文释义

本页围绕“Data Warehouses”展开。课件中的关键信息包括：数据仓库；Persistent storage for structured data, processed to optimize data analytics workloads；- Structured data (tables)；- 数据从运营系统流向决策支持系统。复习时先抓住数据仓库：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data Warehouses'. The slide includes: Data Warehouses; Persistent storage for structured data, processed to optimize data analytics workloads; - Structured data (tables); - Data flow from operational systems to decision support. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data warehouse / 数据仓库**：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。

拓展复习：把“Data Warehouses”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 3 页的核心主题是什么？
**答：** 本页围绕“Data Warehouses”展开。课件中的关键信息包括：数据仓库；Persistent storage for structured data, processed to optimize data analytics workloads；- Structured data (tables)；- 数据从运营系统流向决策支持系统。复习时先抓住数据仓库：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 3?
**Answer:** This page presents 'Data Warehouses'. The slide includes: Data Warehouses; Persistent storage for structured data, processed to optimize data analytics workloads; - Structured data (tables); - Data flow from operational systems to decision support. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据仓库 / Data warehouse
**答：** 面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。
**Q2 English:** Explain the concept on this page: Data warehouse
**Answer:** The page focuses on Data warehouse. This page presents 'Data Warehouses'. The slide includes: Data Warehouses; Persistent storage for structured data, processed to optimize data analytics workloads; - Structured data (tables); - Data flow from operational systems to decision support. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

## 第 4 页：数据仓库: Features and Players

Source ID: `src-10cd2be200cb-pdf_page-00004`

![PDF page 4](../assets/pages/page_004.jpg)

### 原文 / Original Text

```text
Data Warehouses: Features and Players

Feature

What does it mean?

Query performance

Columnar storage, pre-computed aggregations, materialised views, cost-based query 
optimisation

ACID transactions

Full atomicity, consistency, isolation, and durability guarantees on all operations

Data quality enforcement

Schema constraints (NOT NULL, CHECK, FOREIGN KEY) enforced at load time

SQL compatibility

Mature, standardised query interface; wide tooling support

Governance and lineage

Centralised metadata catalogue; clear provenance from source to report

Concurrent access

Multi-version concurrency control (MVCC) supports many simultaneous readers and 
writers

Major commercial players:
Snowflake, Google BigQuery, Amazon Redshift
```

### 完整中文翻译

数据仓库: Features and Players
特征
问题：What does it mean？
Query performance
列式 storage, pre-computed aggregations, materialised views, cost-based query
optimisation
ACID 事务特性 transactions
Full atomicity, consistency, isolation, and durability guarantees on all operations
数据质量 enforcement
模式/表结构 constraints (NOT 空值, CHECK, FOREIGN KEY) enforced at load time
SQL compatibility
Mature, standardised query interface; wide tooling support
Governance and lineage
Centralised metadata catalogue; clear provenance from source to report
Concurrent access
Multi-version concurrency control (MVCC) supports many simultaneous readers and
writers
Major commercial players:
Snowflake, Google BigQuery, Amazon Redshift

### 中文释义

本页围绕“Data Warehouses: Features and Players”展开。课件中的关键信息包括：数据仓库: Features and Players；特征；问题：What does it mean？；Query performance。复习时先抓住数据仓库：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data Warehouses: Features and Players'. The slide includes: Data Warehouses: Features and Players; Feature; What does it mean?; Query performance. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data warehouse / 数据仓库**：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。
- **ACID / ACID**：原子性、一致性、隔离性、持久性，用于保证事务操作可靠完成。
- **Schema / 模式**：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。
- **MNAR / 非随机缺失**：缺失本身携带信息，可能与未观测值或特定人群/事件有关。

拓展复习：把“Data Warehouses: Features and Players”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 4 页的核心主题是什么？
**答：** 本页围绕“Data Warehouses: Features and Players”展开。课件中的关键信息包括：数据仓库: Features and Players；特征；问题：What does it mean？；Query performance。复习时先抓住数据仓库：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 4?
**Answer:** This page presents 'Data Warehouses: Features and Players'. The slide includes: Data Warehouses: Features and Players; Feature; What does it mean?; Query performance. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据仓库 / Data warehouse
**答：** 面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。
**Q2 English:** Explain the concept on this page: Data warehouse
**Answer:** The page focuses on Data warehouse. This page presents 'Data Warehouses: Features and Players'. The slide includes: Data Warehouses: Features and Players; Feature; What does it mean?; Query performance. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

## 第 5 页：ACID 事务特性 transactions. -- look it up!

Source ID: `src-10cd2be200cb-pdf_page-00005`

![PDF page 5](../assets/pages/page_005.jpg)

### 原文 / Original Text

```text
ACID transactions. -- look it up!

Try: “basics of ACID transaction management”

• Atomicity
• Consistency
• Isolation
• Durability

https://www.datacamp.com/blog/acid-transactions
https://www.databricks.com/blog/what-are-acid-transactions

Classic examples:
- Reserving a seat
- Transferring funds between bank accounts
```

### 完整中文翻译

ACID 事务特性 transactions. -- look it up!
Try: “basics of ACID 事务特性 transaction management”
• Atomicity
• Consistency
• Isolation
• Durability
参考链接：https://www.datacamp.com/blog/acid-transactions
参考链接：https://www.databricks.com/blog/what-are-acid-transactions
Classic examples:
- Reserving a seat
- Transferring funds between bank accounts

### 中文释义

本页围绕“ACID transactions. -- look it up!”展开。课件中的关键信息包括：ACID 事务特性 transactions. -- look it up!；Try: “basics of ACID 事务特性 transaction management”；• Atomicity；• Consistency。复习时先抓住ACID：原子性、一致性、隔离性、持久性，用于保证事务操作可靠完成。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'ACID transactions. -- look it up!'. The slide includes: ACID transactions. -- look it up!; Try: “basics of ACID transaction management”; • Atomicity; • Consistency. The revision focus is ACID; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **ACID / ACID**：原子性、一致性、隔离性、持久性，用于保证事务操作可靠完成。

拓展复习：把“ACID transactions. -- look it up!”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 5 页的核心主题是什么？
**答：** 本页围绕“ACID transactions. -- look it up!”展开。课件中的关键信息包括：ACID 事务特性 transactions. -- look it up!；Try: “basics of ACID 事务特性 transaction management”；• Atomicity；• Consistency。复习时先抓住ACID：原子性、一致性、隔离性、持久性，用于保证事务操作可靠完成。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 5?
**Answer:** This page presents 'ACID transactions. -- look it up!'. The slide includes: ACID transactions. -- look it up!; Try: “basics of ACID transaction management”; • Atomicity; • Consistency. The revision focus is ACID; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：ACID / ACID
**答：** 原子性、一致性、隔离性、持久性，用于保证事务操作可靠完成。
**Q2 English:** Explain the concept on this page: ACID
**Answer:** The page focuses on ACID. This page presents 'ACID transactions. -- look it up!'. The slide includes: ACID transactions. -- look it up!; Try: “basics of ACID transaction management”; • Atomicity; • Consistency. The revision focus is ACID; connect its definition, evidence, and use to the examples on the page.

## 第 6 页：数据仓库: limitations

Source ID: `src-10cd2be200cb-pdf_page-00006`

![PDF page 6](../assets/pages/page_006.jpg)

### 原文 / Original Text

```text
Data warehouse: limitations

1. Schema rigidity:

Schema-on-write makes it difficult to accommodate schema evolution. 

Upgrading schema and ETL pipeline is expensive

2. Data type restriction. Cannot store semi-structured and unstructured data natively

3. Coupling of storage and compute. Expensive to scale up

4. Data is stored in proprietary formats with an SQL access path

Accessing data with non-SQL tools requires expensive data transformation

5. Batch updates. New data not immediately available

6. Processed data unsuitable for ML/AI applications

pre-aggregated “OLAP cubes” are good for analytics but not as training sets
```

### 完整中文翻译

数据仓库: limitations
1. 模式/表结构 rigidity:
写时定义模式 makes it difficult to accommodate 模式/表结构 evolution.
Upgrading 模式/表结构 and ETL pipeline is expensive
2. Data type restriction. Cannot store semi-structured and unstructured data natively
3. Coupling of storage and compute. Expensive to scale up
4. Data is stored in proprietary formats with an SQL access path
Accessing data with non-SQL tools requires expensive data transformation
5. Batch updates. New data not immediately available
6. Processed data unsuitable for 机器学习/AI applications
pre-aggregated “OLAP cubes” are good for analytics but not as training sets

### 中文释义

本页围绕“Data warehouse: limitations”展开。课件中的关键信息包括：数据仓库: limitations；1. 模式/表结构 rigidity:；写时定义模式 makes it difficult to accommodate 模式/表结构 evolution.；Upgrading 模式/表结构 and ETL pipeline is expensive。复习时先抓住数据仓库：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data warehouse: limitations'. The slide includes: Data warehouse: limitations; 1. Schema rigidity:; Schema-on-write makes it difficult to accommodate schema evolution.; Upgrading schema and ETL pipeline is expensive. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data warehouse / 数据仓库**：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。
- **Schema / 模式**：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。

拓展复习：把“Data warehouse: limitations”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 6 页的核心主题是什么？
**答：** 本页围绕“Data warehouse: limitations”展开。课件中的关键信息包括：数据仓库: limitations；1. 模式/表结构 rigidity:；写时定义模式 makes it difficult to accommodate 模式/表结构 evolution.；Upgrading 模式/表结构 and ETL pipeline is expensive。复习时先抓住数据仓库：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 6?
**Answer:** This page presents 'Data warehouse: limitations'. The slide includes: Data warehouse: limitations; 1. Schema rigidity:; Schema-on-write makes it difficult to accommodate schema evolution.; Upgrading schema and ETL pipeline is expensive. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据仓库 / Data warehouse
**答：** 面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。
**Q2 English:** Explain the concept on this page: Data warehouse
**Answer:** The page focuses on Data warehouse. This page presents 'Data warehouse: limitations'. The slide includes: Data warehouse: limitations; 1. Schema rigidity:; Schema-on-write makes it difficult to accommodate schema evolution.; Upgrading schema and ETL pipeline is expensive. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

## 第 7 页：数据湖

Source ID: `src-10cd2be200cb-pdf_page-00007`

![PDF page 7](../assets/pages/page_007.jpg)

### 原文 / Original Text

```text
Data Lakes

Format heterogeneity. Data stored in native format
•
structured (CSV, Parquet), semi-structured (JSON)
• unstructured (text, images, video, sensor streams)

Schema-on-read
• Structure not known at ingestion time. 
• Discovered at query time by the application

Decoupled storage and compute —
- storage layer independent of the compute layer. They can scale independently

HDFS, Amazon S3. -->  Spark, Hive 

Read-only: processed data is not stored back into a data lake
```

### 完整中文翻译

数据湖
Format heterogeneity. Data stored in native format
•
structured (CSV, Parquet 列式文件格式), semi-structured (JSON)
• unstructured (text, images, video, sensor streams)
读时定义模式
• Structure not known at ingestion time.
• Discovered at query time by the application
Decoupled storage and compute —
- storage layer independent of the compute layer. They can scale independently
HDFS, Amazon S3. --> Spark, Hive
Read-only: processed data is not stored back into a 数据湖

### 中文释义

本页围绕“Data Lakes”展开。课件中的关键信息包括：数据湖；Format heterogeneity. Data stored in native format；•；structured (CSV, Parquet 列式文件格式), semi-structured (JSON)。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data Lakes'. The slide includes: Data Lakes; Format heterogeneity. Data stored in native format; •; structured (CSV, Parquet), semi-structured (JSON). The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data lake / 数据湖**：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
- **Parquet / Parquet**：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。
- **Schema / 模式**：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。

拓展复习：把“Data Lakes”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 7 页的核心主题是什么？
**答：** 本页围绕“Data Lakes”展开。课件中的关键信息包括：数据湖；Format heterogeneity. Data stored in native format；•；structured (CSV, Parquet 列式文件格式), semi-structured (JSON)。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 7?
**Answer:** This page presents 'Data Lakes'. The slide includes: Data Lakes; Format heterogeneity. Data stored in native format; •; structured (CSV, Parquet), semi-structured (JSON). The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据湖 / Data lake
**答：** 保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
**Q2 English:** Explain the concept on this page: Data lake
**Answer:** The page focuses on Data lake. This page presents 'Data Lakes'. The slide includes: Data Lakes; Format heterogeneity. Data stored in native format; •; structured (CSV, Parquet), semi-structured (JSON). The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

## 第 8 页：The Data and AI maturity curve

Source ID: `src-10cd2be200cb-pdf_page-00008`

![PDF page 8](../assets/pages/page_008.jpg)

### 原文 / Original Text

```text
The Data and AI maturity curve
```

### 完整中文翻译

The Data and AI maturity curve

### 中文释义

本页围绕“The Data and AI maturity curve”展开。课件中的关键信息包括：The Data and AI maturity curve。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'The Data and AI maturity curve'. The slide includes: The Data and AI maturity curve. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“The Data and AI maturity curve”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 8 页的核心主题是什么？
**答：** 本页围绕“The Data and AI maturity curve”展开。课件中的关键信息包括：The Data and AI maturity curve。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 8?
**Answer:** This page presents 'The Data and AI maturity curve'. The slide includes: The Data and AI maturity curve. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'The Data and AI maturity curve'. The slide includes: The Data and AI maturity curve. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

## 第 9 页：Key Design Principles of a 数据湖

Source ID: `src-10cd2be200cb-pdf_page-00009`

![PDF page 9](../assets/pages/page_009.jpg)

### 原文 / Original Text

```text
Key Design Principles of a Data Lake

1.

Immutability of raw data
•
•

Raw files are written once and never overwritten.
If a cleaning step is found to be wrong later, you reprocess from the raw zone

2. Partitioning for query efficiency
Files are organised in a directory hierarchy that maps 
to the most common query predicates:
```

### 完整中文翻译

Key Design Principles of a 数据湖
1.
Immutability of raw data
•
•
Raw files are written once and never overwritten.
If a cleaning step is found to be wrong later, you reprocess from the raw zone
2. Partitioning for query 效率
Files are organised in a directory hierarchy that maps
to the most common query predicates:

### 中文释义

本页围绕“Key Design Principles of a Data Lake”展开。课件中的关键信息包括：Key Design Principles of a 数据湖；1.；Immutability of raw data；•。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Key Design Principles of a Data Lake'. The slide includes: Key Design Principles of a Data Lake; 1.; Immutability of raw data; •. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data lake / 数据湖**：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
- **partition / 分区**：把数据切分到不同 worker；分区均衡决定分布式任务是否会卡在慢节点。

拓展复习：把“Key Design Principles of a Data Lake”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 9 页的核心主题是什么？
**答：** 本页围绕“Key Design Principles of a Data Lake”展开。课件中的关键信息包括：Key Design Principles of a 数据湖；1.；Immutability of raw data；•。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 9?
**Answer:** This page presents 'Key Design Principles of a Data Lake'. The slide includes: Key Design Principles of a Data Lake; 1.; Immutability of raw data; •. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据湖 / Data lake
**答：** 保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
**Q2 English:** Explain the concept on this page: Data lake
**Answer:** The page focuses on Data lake. This page presents 'Key Design Principles of a Data Lake'. The slide includes: Key Design Principles of a Data Lake; 1.; Immutability of raw data; •. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

## 第 10 页：Key Design Principles of a 数据湖

Source ID: `src-10cd2be200cb-pdf_page-00010`

![PDF page 10](../assets/pages/page_010.jpg)

### 原文 / Original Text

```text
Key Design Principles of a Data Lake

3. Open file formats
• Parquet (columnar, compressed), Delta Lake

• Data becomes portable across implementations

https://www.databricks.com/blog/what-is-parquet

4. Columnar storage
• Only the columns needed by a query are read (column pruning)
• Optimises aggregation over all values in a column allows Spark to read only the columns 

needed by a query

• Using pre-computed column statistics (min/max per row group), row groups that cannot 

satisfy a filter can be skipped (predicate pushdown)

5. Compression (Snappy, Zstandard) reduces both storage cost and network transfer time when 
data moves between storage and executors
```

### 完整中文翻译

Key Design Principles of a 数据湖
3. Open file formats
• Parquet 列式文件格式 (列式, compressed), Delta Lake 湖仓存储层
• Data becomes portable across implementations
参考链接：https://www.databricks.com/blog/what-is-parquet
4. 列式 storage
• Only the columns needed by a query are read (column pruning)
• Optimises aggregation over all values in a column allows Spark to read only the columns
needed by a query
• Using pre-computed column statistics (min/max per row group), row groups that cannot
satisfy a filter can be skipped (predicate pushdown)
5. Compression (Snappy, Zstandard) reduces both storage cost and network transfer time when
data moves between storage and executors

### 中文释义

本页围绕“Key Design Principles of a Data Lake”展开。课件中的关键信息包括：Key Design Principles of a 数据湖；3. Open file formats；• Parquet 列式文件格式 (列式, compressed), Delta Lake 湖仓存储层；• Data becomes portable across implementations。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Key Design Principles of a Data Lake'. The slide includes: Key Design Principles of a Data Lake; 3. Open file formats; • Parquet (columnar, compressed), Delta Lake; • Data becomes portable across implementations. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data lake / 数据湖**：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
- **Delta Lake / Delta Lake**：Databricks 发起的开放湖仓存储框架，在 Parquet 文件上添加事务日志、更新删除和 ACID 能力。
- **Parquet / Parquet**：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。
- **MNAR / 非随机缺失**：缺失本身携带信息，可能与未观测值或特定人群/事件有关。

拓展复习：把“Key Design Principles of a Data Lake”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 10 页的核心主题是什么？
**答：** 本页围绕“Key Design Principles of a Data Lake”展开。课件中的关键信息包括：Key Design Principles of a 数据湖；3. Open file formats；• Parquet 列式文件格式 (列式, compressed), Delta Lake 湖仓存储层；• Data becomes portable across implementations。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 10?
**Answer:** This page presents 'Key Design Principles of a Data Lake'. The slide includes: Key Design Principles of a Data Lake; 3. Open file formats; • Parquet (columnar, compressed), Delta Lake; • Data becomes portable across implementations. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据湖 / Data lake
**答：** 保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
**Q2 English:** Explain the concept on this page: Data lake
**Answer:** The page focuses on Data lake. This page presents 'Key Design Principles of a Data Lake'. The slide includes: Key Design Principles of a Data Lake; 3. Open file formats; • Parquet (columnar, compressed), Delta Lake; • Data becomes portable across implementations. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

## 第 11 页：列式 data storage: efficient aggregation

Source ID: `src-10cd2be200cb-pdf_page-00011`

![PDF page 11](../assets/pages/page_011.jpg)

### 原文 / Original Text

```text
Columnar data storage: efficient aggregation

Sales:

id

region product

amount

Row-oriented layout (CSV, or a row-store database)

1

2

3

4

5

6

EU

US

EU

US

EU

US

A

B

A

C

B

A

10

20

30

40

50

60

[1,EU,A,10] [2,US,B,20] [3,EU,A,30] [4,US,C,40] [5,EU,B,50] [6,US,A,60]

Columnar layout (Parquet)
id: 
region: 
product:  [A, B, A, C, B, A]
amount:  [10, 20, 30, 40, 50, 60]

[1, 2, 3, 4, 5, 6]
[EU, US, EU, US, EU, US]

Query: SELECT SUM(amount) FROM sales

How do you compute the result given each of the two layouts?

1. Row layout: 

Scan each row / retrieve amount / add  --> read 6x4 values, 
used 6.  75% of the reads are never used

2. Column layout: 

Scan amount column / add  --> read 6 values, used 6
```

### 完整中文翻译

列式 data storage: efficient aggregation
Sales:
id
region product
amount
Row-oriented layout (CSV, or a row-store database)
1
2
3
4
5
6
EU
US
EU
US
EU
US
A
B
A
C
B
A
10
20
30
40
50
60
[1,EU,A,10] [2,US,B,20] [3,EU,A,30] [4,US,C,40] [5,EU,B,50] [6,US,A,60]
列式 layout (Parquet 列式文件格式)
id:
region:
product: [A, B, A, C, B, A]
amount: [10, 20, 30, 40, 50, 60]
[1, 2, 3, 4, 5, 6]
[EU, US, EU, US, EU, US]
Query: SELECT SUM(amount) FROM sales
问题：How do you compute the result given each of the two layouts？
1. Row layout:
Scan each row / retrieve amount / add --> read 6x4 values,
used 6. 75% of the reads are never used
2. Column layout:
Scan amount column / add --> read 6 values, used 6

### 中文释义

本页围绕“Columnar data storage: efficient aggregation”展开。课件中的关键信息包括：列式 data storage: efficient aggregation；Sales:；id；region product。复习时先抓住Parquet：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Columnar data storage: efficient aggregation'. The slide includes: Columnar data storage: efficient aggregation; Sales:; id; region product. The revision focus is Parquet; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Parquet / Parquet**：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。
- **MNAR / 非随机缺失**：缺失本身携带信息，可能与未观测值或特定人群/事件有关。

拓展复习：把“Columnar data storage: efficient aggregation”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 11 页的核心主题是什么？
**答：** 本页围绕“Columnar data storage: efficient aggregation”展开。课件中的关键信息包括：列式 data storage: efficient aggregation；Sales:；id；region product。复习时先抓住Parquet：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 11?
**Answer:** This page presents 'Columnar data storage: efficient aggregation'. The slide includes: Columnar data storage: efficient aggregation; Sales:; id; region product. The revision focus is Parquet; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：Parquet / Parquet
**答：** 列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。
**Q2 English:** Explain the concept on this page: Parquet
**Answer:** The page focuses on Parquet. This page presents 'Columnar data storage: efficient aggregation'. The slide includes: Columnar data storage: efficient aggregation; Sales:; id; region product. The revision focus is Parquet; connect its definition, evidence, and use to the examples on the page.

## 第 12 页：列式 data storage: efficient filtering

Source ID: `src-10cd2be200cb-pdf_page-00012`

![PDF page 12](../assets/pages/page_012.jpg)

### 原文 / Original Text

```text
Columnar data storage: efficient filtering 

id region product

amount

1

EU

2 US

3

EU

4 US

5

EU

6 US

A

B

A

C

B

A

10

20

30

40

50

60

Group stats
amount

- Parquet splits the data into row groups
- Stores min/max statistics per column chunk in the file 

footer

min max

10

40

30

60

Query: SELECT * FROM sales WHERE amount > 35

How do you compute the result given each of the two layouts?

1. Row layout: 

Scan each row / if amount > 35, add to result

2. Column layout: 

Consult group stats for amount / Select group 2 (rows 4-6)
Add all rows in group to result
```

### 完整中文翻译

列式 data storage: efficient filtering
id region product
amount
1
EU
2 US
3
EU
4 US
5
EU
6 US
A
B
A
C
B
A
10
20
30
40
50
60
Group stats
amount
- Parquet 列式文件格式 splits the data into row groups
- Stores min/max statistics per column chunk in the file
footer
min max
10
40
30
60
Query: SELECT * FROM sales WHERE amount > 35
问题：How do you compute the result given each of the two layouts？
1. Row layout:
Scan each row / if amount > 35, add to result
2. Column layout:
Consult group stats for amount / Select group 2 (rows 4-6)
Add all rows in group to result

### 中文释义

本页围绕“Columnar data storage: efficient filtering”展开。课件中的关键信息包括：列式 data storage: efficient filtering；id region product；amount；1。复习时先抓住Parquet：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Columnar data storage: efficient filtering'. The slide includes: Columnar data storage: efficient filtering; id region product; amount; 1. The revision focus is Parquet; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Parquet / Parquet**：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。
- **MNAR / 非随机缺失**：缺失本身携带信息，可能与未观测值或特定人群/事件有关。

拓展复习：把“Columnar data storage: efficient filtering”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 12 页的核心主题是什么？
**答：** 本页围绕“Columnar data storage: efficient filtering”展开。课件中的关键信息包括：列式 data storage: efficient filtering；id region product；amount；1。复习时先抓住Parquet：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 12?
**Answer:** This page presents 'Columnar data storage: efficient filtering'. The slide includes: Columnar data storage: efficient filtering; id region product; amount; 1. The revision focus is Parquet; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：Parquet / Parquet
**答：** 列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。
**Q2 English:** Explain the concept on this page: Parquet
**Answer:** The page focuses on Parquet. This page presents 'Columnar data storage: efficient filtering'. The slide includes: Columnar data storage: efficient filtering; id region product; amount; 1. The revision focus is Parquet; connect its definition, evidence, and use to the examples on the page.

## 第 13 页：列式 data storage: combined benefits

Source ID: `src-10cd2be200cb-pdf_page-00013`

![PDF page 13](../assets/pages/page_013.jpg)

### 原文 / Original Text

```text
Columnar data storage: combined benefits

Query:  SELECT SUM(amount) FROM sales WHERE amount > 35

id

region product

amount

1

2

3

4

5

6

EU

US

EU

US

EU

US

A

B

A

C

B

A

10

20

30

40

50

60

Group stats
amount

min max

10

40

30

60

Exercise:
show how this combined query is executed on a columnar store
```

### 完整中文翻译

列式 data storage: combined benefits
Query: SELECT SUM(amount) FROM sales WHERE amount > 35
id
region product
amount
1
2
3
4
5
6
EU
US
EU
US
EU
US
A
B
A
C
B
A
10
20
30
40
50
60
Group stats
amount
min max
10
40
30
60
Exercise:
show how this combined query is executed on a 列式 store

### 中文释义

本页围绕“Columnar data storage: combined benefits”展开。课件中的关键信息包括：列式 data storage: combined benefits；Query: SELECT SUM(amount) FROM sales WHERE amount > 35；id；region product。复习时先抓住非随机缺失：缺失本身携带信息，可能与未观测值或特定人群/事件有关。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Columnar data storage: combined benefits'. The slide includes: Columnar data storage: combined benefits; Query:  SELECT SUM(amount) FROM sales WHERE amount > 35; id; region product. The revision focus is MNAR; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **MNAR / 非随机缺失**：缺失本身携带信息，可能与未观测值或特定人群/事件有关。

拓展复习：把“Columnar data storage: combined benefits”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 13 页的核心主题是什么？
**答：** 本页围绕“Columnar data storage: combined benefits”展开。课件中的关键信息包括：列式 data storage: combined benefits；Query: SELECT SUM(amount) FROM sales WHERE amount > 35；id；region product。复习时先抓住非随机缺失：缺失本身携带信息，可能与未观测值或特定人群/事件有关。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 13?
**Answer:** This page presents 'Columnar data storage: combined benefits'. The slide includes: Columnar data storage: combined benefits; Query:  SELECT SUM(amount) FROM sales WHERE amount > 35; id; region product. The revision focus is MNAR; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：非随机缺失 / MNAR
**答：** 缺失本身携带信息，可能与未观测值或特定人群/事件有关。
**Q2 English:** Explain the concept on this page: MNAR
**Answer:** The page focuses on MNAR. This page presents 'Columnar data storage: combined benefits'. The slide includes: Columnar data storage: combined benefits; Query:  SELECT SUM(amount) FROM sales WHERE amount > 35; id; region product. The revision focus is MNAR; connect its definition, evidence, and use to the examples on the page.

## 第 14 页：Key Design Principles of a 数据湖

Source ID: `src-10cd2be200cb-pdf_page-00014`

![PDF page 14](../assets/pages/page_014.jpg)

### 原文 / Original Text

```text
Key Design Principles of a Data Lake

5. Metadata and governance
• A data lake without a catalogue is a data swamp
• Data lakes use a metastore (Apache Hive Metastore, AWS Glue Data Catalog, Unity Catalog) 

to record:

•

tables, their schema, their partition layout

6. Separation of compute and storage
• Compute cluster can be shut down between jobs 

without losing data
(Spark) workers have no persistent state

•
```

### 完整中文翻译

Key Design Principles of a 数据湖
5. Metadata and governance
• A 数据湖 without a catalogue is a data swamp
• 数据湖 use a metastore (Apache Hive Metastore, AWS Glue Data Catalog, Unity Catalog)
to record:
•
tables, their 模式/表结构, their 分区 layout
6. Separation of compute and storage
• Compute cluster can be shut down between jobs
without losing data
(Spark) workers have no persistent state
•

### 中文释义

本页围绕“Key Design Principles of a Data Lake”展开。课件中的关键信息包括：Key Design Principles of a 数据湖；5. Metadata and governance；• A 数据湖 without a catalogue is a data swamp；• 数据湖 use a metastore (Apache Hive Metastore, AWS Glue Data Catalog, Unity Catalog)。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Key Design Principles of a Data Lake'. The slide includes: Key Design Principles of a Data Lake; 5. Metadata and governance; • A data lake without a catalogue is a data swamp; • Data lakes use a metastore (Apache Hive Metastore, AWS Glue Data Catalog, Unity Catalog). The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data lake / 数据湖**：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
- **Schema / 模式**：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。
- **partition / 分区**：把数据切分到不同 worker；分区均衡决定分布式任务是否会卡在慢节点。

拓展复习：把“Key Design Principles of a Data Lake”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 14 页的核心主题是什么？
**答：** 本页围绕“Key Design Principles of a Data Lake”展开。课件中的关键信息包括：Key Design Principles of a 数据湖；5. Metadata and governance；• A 数据湖 without a catalogue is a data swamp；• 数据湖 use a metastore (Apache Hive Metastore, AWS Glue Data Catalog, Unity Catalog)。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 14?
**Answer:** This page presents 'Key Design Principles of a Data Lake'. The slide includes: Key Design Principles of a Data Lake; 5. Metadata and governance; • A data lake without a catalogue is a data swamp; • Data lakes use a metastore (Apache Hive Metastore, AWS Glue Data Catalog, Unity Catalog). The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据湖 / Data lake
**答：** 保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
**Q2 English:** Explain the concept on this page: Data lake
**Answer:** The page focuses on Data lake. This page presents 'Key Design Principles of a Data Lake'. The slide includes: Key Design Principles of a Data Lake; 5. Metadata and governance; • A data lake without a catalogue is a data swamp; • Data lakes use a metastore (Apache Hive Metastore, AWS Glue Data Catalog, Unity Catalog). The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

## 第 15 页：数据湖: 总结 of Features and Strengths

Source ID: `src-10cd2be200cb-pdf_page-00015`

![PDF page 15](../assets/pages/page_015.jpg)

### 原文 / Original Text

```text
Data Lakes: Summary of Features and Strengths

Feature

Elastic scale

Cost efficiency

What it means

Storage (S3, ADLS) scales to exabytes; compute (Spark clusters) 
scales independently

Object store pricing (~$0.02/GB/month) is orders of magnitude 
cheaper than warehouse storage

ML and AI workload support

columnar Parquet files are natively consumed by Machine Learning 
libraries

Preservation of raw data

The original data is preserved, enabling re-processing when required

Open formats

Same files can be queried by Spark and other processors — no 
vendor lock-in
```

### 完整中文翻译

数据湖: 总结 of Features and Strengths
特征
Elastic scale
Cost 效率
What it means
Storage (S3, ADLS) scales to exabytes; compute (Spark clusters)
scales independently
Object store pricing (~$0.02/GB/month) is orders of magnitude
cheaper than warehouse storage
机器学习 and AI workload support
列式 Parquet 列式文件格式 files are natively consumed by 机器学习
libraries
Preservation of raw data
The original data is preserved, enabling re-processing when required
Open formats
Same files can be queried by Spark and other processors — no
vendor lock-in

### 中文释义

本页围绕“Data Lakes: Summary of Features and Strengths”展开。课件中的关键信息包括：数据湖: 总结 of Features and Strengths；特征；Elastic scale；Cost 效率。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data Lakes: Summary of Features and Strengths'. The slide includes: Data Lakes: Summary of Features and Strengths; Feature; Elastic scale; Cost efficiency. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data lake / 数据湖**：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
- **Parquet / Parquet**：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。
- **MAR / 随机缺失**：缺失与其他可观测变量有关，但不直接由缺失值本身决定。
- **MNAR / 非随机缺失**：缺失本身携带信息，可能与未观测值或特定人群/事件有关。

拓展复习：把“Data Lakes: Summary of Features and Strengths”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 15 页的核心主题是什么？
**答：** 本页围绕“Data Lakes: Summary of Features and Strengths”展开。课件中的关键信息包括：数据湖: 总结 of Features and Strengths；特征；Elastic scale；Cost 效率。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 15?
**Answer:** This page presents 'Data Lakes: Summary of Features and Strengths'. The slide includes: Data Lakes: Summary of Features and Strengths; Feature; Elastic scale; Cost efficiency. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据湖 / Data lake
**答：** 保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
**Q2 English:** Explain the concept on this page: Data lake
**Answer:** The page focuses on Data lake. This page presents 'Data Lakes: Summary of Features and Strengths'. The slide includes: Data Lakes: Summary of Features and Strengths; Feature; Elastic scale; Cost efficiency. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

## 第 16 页：数据湖: Limitations and Risks

Source ID: `src-10cd2be200cb-pdf_page-00016`

![PDF page 16](../assets/pages/page_016.jpg)

### 原文 / Original Text

```text
Data Lakes: Limitations and Risks

Risk

Data swamp

Schema drift

Small-file problem

Description
Files accumulate with no schema 
documentation or ownership

Mitigation
Mandatory metadata registration 
at ingest

A source system changes a column name or 
type; downstream jobs silently break or 
produce wrong results
Errors are only detected late – at query time

Many tiny files (e.g., one Parquet per hour) 
degrade Spark read performance 
catastrophically

Schema-on-read validation

Periodic compaction jobs; target 
128 MB–1 GB per file

Read amplification

Unpartitioned tables force full scans even for 
highly selective queries

Design partition keys around the 
most frequent query patterns
```

### 完整中文翻译

数据湖: Limitations and Risks
Risk
Data swamp
模式/表结构 drift
Small-file problem
Description
Files accumulate with no 模式/表结构
documentation or ownership
Mitigation
Mandatory metadata registration
at ingest
A source system changes a column name or
type; downstream jobs silently break or
produce wrong results
Errors are only detected late – at query time
Many tiny files (e.g., one Parquet 列式文件格式 per hour)
degrade Spark read performance
catastrophically
读时定义模式 validation
Periodic compaction jobs; target
128 MB–1 GB per file
Read amplification
Unpartitioned tables force full scans even for
highly selective queries
Design 分区 keys around the
most frequent query patterns

### 中文释义

本页围绕“Data Lakes: Limitations and Risks”展开。课件中的关键信息包括：数据湖: Limitations and Risks；Risk；Data swamp；模式/表结构 drift。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data Lakes: Limitations and Risks'. The slide includes: Data Lakes: Limitations and Risks; Risk; Data swamp; Schema drift. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data lake / 数据湖**：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
- **Parquet / Parquet**：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。
- **Schema / 模式**：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。
- **partition / 分区**：把数据切分到不同 worker；分区均衡决定分布式任务是否会卡在慢节点。

拓展复习：把“Data Lakes: Limitations and Risks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 16 页的核心主题是什么？
**答：** 本页围绕“Data Lakes: Limitations and Risks”展开。课件中的关键信息包括：数据湖: Limitations and Risks；Risk；Data swamp；模式/表结构 drift。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 16?
**Answer:** This page presents 'Data Lakes: Limitations and Risks'. The slide includes: Data Lakes: Limitations and Risks; Risk; Data swamp; Schema drift. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据湖 / Data lake
**答：** 保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
**Q2 English:** Explain the concept on this page: Data lake
**Answer:** The page focuses on Data lake. This page presents 'Data Lakes: Limitations and Risks'. The slide includes: Data Lakes: Limitations and Risks; Risk; Data swamp; Schema drift. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

## 第 17 页：数据湖: Limitations

Source ID: `src-10cd2be200cb-pdf_page-00017`

![PDF page 17](../assets/pages/page_017.jpg)

### 原文 / Original Text

```text
Data Lakes: Limitations

Risk

No ACID 
transaction support

No update or 
delete semantics

What it means
• Concurrent writers to the same dataset can produce partially written, 

inconsistent states. 
•
There is no native mechanism to roll back a failed multi-file write
• Object stores are optimised for append and full-object overwrite.
•

Implementing GDPR-mandated deletion of a specific user's records requires 
rewriting entire Parquet files
```

### 完整中文翻译

数据湖: Limitations
Risk
No ACID 事务特性
transaction support
No update or
delete 语义问题s
What it means
• Concurrent writers to the same dataset can produce partially written,
inconsistent states.
•
There is no native mechanism to roll back a failed multi-file write
• Object stores are optimised for append and full-object overwrite.
•
Implementing GDPR-mandated deletion of a specific user's records requires
rewriting entire Parquet 列式文件格式 files

### 中文释义

本页围绕“Data Lakes: Limitations”展开。课件中的关键信息包括：数据湖: Limitations；Risk；No ACID 事务特性；transaction support。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data Lakes: Limitations'. The slide includes: Data Lakes: Limitations; Risk; No ACID; transaction support. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data lake / 数据湖**：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
- **ACID / ACID**：原子性、一致性、隔离性、持久性，用于保证事务操作可靠完成。
- **Parquet / Parquet**：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。

拓展复习：把“Data Lakes: Limitations”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 17 页的核心主题是什么？
**答：** 本页围绕“Data Lakes: Limitations”展开。课件中的关键信息包括：数据湖: Limitations；Risk；No ACID 事务特性；transaction support。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 17?
**Answer:** This page presents 'Data Lakes: Limitations'. The slide includes: Data Lakes: Limitations; Risk; No ACID; transaction support. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据湖 / Data lake
**答：** 保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
**Q2 English:** Explain the concept on this page: Data lake
**Answer:** The page focuses on Data lake. This page presents 'Data Lakes: Limitations'. The slide includes: Data Lakes: Limitations; Risk; No ACID; transaction support. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

## 第 18 页：数据仓库 vs 数据湖

Source ID: `src-10cd2be200cb-pdf_page-00018`

![PDF page 18](../assets/pages/page_018.jpg)

### 原文 / Original Text

```text
Data warehouses vs data lakes

Property

Data Warehouse

Data Lake

Schema

Schema-on-write (defined before ingest)

Data format

Normalised tables (SQL)

Schema-on-read (defined at query 
time)

Files: Parquet, JSON, CSV, images, 
logs

Who uses it

BI analysts, fixed dashboards

Data scientists, ML engineers

Flexibility

Low — changing schema is expensive

Risk

Low — data is validated at ingest

High — raw data is always 
preserved

High — "data swamp" if 
ungoverned

References:
[1] (data lakehouse book)
https://learn.microsoft.com/en-us/azure/databricks/lakehouse/
```

### 完整中文翻译

数据仓库 vs 数据湖
Property
数据仓库
数据湖
模式/表结构
写时定义模式 (defined before ingest)
Data format
Normalised tables (SQL)
读时定义模式 (defined at query
time)
Files: Parquet 列式文件格式, JSON, CSV, images,
logs
Who uses it
BI analysts, fixed dashboards
Data scientists, 机器学习 engineers
Flexibility
Low — changing 模式/表结构 is expensive
Risk
Low — data is validated at ingest
High — raw data is always
preserved
High — "data swamp" if
ungoverned
References:
[1] (data 湖仓一体 book)
参考链接：https://learn.microsoft.com/en-us/azure/databricks/lakehouse/

### 中文释义

本页围绕“Data warehouses vs data lakes”展开。课件中的关键信息包括：数据仓库 vs 数据湖；Property；数据仓库；数据湖。复习时先抓住数据仓库：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data warehouses vs data lakes'. The slide includes: Data warehouses vs data lakes; Property; Data Warehouse; Data Lake. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data warehouse / 数据仓库**：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。
- **Data lake / 数据湖**：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
- **Lakehouse / 湖仓一体**：在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。
- **Parquet / Parquet**：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。
- **Schema / 模式**：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。

拓展复习：把“Data warehouses vs data lakes”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 18 页的核心主题是什么？
**答：** 本页围绕“Data warehouses vs data lakes”展开。课件中的关键信息包括：数据仓库 vs 数据湖；Property；数据仓库；数据湖。复习时先抓住数据仓库：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 18?
**Answer:** This page presents 'Data warehouses vs data lakes'. The slide includes: Data warehouses vs data lakes; Property; Data Warehouse; Data Lake. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据仓库 / Data warehouse
**答：** 面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。
**Q2 English:** Explain the concept on this page: Data warehouse
**Answer:** The page focuses on Data warehouse. This page presents 'Data warehouses vs data lakes'. The slide includes: Data warehouses vs data lakes; Property; Data Warehouse; Data Lake. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

## 第 19 页：Databricks’ “奖牌架构” reference architecture

Source ID: `src-10cd2be200cb-pdf_page-00019`

![PDF page 19](../assets/pages/page_019.jpg)

### 原文 / Original Text

```text
Databricks’ “Medallion” reference architecture

A medallion architecture is a data design pattern used to logically organize data in a lakehouse, with the goal 
of incrementally and progressively improving the structure and quality of data as it flows through each layer of 
the architecture (from Bronze ⇒ Silver ⇒ Gold layer tables).

Ref: https://www.databricks.com/blog/what-is-medallion-architecture
```

### 完整中文翻译

Databricks’ “奖牌架构” reference architecture
A 奖牌架构 architecture is a data design pattern used to logically organize data in a 湖仓一体, with the goal
of incrementally and progressively improving the structure and quality of data as it flows through each layer of
the architecture (from 铜牌层/原始可追溯层 ⇒ 银牌层/清洗整合层 ⇒ 金牌层/可服务层 layer tables).
参考链接：Ref: https://www.databricks.com/blog/what-is-medallion-architecture

### 中文释义

本页围绕“Databricks’ “Medallion” reference architecture”展开。课件中的关键信息包括：Databricks’ “奖牌架构” reference architecture；A 奖牌架构 architecture is a data design pattern used to logically organize data in a 湖仓一体, with the goal；of incrementally and progressively improving the structure and quality of data as it flows through each layer of；the architecture (from 铜牌层/原始可追溯层 ⇒ 银牌层/清洗整合层 ⇒ 金牌层/可服务层 layer tables).。复习时先抓住湖仓一体：在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Databricks’ “Medallion” reference architecture'. The slide includes: Databricks’ “Medallion” reference architecture; A medallion architecture is a data design pattern used to logically organize data in a lakehouse, with the goal; of incrementally and progressively improving the structure and quality of data as it flows through each layer of; the architecture (from Bronze ⇒ Silver ⇒ Gold layer tables).. The revision focus is Lakehouse; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Lakehouse / 湖仓一体**：在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。
- **Medallion / 奖牌架构**：把数据从 Landing/Bronze 的原始层逐步提升到 Silver 的清洗整合层和 Gold 的可训练/可服务层。

拓展复习：把“Databricks’ “Medallion” reference architecture”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 19 页的核心主题是什么？
**答：** 本页围绕“Databricks’ “Medallion” reference architecture”展开。课件中的关键信息包括：Databricks’ “奖牌架构” reference architecture；A 奖牌架构 architecture is a data design pattern used to logically organize data in a 湖仓一体, with the goal；of incrementally and progressively improving the structure and quality of data as it flows through each layer of；the architecture (from 铜牌层/原始可追溯层 ⇒ 银牌层/清洗整合层 ⇒ 金牌层/可服务层 layer tables).。复习时先抓住湖仓一体：在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 19?
**Answer:** This page presents 'Databricks’ “Medallion” reference architecture'. The slide includes: Databricks’ “Medallion” reference architecture; A medallion architecture is a data design pattern used to logically organize data in a lakehouse, with the goal; of incrementally and progressively improving the structure and quality of data as it flows through each layer of; the architecture (from Bronze ⇒ Silver ⇒ Gold layer tables).. The revision focus is Lakehouse; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：湖仓一体 / Lakehouse
**答：** 在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。
**Q2 English:** Explain the concept on this page: Lakehouse
**Answer:** The page focuses on Lakehouse. This page presents 'Databricks’ “Medallion” reference architecture'. The slide includes: Databricks’ “Medallion” reference architecture; A medallion architecture is a data design pattern used to logically organize data in a lakehouse, with the goal; of incrementally and progressively improving the structure and quality of data as it flows through each layer of; the architecture (from Bronze ⇒ Silver ⇒ Gold layer tables).. The revision focus is Lakehouse; connect its definition, evidence, and use to the examples on the page.

## 第 20 页：Example: the NYC TLC Taxi dataset

Source ID: `src-10cd2be200cb-pdf_page-00020`

![PDF page 20](../assets/pages/page_020.jpg)

### 原文 / Original Text

```text
Example: the NYC TLC Taxi dataset

https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page

Zone

Lake Role

NYC Taxi Artefact

Landing

Transient raw files, exactly as received from the source

Raw .parquet files downloaded from TLC 
CDN

Bronze

Immutable raw copy
read into Spark but never modified

yellow_raw, green_raw, zones
- Delta Table --> files / DataFrames

Silver

Cleaned, integrated (union, join)

Gold

ML-ready, balanced, etc 
fully quality-controlled feature matrix

trips_integrated
- Delta Table --> files / DataFrames

- Delta Table --> files / DataFrames
```

### 完整中文翻译

Example: the NYC TLC Taxi dataset
参考链接：https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page
Zone
Lake Role
NYC Taxi Artefact
Landing
Transient raw files, exactly as received from the source
Raw .Parquet 列式文件格式 files downloaded from TLC
CDN
铜牌层/原始可追溯层
Immutable raw copy
read into Spark but never modified
yellow_raw, green_raw, zones
- Delta Table --> files / DataFrames
银牌层/清洗整合层
Cleaned, integrated (并集/纵向合并, 连接)
金牌层/可服务层
机器学习-ready, balanced, etc
fully quality-controlled 特征 matrix
trips_integrated
- Delta Table --> files / DataFrames
- Delta Table --> files / DataFrames

### 中文释义

本页围绕“Example: the NYC TLC Taxi dataset”展开。课件中的关键信息包括：Example: the NYC TLC Taxi dataset；参考链接：https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page；Zone；Lake Role。复习时先抓住Parquet：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Example: the NYC TLC Taxi dataset'. The slide includes: Example: the NYC TLC Taxi dataset; https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page; Zone; Lake Role. The revision focus is Parquet; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Parquet / Parquet**：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。
- **union / 并集/纵向合并**：把结构兼容的数据表按行合并；如果语义不同，技术上成功也可能训练出错误模型。
- **join / 连接**：按键把表横向组合；键的语义不一致时会产生看似正确但实际错误的数据视图。

拓展复习：把“Example: the NYC TLC Taxi dataset”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 20 页的核心主题是什么？
**答：** 本页围绕“Example: the NYC TLC Taxi dataset”展开。课件中的关键信息包括：Example: the NYC TLC Taxi dataset；参考链接：https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page；Zone；Lake Role。复习时先抓住Parquet：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 20?
**Answer:** This page presents 'Example: the NYC TLC Taxi dataset'. The slide includes: Example: the NYC TLC Taxi dataset; https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page; Zone; Lake Role. The revision focus is Parquet; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：Parquet / Parquet
**答：** 列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。
**Q2 English:** Explain the concept on this page: Parquet
**Answer:** The page focuses on Parquet. This page presents 'Example: the NYC TLC Taxi dataset'. The slide includes: Example: the NYC TLC Taxi dataset; https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page; Zone; Lake Role. The revision focus is Parquet; connect its definition, evidence, and use to the examples on the page.

## 第 21 页：数据湖 + 数据仓库 = “湖仓一体”

Source ID: `src-10cd2be200cb-pdf_page-00021`

![PDF page 21](../assets/pages/page_021.jpg)

### 原文 / Original Text

```text
Data lake + data warehouse = “Lakehouse”

Enable transactional data management features directly on top of object store files

Key insight:
store a transaction log alongside 
data files in the object store itself

Ref: Armbrust, M. et al. (2021). Lakehouse: A new generation of open platforms that unify data warehousing and advanced analytics.CIDR.
```

### 完整中文翻译

数据湖 + 数据仓库 = “湖仓一体”
Enable transactional data management features directly on top of object store files
Key insight:
store a transaction log alongside
data files in the object store itself
Ref: Armbrust, M. et al. (2021). 湖仓一体: A new generation of open platforms that unify data warehousing and advanced analytics.CIDR.

### 中文释义

本页围绕“Data lake + data warehouse = “Lakehouse””展开。课件中的关键信息包括：数据湖 + 数据仓库 = “湖仓一体”；Enable transactional data management features directly on top of object store files；Key insight:；store a transaction log alongside。复习时先抓住数据仓库：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data lake + data warehouse = “Lakehouse”'. The slide includes: Data lake + data warehouse = “Lakehouse”; Enable transactional data management features directly on top of object store files; Key insight:; store a transaction log alongside. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data warehouse / 数据仓库**：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。
- **Data lake / 数据湖**：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
- **Lakehouse / 湖仓一体**：在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。

拓展复习：把“Data lake + data warehouse = “Lakehouse””放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 21 页的核心主题是什么？
**答：** 本页围绕“Data lake + data warehouse = “Lakehouse””展开。课件中的关键信息包括：数据湖 + 数据仓库 = “湖仓一体”；Enable transactional data management features directly on top of object store files；Key insight:；store a transaction log alongside。复习时先抓住数据仓库：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 21?
**Answer:** This page presents 'Data lake + data warehouse = “Lakehouse”'. The slide includes: Data lake + data warehouse = “Lakehouse”; Enable transactional data management features directly on top of object store files; Key insight:; store a transaction log alongside. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据仓库 / Data warehouse
**答：** 面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。
**Q2 English:** Explain the concept on this page: Data warehouse
**Answer:** The page focuses on Data warehouse. This page presents 'Data lake + data warehouse = “Lakehouse”'. The slide includes: Data lake + data warehouse = “Lakehouse”; Enable transactional data management features directly on top of object store files; Key insight:; store a transaction log alongside. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

## 第 22 页：Addressing the limitations: 湖仓一体 capabilities

Source ID: `src-10cd2be200cb-pdf_page-00022`

![PDF page 22](../assets/pages/page_022.jpg)

### 原文 / Original Text

```text
Addressing the limitations: Lakehouse capabilities

Warehouse and Data 
Lake Limitation

Schema rigidity

Addressed by Lakehouse Capability…

Unity Catalog provides lineage, tagging, access control, search
Schema declared in log; violations rejected at commit time
Controlled column additions/renames recorded in log without rewriting data files

Proprietary formats

Delta/Iceberg/Hudi are open-source; any engine can read the Parquet files

No ACID transactions

Optimistic concurrency control on the Delta transaction log

Poor query performance

Data skipping via per-file statistics; Z-ordering; liquid clustering
Per-file min/max statistics in log allow the query engine to skip files that cannot contain 
qualifying rows

Cost at scale

Object store pricing; compute clusters spun up/down on demand

No ML support

Row-level Parquet files directly consumed by ML frameworks; no export step needed
```

### 完整中文翻译

Addressing the limitations: 湖仓一体 capabilities
Warehouse and Data
Lake Limitation
模式/表结构 rigidity
Addressed by 湖仓一体 Capability…
Unity Catalog provides lineage, tagging, access control, search
模式/表结构 declared in log; violations rejected at commit time
Controlled column additions/renames recorded in log without rewriting data files
Proprietary formats
Delta/Iceberg/Hudi are open-source; any engine can read the Parquet 列式文件格式 files
No ACID 事务特性 transactions
Optimistic concurrency control on the Delta transaction log
Poor query performance
Data skipping via per-file statistics; Z 顺序聚簇; liquid 聚类
Per-file min/max statistics in log allow the query engine to skip files that cannot contain
qualifying rows
Cost at scale
Object store pricing; compute clusters spun up/down on demand
No 机器学习 support
Row-level Parquet 列式文件格式 files directly consumed by 机器学习 frameworks; no export step needed

### 中文释义

本页围绕“Addressing the limitations: Lakehouse capabilities”展开。课件中的关键信息包括：Addressing the limitations: 湖仓一体 capabilities；Warehouse and Data；Lake Limitation；模式/表结构 rigidity。复习时先抓住湖仓一体：在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Addressing the limitations: Lakehouse capabilities'. The slide includes: Addressing the limitations: Lakehouse capabilities; Warehouse and Data; Lake Limitation; Schema rigidity. The revision focus is Lakehouse; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Lakehouse / 湖仓一体**：在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。
- **ACID / ACID**：原子性、一致性、隔离性、持久性，用于保证事务操作可靠完成。
- **Parquet / Parquet**：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。
- **Schema / 模式**：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。

拓展复习：把“Addressing the limitations: Lakehouse capabilities”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 22 页的核心主题是什么？
**答：** 本页围绕“Addressing the limitations: Lakehouse capabilities”展开。课件中的关键信息包括：Addressing the limitations: 湖仓一体 capabilities；Warehouse and Data；Lake Limitation；模式/表结构 rigidity。复习时先抓住湖仓一体：在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 22?
**Answer:** This page presents 'Addressing the limitations: Lakehouse capabilities'. The slide includes: Addressing the limitations: Lakehouse capabilities; Warehouse and Data; Lake Limitation; Schema rigidity. The revision focus is Lakehouse; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：湖仓一体 / Lakehouse
**答：** 在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。
**Q2 English:** Explain the concept on this page: Lakehouse
**Answer:** The page focuses on Lakehouse. This page presents 'Addressing the limitations: Lakehouse capabilities'. The slide includes: Addressing the limitations: Lakehouse capabilities; Warehouse and Data; Lake Limitation; Schema rigidity. The revision focus is Lakehouse; connect its definition, evidence, and use to the examples on the page.

## 第 23 页：Delta Lake 湖仓存储层 and Delta 表

Source ID: `src-10cd2be200cb-pdf_page-00023`

![PDF page 23](../assets/pages/page_023.jpg)

### 原文 / Original Text

```text
Delta Lake and Delta Tables

Delta Lake is Databrick’s implementation of a lakehouse
Delta Lake is an open-source storage framework
- originally developed by Databricks and donated to the Linux Foundation in 2019
-

It is a transactional metadata layer on top of standard Apache Parquet files stored in an object store

A Delta table is a table whose data is stored as 
a collection of Parquet files managed by a 
Delta Lake transaction log

From the user's perspective it behaves identically to a standard SQL table
- it has a schema, supports SELECT, INSERT, UPDATE, DELETE, and MERGE
```

### 完整中文翻译

Delta Lake 湖仓存储层 and Delta 表
Delta Lake 湖仓存储层 is Databrick’s implementation of a 湖仓一体
Delta Lake 湖仓存储层 is an open-source storage framework
- originally developed by Databricks and donated to the Linux Foundation in 2019
-
It is a transactional metadata layer on top of standard Apache Parquet 列式文件格式 files stored in an object store
A Delta table is a table whose data is stored as
a collection of Parquet 列式文件格式 files managed by a
Delta Lake 湖仓存储层 transaction log
From the user's perspective it behaves identically to a standard SQL table
- it has a 模式/表结构, supports SELECT, INSERT, UPDATE, DELETE, and MERGE

### 中文释义

本页围绕“Delta Lake and Delta Tables”展开。课件中的关键信息包括：Delta Lake 湖仓存储层 and Delta 表；Delta Lake 湖仓存储层 is Databrick’s implementation of a 湖仓一体；Delta Lake 湖仓存储层 is an open-source storage framework；- originally developed by Databricks and donated to the Linux Foundation in 2019。复习时先抓住湖仓一体：在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Delta Lake and Delta Tables'. The slide includes: Delta Lake and Delta Tables; Delta Lake is Databrick’s implementation of a lakehouse; Delta Lake is an open-source storage framework; - originally developed by Databricks and donated to the Linux Foundation in 2019. The revision focus is Lakehouse; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Lakehouse / 湖仓一体**：在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。
- **Delta Lake / Delta Lake**：Databricks 发起的开放湖仓存储框架，在 Parquet 文件上添加事务日志、更新删除和 ACID 能力。
- **Parquet / Parquet**：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。
- **Schema / 模式**：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。

拓展复习：把“Delta Lake and Delta Tables”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 23 页的核心主题是什么？
**答：** 本页围绕“Delta Lake and Delta Tables”展开。课件中的关键信息包括：Delta Lake 湖仓存储层 and Delta 表；Delta Lake 湖仓存储层 is Databrick’s implementation of a 湖仓一体；Delta Lake 湖仓存储层 is an open-source storage framework；- originally developed by Databricks and donated to the Linux Foundation in 2019。复习时先抓住湖仓一体：在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 23?
**Answer:** This page presents 'Delta Lake and Delta Tables'. The slide includes: Delta Lake and Delta Tables; Delta Lake is Databrick’s implementation of a lakehouse; Delta Lake is an open-source storage framework; - originally developed by Databricks and donated to the Linux Foundation in 2019. The revision focus is Lakehouse; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：湖仓一体 / Lakehouse
**答：** 在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。
**Q2 English:** Explain the concept on this page: Lakehouse
**Answer:** The page focuses on Lakehouse. This page presents 'Delta Lake and Delta Tables'. The slide includes: Delta Lake and Delta Tables; Delta Lake is Databrick’s implementation of a lakehouse; Delta Lake is an open-source storage framework; - originally developed by Databricks and donated to the Linux Foundation in 2019. The revision focus is Lakehouse; connect its definition, evidence, and use to the examples on the page.

## 第 24 页：Delta Lake 湖仓存储层 architecture in Databricks

Source ID: `src-10cd2be200cb-pdf_page-00024`

![PDF page 24](../assets/pages/page_024.jpg)

### 原文 / Original Text

```text
Delta Lake architecture in Databricks

In Databricks every table is a Delta table by default.
- The Medallion architecture (Bronze → Silver → Gold) is implemented as three sets of 

Delta tables at progressively higher quality levels

- The transaction log provides the audit trail across all transformations
```

### 完整中文翻译

Delta Lake 湖仓存储层 architecture in Databricks
In Databricks every table is a Delta table by default.
- 奖牌架构 分层架构 (铜牌层/原始可追溯层 → 银牌层/清洗整合层 → 金牌层/可服务层) is implemented as three sets of
Delta 表 at progressively higher quality levels
- The transaction log provides the audit trail across all transformations

### 中文释义

本页围绕“Delta Lake architecture in Databricks”展开。课件中的关键信息包括：Delta Lake 湖仓存储层 architecture in Databricks；In Databricks every table is a Delta table by default.；- 奖牌架构 分层架构 (铜牌层/原始可追溯层 → 银牌层/清洗整合层 → 金牌层/可服务层) is implemented as three sets of；Delta 表 at progressively higher quality levels。复习时先抓住奖牌架构：把数据从 Landing/Bronze 的原始层逐步提升到 Silver 的清洗整合层和 Gold 的可训练/可服务层。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Delta Lake architecture in Databricks'. The slide includes: Delta Lake architecture in Databricks; In Databricks every table is a Delta table by default.; - The Medallion architecture (Bronze → Silver → Gold) is implemented as three sets of; Delta tables at progressively higher quality levels. The revision focus is Medallion; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Medallion / 奖牌架构**：把数据从 Landing/Bronze 的原始层逐步提升到 Silver 的清洗整合层和 Gold 的可训练/可服务层。
- **Delta Lake / Delta Lake**：Databricks 发起的开放湖仓存储框架，在 Parquet 文件上添加事务日志、更新删除和 ACID 能力。

拓展复习：把“Delta Lake architecture in Databricks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 24 页的核心主题是什么？
**答：** 本页围绕“Delta Lake architecture in Databricks”展开。课件中的关键信息包括：Delta Lake 湖仓存储层 architecture in Databricks；In Databricks every table is a Delta table by default.；- 奖牌架构 分层架构 (铜牌层/原始可追溯层 → 银牌层/清洗整合层 → 金牌层/可服务层) is implemented as three sets of；Delta 表 at progressively higher quality levels。复习时先抓住奖牌架构：把数据从 Landing/Bronze 的原始层逐步提升到 Silver 的清洗整合层和 Gold 的可训练/可服务层。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 24?
**Answer:** This page presents 'Delta Lake architecture in Databricks'. The slide includes: Delta Lake architecture in Databricks; In Databricks every table is a Delta table by default.; - The Medallion architecture (Bronze → Silver → Gold) is implemented as three sets of; Delta tables at progressively higher quality levels. The revision focus is Medallion; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：奖牌架构 / Medallion
**答：** 把数据从 Landing/Bronze 的原始层逐步提升到 Silver 的清洗整合层和 Gold 的可训练/可服务层。
**Q2 English:** Explain the concept on this page: Medallion
**Answer:** The page focuses on Medallion. This page presents 'Delta Lake architecture in Databricks'. The slide includes: Delta Lake architecture in Databricks; In Databricks every table is a Delta table by default.; - The Medallion architecture (Bronze → Silver → Gold) is implemented as three sets of; Delta tables at progressively higher quality levels. The revision focus is Medallion; connect its definition, evidence, and use to the examples on the page.

## 第 25 页：Delta Table: Data Skipping and Z 顺序聚簇

Source ID: `src-10cd2be200cb-pdf_page-00025`

![PDF page 25](../assets/pages/page_025.jpg)

### 原文 / Original Text

```text
Delta Table: Data Skipping and Z-Ordering

When Delta Lake writes data files, it records column-level statistics for the first 32 columns in every Parquet 
file:

minimum value, maximum value, null count

At query time, files whose min/max ranges cannot contain any rows satisfying the WHERE predicate are 
skipped entirely — without being opened or decompressed.

Z-Ordering (multi-dimensional clustering) physically co-locates rows with similar values of multiple 
columns in the same files:

Z-ordering on (pickup_month, pickup_borough) means that a query filtering on both columns will skip 
the vast majority of files — the query touches only the files that could contain matching rows.
```

### 完整中文翻译

Delta Table: Data Skipping and Z 顺序聚簇
When Delta Lake 湖仓存储层 writes data files, it records column-level statistics for the first 32 columns in every Parquet 列式文件格式
file:
minimum value, maximum value, 空值 count
At query time, files whose min/max ranges cannot contain any rows satisfying the WHERE predicate are
skipped entirely — without being opened or decompressed.
Z 顺序聚簇 (multi-dimensional 聚类) physically co-locates rows with similar values of multiple
columns in the same files:
Z 顺序聚簇 on (pickup_month, pickup_borough) means that a query filtering on both columns will skip
the vast majority of files — the query touches only the files that could contain matching rows.

### 中文释义

本页围绕“Delta Table: Data Skipping and Z-Ordering”展开。课件中的关键信息包括：Delta Table: Data Skipping and Z 顺序聚簇；When Delta Lake 湖仓存储层 writes data files, it records column-level statistics for the first 32 columns in every Parquet 列式文件格式；file:；minimum value, maximum value, 空值 count。复习时先抓住Delta Lake：Databricks 发起的开放湖仓存储框架，在 Parquet 文件上添加事务日志、更新删除和 ACID 能力。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Delta Table: Data Skipping and Z-Ordering'. The slide includes: Delta Table: Data Skipping and Z-Ordering; When Delta Lake writes data files, it records column-level statistics for the first 32 columns in every Parquet; file:; minimum value, maximum value, null count. The revision focus is Delta Lake; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Delta Lake / Delta Lake**：Databricks 发起的开放湖仓存储框架，在 Parquet 文件上添加事务日志、更新删除和 ACID 能力。
- **Parquet / Parquet**：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。

拓展复习：把“Delta Table: Data Skipping and Z-Ordering”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 25 页的核心主题是什么？
**答：** 本页围绕“Delta Table: Data Skipping and Z-Ordering”展开。课件中的关键信息包括：Delta Table: Data Skipping and Z 顺序聚簇；When Delta Lake 湖仓存储层 writes data files, it records column-level statistics for the first 32 columns in every Parquet 列式文件格式；file:；minimum value, maximum value, 空值 count。复习时先抓住Delta Lake：Databricks 发起的开放湖仓存储框架，在 Parquet 文件上添加事务日志、更新删除和 ACID 能力。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 25?
**Answer:** This page presents 'Delta Table: Data Skipping and Z-Ordering'. The slide includes: Delta Table: Data Skipping and Z-Ordering; When Delta Lake writes data files, it records column-level statistics for the first 32 columns in every Parquet; file:; minimum value, maximum value, null count. The revision focus is Delta Lake; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：Delta Lake / Delta Lake
**答：** Databricks 发起的开放湖仓存储框架，在 Parquet 文件上添加事务日志、更新删除和 ACID 能力。
**Q2 English:** Explain the concept on this page: Delta Lake
**Answer:** The page focuses on Delta Lake. This page presents 'Delta Table: Data Skipping and Z-Ordering'. The slide includes: Delta Table: Data Skipping and Z-Ordering; When Delta Lake writes data files, it records column-level statistics for the first 32 columns in every Parquet; file:; minimum value, maximum value, null count. The revision focus is Delta Lake; connect its definition, evidence, and use to the examples on the page.

## 第 26 页：练习

Source ID: `src-10cd2be200cb-pdf_page-00026`

![PDF page 26](../assets/pages/page_026.jpg)

### 原文 / Original Text

```text
Exercise

- Assume a uniform distribution of records for both pickup_month, 

pickup_borough

- Write a query to select rides for a specific time window (months) and a specific set of 

boroughs

- Estimate how many of the files will be read to answer the query

(hint: consider the number of months and the number of boroughs)
```

### 完整中文翻译

练习
- Assume a uniform distribution of records for both pickup_month,
pickup_borough
- Write a query to select rides for a specific time window (months) and a specific set of
boroughs
- Estimate how many of the files will be read to answer the query
(hint: consider the number of months and the number of boroughs)

### 中文释义

本页围绕“Exercise”展开。课件中的关键信息包括：练习；- Assume a uniform distribution of records for both pickup_month,；pickup_borough；- Write a query to select rides for a specific time window (months) and a specific set of。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Exercise'. The slide includes: Exercise; - Assume a uniform distribution of records for both pickup_month,; pickup_borough; - Write a query to select rides for a specific time window (months) and a specific set of. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“Exercise”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 26 页的核心主题是什么？
**答：** 本页围绕“Exercise”展开。课件中的关键信息包括：练习；- Assume a uniform distribution of records for both pickup_month,；pickup_borough；- Write a query to select rides for a specific time window (months) and a specific set of。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 26?
**Answer:** This page presents 'Exercise'. The slide includes: Exercise; - Assume a uniform distribution of records for both pickup_month,; pickup_borough; - Write a query to select rides for a specific time window (months) and a specific set of. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'Exercise'. The slide includes: Exercise; - Assume a uniform distribution of records for both pickup_month,; pickup_borough; - Write a query to select rides for a specific time window (months) and a specific set of. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

## 第 27 页：总结

Source ID: `src-10cd2be200cb-pdf_page-00027`

![PDF page 27](../assets/pages/page_027.jpg)

### 原文 / Original Text

```text
Summary

• Data warehouses
• Datalakes

• Their convergence: the lakehouse

• Open specs, open format
• DeltaLake, Delta Tables: Databricks’ implementation

• Used in our labs
```

### 完整中文翻译

总结
• 数据仓库
• Datalakes
• Their convergence: the 湖仓一体
• Open specs, open format
• DeltaLake, Delta 表: Databricks’ implementation
• Used in our labs

### 中文释义

本页围绕“Summary”展开。课件中的关键信息包括：总结；• 数据仓库；• Datalakes；• Their convergence: the 湖仓一体。复习时先抓住数据仓库：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Summary'. The slide includes: Summary; • Data warehouses; • Datalakes; • Their convergence: the lakehouse. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data warehouse / 数据仓库**：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。
- **Lakehouse / 湖仓一体**：在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。
- **MAR / 随机缺失**：缺失与其他可观测变量有关，但不直接由缺失值本身决定。

拓展复习：把“Summary”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 27 页的核心主题是什么？
**答：** 本页围绕“Summary”展开。课件中的关键信息包括：总结；• 数据仓库；• Datalakes；• Their convergence: the 湖仓一体。复习时先抓住数据仓库：面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 27?
**Answer:** This page presents 'Summary'. The slide includes: Summary; • Data warehouses; • Datalakes; • Their convergence: the lakehouse. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据仓库 / Data warehouse
**答：** 面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。
**Q2 English:** Explain the concept on this page: Data warehouse
**Answer:** The page focuses on Data warehouse. This page presents 'Summary'. The slide includes: Summary; • Data warehouses; • Datalakes; • Their convergence: the lakehouse. The revision focus is Data warehouse; connect its definition, evidence, and use to the examples on the page.
