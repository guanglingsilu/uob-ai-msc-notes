# Computer Vision and Imaging Week 4 逐页双语复习资料

# Week 4: Edges, Hough Detection and Eigenfaces / 边缘、Hough 检测与 Eigenfaces

## 第 1 页：Computer Vision and Imaging

![PDF page 1](../assets/cv_w4/pages/page_001.png)

### 原文 / Original Text
```text
Computer Vision and 
Imaging
Dr. Qingjie meng
Assistant Professor in Medical AI
School of Computer Science
University of Birmingham
Week 4- 1
```

### 完整中文翻译
计算机视觉与成像。第 4 周课件。课程教师与学校信息见原页。

### 中文释义
本页属于边缘检测。计算机视觉与成像。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 计算机视觉与成像。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：计算机视觉与成像。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 1 页的 Computer Vision and Imaging 解决了什么问题？
  - 答案：计算机视觉与成像。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 1, Computer Vision and Imaging, address?
  - Answer: It addresses computer vision and imaging as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 2 页：Week 4 contents

![PDF page 2](../assets/cv_w4/pages/page_002.png)

### 原文 / Original Text
```text
W4 Content
• Low-level CV&I
• Detection
• Edges
• First-order derivative
• Laplacian
• Canny edge detector
• Lines
• Circles and other shapes
• Advanced
```

### 完整中文翻译
第 4 周内容：低层次计算机视觉与成像、检测、边缘、一次导数、二次导数、Canny 边缘检测、直线、圆以及 Eigenfaces。

### 中文释义
本页属于边缘检测。第 4 周内容：低层次计算机视觉与成像、检测、边缘、一次导数、二次导数、Canny 边缘检测、直线、圆以及 Eigenfaces。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 第 4 周内容：低层次计算机视觉与成像、检测、边缘、一次导数、二次导数、Canny 边缘检测、直线、圆以及 Eigenfaces。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：第 4 周内容：低层次计算机视觉与成像、检测、边缘、一次导数、二次导数、Canny 边缘检测、直线、圆以及 Eigenfaces。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 2 页的 Week 4 contents 解决了什么问题？
  - 答案：第 4 周内容：低层次计算机视觉与成像、检测、边缘、一次导数、二次导数、Canny 边缘检测、直线、圆以及 Eigenfaces。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 2, Week 4 contents, address?
  - Answer: It addresses week 4 contents as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 3 页：Low-level processing

![PDF page 3](../assets/cv_w4/pages/page_003.png)

### 原文 / Original Text
```text
Low-level Processing
• Operations carried out on the pixels in the image to extract properties 
such as the gradient (with respect to intensity) at each point in the 
image. 
Edges Lines
 Circles
```

### 完整中文翻译
低层处理是在图像像素上进行的运算，用来提取图像属性，例如每个位置的强度梯度。边缘和直线是由这些低层线索逐步得到的更高层结构。

### 中文释义
本页属于边缘检测。低层处理是在图像像素上进行的运算，用来提取图像属性，例如每个位置的强度梯度。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 低层处理是在图像像素上进行的运算，用来提取图像属性，例如每个位置的强度梯度。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：低层处理是在图像像素上进行的运算，用来提取图像属性，例如每个位置的强度梯度。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 3 页的 Low-level processing 解决了什么问题？
  - 答案：低层处理是在图像像素上进行的运算，用来提取图像属性，例如每个位置的强度梯度。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 3, Low-level processing, address?
  - Answer: It addresses low-level processing as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 4 页：Edge detection

![PDF page 4](../assets/cv_w4/pages/page_004.png)

### 原文 / Original Text
```text
Edge detection
```

### 完整中文翻译
边缘检测的目标是找出图像中强度变化显著的位置。导数可以把缓慢变化与突变区分开，但噪声也会被放大。

### 中文释义
本页属于边缘检测。边缘检测的目标是找出图像中强度变化显著的位置。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 边缘检测的目标是找出图像中强度变化显著的位置。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：边缘检测的目标是找出图像中强度变化显著的位置。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 4 页的 Edge detection 解决了什么问题？
  - 答案：边缘检测的目标是找出图像中强度变化显著的位置。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 4, Edge detection, address?
  - Answer: It addresses edge detection as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 5 页：Edge detection: derivative

![PDF page 5](../assets/cv_w4/pages/page_005.png)

### 原文 / Original Text
```text
Edge detection: Derivative
• The process of finding a derivative is called differentiation.
• A function of a real variable 𝑓(𝑥) is differentiable at a point 𝑥 of its 
domain, if the limit 𝐿 exists:
𝐿 =  lim
𝑑𝑥→0
𝑓 𝑥 + 𝑑𝑥 − 𝑓(𝑥)
𝑑𝑥
𝐿 = 𝑓′ 𝑥 =  lim
ℎ→0
𝑓 𝑥 + ℎ − 𝑓(𝑥)
ℎ
𝑓(𝑥)
𝑓(𝑥 + ℎ)
𝑓(⋅)
Model of interest
A defined 
intervalCase of interest
Next value
```

### 完整中文翻译
微积分中，导数描述函数在某一点的变化率。若极限存在，函数在该点可导；图像处理中把灰度函数视为二维函数并对其求差分。

### 中文释义
本页属于边缘检测。微积分中，导数描述函数在某一点的变化率。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 微积分中，导数描述函数在某一点的变化率。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：微积分中，导数描述函数在某一点的变化率。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 5 页的 Edge detection: derivative 解决了什么问题？
  - 答案：微积分中，导数描述函数在某一点的变化率。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 5, Edge detection: derivative, address?
  - Answer: It addresses edge detection: derivative as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 6 页：One-pixel finite difference

![PDF page 6](../assets/cv_w4/pages/page_006.png)

### 原文 / Original Text
```text
Edge detection: Derivative
• In our context of interest:
• We will move ONE pixel coordinate at a time, ℎ = 1
𝑓(𝑥)
𝑓(𝑥 + ℎ)
𝑓(⋅)
𝑓′ 𝑥 =  lim
ℎ→0
𝑓 𝑥 + ℎ − 𝑓(𝑥)
ℎ
𝑓′ 𝑥 = 𝑓 𝑥 + 1 − 𝑓(𝑥)
𝑓′ 𝑥 = 𝑓 𝑥 + 1 − 𝑓 𝑥
𝑓′ 𝑦 = 𝑓 𝑦 + 1 − 𝑓 𝑦
```

### 完整中文翻译
课程中每次沿一个像素坐标移动，因此 h=1。前向差分用 f(x+1)-f(x) 近似导数；差分越大，越可能对应边缘。

### 中文释义
本页属于边缘检测。课程中每次沿一个像素坐标移动，因此 h=1。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 课程中每次沿一个像素坐标移动，因此 h=1。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：课程中每次沿一个像素坐标移动，因此 h=1。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 6 页的 One-pixel finite difference 解决了什么问题？
  - 答案：课程中每次沿一个像素坐标移动，因此 h=1。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 6, One-pixel finite difference, address?
  - Answer: It addresses one-pixel finite difference as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 7 页：First-derivative edge detection

![PDF page 7](../assets/cv_w4/pages/page_007.png)

### 原文 / Original Text
```text
Edge detection based on the 
First derivative
```

### 完整中文翻译
一次导数边缘检测把灰度的一阶变化量作为边缘响应。平坦区域的变化接近零，而边缘两侧的灰度跳变产生较大响应。

### 中文释义
本页属于边缘检测。一次导数边缘检测把灰度的一阶变化量作为边缘响应。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 一次导数边缘检测把灰度的一阶变化量作为边缘响应。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：一次导数边缘检测把灰度的一阶变化量作为边缘响应。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 7 页的 First-derivative edge detection 解决了什么问题？
  - 答案：一次导数边缘检测把灰度的一阶变化量作为边缘响应。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 7, First-derivative edge detection, address?
  - Answer: It addresses first-derivative edge detection as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 8 页：Edge detection: gradient

![PDF page 8](../assets/cv_w4/pages/page_008.png)

### 原文 / Original Text
```text
Edge detection: Gradient
• First derivatives in image processing are implemented using the 
magnitude of the gradient.
• The vector ∇𝑓 𝑥, 𝑦  points in the direction of the greatest rate of 
change of f at location (𝑥, 𝑦).
𝑔𝑥 𝑥, 𝑦 = 𝜕𝑓(𝑥, 𝑦)
𝜕𝑥 = 𝑓(𝑥 + 1, 𝑦) − 𝑓(𝑥, 𝑦) 𝑔𝑦 𝑥, 𝑦 = 𝜕𝑓(𝑥, 𝑦)
𝜕𝑦 = 𝑓(𝑥, 𝑦+ 1) − 𝑓(𝑥, 𝑦)
∇𝑓 𝑥, 𝑦 =
𝑔𝑥
𝑔𝑦
```

### 完整中文翻译
图像梯度是由 x 和 y 方向偏导组成的向量。梯度向量指向灰度增长最快的方向，因此同时给出变化方向和强度。

### 中文释义
本页属于边缘检测。图像梯度是由 x 和 y 方向偏导组成的向量。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 图像梯度是由 x 和 y 方向偏导组成的向量。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：图像梯度是由 x 和 y 方向偏导组成的向量。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 8 页的 Edge detection: gradient 解决了什么问题？
  - 答案：图像梯度是由 x 和 y 方向偏导组成的向量。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 8, Edge detection: gradient, address?
  - Answer: It addresses edge detection: gradient as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 9 页：Gradient magnitude and direction

![PDF page 9](../assets/cv_w4/pages/page_009.png)

### 原文 / Original Text
```text
Edge detection: Gradient
• The magnitude of ∇𝑓 at 𝑥, 𝑦  is given by the Euclidean vector norm 
𝑀(𝑥, 𝑦) and the direction is given by the 𝛼 𝑥, 𝑦  angle:
• The magnitude can be approximated by:
𝑀(𝑥, 𝑦) = |∇𝑓 𝑥, 𝑦 | = 𝑔𝑥
2 + 𝑔𝑦
2
 𝛼 𝑥, 𝑦 =  arctan 𝑔𝑦 𝑥, 𝑦
𝑔𝑥 𝑥, 𝑦
𝑀 𝑥, 𝑦 ≈ 𝑔𝑥 + |𝑔𝑦|
```

### 完整中文翻译
梯度幅值是梯度向量的欧氏范数 M(x,y)=sqrt(gx²+gy²)，方向可用 alpha=atan2(gy,gx) 表示。实际实现通常用近似范数减少计算。

### 中文释义
本页属于边缘检测。梯度幅值是梯度向量的欧氏范数 M(x,y)=sqrt(gx²+gy²)，方向可用 alpha=atan2(gy,gx) 表示。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 梯度幅值是梯度向量的欧氏范数 M(x,y)=sqrt(gx²+gy²)，方向可用 alpha=atan2(gy,gx) 表示。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：梯度幅值是梯度向量的欧氏范数 M(x,y)=sqrt(gx²+gy²)，方向可用 alpha=atan2(gy,gx) 表示。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 9 页的 Gradient magnitude and direction 解决了什么问题？
  - 答案：梯度幅值是梯度向量的欧氏范数 M(x,y)=sqrt(gx²+gy²)，方向可用 alpha=atan2(gy,gx) 表示。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 9, Gradient magnitude and direction, address?
  - Answer: It addresses gradient magnitude and direction as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 10 页：Gradient visualisations

![PDF page 10](../assets/cv_w4/pages/page_010.png)

### 原文 / Original Text
```text
Edge detection: Gradient
a) Input image, b) gradient for x, c) gradient for y, d)gradient magnitude, 
e) gradient direction
```

### 完整中文翻译
图示依次比较输入图像、x 方向梯度、y 方向梯度、梯度幅值和梯度方向；它说明方向分量如何合成为边缘证据。

### 中文释义
本页属于边缘检测。图示依次比较输入图像、x 方向梯度、y 方向梯度、梯度幅值和梯度方向；它说明方向分量如何合成为边缘证据。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 图示依次比较输入图像、x 方向梯度、y 方向梯度、梯度幅值和梯度方向；它说明方向分量如何合成为边缘证据。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：图示依次比较输入图像、x 方向梯度、y 方向梯度、梯度幅值和梯度方向；它说明方向分量如何合成为边缘证据。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 10 页的 Gradient visualisations 解决了什么问题？
  - 答案：图示依次比较输入图像、x 方向梯度、y 方向梯度、梯度幅值和梯度方向；它说明方向分量如何合成为边缘证据。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 10, Gradient visualisations, address?
  - Answer: It addresses gradient visualisations as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 11 页：Computing the gradient

![PDF page 11](../assets/cv_w4/pages/page_011.png)

### 原文 / Original Text
```text
Edge detection: Computing the Gradient
𝑔𝑥 𝑥, 𝑦 = 𝜕𝑓(𝑥, 𝑦)
𝜕𝑥 = 𝑓(𝑥 + 1, 𝑦) − 𝑓(𝑥, 𝑦)
𝑔𝑦 𝑥, 𝑦 = 𝜕𝑓(𝑥, 𝑦)
𝜕𝑦 = 𝑓(𝑥, 𝑦+ 1) − 𝑓(𝑥, 𝑦) -1 1
-1
1
If 𝑓(𝑥, 𝑦)  =  𝑧5
𝑔𝑥 𝑥, 𝑦 =  𝑧8  −  𝑧5
𝑔𝑦 𝑥, 𝑦 =  𝑧6  −  𝑧5
```

### 完整中文翻译
前向差分可写为 gx=f(x+1,y)-f(x,y)，gy=f(x,y+1)-f(x,y)。它只看当前位置和一个相邻像素，边界处要特别处理。

### 中文释义
本页属于边缘检测。前向差分可写为 gx=f(x+1,y)-f(x,y)，gy=f(x,y+1)-f(x,y)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 前向差分可写为 gx=f(x+1,y)-f(x,y)，gy=f(x,y+1)-f(x,y)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：前向差分可写为 gx=f(x+1,y)-f(x,y)，gy=f(x,y+1)-f(x,y)。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 11 页的 Computing the gradient 解决了什么问题？
  - 答案：前向差分可写为 gx=f(x+1,y)-f(x,y)，gy=f(x,y+1)-f(x,y)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 11, Computing the gradient, address?
  - Answer: It addresses computing the gradient as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 12 页：Odd kernels and central differences

![PDF page 12](../assets/cv_w4/pages/page_012.png)

### 原文 / Original Text
```text
Edge detection: Computing the Gradient
• We prefer kernels of odd size rather than 2x2
• A 3x3 kernel takes into account opposite sides of the centre point
𝑓′ 𝑥 = 𝑓 𝑥 + 1 − 𝑓 𝑥
 𝑓′ 𝑥 = 𝑓 𝑥 − 𝑓 𝑥 − 1
𝑓′ 𝑥 = 𝑓 𝑥 + 1 − 𝑓 𝑥 + 𝑓 𝑥 − 𝑓 𝑥 − 1
𝑓′ 𝑥 = 𝑓 𝑥 + 1 − 𝑓(𝑥 − 1)
-1 0 1
1D Kernel
```

### 完整中文翻译
实践中偏好奇数尺寸的核。3×3 核能同时观察中心点两侧，中央差分比单侧差分更对称；[-1,0,1] 是常用的一维导数核。

### 中文释义
本页属于边缘检测。实践中偏好奇数尺寸的核。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 实践中偏好奇数尺寸的核。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：实践中偏好奇数尺寸的核。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 12 页的 Odd kernels and central differences 解决了什么问题？
  - 答案：实践中偏好奇数尺寸的核。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 12, Odd kernels and central differences, address?
  - Answer: It addresses odd kernels and central differences as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 13 页：Sobel kernel

![PDF page 13](../assets/cv_w4/pages/page_013.png)

### 原文 / Original Text
```text
Edge detection: Computing the Gradient
Extending to a 3x3 kernel
• Sobel Kernel
• Uses weighted smoothing (centre row/column ×2).
• Provides better noise suppression and smoother gradient estimates.
• Slightly stronger edge response due to higher central weighting.
𝑔𝑥 = ℎ𝑥 ∗ 𝑓 𝑥, 𝑦 𝑔𝑦 = ℎ𝑦 ∗ 𝑓 𝑥, 𝑦
```

### 完整中文翻译
Sobel 核把导数与平滑结合起来，中心行或列权重为 2。它能一定程度抑制噪声，并得到更平滑的梯度估计。

### 中文释义
本页属于边缘检测。Sobel 核把导数与平滑结合起来，中心行或列权重为 2。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. Sobel 核把导数与平滑结合起来，中心行或列权重为 2。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：Sobel 核把导数与平滑结合起来，中心行或列权重为 2。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 13 页的 Sobel kernel 解决了什么问题？
  - 答案：Sobel 核把导数与平滑结合起来，中心行或列权重为 2。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 13, Sobel kernel, address?
  - Answer: It addresses sobel kernel as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 14 页：Sobel edge detector

![PDF page 14](../assets/cv_w4/pages/page_014.png)

### 原文 / Original Text
```text
Sobel Edge detector
Input Image
Sobel gradient magnitude
X-direction gradient Y-direction gradient
```

### 完整中文翻译
Sobel 边缘检测分别计算 x 梯度、y 梯度和梯度幅值。三幅响应图帮助判断边缘的方向性与整体强度。

### 中文释义
本页属于边缘检测。Sobel 边缘检测分别计算 x 梯度、y 梯度和梯度幅值。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. Sobel 边缘检测分别计算 x 梯度、y 梯度和梯度幅值。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：Sobel 边缘检测分别计算 x 梯度、y 梯度和梯度幅值。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 14 页的 Sobel edge detector 解决了什么问题？
  - 答案：Sobel 边缘检测分别计算 x 梯度、y 梯度和梯度幅值。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 14, Sobel edge detector, address?
  - Answer: It addresses sobel edge detector as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 15 页：Sobel edge-detector example

![PDF page 15](../assets/cv_w4/pages/page_015.png)

### 原文 / Original Text
```text
Sobel Edge detector
Sobe edge detector. (a) Input image, (b) X-gradient, (c) Y-gradient, 
(d) Negative of the magnitude: 1 – M(x,y)
```

### 完整中文翻译
示例把输入图像、x 梯度、y 梯度和负梯度幅值 1-M(x,y) 并列显示，用于观察 Sobel 检测后的边缘表现。

### 中文释义
本页属于边缘检测。示例把输入图像、x 梯度、y 梯度和负梯度幅值 1-M(x,y) 并列显示，用于观察 Sobel 检测后的边缘表现。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 示例把输入图像、x 梯度、y 梯度和负梯度幅值 1-M(x,y) 并列显示，用于观察 Sobel 检测后的边缘表现。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：示例把输入图像、x 梯度、y 梯度和负梯度幅值 1-M(x,y) 并列显示，用于观察 Sobel 检测后的边缘表现。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 15 页的 Sobel edge-detector example 解决了什么问题？
  - 答案：示例把输入图像、x 梯度、y 梯度和负梯度幅值 1-M(x,y) 并列显示，用于观察 Sobel 检测后的边缘表现。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 15, Sobel edge-detector example, address?
  - Answer: It addresses sobel edge-detector example as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 16 页：Prewitt kernel

![PDF page 16](../assets/cv_w4/pages/page_016.png)

### 原文 / Original Text
```text
Edge detection: Prewitt
Extending to a 3x3 kernel
• Prewitt Kernel
• Uses uniform weights for smoothing (rows or columns of 1s).
• Simpler and slightly more sensitive to noise.
• Easier to compute  (only additions in practice).
Input Image Prewitt gradient magnitude
```

### 完整中文翻译
Prewitt 核也是 3×3 导数核，但平滑行或列使用均匀的 1。它结构简单，通常比 Sobel 对噪声略敏感。

### 中文释义
本页属于边缘检测。Prewitt 核也是 3×3 导数核，但平滑行或列使用均匀的 1。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. Prewitt 核也是 3×3 导数核，但平滑行或列使用均匀的 1。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：Prewitt 核也是 3×3 导数核，但平滑行或列使用均匀的 1。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 16 页的 Prewitt kernel 解决了什么问题？
  - 答案：Prewitt 核也是 3×3 导数核，但平滑行或列使用均匀的 1。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 16, Prewitt kernel, address?
  - Answer: It addresses prewitt kernel as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 17 页：Second-derivative edge detection

![PDF page 17](../assets/cv_w4/pages/page_017.png)

### 原文 / Original Text
```text
Edge detection based on the 
Second derivative
```

### 完整中文翻译
二阶导数研究变化率的变化。它可以在一阶梯度变化处产生响应，但通常对噪声更敏感，所以常与平滑结合。

### 中文释义
本页属于边缘检测。二阶导数研究变化率的变化。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 二阶导数研究变化率的变化。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：二阶导数研究变化率的变化。
- **Laplacian / 拉普拉斯算子**：把 x 和 y 方向二阶导数相加，突出强度变化率的变化。

### 自测问题 / Self-check
- 中文问题：第 17 页的 Second-derivative edge detection 解决了什么问题？
  - 答案：二阶导数研究变化率的变化。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 17, Second-derivative edge detection, address?
  - Answer: It addresses second-derivative edge detection as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 18 页：Laplacian: one-dimensional second derivative

![PDF page 18](../assets/cv_w4/pages/page_018.png)

### 原文 / Original Text
```text
Edges: Laplacian
• First (central) derivative:
𝑓′ 𝑥 = 𝑓 𝑥 + 1 − 𝑓(𝑥 − 1)
• Second derivative: 
𝑓′′ 𝑥 = [𝑓 𝑥 + 1 − 𝑓 𝑥 ] − [𝑓 𝑥 − 𝑓(𝑥 − 1)]
𝑓′′ 𝑥 = 𝑓 𝑥 + 1 − 2𝑓 𝑥 + 𝑓(𝑥 − 1)
```

### 完整中文翻译
一维中央二阶导数可由两个一阶差分相减得到：f''(x)=f(x+1)-2f(x)+f(x-1)。中心像素的系数为 -2。

### 中文释义
本页属于边缘检测。一维中央二阶导数可由两个一阶差分相减得到：f''(x)=f(x+1)-2f(x)+f(x-1)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 一维中央二阶导数可由两个一阶差分相减得到：f''(x)=f(x+1)-2f(x)+f(x-1)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：一维中央二阶导数可由两个一阶差分相减得到：f''(x)=f(x+1)-2f(x)+f(x-1)。
- **Laplacian / 拉普拉斯算子**：把 x 和 y 方向二阶导数相加，突出强度变化率的变化。

### 自测问题 / Self-check
- 中文问题：第 18 页的 Laplacian: one-dimensional second derivative 解决了什么问题？
  - 答案：一维中央二阶导数可由两个一阶差分相减得到：f''(x)=f(x+1)-2f(x)+f(x-1)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 18, Laplacian: one-dimensional second derivative, address?
  - Answer: It addresses laplacian: one-dimensional second derivative as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 19 页：Laplacian: combining x and y derivatives

![PDF page 19](../assets/cv_w4/pages/page_019.png)

### 原文 / Original Text
```text
Edges: Laplacian
• Combining the second derivatives
𝑓′′ 𝑥 = 𝑓 𝑥 + 1 − 2𝑓 𝑥 + 𝑓 𝑥 − 1 𝑓′′ 𝑦 = 𝑓 𝑦+ 1 − 2𝑓 𝑦 + 𝑓(𝑦− 1)
𝜕2𝑓
𝜕𝑦2 = 𝑓 𝑥, 𝑦+ 1 − 2𝑓 𝑥, 𝑦 + 𝑓(𝑥, 𝑦− 1)𝜕2𝑓
𝜕𝑥2 = 𝑓 𝑥 + 1, 𝑦 − 2𝑓 𝑥, 𝑦 + 𝑓 𝑥 − 1, 𝑦
∇2𝑓 𝑥, 𝑦 = 𝜕2𝑓
𝜕𝑥2 + 𝜕2𝑓
𝜕𝑦2• Laplacian of f at (x,y)
∇2𝑓 𝑥, 𝑦 = 𝑓 𝑥 + 1, 𝑦 + 𝑓 𝑥 − 1, 𝑦 + 𝑓 𝑥, 𝑦 + 1 + 𝑓 𝑥, 𝑦 − 1 − 4𝑓(𝑥, 𝑦)
```

### 完整中文翻译
分别计算 x、y 方向的二阶导数，再将它们相加，就得到二维 Laplacian 的四邻域形式。

### 中文释义
本页属于边缘检测。分别计算 x、y 方向的二阶导数，再将它们相加，就得到二维 Laplacian 的四邻域形式。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 分别计算 x、y 方向的二阶导数，再将它们相加，就得到二维 Laplacian 的四邻域形式。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：分别计算 x、y 方向的二阶导数，再将它们相加，就得到二维 Laplacian 的四邻域形式。
- **Laplacian / 拉普拉斯算子**：把 x 和 y 方向二阶导数相加，突出强度变化率的变化。

### 自测问题 / Self-check
- 中文问题：第 19 页的 Laplacian: combining x and y derivatives 解决了什么问题？
  - 答案：分别计算 x、y 方向的二阶导数，再将它们相加，就得到二维 Laplacian 的四邻域形式。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 19, Laplacian: combining x and y derivatives, address?
  - Answer: It addresses laplacian: combining x and y derivatives as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 20 页：Laplacian: adding diagonal neighbours

![PDF page 20](../assets/cv_w4/pages/page_020.png)

### 原文 / Original Text
```text
Edges: Laplacian
• Adding the diagonals
∇2𝑓 𝑥, 𝑦 = 𝑓 𝑥 + 1, 𝑦 + 𝑓 𝑥 − 1, 𝑦 + 𝑓 𝑥, 𝑦 + 1 + 𝑓 𝑥, 𝑦 − 1 − 4𝑓(𝑥, 𝑦)
∇2𝑓 𝑥, 𝑦 = 𝑓 𝑥 + 1, 𝑦 + 𝑓 𝑥 − 1, 𝑦 + 𝑓 𝑥, 𝑦 + 1 + 𝑓 𝑥, 𝑦 − 1 +
𝑓 𝑥 − 1, 𝑦 − 1 + 𝑓 𝑥 + 1, 𝑦 − 1 + 𝑓 𝑥 − 1, 𝑦 + 1 + 𝑓 𝑥 + 1, 𝑦 + 1 − 8𝑓(𝑥, 𝑦)
```

### 完整中文翻译
把对角线邻居也加入后，Laplacian 采用八邻域：四个正交邻居与四个对角邻居之和减去 8 倍中心像素。

### 中文释义
本页属于边缘检测。把对角线邻居也加入后，Laplacian 采用八邻域：四个正交邻居与四个对角邻居之和减去 8 倍中心像素。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 把对角线邻居也加入后，Laplacian 采用八邻域：四个正交邻居与四个对角邻居之和减去 8 倍中心像素。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：把对角线邻居也加入后，Laplacian 采用八邻域：四个正交邻居与四个对角邻居之和减去 8 倍中心像素。
- **Laplacian / 拉普拉斯算子**：把 x 和 y 方向二阶导数相加，突出强度变化率的变化。

### 自测问题 / Self-check
- 中文问题：第 20 页的 Laplacian: adding diagonal neighbours 解决了什么问题？
  - 答案：把对角线邻居也加入后，Laplacian 采用八邻域：四个正交邻居与四个对角邻居之和减去 8 倍中心像素。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 20, Laplacian: adding diagonal neighbours, address?
  - Answer: It addresses laplacian: adding diagonal neighbours as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 21 页：Laplacian edge-detection example

![PDF page 21](../assets/cv_w4/pages/page_021.png)

### 原文 / Original Text
```text
Edges: Laplacian
Edge detection using the Laplacian. (a) input image, (b) negative central coefficient, (c) positive 
central coefficient
```

### 完整中文翻译
图示用 Laplacian 的负中心系数和正中心系数分别展示边缘响应，说明卷积核符号和显示方式会影响结果外观。

### 中文释义
本页属于边缘检测。图示用 Laplacian 的负中心系数和正中心系数分别展示边缘响应，说明卷积核符号和显示方式会影响结果外观。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 图示用 Laplacian 的负中心系数和正中心系数分别展示边缘响应，说明卷积核符号和显示方式会影响结果外观。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：图示用 Laplacian 的负中心系数和正中心系数分别展示边缘响应，说明卷积核符号和显示方式会影响结果外观。
- **Laplacian / 拉普拉斯算子**：把 x 和 y 方向二阶导数相加，突出强度变化率的变化。

### 自测问题 / Self-check
- 中文问题：第 21 页的 Laplacian edge-detection example 解决了什么问题？
  - 答案：图示用 Laplacian 的负中心系数和正中心系数分别展示边缘响应，说明卷积核符号和显示方式会影响结果外观。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 21, Laplacian edge-detection example, address?
  - Answer: It addresses laplacian edge-detection example as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 22 页：Is the current result good enough?

![PDF page 22](../assets/cv_w4/pages/page_022.png)

### 原文 / Original Text
```text
Is current edge detection result good enough?
Gradient magnitude
 Thresholded gradient 
magnitude
Input image
```

### 完整中文翻译
仅有梯度幅值还不能直接得到干净的边缘图。阈值选择会影响断裂、误检和漏检，因此需要更完整的检测流程。

### 中文释义
本页属于边缘检测。仅有梯度幅值还不能直接得到干净的边缘图。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 仅有梯度幅值还不能直接得到干净的边缘图。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：仅有梯度幅值还不能直接得到干净的边缘图。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 22 页的 Is the current result good enough? 解决了什么问题？
  - 答案：仅有梯度幅值还不能直接得到干净的边缘图。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 22, Is the current result good enough?, address?
  - Answer: It addresses is the current result good enough? as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 23 页：Problems with simple edge maps

![PDF page 23](../assets/cv_w4/pages/page_023.png)

### 原文 / Original Text
```text
Some problems
• Noise contributes to detecting false edges (FP) or missing real edges 
(FN). 
• Given the magnitude maps, where exactly are the edges? 
• Can we generate a binary edge map?
Additional steps to consider:
• Smoothing: Noise reduction using low -pass filters
• Enhance: Emphasise significant changes in intensity
• Detection: Discriminate edges and background pixels (thresholding)
Is current edge detection result good enough?
```

### 完整中文翻译
噪声会产生假阳性或掩盖真实边缘；幅值图也没有直接告诉我们哪些像素应标为边缘。目标是生成可解释的二值边缘图。

### 中文释义
本页属于边缘检测。噪声会产生假阳性或掩盖真实边缘；幅值图也没有直接告诉我们哪些像素应标为边缘。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 噪声会产生假阳性或掩盖真实边缘；幅值图也没有直接告诉我们哪些像素应标为边缘。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：噪声会产生假阳性或掩盖真实边缘；幅值图也没有直接告诉我们哪些像素应标为边缘。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 23 页的 Problems with simple edge maps 解决了什么问题？
  - 答案：噪声会产生假阳性或掩盖真实边缘；幅值图也没有直接告诉我们哪些像素应标为边缘。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 23, Problems with simple edge maps, address?
  - Answer: It addresses problems with simple edge maps as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 24 页：Criteria for optimal edge detection

![PDF page 24](../assets/cv_w4/pages/page_024.png)

### 原文 / Original Text
```text
Criteria for Optimal Edge Detection
Canny1 proposed the following criteria for an edge detector:
• Good detection - There should be a low probability of failing to mark real edge 
points, and low probability of falsely marking non-edge points.
• Good localization - The points marked as edge points by the operator should be as 
close as possible to the center of the true edge.
• Single response - Only one response to a single edge.
1 “A Computational Approach for Edge Detection, ” IEEE Trans. Pattern Anal. Machine Intell., vol. 8, 
no. 6, pp. 679–698.
```

### 完整中文翻译
Canny 的三个标准是良好检测、良好定位和单一响应：尽量少漏检和误检，边缘位置准确，并避免同一边缘出现多条响应。

### 中文释义
本页属于边缘检测。Canny 的三个标准是良好检测、良好定位和单一响应：尽量少漏检和误检，边缘位置准确，并避免同一边缘出现多条响应。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. Canny 的三个标准是良好检测、良好定位和单一响应：尽量少漏检和误检，边缘位置准确，并避免同一边缘出现多条响应。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：Canny 的三个标准是良好检测、良好定位和单一响应：尽量少漏检和误检，边缘位置准确，并避免同一边缘出现多条响应。
- **Non-maximum suppression / 非极大值抑制**：沿梯度方向只保留局部最大响应，把厚边缘压成细边缘。

### 自测问题 / Self-check
- 中文问题：第 24 页的 Criteria for optimal edge detection 解决了什么问题？
  - 答案：Canny 的三个标准是良好检测、良好定位和单一响应：尽量少漏检和误检，边缘位置准确，并避免同一边缘出现多条响应。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 24, Criteria for optimal edge detection, address?
  - Answer: It addresses criteria for optimal edge detection as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 25 页：Canny edge detector: four steps

![PDF page 25](../assets/cv_w4/pages/page_025.png)

### 原文 / Original Text
```text
Canny edge detector
Canny proposed an edge detection algorithm, which can be broken down to the
following steps:
1. Perform Gaussian filtering to suppress noise;
2. Calculate the gradient magnitude and direction;
3. Apply non-maximum suppression (NMS) to get a single response for each edge;
4. Perform hysteresis thresholding to find potential edges.
1 “A Computational Approach for Edge Detection, ” IEEE Trans. Pattern Anal. Machine Intell., vol. 8, no. 6, pp. 679–698.
```

### 完整中文翻译
Canny 四步是：高斯平滑抑制噪声；计算梯度幅值和方向；非极大值抑制得到单像素响应；双阈值与滞后连接保留可靠边缘。

### 中文释义
本页属于边缘检测。Canny 四步是：高斯平滑抑制噪声；计算梯度幅值和方向；非极大值抑制得到单像素响应；双阈值与滞后连接保留可靠边缘。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. Canny 四步是：高斯平滑抑制噪声；计算梯度幅值和方向；非极大值抑制得到单像素响应；双阈值与滞后连接保留可靠边缘。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：Canny 四步是：高斯平滑抑制噪声；计算梯度幅值和方向；非极大值抑制得到单像素响应；双阈值与滞后连接保留可靠边缘。
- **Non-maximum suppression / 非极大值抑制**：沿梯度方向只保留局部最大响应，把厚边缘压成细边缘。

### 自测问题 / Self-check
- 中文问题：第 25 页的 Canny edge detector: four steps 解决了什么问题？
  - 答案：Canny 四步是：高斯平滑抑制噪声；计算梯度幅值和方向；非极大值抑制得到单像素响应；双阈值与滞后连接保留可靠边缘。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 25, Canny edge detector: four steps, address?
  - Answer: It addresses canny edge detector: four steps as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 26 页：Canny: smoothing and gradient

![PDF page 26](../assets/cv_w4/pages/page_026.png)

### 原文 / Original Text
```text
Canny edge detector
Algorithm
1. Perform Gaussian filtering to suppress noise.
2. Calculate the gradient magnitude and 
direction.
3. Apply non-maximum suppression (NMS) to 
get a single response for each edge;
4. Perform hysteresis thresholding to find 
potential edges.
1 “A Computational Approach for Edge Detection, ” IEEE Trans. Pattern Anal. Machine Intell., vol. 8, no. 6, pp. 679–698.
𝑓𝑠 𝑥, 𝑦 = 𝐺 𝑥, 𝑦 ∗ 𝑓(𝑥, 𝑦),
 where 𝐺 𝑥, 𝑦 = exp(−
𝑥2+𝑦2
2𝜎 2 )
Magnitude: |∇𝑓𝑠 𝑥, 𝑦 | = 𝑔𝑥
2 + 𝑔𝑦
2
Direction: 𝛼 𝑥, 𝑦 =  arctan
𝑔𝑦
𝑔𝑥
where 𝑔𝑥 and 𝑔𝑦 are calculated with the 
Sobel operators
1
2
```

### 完整中文翻译
先用 Gaussian filter 平滑输入，再计算梯度幅值和方向。平滑会降低噪声，但过度平滑可能使细节和定位变差。

### 中文释义
本页属于边缘检测。先用 Gaussian filter 平滑输入，再计算梯度幅值和方向。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 先用 Gaussian filter 平滑输入，再计算梯度幅值和方向。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：先用 Gaussian filter 平滑输入，再计算梯度幅值和方向。
- **Non-maximum suppression / 非极大值抑制**：沿梯度方向只保留局部最大响应，把厚边缘压成细边缘。

### 自测问题 / Self-check
- 中文问题：第 26 页的 Canny: smoothing and gradient 解决了什么问题？
  - 答案：先用 Gaussian filter 平滑输入，再计算梯度幅值和方向。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 26, Canny: smoothing and gradient, address?
  - Answer: It addresses canny: smoothing and gradient as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 27 页：Canny: non-maximum suppression

![PDF page 27](../assets/cv_w4/pages/page_027.png)

### 原文 / Original Text
```text
Canny edge detector
Algorithm
3. Apply non-maximum suppression (NMS) to get 
a single response for each edge;
1. Find the direction 𝑑𝑘 that is closest to 
𝛼(𝑥, 𝑦).
2. Let 𝐾 = |∇𝑓𝑠 𝑥, 𝑦 |. If K is less than the 
value of |∇𝑓𝑠 | of the neighbors of (𝑥, 𝑦) 
along 𝑑𝑘, then 𝑔𝑁(𝑥, 𝑦)  =  0 (suppression); 
otherwise, let 𝑔𝑁(𝑥, 𝑦) = 𝐾, where 𝑔𝑁 is the 
new image of the same size as 𝑓𝑆
1 “A Computational Approach for Edge Detection, ” IEEE Trans. Pattern Anal. Machine Intell., vol. 8, no. 6, pp. 679–698.
Quantization of orientation3.1
𝑑4 = +45°
𝑑3 = 90°
𝑑2 = −45°
𝑑1 = 0°
```

### 完整中文翻译
非极大值抑制沿梯度方向比较邻居，只保留局部最大值，从而把较厚的梯度带压成更细的边缘。

### 中文释义
本页属于边缘检测。非极大值抑制沿梯度方向比较邻居，只保留局部最大值，从而把较厚的梯度带压成更细的边缘。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 非极大值抑制沿梯度方向比较邻居，只保留局部最大值，从而把较厚的梯度带压成更细的边缘。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：非极大值抑制沿梯度方向比较邻居，只保留局部最大值，从而把较厚的梯度带压成更细的边缘。
- **Non-maximum suppression / 非极大值抑制**：沿梯度方向只保留局部最大响应，把厚边缘压成细边缘。

### 自测问题 / Self-check
- 中文问题：第 27 页的 Canny: non-maximum suppression 解决了什么问题？
  - 答案：非极大值抑制沿梯度方向比较邻居，只保留局部最大值，从而把较厚的梯度带压成更细的边缘。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 27, Canny: non-maximum suppression, address?
  - Answer: It addresses canny: non-maximum suppression as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 28 页：Canny: non-maximum suppression continued

![PDF page 28](../assets/cv_w4/pages/page_028.png)

### 原文 / Original Text
```text
Canny edge detector
Algorithm
3. Apply non-maximum suppression (NMS) to get 
a single response for each edge;
1. Find the direction 𝑑𝑘 that is closest to 
𝛼(𝑥, 𝑦).
2. Let 𝐾 = |∇𝑓𝑠 𝑥, 𝑦 |. If K is less than the 
value of |∇𝑓𝑠 | of the neighbors of (𝑥, 𝑦) 
along 𝑑𝑘, then 𝑔𝑁(𝑥, 𝑦)  =  0 (suppression); 
otherwise, let 𝑔𝑁(𝑥, 𝑦) = 𝐾, where 𝑔𝑁 is the 
new image of the same size as 𝑓𝑆
1 “A Computational Approach for Edge Detection, ” IEEE Trans. Pattern Anal. Machine Intell., vol. 8, no. 6, pp. 679–698.
Local maxima3.2
```

### 完整中文翻译
非极大值抑制先把连续方向量化到离散方向，再沿最接近的方向比较当前像素与两侧像素；不是局部最大值的响应被清零。

### 中文释义
本页属于边缘检测。非极大值抑制先把连续方向量化到离散方向，再沿最接近的方向比较当前像素与两侧像素；不是局部最大值的响应被清零。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 非极大值抑制先把连续方向量化到离散方向，再沿最接近的方向比较当前像素与两侧像素；不是局部最大值的响应被清零。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：非极大值抑制先把连续方向量化到离散方向，再沿最接近的方向比较当前像素与两侧像素；不是局部最大值的响应被清零。
- **Non-maximum suppression / 非极大值抑制**：沿梯度方向只保留局部最大响应，把厚边缘压成细边缘。

### 自测问题 / Self-check
- 中文问题：第 28 页的 Canny: non-maximum suppression continued 解决了什么问题？
  - 答案：非极大值抑制先把连续方向量化到离散方向，再沿最接近的方向比较当前像素与两侧像素；不是局部最大值的响应被清零。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 28, Canny: non-maximum suppression continued, address?
  - Answer: It addresses canny: non-maximum suppression continued as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 29 页：Canny: double threshold and hysteresis

![PDF page 29](../assets/cv_w4/pages/page_029.png)

### 原文 / Original Text
```text
Canny edge detector
1. Define two thresholds 𝜃1and 𝜃2 for edge detection, 𝜃2 = 2 ∗ 𝜃1
2. If a pixel gradient magnitude is larger than 𝜃2 , it is accepted as an edge.
3. If a pixel gradient magnitude is lower than 𝜃1 , it is rejected.
4. If in between, it may be an edge. Consider its neighbouring pixels; accepted if it is connected 
to an edge.
1 “A Computational Approach for Edge Detection,” IEEE Trans. Pattern Anal. Machine Intell., vol. 8, no. 6, pp. 679–698.
Hysteresis thresholding4
if
if
if
if
and all in
and at least one in
```

### 完整中文翻译
设高低阈值 theta2=2*theta1。高于高阈值的像素直接接受，低于低阈值的拒绝，中间像素只有与可靠边缘相连时才接受，这就是滞后阈值。

### 中文释义
本页属于边缘检测。设高低阈值 theta2=2*theta1。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 设高低阈值 theta2=2*theta1。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：设高低阈值 theta2=2*theta1。
- **Non-maximum suppression / 非极大值抑制**：沿梯度方向只保留局部最大响应，把厚边缘压成细边缘。

### 自测问题 / Self-check
- 中文问题：第 29 页的 Canny: double threshold and hysteresis 解决了什么问题？
  - 答案：设高低阈值 theta2=2*theta1。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 29, Canny: double threshold and hysteresis, address?
  - Answer: It addresses canny: double threshold and hysteresis as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 30 页：Canny summary

![PDF page 30](../assets/cv_w4/pages/page_030.png)

### 原文 / Original Text
```text
Canny edge detector
Summarizing, the Canny edge detection algorithm consists of the 
following steps:
1. Smooth the input image with a Gaussian filter.
2. Compute the gradient magnitude and angle images.
3. Apply nonmaxima suppression to the gradient magnitude image.
4. Use double thresholding and connectivity analysis to detect and link 
edges.
```

### 完整中文翻译
Canny 流程依次为高斯平滑、梯度幅值和角度、非极大值抑制、双阈值滞后。它把噪声抑制、定位和连通性结合起来。

### 中文释义
本页属于边缘检测。Canny 流程依次为高斯平滑、梯度幅值和角度、非极大值抑制、双阈值滞后。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. Canny 流程依次为高斯平滑、梯度幅值和角度、非极大值抑制、双阈值滞后。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：Canny 流程依次为高斯平滑、梯度幅值和角度、非极大值抑制、双阈值滞后。
- **Non-maximum suppression / 非极大值抑制**：沿梯度方向只保留局部最大响应，把厚边缘压成细边缘。

### 自测问题 / Self-check
- 中文问题：第 30 页的 Canny summary 解决了什么问题？
  - 答案：Canny 流程依次为高斯平滑、梯度幅值和角度、非极大值抑制、双阈值滞后。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 30, Canny summary, address?
  - Answer: It addresses canny summary as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 31 页：Canny visual pipeline

![PDF page 31](../assets/cv_w4/pages/page_031.png)

### 原文 / Original Text
```text
Canny edge detector
(a) Input image
(b) Quantized directions
(c) Non-local max suppression
(d) Hysteresis thresholding
```

### 完整中文翻译
图示展示输入图像、量化方向、非局部最大值抑制和滞后阈值四个中间结果，帮助定位 Canny 参数造成的变化。

### 中文释义
本页属于边缘检测。图示展示输入图像、量化方向、非局部最大值抑制和滞后阈值四个中间结果，帮助定位 Canny 参数造成的变化。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 图示展示输入图像、量化方向、非局部最大值抑制和滞后阈值四个中间结果，帮助定位 Canny 参数造成的变化。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：图示展示输入图像、量化方向、非局部最大值抑制和滞后阈值四个中间结果，帮助定位 Canny 参数造成的变化。
- **Non-maximum suppression / 非极大值抑制**：沿梯度方向只保留局部最大响应，把厚边缘压成细边缘。

### 自测问题 / Self-check
- 中文问题：第 31 页的 Canny visual pipeline 解决了什么问题？
  - 答案：图示展示输入图像、量化方向、非局部最大值抑制和滞后阈值四个中间结果，帮助定位 Canny 参数造成的变化。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 31, Canny visual pipeline, address?
  - Answer: It addresses canny visual pipeline as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 32 页：Edge-detection summary

![PDF page 32](../assets/cv_w4/pages/page_032.png)

### 原文 / Original Text
```text
Summary
• Edge detection
• First derivative
• Laplacian
• Canny edge detector
```

### 完整中文翻译
本部分总结：低层边缘检测、一阶导数、Laplacian 二阶导数和 Canny 检测器。复习时要能解释每种方法的响应、优点和局限。

### 中文释义
本页属于边缘检测。本部分总结：低层边缘检测、一阶导数、Laplacian 二阶导数和 Canny 检测器。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to 边缘检测. 本部分总结：低层边缘检测、一阶导数、Laplacian 二阶导数和 Canny 检测器。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **边缘检测**：本部分总结：低层边缘检测、一阶导数、Laplacian 二阶导数和 Canny 检测器。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 32 页的 Edge-detection summary 解决了什么问题？
  - 答案：本部分总结：低层边缘检测、一阶导数、Laplacian 二阶导数和 Canny 检测器。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 32, Edge-detection summary, address?
  - Answer: It addresses edge-detection summary as part of the 边缘检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 33 页：Computer Vision and Imaging

![PDF page 33](../assets/cv_w4/pages/page_033.png)

### 原文 / Original Text
```text
Computer Vision and 
Imaging
Dr. Qingjie Meng
Assistant Professor in Medical AI
School of Computer Science
University of Birmingham
Week 4- 2
```

### 完整中文翻译
计算机视觉与成像。第 4 周第二部分从边缘出发介绍检测、直线、圆和更高级的 Eigenfaces 表示。

### 中文释义
本页属于Hough 直线与圆检测。计算机视觉与成像。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 计算机视觉与成像。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：计算机视觉与成像。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 33 页的 Computer Vision and Imaging 解决了什么问题？
  - 答案：计算机视觉与成像。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 33, Computer Vision and Imaging, address?
  - Answer: It addresses computer vision and imaging as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 34 页：Detection contents

![PDF page 34](../assets/cv_w4/pages/page_034.png)

### 原文 / Original Text
```text
W4 Content
• Low-level CV&I
• Detection
• Lines
• Circles
• Advanced: Eigenfaces
```

### 完整中文翻译
检测部分覆盖从世界表示到边缘图、Hough 直线检测、圆检测以及 Eigenfaces。核心思想是把像素证据变成可参数化的结构。

### 中文释义
本页属于Hough 直线与圆检测。检测部分覆盖从世界表示到边缘图、Hough 直线检测、圆检测以及 Eigenfaces。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 检测部分覆盖从世界表示到边缘图、Hough 直线检测、圆检测以及 Eigenfaces。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：检测部分覆盖从世界表示到边缘图、Hough 直线检测、圆检测以及 Eigenfaces。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 34 页的 Detection contents 解决了什么问题？
  - 答案：检测部分覆盖从世界表示到边缘图、Hough 直线检测、圆检测以及 Eigenfaces。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 34, Detection contents, address?
  - Answer: It addresses detection contents as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 35 页：From pixels to a world representation

![PDF page 35](../assets/cv_w4/pages/page_035.png)

### 原文 / Original Text
```text
The representation of the world
Pixels 
• One important way that we recognise shapes is through mathematical functions that 
describe the boundary curves
Intensity gradient Edge map
Can we parameterise 
the primitives?
```

### 完整中文翻译
世界表示可以从像素开始，经由强度梯度得到边缘图，再由数学边界函数描述直线、圆等形状。每一步都丢弃一部分信息，同时获得更明确的结构。

### 中文释义
本页属于Hough 直线与圆检测。世界表示可以从像素开始，经由强度梯度得到边缘图，再由数学边界函数描述直线、圆等形状。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 世界表示可以从像素开始，经由强度梯度得到边缘图，再由数学边界函数描述直线、圆等形状。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：世界表示可以从像素开始，经由强度梯度得到边缘图，再由数学边界函数描述直线、圆等形状。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 35 页的 From pixels to a world representation 解决了什么问题？
  - 答案：世界表示可以从像素开始，经由强度梯度得到边缘图，再由数学边界函数描述直线、圆等形状。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 35, From pixels to a world representation, address?
  - Answer: It addresses from pixels to a world representation as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 36 页：From edge map to line

![PDF page 36](../assets/cv_w4/pages/page_036.png)

### 原文 / Original Text
```text
From edge to line 
• After edge detection, we get a binary edge map, which contains a set of edge points 
(𝑥',𝑦')𝑖=1,2,⋯,𝑁 . 
• If these edge points belong to a line, how can we get a parametric representation of the 
line?
• A well-known method of utilising this kind of information in computer vision is the Hough 
Transform, named after Paul Hough who patented the method in 1962
```

### 完整中文翻译
边缘检测产生二值边缘点集合。若一批点属于同一直线，就需要从这些点估计直线的参数表示。

### 中文释义
本页属于Hough 直线与圆检测。边缘检测产生二值边缘点集合。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 边缘检测产生二值边缘点集合。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：边缘检测产生二值边缘点集合。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 36 页的 From edge map to line 解决了什么问题？
  - 答案：边缘检测产生二值边缘点集合。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 36, From edge map to line, address?
  - Answer: It addresses from edge map to line as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 37 页：Line parameterisation

![PDF page 37](../assets/cv_w4/pages/page_037.png)

### 原文 / Original Text
```text
Line parameterisation 
• For example, a line can be represented by 
𝑦 = 𝑚𝑥 + 𝑏, 
i.e. just two parameters 𝑚 and 𝑏. 
• This is a much more efficient representation 
than a lot of edge points.
```

### 完整中文翻译
直线可以用 y=mx+b 表示，只需斜率 m 和截距 b 两个参数。这比逐点存储一组边缘点更加紧凑。

### 中文释义
本页属于Hough 直线与圆检测。直线可以用 y=mx+b 表示，只需斜率 m 和截距 b 两个参数。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 直线可以用 y=mx+b 表示，只需斜率 m 和截距 b 两个参数。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：直线可以用 y=mx+b 表示，只需斜率 m 和截距 b 两个参数。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 37 页的 Line parameterisation 解决了什么问题？
  - 答案：直线可以用 y=mx+b 表示，只需斜率 m 和截距 b 两个参数。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 37, Line parameterisation, address?
  - Answer: It addresses line parameterisation as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 38 页：Line parameterisation visual

![PDF page 38](../assets/cv_w4/pages/page_038.png)

### 原文 / Original Text
```text
Line parameterisation
```

### 完整中文翻译
图示把图像空间中的直线与参数表示对应起来，强调同一条几何直线可以用少量参数描述。

### 中文释义
本页属于Hough 直线与圆检测。图示把图像空间中的直线与参数表示对应起来，强调同一条几何直线可以用少量参数描述。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 图示把图像空间中的直线与参数表示对应起来，强调同一条几何直线可以用少量参数描述。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：图示把图像空间中的直线与参数表示对应起来，强调同一条几何直线可以用少量参数描述。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 38 页的 Line parameterisation visual 解决了什么问题？
  - 答案：图示把图像空间中的直线与参数表示对应起来，强调同一条几何直线可以用少量参数描述。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 38, Line parameterisation visual, address?
  - Answer: It addresses line parameterisation visual as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 39 页：Slope-intercept form

![PDF page 39](../assets/cv_w4/pages/page_039.png)

### 原文 / Original Text
```text
Slope intercept form 
𝑦 = 𝑚𝑥+ 𝑏
𝑚: Slope 
𝑏: y-intercept
```

### 完整中文翻译
斜截式 y=mx+b 中，m 是斜率，b 是 y 轴截距。对每个点代入可得到参数空间中的一条约束曲线。

### 中文释义
本页属于Hough 直线与圆检测。斜截式 y=mx+b 中，m 是斜率，b 是 y 轴截距。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 斜截式 y=mx+b 中，m 是斜率，b 是 y 轴截距。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：斜截式 y=mx+b 中，m 是斜率，b 是 y 轴截距。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 39 页的 Slope-intercept form 解决了什么问题？
  - 答案：斜截式 y=mx+b 中，m 是斜率，b 是 y 轴截距。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 39, Slope-intercept form, address?
  - Answer: It addresses slope-intercept form as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 40 页：Double-intercept form

![PDF page 40](../assets/cv_w4/pages/page_040.png)

### 原文 / Original Text
```text
Double intercept form
𝑎: x-intercept 
𝑏: y-intercept
```

### 完整中文翻译
双截距形式用 a 表示 x 轴截距、b 表示 y 轴截距。它直观，但当直线接近坐标轴或穿过原点时要注意退化情况。

### 中文释义
本页属于Hough 直线与圆检测。双截距形式用 a 表示 x 轴截距、b 表示 y 轴截距。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 双截距形式用 a 表示 x 轴截距、b 表示 y 轴截距。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：双截距形式用 a 表示 x 轴截距、b 表示 y 轴截距。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 40 页的 Double-intercept form 解决了什么问题？
  - 答案：双截距形式用 a 表示 x 轴截距、b 表示 y 轴截距。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 40, Double-intercept form, address?
  - Answer: It addresses double-intercept form as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 41 页：Normal form

![PDF page 41](../assets/cv_w4/pages/page_041.png)

### 原文 / Original Text
```text
Normal form 
𝜃: Angle  
𝑏: Distance from the origin
```

### 完整中文翻译
法线式用 theta 表示法线角度，用 rho 表示原点到直线的有符号距离。它能自然表示垂直线，且参数范围更可控。

### 中文释义
本页属于Hough 直线与圆检测。法线式用 theta 表示法线角度，用 rho 表示原点到直线的有符号距离。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 法线式用 theta 表示法线角度，用 rho 表示原点到直线的有符号距离。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：法线式用 theta 表示法线角度，用 rho 表示原点到直线的有符号距离。
- **Gradient / 梯度**：由方向导数组成的向量，给出强度变化最快的方向和大小。

### 自测问题 / Self-check
- 中文问题：第 41 页的 Normal form 解决了什么问题？
  - 答案：法线式用 theta 表示法线角度，用 rho 表示原点到直线的有符号距离。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 41, Normal form, address?
  - Answer: It addresses normal form as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 42 页：Hough transform

![PDF page 42](../assets/cv_w4/pages/page_042.png)

### 原文 / Original Text
```text
Hough transform 
• Hough transform is a transform from image space to parameter space (e.g. from an 
edge map to parameters of a line). 
• Its output is a parametric model, given the input edge points. 
• The basic idea is that each edge point votes for possible parameters in the parameter 
space.
```

### 完整中文翻译
Hough 变换把图像空间转换到参数空间，例如从边缘图估计直线参数。每个边缘点为可能的参数投票，峰值代表共同支持的模型。

### 中文释义
本页属于Hough 直线与圆检测。Hough 变换把图像空间转换到参数空间，例如从边缘图估计直线参数。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. Hough 变换把图像空间转换到参数空间，例如从边缘图估计直线参数。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：Hough 变换把图像空间转换到参数空间，例如从边缘图估计直线参数。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 42 页的 Hough transform 解决了什么问题？
  - 答案：Hough 变换把图像空间转换到参数空间，例如从边缘图估计直线参数。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 42, Hough transform, address?
  - Answer: It addresses hough transform as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 43 页：Hough transform with slope-intercept form

![PDF page 43](../assets/cv_w4/pages/page_043.png)

### 原文 / Original Text
```text
Hough transform – with slope intercept 
form 
• Let us use the slope intercept form for a line model
• We have edge points in the image space 𝑥1, 𝑦1 , 𝑥2, 𝑦2 , 𝑥3, 𝑦3 ,…
• Each point votes for a line model in the parameter space 
• For example, the first point will vote for 𝑏 = 𝑦1 − 𝑚𝑥1
𝑦 = 𝑚𝑥+ 𝑏
𝑏 = 𝑦− 𝑚𝑥
𝑦 = 𝑚𝑥+ 𝑏
Image space Parameter space (Hough space)
𝑏 = −𝑚𝑥+ 𝑦
```

### 完整中文翻译
若使用斜截式，每个图像边缘点都会在 m-b 参数空间投票一条曲线。多个共线点的曲线会在同一个参数位置相交。

### 中文释义
本页属于Hough 直线与圆检测。若使用斜截式，每个图像边缘点都会在 m-b 参数空间投票一条曲线。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 若使用斜截式，每个图像边缘点都会在 m-b 参数空间投票一条曲线。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：若使用斜截式，每个图像边缘点都会在 m-b 参数空间投票一条曲线。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 43 页的 Hough transform with slope-intercept form 解决了什么问题？
  - 答案：若使用斜截式，每个图像边缘点都会在 m-b 参数空间投票一条曲线。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 43, Hough transform with slope-intercept form, address?
  - Answer: It addresses hough transform with slope-intercept form as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 44 页：Hough space visualisation

![PDF page 44](../assets/cv_w4/pages/page_044.png)

### 原文 / Original Text
```text
Image space Parameter space (Hough space)
Hough transform – with slope intercept 
form
```

### 完整中文翻译
图像空间中的点被映射到 Hough 参数空间。共线点的投票轨迹在参数空间形成峰值，因此可以由峰值反推出直线。

### 中文释义
本页属于Hough 直线与圆检测。图像空间中的点被映射到 Hough 参数空间。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 图像空间中的点被映射到 Hough 参数空间。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：图像空间中的点被映射到 Hough 参数空间。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 44 页的 Hough space visualisation 解决了什么问题？
  - 答案：图像空间中的点被映射到 Hough 参数空间。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 44, Hough space visualisation, address?
  - Answer: It addresses hough space visualisation as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 45 页：Hough accumulator bins

![PDF page 45](../assets/cv_w4/pages/page_045.png)

### 原文 / Original Text
```text
• In practice, the parameter space is divided into 2D bins. 
• Each point increments the vote by 1 in one of the bins. 
Hough transform – with slope intercept 
form
```

### 完整中文翻译
实际参数空间被划分成二维 bins，每个点使对应 bin 的票数加一。离散化分辨率决定定位精度、内存和抗噪性能。

### 中文释义
本页属于Hough 直线与圆检测。实际参数空间被划分成二维 bins，每个点使对应 bin 的票数加一。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 实际参数空间被划分成二维 bins，每个点使对应 bin 的票数加一。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：实际参数空间被划分成二维 bins，每个点使对应 bin 的票数加一。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 45 页的 Hough accumulator bins 解决了什么问题？
  - 答案：实际参数空间被划分成二维 bins，每个点使对应 bin 的票数加一。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 45, Hough accumulator bins, address?
  - Answer: It addresses hough accumulator bins as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 46 页：Why slope-intercept form is inconvenient

![PDF page 46](../assets/cv_w4/pages/page_046.png)

### 原文 / Original Text
```text
Disadvantages of the slope-intercept form:
• Vertical line cannot be represented as the slope of a vertical line is ∞.
• The parameter space is too large, 𝑚 ∈ −∞, +∞ , 𝑏 ∈ [−∞, +∞]. We need a lot of cells. 
Hough transform – with slope intercept 
form
```

### 完整中文翻译
斜截式不能表示垂直线，因为垂直线斜率为无穷大；而且 m 和 b 的范围无界，参数空间需要过多单元。

### 中文释义
本页属于Hough 直线与圆检测。斜截式不能表示垂直线，因为垂直线斜率为无穷大；而且 m 和 b 的范围无界，参数空间需要过多单元。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 斜截式不能表示垂直线，因为垂直线斜率为无穷大；而且 m 和 b 的范围无界，参数空间需要过多单元。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：斜截式不能表示垂直线，因为垂直线斜率为无穷大；而且 m 和 b 的范围无界，参数空间需要过多单元。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 46 页的 Why slope-intercept form is inconvenient 解决了什么问题？
  - 答案：斜截式不能表示垂直线，因为垂直线斜率为无穷大；而且 m 和 b 的范围无界，参数空间需要过多单元。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 46, Why slope-intercept form is inconvenient, address?
  - Answer: It addresses why slope-intercept form is inconvenient as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 47 页：Hough transform with normal form

![PDF page 47](../assets/cv_w4/pages/page_047.png)

### 原文 / Original Text
```text
Hough transform – with normal form 
• Solution is using normal form
• We can use much fewer bins 𝜌 ∈ −∞, +∞ , 𝜃 ∈ [0, 𝜋] 
• In practice 𝜌 is not infinite either. It is limited by the image size
```

### 完整中文翻译
法线式把参数限制为 rho 和 theta。theta 可限制在 [0,pi]，rho 也受图像尺寸限制，因此需要的 bins 更少。

### 中文释义
本页属于Hough 直线与圆检测。法线式把参数限制为 rho 和 theta。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 法线式把参数限制为 rho 和 theta。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：法线式把参数限制为 rho 和 theta。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 47 页的 Hough transform with normal form 解决了什么问题？
  - 答案：法线式把参数限制为 rho 和 theta。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 47, Hough transform with normal form, address?
  - Answer: It addresses hough transform with normal form as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 48 页：Normal-form Hough space

![PDF page 48](../assets/cv_w4/pages/page_048.png)

### 原文 / Original Text
```text
Hough transform – with normal form 
The transform from image space to parameter space will look different 
Image space Parameter space (Hough space)
𝜃 can be in [0, 𝜋] or [−90,90] range
```

### 完整中文翻译
法线式的 Hough 变换把图像空间点映射到 rho-theta 空间。theta 可用 [0,pi] 或 [-90°,90°] 表示，取决于约定。

### 中文释义
本页属于Hough 直线与圆检测。法线式的 Hough 变换把图像空间点映射到 rho-theta 空间。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 法线式的 Hough 变换把图像空间点映射到 rho-theta 空间。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：法线式的 Hough 变换把图像空间点映射到 rho-theta 空间。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 48 页的 Normal-form Hough space 解决了什么问题？
  - 答案：法线式的 Hough 变换把图像空间点映射到 rho-theta 空间。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 48, Normal-form Hough space, address?
  - Answer: It addresses normal-form hough space as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 49 页：Hough line-detection algorithm

![PDF page 49](../assets/cv_w4/pages/page_049.png)

### 原文 / Original Text
```text
Hough transform for line detection  algorithm
1. Given an input image 𝑓(𝑥, 𝑦), detect edge points using the Canny edge detector.
2. Define the intervals for 𝜌 and 𝜃, for example, − 2𝐷 ≤ 𝜌 ≤  + 2𝐷 and −90 ≤ 𝜃 ≤ 90, 
where 𝐷 is the distance between opposite corners in 𝑓 𝑥, 𝑦 .
3. Create and initialize 𝐻(𝜌, 𝜃) to zero to accumulate the votes of each pair (𝜌, 𝜃).
4. For each edge point 𝑥, y : 
1. For each value in 𝜃 range:
1. Calculate 𝜌 = 𝑥 𝑐𝑜𝑠 𝜃 + y sin 𝜃
2. Accumulate H 𝜌, 𝜃 = H 𝜌, 𝜃 + 1
5. Apply a threshold to matrix 𝐻 to find the most voted pairs (𝜌, 𝜃) representing the 
detected lines in the input image.
```

### 完整中文翻译
直线检测流程：先用 Canny 得到边缘点；定义 rho 和 theta 的区间；建立零初始化的累加器 H(rho,theta)；为每个边缘点投票；提取超过阈值的局部峰值。

### 中文释义
本页属于Hough 直线与圆检测。直线检测流程：先用 Canny 得到边缘点；定义 rho 和 theta 的区间；建立零初始化的累加器 H(rho,theta)；为每个边缘点投票；提取超过阈值的局部峰值。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 直线检测流程：先用 Canny 得到边缘点；定义 rho 和 theta 的区间；建立零初始化的累加器 H(rho,theta)；为每个边缘点投票；提取超过阈值的局部峰值。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：直线检测流程：先用 Canny 得到边缘点；定义 rho 和 theta 的区间；建立零初始化的累加器 H(rho,theta)；为每个边缘点投票；提取超过阈值的局部峰值。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 49 页的 Hough line-detection algorithm 解决了什么问题？
  - 答案：直线检测流程：先用 Canny 得到边缘点；定义 rho 和 theta 的区间；建立零初始化的累加器 H(rho,theta)；为每个边缘点投票；提取超过阈值的局部峰值。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 49, Hough line-detection algorithm, address?
  - Answer: It addresses hough line-detection algorithm as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 50 页：Line detection by Hough transform

![PDF page 50](../assets/cv_w4/pages/page_050.png)

### 原文 / Original Text
```text
Line detection by Hough transform 
Canny edge detection
Image 
Line detection 
using Hough 
transform
```

### 完整中文翻译
直线检测先生成 Canny 边缘图，再进行 Hough 投票，最后把 Hough 空间峰值转回图像中的直线。

### 中文释义
本页属于Hough 直线与圆检测。直线检测先生成 Canny 边缘图，再进行 Hough 投票，最后把 Hough 空间峰值转回图像中的直线。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 直线检测先生成 Canny 边缘图，再进行 Hough 投票，最后把 Hough 空间峰值转回图像中的直线。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：直线检测先生成 Canny 边缘图，再进行 Hough 投票，最后把 Hough 空间峰值转回图像中的直线。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 50 页的 Line detection by Hough transform 解决了什么问题？
  - 答案：直线检测先生成 Canny 边缘图，再进行 Hough 投票，最后把 Hough 空间峰值转回图像中的直线。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 50, Line detection by Hough transform, address?
  - Answer: It addresses line detection by hough transform as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 51 页：Detecting multiple lines

![PDF page 51](../assets/cv_w4/pages/page_051.png)

### 原文 / Original Text
```text
Image Edge map Parameter space 
(Hough space)
Detected lines
Hough transform can simultaneously detect multiple lines, as long as they are local 
maxima above a threshold 
Hough transform
```

### 完整中文翻译
一个累加器可以同时包含多条直线。只要局部峰值超过阈值，就能把不同峰值解释为不同的直线模型。

### 中文释义
本页属于Hough 直线与圆检测。一个累加器可以同时包含多条直线。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 一个累加器可以同时包含多条直线。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：一个累加器可以同时包含多条直线。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 51 页的 Detecting multiple lines 解决了什么问题？
  - 答案：一个累加器可以同时包含多条直线。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 51, Detecting multiple lines, address?
  - Answer: It addresses detecting multiple lines as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 52 页：Robustness to noise

![PDF page 52](../assets/cv_w4/pages/page_052.png)

### 原文 / Original Text
```text
It is robust to noise. Broken edge points can still vote and contribute to line detection. 
Image Edge map Parameter space 
(Hough space)
Detected lines
Hough transform
```

### 完整中文翻译
Hough 对噪声较稳健：即使边缘点破碎，仍有一部分点能投票到同一模型，累积证据可能保留直线峰值。

### 中文释义
本页属于Hough 直线与圆检测。Hough 对噪声较稳健：即使边缘点破碎，仍有一部分点能投票到同一模型，累积证据可能保留直线峰值。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. Hough 对噪声较稳健：即使边缘点破碎，仍有一部分点能投票到同一模型，累积证据可能保留直线峰值。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：Hough 对噪声较稳健：即使边缘点破碎，仍有一部分点能投票到同一模型，累积证据可能保留直线峰值。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 52 页的 Robustness to noise 解决了什么问题？
  - 答案：Hough 对噪声较稳健：即使边缘点破碎，仍有一部分点能投票到同一模型，累积证据可能保留直线峰值。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 52, Robustness to noise, address?
  - Answer: It addresses robustness to noise as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 53 页：Robustness to occlusion

![PDF page 53](../assets/cv_w4/pages/page_053.png)

### 原文 / Original Text
```text
It is robust to object occlusion. The remaining edge points still contribute to line detection. 
Image Edge map Parameter space 
(Hough space)
Detected lines
Hough transform
```

### 完整中文翻译
Hough 对遮挡也较稳健：物体被遮挡后剩余的可见边缘点仍能共同投票，因此不需要整条边界完整可见。

### 中文释义
本页属于Hough 直线与圆检测。Hough 对遮挡也较稳健：物体被遮挡后剩余的可见边缘点仍能共同投票，因此不需要整条边界完整可见。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. Hough 对遮挡也较稳健：物体被遮挡后剩余的可见边缘点仍能共同投票，因此不需要整条边界完整可见。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：Hough 对遮挡也较稳健：物体被遮挡后剩余的可见边缘点仍能共同投票，因此不需要整条边界完整可见。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 53 页的 Robustness to occlusion 解决了什么问题？
  - 答案：Hough 对遮挡也较稳健：物体被遮挡后剩余的可见边缘点仍能共同投票，因此不需要整条边界完整可见。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 53, Robustness to occlusion, address?
  - Answer: It addresses robustness to occlusion as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 54 页：Circle parameterisation

![PDF page 54](../assets/cv_w4/pages/page_054.png)

### 原文 / Original Text
```text
Circle detection by Hough transform 
• We can parameterise a circle as, 
• With 1 ≤  𝑎 ≤  𝑀 and 1 ≤  𝑏 ≤  𝑁 
• Where 𝑎 and 𝑏 are the centre of the circle and 𝑀 and 𝑁 are the width and 
height of 𝑓(𝑥, 𝑦)
• The image space (𝑥, 𝑦) is transformed to the parameter space (𝑎, 𝑏, 𝑟) 
(a,b)
```

### 完整中文翻译
圆可用中心 (a,b) 和半径 r 参数化：(x-a)^2+(y-b)^2=r^2。a、b 位于图像范围内，r 控制圆的大小。

### 中文释义
本页属于Hough 直线与圆检测。圆可用中心 (a,b) 和半径 r 参数化：(x-a)^2+(y-b)^2=r^2。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 圆可用中心 (a,b) 和半径 r 参数化：(x-a)^2+(y-b)^2=r^2。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：圆可用中心 (a,b) 和半径 r 参数化：(x-a)^2+(y-b)^2=r^2。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 54 页的 Circle parameterisation 解决了什么问题？
  - 答案：圆可用中心 (a,b) 和半径 r 参数化：(x-a)^2+(y-b)^2=r^2。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 54, Circle parameterisation, address?
  - Answer: It addresses circle parameterisation as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 55 页：Known-radius circle voting

![PDF page 55](../assets/cv_w4/pages/page_055.png)

### 原文 / Original Text
```text
Circle detection by Hough transform 
• If we know the radius 𝑟, it would be easier. 
• Then for each edge point (𝑥, 𝑦) , we only need to vote for possible values of (𝑎, 𝑏) 
• It is a circle in the parameter space H(𝑎, 𝑏)
```

### 完整中文翻译
若半径已知，每个边缘点只需为可能的中心 (a,b) 投票；在参数空间中，这些中心形成一条圆。

### 中文释义
本页属于Hough 直线与圆检测。若半径已知，每个边缘点只需为可能的中心 (a,b) 投票；在参数空间中，这些中心形成一条圆。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 若半径已知，每个边缘点只需为可能的中心 (a,b) 投票；在参数空间中，这些中心形成一条圆。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：若半径已知，每个边缘点只需为可能的中心 (a,b) 投票；在参数空间中，这些中心形成一条圆。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 55 页的 Known-radius circle voting 解决了什么问题？
  - 答案：若半径已知，每个边缘点只需为可能的中心 (a,b) 投票；在参数空间中，这些中心形成一条圆。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 55, Known-radius circle voting, address?
  - Answer: It addresses known-radius circle voting as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 56 页：Circle Hough space

![PDF page 56](../assets/cv_w4/pages/page_056.png)

### 原文 / Original Text
```text
Circle detection by Hough transform 
Image space Parameter space (Hough space)
```

### 完整中文翻译
图示比较图像空间的圆边缘与参数空间中的投票结构。峰值位置给出最可能的圆心。

### 中文释义
本页属于Hough 直线与圆检测。图示比较图像空间的圆边缘与参数空间中的投票结构。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 图示比较图像空间的圆边缘与参数空间中的投票结构。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：图示比较图像空间的圆边缘与参数空间中的投票结构。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 56 页的 Circle Hough space 解决了什么问题？
  - 答案：图示比较图像空间的圆边缘与参数空间中的投票结构。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 56, Circle Hough space, address?
  - Answer: It addresses circle hough space as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 57 页：Unknown-radius circle voting

![PDF page 57](../assets/cv_w4/pages/page_057.png)

### 原文 / Original Text
```text
Circle detection by Hough transform 
• If the radius 𝑟 is unknown, then it is a 3D parameter space H(𝑎, b, r)
• We set a range for the radius 𝑟. 
For each 𝑟 ∈ [𝑟𝑚𝑖𝑛 , 𝑟𝑚𝑎𝑥]:
For each edge point 𝑥, y :
We vote for possible values of 𝑎, b  and accumulate H(𝑎, b, r)
• For example, we can start from 𝑟 = 1 pixel to 10 pixels, each time increasing by 1 pixel.
```

### 完整中文翻译
半径未知时需要三维累加器 H(a,b,r)。先限定 r 的最小和最大范围，再对每个半径和边缘点累积投票。

### 中文释义
本页属于Hough 直线与圆检测。半径未知时需要三维累加器 H(a,b,r)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 半径未知时需要三维累加器 H(a,b,r)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：半径未知时需要三维累加器 H(a,b,r)。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 57 页的 Unknown-radius circle voting 解决了什么问题？
  - 答案：半径未知时需要三维累加器 H(a,b,r)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 57, Unknown-radius circle voting, address?
  - Answer: It addresses unknown-radius circle voting as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 58 页：Trigonometric parameterisation

![PDF page 58](../assets/cv_w4/pages/page_058.png)

### 原文 / Original Text
```text
Circle detection by Hough transform 
• Parametric form using trigonometric functions 
• This form gives us some ideas for acceleration. 
• If we know the angle 𝜃 (direction) from the edge point 𝑥,𝑦 to the circle centre (𝑎, 𝑏) , we 
can more accurately vote in the parameter space.
```

### 完整中文翻译
圆也可用三角函数参数化：x=a+r cos(theta)，y=b+r sin(theta)。若能估计边缘到圆心的方向，就能把投票限制在更准确的方向上。

### 中文释义
本页属于Hough 直线与圆检测。圆也可用三角函数参数化：x=a+r cos(theta)，y=b+r sin(theta)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 圆也可用三角函数参数化：x=a+r cos(theta)，y=b+r sin(theta)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：圆也可用三角函数参数化：x=a+r cos(theta)，y=b+r sin(theta)。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 58 页的 Trigonometric parameterisation 解决了什么问题？
  - 答案：圆也可用三角函数参数化：x=a+r cos(theta)，y=b+r sin(theta)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 58, Trigonometric parameterisation, address?
  - Answer: It addresses trigonometric parameterisation as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 59 页：Circle Hough space visualisation

![PDF page 59](../assets/cv_w4/pages/page_059.png)

### 原文 / Original Text
```text
Circle detection by Hough transform 
Image space Parameter space (Hough space)
𝜃 is unknown so 
we vote for the 
whole circle
```

### 完整中文翻译
当 theta 未知时，每个边缘点要在参数空间投票一整圈；这解释了计算量，也说明方向信息可以用来加速。

### 中文释义
本页属于Hough 直线与圆检测。当 theta 未知时，每个边缘点要在参数空间投票一整圈；这解释了计算量，也说明方向信息可以用来加速。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 当 theta 未知时，每个边缘点要在参数空间投票一整圈；这解释了计算量，也说明方向信息可以用来加速。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：当 theta 未知时，每个边缘点要在参数空间投票一整圈；这解释了计算量，也说明方向信息可以用来加速。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 59 页的 Circle Hough space visualisation 解决了什么问题？
  - 答案：当 theta 未知时，每个边缘点要在参数空间投票一整圈；这解释了计算量，也说明方向信息可以用来加速。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 59, Circle Hough space visualisation, address?
  - Answer: It addresses circle hough space visualisation as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 60 页：Circle-detection algorithm

![PDF page 60](../assets/cv_w4/pages/page_060.png)

### 原文 / Original Text
```text
Circle detection by Hough transform 
1. Given an input image 𝑓(𝑥, 𝑦), detect edge points using the Canny edge detector.
2. Define the interval for 𝜃, for example, [0,360], and a predefined 𝑟 value.
3. Create and initialize 𝐻(𝑎, 𝑏) to zero to accumulate the votes of each pair (𝑎, 𝑏).
4. For each edge point 𝑥, y : 
1. For each value in 𝜃 range:
1. Calculate 𝑎 = 𝑥 − r ∗ cos 𝜃 , 𝑏 = 𝑦− 𝑟 ∗ sin(𝜃) 
2. Accumulate H 𝑎, 𝑏 = H 𝑎, 𝑏 + 1
5. Apply a threshold to matrix 𝐻 to find the most voted pairs (𝜌, 𝜃) representing the 
detected lines in the input image.
```

### 完整中文翻译
圆检测流程与直线类似：用 Canny 得到边缘，设定 theta 和半径范围，初始化 H(a,b)，再让每个边缘点对候选圆心投票并找峰值。

### 中文释义
本页属于Hough 直线与圆检测。圆检测流程与直线类似：用 Canny 得到边缘，设定 theta 和半径范围，初始化 H(a,b)，再让每个边缘点对候选圆心投票并找峰值。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 圆检测流程与直线类似：用 Canny 得到边缘，设定 theta 和半径范围，初始化 H(a,b)，再让每个边缘点对候选圆心投票并找峰值。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：圆检测流程与直线类似：用 Canny 得到边缘，设定 theta 和半径范围，初始化 H(a,b)，再让每个边缘点对候选圆心投票并找峰值。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 60 页的 Circle-detection algorithm 解决了什么问题？
  - 答案：圆检测流程与直线类似：用 Canny 得到边缘，设定 theta 和半径范围，初始化 H(a,b)，再让每个边缘点对候选圆心投票并找峰值。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 60, Circle-detection algorithm, address?
  - Answer: It addresses circle-detection algorithm as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 61 页：Circle detection visual

![PDF page 61](../assets/cv_w4/pages/page_061.png)

### 原文 / Original Text
```text
Circle detection by Hough transform
```

### 完整中文翻译
图示展示圆的图像空间、参数空间和检测结果。检测质量取决于半径范围、阈值、边缘质量与投票分辨率。

### 中文释义
本页属于Hough 直线与圆检测。图示展示圆的图像空间、参数空间和检测结果。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. 图示展示圆的图像空间、参数空间和检测结果。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：图示展示圆的图像空间、参数空间和检测结果。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 61 页的 Circle detection visual 解决了什么问题？
  - 答案：图示展示圆的图像空间、参数空间和检测结果。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 61, Circle detection visual, address?
  - Answer: It addresses circle detection visual as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 62 页：Hough-transform advantages

![PDF page 62](../assets/cv_w4/pages/page_062.png)

### 原文 / Original Text
```text
• It detects multiple instances. 
• Robust to image noise. 
• Robust to occlusion.
• Other shapes: 
Hough transform - advantages
```

### 完整中文翻译
Hough 可以检测多个实例，对噪声和遮挡较稳健，也可以扩展到其他有参数边界的形状；代价是参数维度和计算量可能迅速增加。

### 中文释义
本页属于Hough 直线与圆检测。Hough 可以检测多个实例，对噪声和遮挡较稳健，也可以扩展到其他有参数边界的形状；代价是参数维度和计算量可能迅速增加。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to Hough 直线与圆检测. Hough 可以检测多个实例，对噪声和遮挡较稳健，也可以扩展到其他有参数边界的形状；代价是参数维度和计算量可能迅速增加。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **Hough 直线与圆检测**：Hough 可以检测多个实例，对噪声和遮挡较稳健，也可以扩展到其他有参数边界的形状；代价是参数维度和计算量可能迅速增加。
- **Accumulator / 累加器**：把参数空间离散成 bins，用投票计数寻找支持度高的模型。

### 自测问题 / Self-check
- 中文问题：第 62 页的 Hough-transform advantages 解决了什么问题？
  - 答案：Hough 可以检测多个实例，对噪声和遮挡较稳健，也可以扩展到其他有参数边界的形状；代价是参数维度和计算量可能迅速增加。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 62, Hough-transform advantages, address?
  - Answer: It addresses hough-transform advantages as part of the Hough 直线与圆检测 pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 63 页：Advanced detection: Eigenfaces

![PDF page 63](../assets/cv_w4/pages/page_063.png)

### 原文 / Original Text
```text
Detection of advanced forms:
Eigenfaces
```

### 完整中文翻译
Eigenfaces 是把 PCA 应用于人脸图像的高级检测/表示形式。它用一组主成分基表示人脸的主要变化方向。

### 中文释义
本页属于PCA 与 Eigenfaces。Eigenfaces 是把 PCA 应用于人脸图像的高级检测/表示形式。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to PCA 与 Eigenfaces. Eigenfaces 是把 PCA 应用于人脸图像的高级检测/表示形式。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **PCA 与 Eigenfaces**：Eigenfaces 是把 PCA 应用于人脸图像的高级检测/表示形式。
- **Principal component / 主成分**：按解释方差排序、彼此正交的低维表示方向。

### 自测问题 / Self-check
- 中文问题：第 63 页的 Advanced detection: Eigenfaces 解决了什么问题？
  - 答案：Eigenfaces 是把 PCA 应用于人脸图像的高级检测/表示形式。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 63, Advanced detection: Eigenfaces, address?
  - Answer: It addresses advanced detection: eigenfaces as part of the PCA 与 Eigenfaces pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 64 页：Principal Component Analysis

![PDF page 64](../assets/cv_w4/pages/page_064.png)

### 原文 / Original Text
```text
Principle Component Analysis (PCA)
PCA is a technique that simplifies the complexity of a dataset. It uses smaller number of 
uncorrelated variables (principal components) to represent the original complex dataset. 
Each uncorrelated variable is the representation of the differences between the data in the 
dataset.
• Reducing the dimensionality of a dataset
• Increasing the interpretability without losing information
```

### 完整中文翻译
PCA 用较少的互不相关变量表示复杂数据。每个主成分代表数据集差异中的一个方向，并按解释方差的重要性排序。

### 中文释义
本页属于PCA 与 Eigenfaces。PCA 用较少的互不相关变量表示复杂数据。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to PCA 与 Eigenfaces. PCA 用较少的互不相关变量表示复杂数据。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **PCA 与 Eigenfaces**：PCA 用较少的互不相关变量表示复杂数据。
- **Principal component / 主成分**：按解释方差排序、彼此正交的低维表示方向。

### 自测问题 / Self-check
- 中文问题：第 64 页的 Principal Component Analysis 解决了什么问题？
  - 答案：PCA 用较少的互不相关变量表示复杂数据。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 64, Principal Component Analysis, address?
  - Answer: It addresses principal component analysis as part of the PCA 与 Eigenfaces pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 65 页：PCA concepts to review

![PDF page 65](../assets/cv_w4/pages/page_065.png)

### 原文 / Original Text
```text
Principle Component Analysis (PCA)
We need to review the following concepts
• Variance 
• Covariance
• Eigenvectors
• Eigenvalues
```

### 完整中文翻译
理解 PCA 需要回顾方差、协方差、协方差矩阵、特征向量和特征值。这些概念共同决定主成分方向与保留的信息量。

### 中文释义
本页属于PCA 与 Eigenfaces。理解 PCA 需要回顾方差、协方差、协方差矩阵、特征向量和特征值。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to PCA 与 Eigenfaces. 理解 PCA 需要回顾方差、协方差、协方差矩阵、特征向量和特征值。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **PCA 与 Eigenfaces**：理解 PCA 需要回顾方差、协方差、协方差矩阵、特征向量和特征值。
- **Principal component / 主成分**：按解释方差排序、彼此正交的低维表示方向。

### 自测问题 / Self-check
- 中文问题：第 65 页的 PCA concepts to review 解决了什么问题？
  - 答案：理解 PCA 需要回顾方差、协方差、协方差矩阵、特征向量和特征值。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 65, PCA concepts to review, address?
  - Answer: It addresses pca concepts to review as part of the PCA 与 Eigenfaces pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 66 页：Variance

![PDF page 66](../assets/cv_w4/pages/page_066.png)

### 原文 / Original Text
```text
Variance 
𝜎2 = ෍
𝑖=0
𝑛
(𝑥𝑖 − ҧ𝑥)2
𝑛
Variance Number of values 
Values  
Mean value 
Variance – measure of the deviation from the mean for points in one dimension
```

### 完整中文翻译
方差衡量数据围绕均值的离散程度，典型形式是 sigma²=sum((xi-xbar)²)。方差越大，数据在该方向上的变化越明显。

### 中文释义
本页属于PCA 与 Eigenfaces。方差衡量数据围绕均值的离散程度，典型形式是 sigma²=sum((xi-xbar)²)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to PCA 与 Eigenfaces. 方差衡量数据围绕均值的离散程度，典型形式是 sigma²=sum((xi-xbar)²)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **PCA 与 Eigenfaces**：方差衡量数据围绕均值的离散程度，典型形式是 sigma²=sum((xi-xbar)²)。
- **Principal component / 主成分**：按解释方差排序、彼此正交的低维表示方向。

### 自测问题 / Self-check
- 中文问题：第 66 页的 Variance 解决了什么问题？
  - 答案：方差衡量数据围绕均值的离散程度，典型形式是 sigma²=sum((xi-xbar)²)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 66, Variance, address?
  - Answer: It addresses variance as part of the PCA 与 Eigenfaces pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 67 页：Covariance and covariance matrix

![PDF page 67](../assets/cv_w4/pages/page_067.png)

### 原文 / Original Text
```text
Covariance 
Covariance matrix 
Covariance is measured between 2 dimensions to see if there is a relationship between the 
2 dimensions, e.g., number of hours studies and marks
𝐶 = 𝑐𝑜𝑣(𝑥, 𝑥) 𝑐𝑜𝑣(𝑥, 𝑦)
𝑐𝑜𝑣(𝑦, 𝑥) 𝑐𝑜𝑣(𝑦, 𝑦)
𝑐𝑜𝑣(𝑥, 𝑥) , 𝑐𝑜𝑣(𝑦, 𝑦) are variance 
𝐶 =
𝑐𝑜𝑣(𝑥, 𝑥) 𝑐𝑜𝑣(𝑥, 𝑦) 𝑐𝑜𝑣(𝑥, 𝑦)
𝑐𝑜𝑣(𝑦, 𝑥) 𝑐𝑜𝑣(𝑦, 𝑦) 𝑐𝑜𝑣(𝑦, 𝑧)
𝑐𝑜𝑣(𝑧, 𝑥) 𝑐𝑜𝑣(𝑧, 𝑦) 𝑐𝑜𝑣(𝑧, 𝑧)
𝑐𝑜𝑣(𝑥, 𝑦) = ෍
𝑖=0
𝑛
(𝑥𝑖 − ҧ𝑥)(𝑦𝑖 − ത𝑦)
𝑛𝑐𝑜𝑣(𝑥, 𝑥) = ෍
𝑖=0
𝑛
(𝑥𝑖 − ҧ𝑥)2
𝑛
```

### 完整中文翻译
协方差衡量两个维度是否一起变化，协方差矩阵把各维度之间的关系组织成矩阵，主对角线是方差。

### 中文释义
本页属于PCA 与 Eigenfaces。协方差衡量两个维度是否一起变化，协方差矩阵把各维度之间的关系组织成矩阵，主对角线是方差。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to PCA 与 Eigenfaces. 协方差衡量两个维度是否一起变化，协方差矩阵把各维度之间的关系组织成矩阵，主对角线是方差。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **PCA 与 Eigenfaces**：协方差衡量两个维度是否一起变化，协方差矩阵把各维度之间的关系组织成矩阵，主对角线是方差。
- **Principal component / 主成分**：按解释方差排序、彼此正交的低维表示方向。

### 自测问题 / Self-check
- 中文问题：第 67 页的 Covariance and covariance matrix 解决了什么问题？
  - 答案：协方差衡量两个维度是否一起变化，协方差矩阵把各维度之间的关系组织成矩阵，主对角线是方差。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 67, Covariance and covariance matrix, address?
  - Answer: It addresses covariance and covariance matrix as part of the PCA 与 Eigenfaces pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 68 页：Covariance interpretation

![PDF page 68](../assets/cv_w4/pages/page_068.png)

### 原文 / Original Text
```text
Covariance
• A positive value of covariance indicates both 
dimensions increase or decrease together 
• A negative value indicates while one increases 
the other decreases, or vice-versa
• If covariance is zero: the two dimensions are 
independent of each other e.g. heights of 
student's vs the marks obtained in a subject
```

### 完整中文翻译
正协方差表示两个维度倾向于同向增减；负协方差表示一个增大时另一个倾向减小。接近零不等于一定没有任何关系，只表示线性共变弱。

### 中文释义
本页属于PCA 与 Eigenfaces。正协方差表示两个维度倾向于同向增减；负协方差表示一个增大时另一个倾向减小。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to PCA 与 Eigenfaces. 正协方差表示两个维度倾向于同向增减；负协方差表示一个增大时另一个倾向减小。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **PCA 与 Eigenfaces**：正协方差表示两个维度倾向于同向增减；负协方差表示一个增大时另一个倾向减小。
- **Principal component / 主成分**：按解释方差排序、彼此正交的低维表示方向。

### 自测问题 / Self-check
- 中文问题：第 68 页的 Covariance interpretation 解决了什么问题？
  - 答案：正协方差表示两个维度倾向于同向增减；负协方差表示一个增大时另一个倾向减小。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 68, Covariance interpretation, address?
  - Answer: It addresses covariance interpretation as part of the PCA 与 Eigenfaces pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 69 页：Eigenvectors and eigenvalues

![PDF page 69](../assets/cv_w4/pages/page_069.png)

### 原文 / Original Text
```text
Eigenvectors and Eigenvalues
Eigenvectors and Eigenvalues describe the fundamental behaviour of a linear transformation.
• Eigenvector (x; direction) 
• A special vector that only changes in magnitude when a linear transformation A is applied to it.
• The direction along which the transformation acts (stretching or shrinking), without any rotation or shear.
• Eigenvalue (𝜆; scale) 
• The scalar factor by which the corresponding eigenvector x is scaled. 
• It quantifies the magnitude of the stretching or shrinking along the eigenvector's direction.
2 3
2 1 × 3
2 = 12
8 = 4× 3
2
Matrix 𝐴 Eigenvector 𝒙
Eigenvalue 
𝐴𝑥 = 𝜆𝑥
```

### 完整中文翻译
特征向量是线性变换后方向保持不变、只改变长度的特殊向量；特征值表示沿该方向的缩放强度。

### 中文释义
本页属于PCA 与 Eigenfaces。特征向量是线性变换后方向保持不变、只改变长度的特殊向量；特征值表示沿该方向的缩放强度。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to PCA 与 Eigenfaces. 特征向量是线性变换后方向保持不变、只改变长度的特殊向量；特征值表示沿该方向的缩放强度。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **PCA 与 Eigenfaces**：特征向量是线性变换后方向保持不变、只改变长度的特殊向量；特征值表示沿该方向的缩放强度。
- **Principal component / 主成分**：按解释方差排序、彼此正交的低维表示方向。

### 自测问题 / Self-check
- 中文问题：第 69 页的 Eigenvectors and eigenvalues 解决了什么问题？
  - 答案：特征向量是线性变换后方向保持不变、只改变长度的特殊向量；特征值表示沿该方向的缩放强度。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 69, Eigenvectors and eigenvalues, address?
  - Answer: It addresses eigenvectors and eigenvalues as part of the PCA 与 Eigenfaces pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 70 页：Eigen-directions and strength

![PDF page 70](../assets/cv_w4/pages/page_070.png)

### 原文 / Original Text
```text
Eigenvectors and Eigenvalues
• In what direction do you think the line should stop so that it covers the maximum 
variation of the data points
eigenvectors = directions, 
eigenvalues = strength (variance along that direction)
```

### 完整中文翻译
在 PCA 中，特征向量给出数据变化的方向，特征值给出该方向上的方差强度。特征值越大，方向越重要。

### 中文释义
本页属于PCA 与 Eigenfaces。在 PCA 中，特征向量给出数据变化的方向，特征值给出该方向上的方差强度。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to PCA 与 Eigenfaces. 在 PCA 中，特征向量给出数据变化的方向，特征值给出该方向上的方差强度。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **PCA 与 Eigenfaces**：在 PCA 中，特征向量给出数据变化的方向，特征值给出该方向上的方差强度。
- **Principal component / 主成分**：按解释方差排序、彼此正交的低维表示方向。

### 自测问题 / Self-check
- 中文问题：第 70 页的 Eigen-directions and strength 解决了什么问题？
  - 答案：在 PCA 中，特征向量给出数据变化的方向，特征值给出该方向上的方差强度。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 70, Eigen-directions and strength, address?
  - Answer: It addresses eigen-directions and strength as part of the PCA 与 Eigenfaces pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 71 页：Principal components

![PDF page 71](../assets/cv_w4/pages/page_071.png)

### 原文 / Original Text
```text
Principle Components Analysis
• The eigenvalue with the largest magnitude corresponds to the direction (its eigenvector) 
along which the data exhibit the greatest variance .
• Each subsequent principal component corresponds to the direction of greatest remaining 
variance, subject to being orthogonal to all previous components.
```

### 完整中文翻译
最大特征值对应最大方差方向；后续主成分选择剩余方差最大的方向，并要求与之前方向正交。

### 中文释义
本页属于PCA 与 Eigenfaces。最大特征值对应最大方差方向；后续主成分选择剩余方差最大的方向，并要求与之前方向正交。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to PCA 与 Eigenfaces. 最大特征值对应最大方差方向；后续主成分选择剩余方差最大的方向，并要求与之前方向正交。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **PCA 与 Eigenfaces**：最大特征值对应最大方差方向；后续主成分选择剩余方差最大的方向，并要求与之前方向正交。
- **Principal component / 主成分**：按解释方差排序、彼此正交的低维表示方向。

### 自测问题 / Self-check
- 中文问题：第 71 页的 Principal components 解决了什么问题？
  - 答案：最大特征值对应最大方差方向；后续主成分选择剩余方差最大的方向，并要求与之前方向正交。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 71, Principal components, address?
  - Answer: It addresses principal components as part of the PCA 与 Eigenfaces pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 72 页：PCA steps

![PDF page 72](../assets/cv_w4/pages/page_072.png)

### 原文 / Original Text
```text
Principle Components Analysis
Steps:
1. Prepare the data
2. Centre data (subtract mean).
3. Compute the covariance matrix.
4. Compute eigenvectors and eigenvalues.
5. Choose k eigenvectors that explain most 
of the variance
6. Project data onto the top 𝑘 eigenvectors.
```

### 完整中文翻译
PCA 步骤是准备数据、减去均值、计算协方差矩阵、求特征向量和特征值、按特征值排序，再选择要保留的主成分。

### 中文释义
本页属于PCA 与 Eigenfaces。PCA 步骤是准备数据、减去均值、计算协方差矩阵、求特征向量和特征值、按特征值排序，再选择要保留的主成分。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to PCA 与 Eigenfaces. PCA 步骤是准备数据、减去均值、计算协方差矩阵、求特征向量和特征值、按特征值排序，再选择要保留的主成分。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **PCA 与 Eigenfaces**：PCA 步骤是准备数据、减去均值、计算协方差矩阵、求特征向量和特征值、按特征值排序，再选择要保留的主成分。
- **Principal component / 主成分**：按解释方差排序、彼此正交的低维表示方向。

### 自测问题 / Self-check
- 中文问题：第 72 页的 PCA steps 解决了什么问题？
  - 答案：PCA 步骤是准备数据、减去均值、计算协方差矩阵、求特征向量和特征值、按特征值排序，再选择要保留的主成分。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 72, PCA steps, address?
  - Answer: It addresses pca steps as part of the PCA 与 Eigenfaces pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 73 页：PCA for faces: eigenfaces

![PDF page 73](../assets/cv_w4/pages/page_073.png)

### 原文 / Original Text
```text
Principle Components Analysis for Faces
bold italic cap X bar
equals bold italic 
bold
italic
start
equation script epsilon 
element of , 
lambda sub 1 , , plus lambda sub 2 , , 
plus dot dot dot , plus lambda sub k 
w sub k , , equals u sub k to 
the cap T , open paren x 
minus bold italic cap X bar start
equation
cap
X 
u 
sub 
w 
sub k u 
sub 
Prepare a training set of face 
images
• Resample to a common size (M,N)
• Flat each image (1,M*N)
• Create a T matrix (M*N,#Images)
Subtract the mean
• Obtain ഥ𝑿 = 𝑻 − 𝒂, where a is the average 
of all face images
Compute the Covariance
• Compute the covariance matrix S from ഥ𝑿
Compute eigenvectors and 
eigenvalues
• Compute eigenvectors (e) and 
eigenvalues (𝜆) from S
• Eigenvectors are called eigenfaces
Choose k principal components
• Rank eigenvalues in descending order
• Sort eigenvectors accordingly
• Set the minimum variance to be explained 
(𝜖 ∈ [0,1))
• Choose k such that 𝜆1 + 𝜆2 + ⋯ + 𝜆𝑘 ≥ 𝜖
Projection
• Obtain k coefficients of eace image as: 
𝑤𝑘 = 𝑢𝑘
𝑇(𝑥 − ഥ𝑿) where:
• 𝑥 is a face image reshaped as (1,#Pixels)
• ത𝑋 is the mean face
• 𝑢𝑘 is the k-th eigenvector
• 𝑤𝑘 is the projection coefficient (weight) of 
the face on 𝑢𝑘
```

### 完整中文翻译
对人脸 PCA：把训练人脸统一为相同尺寸并展平，组成数据矩阵；减去平均脸；对协方差矩阵求特征向量。满足保留方差阈值的特征向量称为 eigenfaces。

### 中文释义
本页属于PCA 与 Eigenfaces。对人脸 PCA：把训练人脸统一为相同尺寸并展平，组成数据矩阵；减去平均脸；对协方差矩阵求特征向量。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to PCA 与 Eigenfaces. 对人脸 PCA：把训练人脸统一为相同尺寸并展平，组成数据矩阵；减去平均脸；对协方差矩阵求特征向量。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **PCA 与 Eigenfaces**：对人脸 PCA：把训练人脸统一为相同尺寸并展平，组成数据矩阵；减去平均脸；对协方差矩阵求特征向量。
- **Principal component / 主成分**：按解释方差排序、彼此正交的低维表示方向。

### 自测问题 / Self-check
- 中文问题：第 73 页的 PCA for faces: eigenfaces 解决了什么问题？
  - 答案：对人脸 PCA：把训练人脸统一为相同尺寸并展平，组成数据矩阵；减去平均脸；对协方差矩阵求特征向量。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 73, PCA for faces: eigenfaces, address?
  - Answer: It addresses pca for faces: eigenfaces as part of the PCA 与 Eigenfaces pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 74 页：PCA application: eigenfaces

![PDF page 74](../assets/cv_w4/pages/page_074.png)

### 原文 / Original Text
```text
PCA application: Eigenfaces
-8029        2900       1751            1445        4238            
6193
…
• Every face becomes a low-dimensional vector of coefficients 𝑤1, 𝑤2, … , 𝑤𝑘 𝑇.
• The high-dimensional pixel space (𝑛) is replaced by a smaller “face space” (𝑘 ≪ 𝑛).
```

### 完整中文翻译
每张人脸都被投影成低维权重向量 (w1,...,wk)。原来的 n 维像素空间被较小的 k 维 face space 取代，其中 k 远小于 n。

### 中文释义
本页属于PCA 与 Eigenfaces。每张人脸都被投影成低维权重向量 (w1,...,wk)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to PCA 与 Eigenfaces. 每张人脸都被投影成低维权重向量 (w1,...,wk)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **PCA 与 Eigenfaces**：每张人脸都被投影成低维权重向量 (w1,...,wk)。
- **Principal component / 主成分**：按解释方差排序、彼此正交的低维表示方向。

### 自测问题 / Self-check
- 中文问题：第 74 页的 PCA application: eigenfaces 解决了什么问题？
  - 答案：每张人脸都被投影成低维权重向量 (w1,...,wk)。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 74, PCA application: eigenfaces, address?
  - Answer: It addresses pca application: eigenfaces as part of the PCA 与 Eigenfaces pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 75 页：Eigenface reconstruction

![PDF page 75](../assets/cv_w4/pages/page_075.png)

### 原文 / Original Text
```text
The more eigenfaces you have the better the reconstruction, and you can have high 
quality reconstruction even with a small number of eigenfaces
Using Eigenfaces for reconstruction 
80 70 50 30 10
```

### 完整中文翻译
保留的 eigenfaces 越多，重建通常越好；即使只用少量主成分，也可能得到质量较高的人脸重建，说明主要结构集中在低维空间。

### 中文释义
本页属于PCA 与 Eigenfaces。保留的 eigenfaces 越多，重建通常越好；即使只用少量主成分，也可能得到质量较高的人脸重建，说明主要结构集中在低维空间。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to PCA 与 Eigenfaces. 保留的 eigenfaces 越多，重建通常越好；即使只用少量主成分，也可能得到质量较高的人脸重建，说明主要结构集中在低维空间。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **PCA 与 Eigenfaces**：保留的 eigenfaces 越多，重建通常越好；即使只用少量主成分，也可能得到质量较高的人脸重建，说明主要结构集中在低维空间。
- **Principal component / 主成分**：按解释方差排序、彼此正交的低维表示方向。

### 自测问题 / Self-check
- 中文问题：第 75 页的 Eigenface reconstruction 解决了什么问题？
  - 答案：保留的 eigenfaces 越多，重建通常越好；即使只用少量主成分，也可能得到质量较高的人脸重建，说明主要结构集中在低维空间。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 75, Eigenface reconstruction, address?
  - Answer: It addresses eigenface reconstruction as part of the PCA 与 Eigenfaces pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 76 页：Eigenfaces as a representation

![PDF page 76](../assets/cv_w4/pages/page_076.png)

### 原文 / Original Text
```text
Eigenfaces: representing faces
-8029       -1183   2900     -2088  1751      -4336  1445       -669  4238      -4221  6193    10549
• These basis faces can be differently weighted to represent any face
• We can use different vectors of weights to represent different faces
```

### 完整中文翻译
eigenfaces 是一组基脸，不同的人脸由不同的权重组合得到。改变权重向量，就能表示不同的脸或脸部变化。

### 中文释义
本页属于PCA 与 Eigenfaces。eigenfaces 是一组基脸，不同的人脸由不同的权重组合得到。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to PCA 与 Eigenfaces. eigenfaces 是一组基脸，不同的人脸由不同的权重组合得到。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **PCA 与 Eigenfaces**：eigenfaces 是一组基脸，不同的人脸由不同的权重组合得到。
- **Principal component / 主成分**：按解释方差排序、彼此正交的低维表示方向。

### 自测问题 / Self-check
- 中文问题：第 76 页的 Eigenfaces as a representation 解决了什么问题？
  - 答案：eigenfaces 是一组基脸，不同的人脸由不同的权重组合得到。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 76, Eigenfaces as a representation, address?
  - Answer: It addresses eigenfaces as a representation as part of the PCA 与 Eigenfaces pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 77 页：Eigenfaces for recognition

![PDF page 77](../assets/cv_w4/pages/page_077.png)

### 原文 / Original Text
```text
We find the Euclidean distance 𝑑 between our face and all the other stored faces in face 
space
The closest face in face space is the chosen match
Using Eigenfaces for recognition 
( )
2
1 2 1 2
1
( , )
n
ii
i
d w w w w
=
=−
```

### 完整中文翻译
识别时把输入脸投影到 face space，计算它与数据库人脸权重向量之间的欧氏距离，距离最小的样本作为匹配结果。

### 中文释义
本页属于PCA 与 Eigenfaces。识别时把输入脸投影到 face space，计算它与数据库人脸权重向量之间的欧氏距离，距离最小的样本作为匹配结果。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to PCA 与 Eigenfaces. 识别时把输入脸投影到 face space，计算它与数据库人脸权重向量之间的欧氏距离，距离最小的样本作为匹配结果。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **PCA 与 Eigenfaces**：识别时把输入脸投影到 face space，计算它与数据库人脸权重向量之间的欧氏距离，距离最小的样本作为匹配结果。
- **Principal component / 主成分**：按解释方差排序、彼此正交的低维表示方向。

### 自测问题 / Self-check
- 中文问题：第 77 页的 Eigenfaces for recognition 解决了什么问题？
  - 答案：识别时把输入脸投影到 face space，计算它与数据库人脸权重向量之间的欧氏距离，距离最小的样本作为匹配结果。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 77, Eigenfaces for recognition, address?
  - Answer: It addresses eigenfaces for recognition as part of the PCA 与 Eigenfaces pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.

## 第 78 页：Week 4 summary

![PDF page 78](../assets/cv_w4/pages/page_078.png)

### 原文 / Original Text
```text
Summary
• Low-level CV&I
• Detection
• Lines
• Circles
• Advanced: Eigenfaces
```

### 完整中文翻译
本周总结：低层次视觉、边缘、直线、圆和高级 Eigenfaces。应能从像素变化解释到参数模型，再解释 PCA 如何压缩和识别人脸。

### 中文释义
本页属于PCA 与 Eigenfaces。本周总结：低层次视觉、边缘、直线、圆和高级 Eigenfaces。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### English Explanation
This page belongs to PCA 与 Eigenfaces. 本周总结：低层次视觉、边缘、直线、圆和高级 Eigenfaces。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。

### 概念解析与拓展
- **PCA 与 Eigenfaces**：本周总结：低层次视觉、边缘、直线、圆和高级 Eigenfaces。
- **Principal component / 主成分**：按解释方差排序、彼此正交的低维表示方向。

### 自测问题 / Self-check
- 中文问题：第 78 页的 Week 4 summary 解决了什么问题？
  - 答案：本周总结：低层次视觉、边缘、直线、圆和高级 Eigenfaces。复习时要把公式、图示和它在整条图像处理流程中的作用联系起来。
- English question: What problem does page 78, Week 4 summary, address?
  - Answer: It addresses week 4 summary as part of the PCA 与 Eigenfaces pipeline; connect the displayed formula or visual result to its role in the full image-processing workflow.
