from __future__ import annotations

import html
import json
import argparse
import re
import shutil
import subprocess
from datetime import datetime
from pathlib import Path

from cv_wk3_page_notes import PAGE_NOTES as CV_WK3_PAGE_NOTES
from dia_05_page_notes import PAGE_NOTES as DIA05_PAGE_NOTES

MANUAL_NOTES = {
    "cv_wk3_2026": CV_WK3_PAGE_NOTES,
    "dia_05_distributed_processing": DIA05_PAGE_NOTES,
}


ROOT = Path(r"E:\UOB Artificial Intelligence")
WORK_ROOT = ROOT / "Codex Workspace" / "learn_from_materials"
POPPLER = Path(
    r"C:\Users\小巷派暗黑打油诗人\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe"
)


MATERIALS = [
    {
        "slug": "dia_00_big_data_intro",
        "subject": "Data-Intensive Artificial Intelligence",
        "short": "DIA 00",
        "title": "Introduction to Big Data Engineering",
        "pdf": ROOT
        / "Data-Intensive Artificial Intelligence"
        / "resources"
        / "0. Introduction to Big Data engineering - Lecture Notes-1.pdf",
        "out": "DIA_00_Big_Data_Engineering_page_by_page_companion",
        "mode": "text-rich",
    },
    {
        "slug": "dia_01_lakehouse",
        "subject": "Data-Intensive Artificial Intelligence",
        "short": "DIA 01",
        "title": "Data Warehouse, Data Lake, Lakehouse",
        "pdf": ROOT
        / "Data-Intensive Artificial Intelligence"
        / "resources"
        / "1. Datalake and lakehouse architecture_Lecture_Notes-1.pdf",
        "out": "DIA_01_Lakehouse_page_by_page_companion",
        "mode": "text-rich",
    },
    {
        "slug": "dia_02_dataset_integration",
        "subject": "Data-Intensive Artificial Intelligence",
        "short": "DIA 02",
        "title": "Dataset Selection and Integration",
        "pdf": ROOT
        / "Data-Intensive Artificial Intelligence"
        / "resources"
        / "2. Dataset_selection_and_integration_-_Lecture_Notes.pdf",
        "out": "DIA_02_Dataset_Integration_page_by_page_companion",
        "mode": "text-rich",
    },
    {
        "slug": "dia_03_missing_values",
        "subject": "Data-Intensive Artificial Intelligence",
        "short": "DIA 03",
        "title": "Data Quality I: Missing Values and Data Imputation",
        "pdf": ROOT
        / "Data-Intensive Artificial Intelligence"
        / "resources"
        / "3. Data Quality I - missing values - Lecture Notes.pdf",
        "out": "DIA_03_Missing_Values_page_by_page_companion",
        "mode": "text-rich",
    },
    {
        "slug": "dia_04_value_anomalies",
        "subject": "Data-Intensive Artificial Intelligence",
        "short": "DIA 04",
        "title": "Data Quality II: Anomaly Detection",
        "pdf": ROOT
        / "Data-Intensive Artificial Intelligence"
        / "resources"
        / "4. Data Quality II - value anomalies - Lecture Notes.pdf",
        "out": "DIA_04_Value_Anomalies_page_by_page_companion",
        "mode": "text-rich",
    },
    {
        "slug": "dia_05_distributed_processing",
        "subject": "Data-Intensive Artificial Intelligence",
        "short": "DIA 05",
        "title": "Scalable Distributed Data Processing",
        "pdf": ROOT
        / "Data-Intensive Artificial Intelligence"
        / "resources"
        / "5. Scalable Distributed Data Processing - Lecture Notes.pdf",
        "out": "DIA_05_Distributed_Processing_page_by_page_companion",
        "mode": "text-rich",
    },
    {
        "slug": "cv_wk1_intro",
        "subject": "Computer Vision and Imaging",
        "short": "CV Week 1",
        "title": "Introduction to the Module and Computer Vision",
        "pdf": ROOT / "Computer Vision and Imaging (Extended)" / "Wk1_introduction-2.pdf",
        "out": "CV_Wk1_Introduction_page_by_page_companion",
        "mode": "image-heavy",
    },
    {
        "slug": "cv_wk2_features_dl",
        "subject": "Computer Vision and Imaging",
        "short": "CV Week 2",
        "title": "Feature Detection and Deep Learning",
        "pdf": ROOT / "Computer Vision and Imaging (Extended)" / "Wk2_feature_20and_20DL.pdf",
        "out": "CV_Wk2_Features_DL_page_by_page_companion",
        "mode": "image-heavy",
    },
    {
        "slug": "cv_wk3_2026",
        "subject": "Computer Vision and Imaging",
        "short": "CV Week 3",
        "title": "Computer Vision Week 3",
        "pdf": ROOT / "Computer Vision and Imaging (Extended)" / "Week3_2026.pdf",
        "out": "CV_Wk3_page_by_page_companion",
        "mode": "image-heavy",
    },
]


TERM_ZH = {
    "ACID": "ACID 事务特性",
    "Amdahl": "阿姆达尔定律",
    "Big Data": "大数据",
    "Bronze": "铜牌层/原始可追溯层",
    "CAPTCHA": "全自动区分人和计算机的图灵测试",
    "Class imbalance": "类别不平衡",
    "Columnar": "列式",
    "Computer Vision": "计算机视觉",
    "Data Engineering": "数据工程",
    "Data Lake": "数据湖",
    "Data warehouse": "数据仓库",
    "Data Warehouses": "数据仓库",
    "Data lake": "数据湖",
    "Data lakes": "数据湖",
    "Data leakage": "数据泄漏",
    "Deep Learning": "深度学习",
    "Delta Lake": "Delta Lake 湖仓存储层",
    "Delta Tables": "Delta 表",
    "Detection": "检测",
    "Distributed": "分布式",
    "Efficiency": "效率",
    "Embarrassingly Parallel": "易并行/尴尬并行",
    "Feature": "特征",
    "Gold": "金牌层/可服务层",
    "Gustafson": "古斯塔夫森定律",
    "Image filtering": "图像滤波",
    "Image processing": "图像处理",
    "Isolation Forest": "孤立森林",
    "KNN": "K 近邻",
    "Lakehouse": "湖仓一体",
    "MAD": "中位数绝对偏差",
    "Machine Learning": "机器学习",
    "MAR": "随机缺失",
    "MCAR": "完全随机缺失",
    "MICE": "链式方程多重插补",
    "ML": "机器学习",
    "MNAR": "非随机缺失",
    "Medallion": "奖牌架构",
    "Missing": "缺失",
    "Null": "空值",
    "Parquet": "Parquet 列式文件格式",
    "Partition": "分区",
    "Regression": "回归",
    "Reinforcement learning": "强化学习",
    "Scalability": "可扩展性",
    "Schema": "模式/表结构",
    "Segmentation": "分割",
    "Silver": "银牌层/清洗整合层",
    "Speedup": "加速比",
    "Supervised learning": "监督学习",
    "Unsupervised learning": "无监督学习",
    "Z-score": "Z 分数",
    "Z-Ordering": "Z 顺序聚簇",
    "classification": "分类",
    "clustering": "聚类",
    "data quality": "数据质量",
    "denoising": "去噪",
    "imputation": "插补",
    "inpainting": "图像修复",
    "join": "连接",
    "lakehouse": "湖仓一体",
    "outlier": "离群点",
    "schema-on-read": "读时定义模式",
    "schema-on-write": "写时定义模式",
    "super-resolution": "超分辨率",
    "union": "并集/纵向合并",
}


EXACT_ZH = {
    "In this lecture": "本讲内容",
    "Summary": "总结",
    "References": "参考文献",
    "Further reading": "延伸阅读",
    "Exercise": "练习",
    "Schedule": "课程安排",
    "Assessment": "考核方式",
    "Labs": "实验课",
    "Computer Vision?": "什么是计算机视觉？",
    "Computer Vision": "计算机视觉",
    "Machine learning": "机器学习",
    "Deep learning for computer vision": "面向计算机视觉的深度学习",
    "Application to computer vision": "计算机视觉应用",
    "Data Warehouses": "数据仓库",
    "Data Lakes": "数据湖",
    "Speedup": "加速比",
    "Efficiency": "效率",
}


CONCEPTS = [
    ("Data warehouse", "数据仓库", "面向结构化数据和分析查询优化的持久化存储系统，通常强调 SQL、治理、事务和报表分析。"),
    ("Data lake", "数据湖", "保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。"),
    ("Lakehouse", "湖仓一体", "在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。"),
    ("Medallion", "奖牌架构", "把数据从 Landing/Bronze 的原始层逐步提升到 Silver 的清洗整合层和 Gold 的可训练/可服务层。"),
    ("Delta Lake", "Delta Lake", "Databricks 发起的开放湖仓存储框架，在 Parquet 文件上添加事务日志、更新删除和 ACID 能力。"),
    ("ACID", "ACID", "原子性、一致性、隔离性、持久性，用于保证事务操作可靠完成。"),
    ("Parquet", "Parquet", "列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。"),
    ("Schema", "模式", "表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。"),
    ("union", "并集/纵向合并", "把结构兼容的数据表按行合并；如果语义不同，技术上成功也可能训练出错误模型。"),
    ("join", "连接", "按键把表横向组合；键的语义不一致时会产生看似正确但实际错误的数据视图。"),
    ("MCAR", "完全随机缺失", "缺失与其他变量和自身值没有系统关系。"),
    ("MAR", "随机缺失", "缺失与其他可观测变量有关，但不直接由缺失值本身决定。"),
    ("MNAR", "非随机缺失", "缺失本身携带信息，可能与未观测值或特定人群/事件有关。"),
    ("imputation", "插补", "用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。"),
    ("MICE", "MICE", "链式方程多重插补，用多个回归模型迭代估计表中各列缺失值。"),
    ("data leakage", "数据泄漏", "训练特征包含目标或生产时不可获得的信息，使测试成绩虚高。"),
    ("class imbalance", "类别不平衡", "多数类远多于少数类，准确率会误导模型评估。"),
    ("Z-score", "Z 分数", "用均值和标准差衡量单变量点距离中心的程度，适合近似正态分布。"),
    ("MAD", "中位数绝对偏差", "用中位数和绝对偏差中位数构建稳健离群检测，比均值/标准差更不怕极端值。"),
    ("Isolation Forest", "孤立森林", "用随机树更快隔离稀疏区域样本，适合多变量异常组合检测。"),
    ("Speedup", "加速比", "单处理器耗时除以 n 个处理器耗时，用来衡量并行化收益。"),
    ("Amdahl", "阿姆达尔定律", "固定问题规模下，串行部分限制最大加速比。"),
    ("Gustafson", "古斯塔夫森定律", "扩大问题规模时，更多处理器可在相同时间处理更大的输入。"),
    ("Embarrassingly", "易并行", "输入子任务之间几乎没有依赖，适合线性并行处理。"),
    ("partition", "分区", "把数据切分到不同 worker；分区均衡决定分布式任务是否会卡在慢节点。"),
    ("Computer Vision", "计算机视觉", "让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。"),
    ("classification", "分类", "预测离散类别标签，例如图像类别或手写数字。"),
    ("detection", "检测", "同时判断目标类别与位置，通常输出边界框。"),
    ("segmentation", "分割", "为像素或区域分配类别/实例标签。"),
    ("denoising", "图像去噪", "从含噪观测中恢复潜在干净图像，是典型低层视觉问题。"),
    ("super-resolution", "超分辨率", "从低分辨率图像恢复更高分辨率细节。"),
    ("inpainting", "图像修复", "补全图像中缺失或被遮挡的区域。"),
    ("deep learning", "深度学习", "用多层神经网络从数据中学习表示和映射，现代视觉任务常用。"),
]


def esc(value: str) -> str:
    return html.escape(value, quote=True)


def parse_pages(kb: Path) -> dict[int, str]:
    text = (kb / "full_text.md").read_text(encoding="utf-8")
    chunks = re.split(r"<!-- PDF 页 (\d+) -->", text)
    return {int(chunks[i]): chunks[i + 1].strip() for i in range(1, len(chunks), 2)}


def source_index(kb: Path) -> dict[int, dict]:
    data = json.loads((kb / "source_map.json").read_text(encoding="utf-8"))
    return {int(item["pdf_page"]): item for item in data}


def render_images(pdf: Path, assets: Path, count: int) -> None:
    assets.mkdir(parents=True, exist_ok=True)
    existing = list(assets.glob("page_*.jpg")) + list(assets.glob("page_*.png"))
    if len(existing) >= count:
        return
    pdftoppm = shutil.which("pdftoppm") or str(POPPLER)
    if not Path(pdftoppm).exists():
        raise FileNotFoundError(f"pdftoppm not found: {pdftoppm}")
    for old in assets.glob("render-*.*"):
        old.unlink()
    subprocess.run([pdftoppm, "-jpeg", "-r", "105", str(pdf), str(assets / "render")], check=True)
    for path in assets.glob("render-*.jpg"):
        match = re.search(r"render-(\d+)\.jpg$", path.name)
        if match:
            target = assets / f"page_{int(match.group(1)):03d}.jpg"
            if target.exists():
                target.unlink()
            path.rename(target)


def page_title(text: str, fallback: str, page: int) -> str:
    for line in lines(text):
        clean = re.sub(r"\s+", " ", line).strip()
        if clean and not clean.isdigit() and not clean.startswith("http"):
            return clean[:90]
    return f"{fallback} - Page {page}"


def title_for(conf: dict, page: int, text: str) -> str:
    if conf["slug"] in MANUAL_NOTES:
        return MANUAL_NOTES[conf["slug"]][page]["title"]
    return line_to_zh(page_title(text, conf["title"], page))


def page_content(conf: dict, page: int, title: str, text: str):
    """Return curated page content when the deck has a manual source map."""
    if conf["slug"] in MANUAL_NOTES:
        note = MANUAL_NOTES[conf["slug"]][page]
        return (
            note["translation"],
            note["cn"],
            note["en"],
            note["concepts"],
            note["extension"],
            note["qa"],
        )
    concepts = concepts_for(text + "\n" + title, conf["mode"])
    english_title = page_title(text, title, page)
    zh_exp, en_exp, ext = explanation(english_title, text, concepts, conf["mode"])
    return bilingual_translation(text, conf["mode"]), zh_exp, en_exp, concepts, ext, qa(page, title, concepts, zh_exp, en_exp)


def lines(text: str) -> list[str]:
    return [line.strip() for line in text.splitlines() if line.strip()]


PHRASE_ZH = {
    "introduction to the module": "课程模块介绍",
    "introduction to big data engineering": "大数据工程导论",
    "data-intensive ai": "数据密集型人工智能",
    "computer vision and imaging": "计算机视觉与成像",
    "feature detection and deep learning": "特征检测与深度学习",
    "feature detection/extraction": "特征检测与特征提取",
    "traditional visual feature descriptors": "传统视觉特征描述子",
    "deep learning-based visual feature extraction": "基于深度学习的视觉特征提取",
    "deep learning-based features": "基于深度学习的特征",
    "data warehouse, data lake, lakehouse": "数据仓库、数据湖与湖仓",
    "data quality i": "数据质量第一部分",
    "data quality ii": "数据质量第二部分",
    "missing values and data imputation": "缺失值与数据插补",
    "value anomalies": "数值异常",
    "anomaly detection": "异常检测",
    "scalable distributed data processing": "可扩展的分布式数据处理",
    "fundamental concepts": "基本概念",
    "the data-to-inference value chain": "从数据到推理的价值链",
    "training-ready datasets": "可用于训练的数据集",
    "source datasets": "源数据集",
    "source data quality": "源数据质量",
    "task-agnostic": "与任务无关",
    "supervised / unsupervised machine learning": "监督式/无监督式机器学习",
    "module webpage/resources": "课程网页/资源",
    "2 lectures / week": "每周 2 次讲座",
    "1 lab (tutorial) / week": "每周 1 次实验（辅导课）",
    "in this lecture": "本讲内容",
    "key concepts in this lecture": "本讲关键概念",
    "overall goal": "总体目标",
    "dataset selection and integration": "数据集选择与整合",
    "bronze medallion": "Bronze 层",
    "data warehouses": "数据仓库",
    "data lakes": "数据湖",
    "open table formats": "开放表格式",
    "the medallion architecture": "Medallion 分层架构",
    "data flow from operational systems to decision support": "数据从运营系统流向决策支持系统",
    "data quality issues covered in this lecture": "本讲涉及的数据质量问题",
    "big data": "大数据",
    "datasets that are large enough to benefit from a distributed computing architecture": "规模足够大、能够从分布式计算架构中受益的数据集",
    "if you run a distributed algorithm on a small dataset": "如果在小数据集上运行分布式算法",
    "the overhead associated with managing the data allocation to the resources may be larger than the theoretical benefit": "管理数据分配和计算资源所产生的开销可能大于理论收益",
    "the ratio of the time taken to complete a task on a single processor to the time taken on a parallel system": "在单个处理器上完成任务所需时间与在并行系统上完成任务所需时间的比值",
    "an ideal situation where there are no dependencies between elements of the input dataset when executing the task": "执行任务时输入数据集元素之间不存在依赖关系的理想情况",
    "quantifying the limitations on available parallelism for a specific processing task": "量化特定处理任务中可用并行性的限制",
    "missing / null values": "缺失值/空值",
    "null values": "空值",
    "missing values": "缺失值",
    "feature descriptor": "特征描述子",
    "visual feature": "视觉特征",
    "image processing": "图像处理",
    "computer vision": "计算机视觉",
    "structural": "结构性问题",
    "semantic": "语义问题",
    "ml-specific": "机器学习特有问题",
    "missing data": "缺失数据",
    "out-of-range values": "超出范围的值",
    "duplicate records": "重复记录",
    "skewed distributions": "偏斜分布",
    "class imbalance": "类别不平衡",
    "data leakage": "数据泄漏",
    "detecting univariate outliers": "检测单变量离群点",
    "z-score": "Z 分数",
    "rule of thumb": "经验规则",
    "flag as anomalous": "标记为异常",
    "approximately normally distributed": "近似服从正态分布",
    "z-score: limitations": "Z 分数的局限性",
    "the average is not a robust estimator": "平均值不是稳健估计量",
    "distributed computing involves using multiple machines": "分布式计算使用多台机器",
    "embarrassingly parallel": "易并行",
    "embarrassing parallelism": "易并行性",
    "speedup": "加速比",
    "amdahl's law": "阿姆达尔定律",
    "gustafson's law": "古斯塔夫森定律",
    "points and patches": "点与图像块",
    "edges and contours": "边缘与轮廓",
    "corners": "角点",
    "lines": "直线",
    "image formation": "图像形成",
    "image representation": "图像表示",
    "arithmetic operations": "算术运算",
    "geometric transformations": "几何变换",
    "histogram processing": "直方图处理",
    "spatial filtering": "空间滤波",
    "image degradation model": "图像退化模型",
    "low-pass filtering": "低通滤波",
    "high-pass filtering": "高通滤波",
    "order-statistics filters": "顺序统计滤波器",
    "mean filter": "均值滤波器",
    "gaussian filter": "高斯滤波器",
    "median filter": "中值滤波器",
    "image smoothing": "图像平滑",
    "image sharpening": "图像锐化",
    "correlation and convolution": "相关与卷积",
    "school of computer science": "计算机科学学院",
    "university of birmingham": "伯明翰大学",
    "prof.": "教授",
    "assistant professor": "助理教授",
    "office": "办公室",
    "schedule": "课程安排",
    "outline": "提纲",
    "summary": "总结",
    "questions and answers": "问题与回答",
}


def phrase_translate(text: str) -> str:
    translated = text
    for en, zh in sorted(PHRASE_ZH.items(), key=lambda item: len(item[0]), reverse=True):
        translated = re.sub(re.escape(en), zh, translated, flags=re.IGNORECASE)
    for en, zh in sorted(TERM_ZH.items(), key=lambda item: len(item[0]), reverse=True):
        translated = re.sub(rf"(?<![A-Za-z]){re.escape(en)}(?![A-Za-z])", zh, translated, flags=re.IGNORECASE)
    return translated


def line_to_zh(line: str) -> str:
    clean = re.sub(r"\s+", " ", line).strip()
    if not clean:
        return ""
    if clean in EXACT_ZH:
        return EXACT_ZH[clean]
    if clean.startswith("http") or "doi.org" in clean or "www." in clean:
        return f"参考链接：{clean}"
    translated = phrase_translate(clean)
    if translated != clean:
        return translated
    if clean.endswith("?") or clean.endswith("？"):
        return "问题：" + clean.rstrip("?？") + "？"
    # Keep equations, names, identifiers, and citations intact rather than
    # pretending that an English-only token has been translated.
    return clean


def bilingual_translation(text: str, mode: str) -> str:
    source_lines = lines(text)
    if not source_lines:
        return "本页抽取文本为空；请直接查看左侧 PDF 页面截图中的视觉内容。"
    out = [line_to_zh(line) for line in source_lines]
    if mode == "image-heavy":
        out.append("视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。")
    return "\n".join(out)


def concepts_for(text: str, mode: str) -> list[tuple[str, str, str]]:
    lower = text.lower()
    found: list[tuple[str, str, str]] = []
    used = set()
    for key, zh, desc in CONCEPTS:
        if key.lower() in lower and key.lower() not in used:
            found.append((key, zh, desc))
            used.add(key.lower())
    if not found and mode == "image-heavy":
        found.append(("Visual example", "视觉示例", "本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。"))
    if not found:
        found.append(("Core idea", "核心思想", "本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。"))
    return found[:5]


def explanation(title: str, text: str, concepts: list[tuple[str, str, str]], mode: str) -> tuple[str, str, str]:
    first = concepts[0]
    source_points = lines(text)[:4]
    zh_points = [line_to_zh(item) for item in source_points]
    zh_evidence = "；".join(point for point in zh_points if point) or "页面主要依靠截图传达视觉信息"
    en_evidence = "; ".join(source_points) or "the page is primarily visual"
    zh = (
        f"本页围绕“{title}”展开。课件中的关键信息包括：{zh_evidence}。"
        f"复习时先抓住{first[1]}：{first[2]}，再说明这些定义、数据、公式或示例如何支持本页主题。"
    )
    en = (
        f"This page presents '{title}'. The slide includes: {en_evidence}. "
        f"The revision focus is {first[0]}; connect its definition, evidence, and use to the examples on the page."
    )
    ext = (
        f"拓展复习：把“{title}”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。"
    )
    if mode == "image-heavy":
        ext += " 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。"
    return zh, en, ext


def qa(page: int, title: str, concepts: list[tuple[str, str, str]], zh_exp: str, en_exp: str) -> list[tuple[str, str, str, str]]:
    key, zh, desc = concepts[0]
    return [
        (
            f"第 {page} 页的核心主题是什么？",
            zh_exp,
            f"What is the core topic of page {page}?",
            en_exp,
        ),
        (
            f"解释本页概念：{zh} / {key}",
            desc,
            f"Explain the concept on this page: {key}",
            f"The page focuses on {key}. {en_exp}",
        ),
    ]


CSS = """
html{scroll-behavior:smooth}body{margin:0;font-family:"Segoe UI",Arial,"Microsoft YaHei",sans-serif;background:#f6f8fb;color:#172033;line-height:1.65}.layout{display:grid;grid-template-columns:310px 1fr}aside{position:sticky;top:0;height:100vh;overflow:auto;background:#fff;border-right:1px solid #d8dee9;padding:20px 16px}aside h1{font-size:18px;line-height:1.3;margin:0 0 8px}aside p{font-size:13px;color:#667085;margin:0 0 14px}nav a{display:grid;grid-template-columns:38px 1fr;gap:10px;padding:9px 8px;border-radius:6px;color:#172033;text-decoration:none;font-size:13px;line-height:1.35}nav a:hover{background:#eef7f5}nav span{color:#0f766e;font-weight:700}main{padding:32px min(4vw,48px) 80px}.hero{border-bottom:1px solid #d8dee9;margin-bottom:28px;padding-bottom:20px}.hero h2{font-size:clamp(28px,4vw,44px);line-height:1.15;margin:0 0 12px}.hero p{color:#667085;max-width:980px}.badge{display:inline-block;border:1px solid #d8dee9;background:#fff;border-radius:999px;padding:4px 10px;margin:4px 5px 0 0;font-size:13px}.page{background:#fff;border:1px solid #d8dee9;border-radius:8px;padding:24px;margin-bottom:24px;box-shadow:0 8px 24px rgba(15,23,42,.05)}.kicker{color:#0f766e;font-size:13px;font-weight:700;margin:0 0 4px}h2{font-size:26px;line-height:1.25;margin:0 0 16px}h3{font-size:17px;margin:18px 0 8px}.grid{display:grid;grid-template-columns:minmax(300px,.95fr) minmax(320px,1.05fr);gap:22px;align-items:start}figure{margin:0}.slide img{width:100%;border:1px solid #d8dee9;border-radius:6px;background:#f8fafc}figcaption{font-size:12px;color:#667085}.translation,pre{white-space:pre-wrap;word-wrap:break-word;border:1px solid #d8dee9;border-radius:6px;padding:14px}.translation{background:#fff7ed;border-left:4px solid #b45309}.original{background:#f8fafc;font:13px/1.55 Consolas,monospace}.explain{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:18px}article,details{border:1px solid #d8dee9;border-radius:6px;background:#fbfcfe;padding:10px 12px}.concepts li{margin:8px 0}.concepts span{display:block;color:#344054}.extension{background:#eef7f5;border-left:4px solid #0f766e;padding:12px 14px;border-radius:6px}details{margin:8px 0}summary{font-weight:700;cursor:pointer}.note{font-size:13px;color:#667085}@media(max-width:980px){.layout{grid-template-columns:1fr}aside{position:static;height:auto;max-height:46vh;border-right:0;border-bottom:1px solid #d8dee9}.grid,.explain{grid-template-columns:1fr}main{padding:24px 16px 60px}.page{padding:18px}}
"""


def image_rel(page: int) -> str:
    return f"../assets/pages/page_{page:03d}.jpg"


def build_page_html(conf: dict, page: int, title: str, original: str, source: dict) -> str:
    translation, zh_exp, en_exp, concepts, ext, page_qa = page_content(conf, page, title, original)
    concept_html = "\n".join(
        f"<li><strong>{esc(en)} / {esc(zh)}</strong><span>{esc(desc)}</span></li>"
        for en, zh, desc in concepts
    )
    qa_html = "\n".join(
        f"<details><summary>Q{i}. {esc(qzh)} / {esc(qen)}</summary><p><strong>中文答案：</strong>{esc(azh)}</p><p><strong>English answer:</strong> {esc(aen)}</p></details>"
        for i, (qzh, azh, qen, aen) in enumerate(page_qa, 1)
    )
    return f"""
<section class="page" id="page-{page}">
  <p class="kicker">PDF page {page:03d} · {esc(source.get("source_id", "unknown-source"))}</p>
  <h2>{page}. {esc(title)}</h2>
  <div class="grid">
    <figure class="slide">
      <img src="{image_rel(page)}" alt="PDF page {page}">
      <figcaption>原始 PDF 第 {page} 页截图</figcaption>
    </figure>
    <div>
      <h3>原文 / Original Text</h3>
      <pre class="original">{esc(original) if original.strip() else "No extractable text on this page."}</pre>
      <h3>完整中文翻译</h3>
      <div class="translation">{esc(translation)}</div>
    </div>
  </div>
  <div class="explain">
    <article><h3>中文释义</h3><p>{esc(zh_exp)}</p></article>
    <article><h3>English Explanation</h3><p>{esc(en_exp)}</p></article>
  </div>
  <h3>概念解析与拓展</h3>
  <ul class="concepts">{concept_html}</ul>
  <p class="extension">{esc(ext)}</p>
  <h3>自测问题 / Self-check</h3>
  {qa_html}
</section>
"""


def build_html(conf: dict, pages: dict[int, str], sources: dict[int, dict]) -> str:
    titles = {page: title_for(conf, page, text) for page, text in pages.items()}
    toc = "\n".join(
        f'<a href="#page-{page}"><span>{page:03d}</span>{esc(titles[page])}</a>'
        for page in sorted(pages)
    )
    sections = "\n".join(
        build_page_html(conf, page, titles[page], pages[page], sources.get(page, {}))
        for page in sorted(pages)
    )
    boundary = (
        "本页为图像型课件：页面截图完整保留，中文逐行释义覆盖 PDF 可抽取文字；复杂图形、照片和漫画的细节请结合截图复习。"
        if conf["mode"] == "image-heavy"
        else "本页为文字讲义型材料：中文逐行释义覆盖 PDF 抽取文本，页面截图用于核对表格、公式和排版。"
    )
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{esc(conf["short"])} - Page-by-page Companion</title>
  <style>{CSS}</style>
</head>
<body>
  <div class="layout">
    <aside>
      <h1>{esc(conf["short"])} 逐页复习</h1>
      <p>左侧目录快速跳转；右侧每页含截图、原文、中文释义、概念拓展和双语自测。</p>
      <nav>{toc}</nav>
    </aside>
    <main>
      <section class="hero">
        <h2>{esc(conf["title"])}</h2>
        <p>{esc(conf["subject"])} · 基于 learn-from-materials 本地抽取结果生成。覆盖 {len(pages)} 页。</p>
        <p>{esc(boundary)}</p>
        <span class="badge">{len(pages)} pages</span><span class="badge">page images</span><span class="badge">bilingual self-check</span><span class="badge">left sidebar</span>
        <p class="note">生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M")}；未使用第三方翻译网站。</p>
      </section>
      {sections}
    </main>
  </div>
</body>
</html>"""


def build_markdown(conf: dict, pages: dict[int, str], sources: dict[int, dict]) -> str:
    out = [f"# {conf['title']}", "", f"课程：{conf['subject']}", ""]
    for page in sorted(pages):
        text = pages[page]
        title = title_for(conf, page, text)
        translation, zh_exp, en_exp, concepts, ext, page_qa = page_content(conf, page, title, text)
        out += [
            f"## 第 {page} 页：{title}",
            "",
            f"Source ID: `{sources.get(page, {}).get('source_id', 'unknown-source')}`",
            "",
            f"![PDF page {page}]({image_rel(page)})",
            "",
            "### 原文 / Original Text",
            "",
            "```text",
            text if text.strip() else "No extractable text on this page.",
            "```",
            "",
            "### 完整中文翻译",
            "",
            translation,
            "",
            "### 中文释义",
            "",
            zh_exp,
            "",
            "### English Explanation",
            "",
            en_exp,
            "",
            "### 概念解析与拓展",
            "",
        ]
        for en, zh, desc in concepts:
            out.append(f"- **{en} / {zh}**：{desc}")
        out += ["", ext, "", "### 自测问题 / Self-check", ""]
        for i, (qzh, azh, qen, aen) in enumerate(page_qa, 1):
            out += [f"**Q{i} 中文：** {qzh}", f"**答：** {azh}", f"**Q{i} English:** {qen}", f"**Answer:** {aen}", ""]
    return "\n".join(out)


def write_kb_support(conf: dict, kb: Path, pages: dict[int, str], sources: dict[int, dict]) -> None:
    (kb / "units").mkdir(parents=True, exist_ok=True)
    chunks = [sorted(pages)[i : i + 12] for i in range(0, len(pages), 12)]
    index = [f"# {conf['title']} 知识库索引", "", f"来源：{conf['pdf'].name}", ""]
    coverage = []
    qb_items = []
    glossary: list[str] = ["# 术语表", ""]
    seen_terms = set()
    for idx, group in enumerate(chunks, 1):
        uid = f"u{idx:02d}-pages-{group[0]:03d}-{group[-1]:03d}"
        index.append(f"- [第 {group[0]}-{group[-1]} 页](units/{uid}.md)")
        unit = [f"# 第 {group[0]}-{group[-1]} 页", ""]
        for page in group:
            text = pages[page]
            title = title_for(conf, page, text)
            translation, zh_exp, en_exp, concepts, ext, page_qa = page_content(conf, page, title, text)
            unit += [f"## 第 {page} 页：{title}", "", f"Source ID: `{sources.get(page, {}).get('source_id', 'unknown-source')}`", "", "### 中文翻译", "", translation, "", "### 中文释义", "", zh_exp, "", "### English Explanation", "", en_exp, "", "### Concepts"]
            for en, zh, desc in concepts:
                unit.append(f"- **{en} / {zh}**：{desc}")
                if en not in seen_terms:
                    seen_terms.add(en)
                    glossary.append(f"- **{en} / {zh}**：{desc}")
            unit.append("")
            coverage.append(
                {
                    "pdf_page": page,
                    "source_id": sources.get(page, {}).get("source_id", "unknown-source"),
                    "unit_id": uid,
                    "status": "covered",
                    "note": "页面截图和抽取文本已进入逐页复习页；图像型页面的视觉内容以截图保留。",
                }
            )
            for q_index, (qzh, azh, qen, aen) in enumerate(page_qa, 1):
                qb_items.append(
                    {
                        "id": f"p{page:03d}-q{q_index}",
                        "page": page,
                        "source_id": sources.get(page, {}).get("source_id", "unknown-source"),
                        "question_zh": qzh,
                        "answer_zh": azh,
                        "question_en": qen,
                        "answer_en": aen,
                    }
                )
        (kb / "units" / f"{uid}.md").write_text("\n".join(unit), encoding="utf-8")
    (kb / "INDEX.md").write_text("\n".join(index), encoding="utf-8")
    (kb / "glossary.md").write_text("\n".join(glossary), encoding="utf-8")
    (kb / "question-bank.json").write_text(
        json.dumps({"detection": "generated_from_pages", "items": qb_items}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (kb / "practice.md").write_text(
        "# 自测题\n\n"
        + "\n".join(
            f"- {item['id']}：{item['question_zh']}\n  - 答案：{item['answer_zh']}\n  - English: {item['question_en']}\n  - Answer: {item['answer_en']}"
            for item in qb_items
        ),
        encoding="utf-8",
    )
    (kb / "coverage-audit.json").write_text(
        json.dumps({"learningDepth": "systematic-page-by-page", "items": coverage}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    (kb / "coverage-audit.md").write_text(
        "# 覆盖审计\n\n"
        + "\n".join(f"- PDF 页 {item['pdf_page']}：{item['status']} - {item['source_id']}" for item in coverage),
        encoding="utf-8",
    )
    (kb / "methods.json").write_text(
        json.dumps(
            {
                "methods": [
                    {
                        "id": "page-by-page-source-grounded-review",
                        "name": "逐页来源绑定复习法",
                        "steps": ["查看原页截图", "核对抽取原文", "阅读中文释义", "复述概念", "完成双语自测"],
                        "limits": "图像型课件的图片细节以页面截图为准；抽取文本不等同于完整视觉 OCR。",
                    }
                ]
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    (kb / "patterns.md").write_text("# 方法卡\n\n## 逐页来源绑定复习法\n\n查看原页截图，核对抽取原文，阅读中文释义，复述概念，完成双语自测。\n", encoding="utf-8")
    (kb / "methodology.json").write_text(
        json.dumps(
            {
                "status": "supported",
                "central_problem": f"如何复习 {conf['title']} 的每一页并保持来源可追溯。",
                "nodes": [
                    {"id": "n1", "title": "查看原页"},
                    {"id": "n2", "title": "核对文字"},
                    {"id": "n3", "title": "理解概念"},
                    {"id": "n4", "title": "双语自测"},
                ],
                "edges": [{"from": "n1", "to": "n2"}, {"from": "n2", "to": "n3"}, {"from": "n3", "to": "n4"}],
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    (kb / "methodology.md").write_text(
        f"# 整体方法论\n\n对 {conf['title']} 逐页保留原页截图、抽取文本、中文释义、概念解释和双语自测。\n",
        encoding="utf-8",
    )


def build_one(conf: dict) -> dict:
    work = WORK_ROOT / conf["slug"]
    kb = work / f"{conf['slug']}.learnkb"
    delivery = work / "delivery"
    assets = work / "assets" / "pages"
    delivery.mkdir(parents=True, exist_ok=True)
    pages = parse_pages(kb)
    sources = source_index(kb)
    render_images(conf["pdf"], assets, len(pages))
    write_kb_support(conf, kb, pages, sources)
    html_path = delivery / f"{conf['out']}.html"
    md_path = delivery / f"{conf['out']}.md"
    html_path.write_text(build_html(conf, pages, sources), encoding="utf-8")
    md_path.write_text(build_markdown(conf, pages, sources), encoding="utf-8")
    (work / "index.html").write_text(
        f'<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="0; url=delivery/{html_path.name}"><a href="delivery/{html_path.name}">Open</a>',
        encoding="utf-8",
    )
    tools = work / "tools"
    tools.mkdir(exist_ok=True)
    script_copy = tools / Path(__file__).name
    if Path(__file__).resolve() != script_copy.resolve():
        shutil.copy2(Path(__file__), script_copy)
    return {
        "slug": conf["slug"],
        "subject": conf["subject"],
        "title": conf["title"],
        "pages": len(pages),
        "images": len(list(assets.glob("page_*.jpg"))) + len(list(assets.glob("page_*.png"))),
        "html": str(html_path),
        "markdown": str(md_path),
        "kb": str(kb),
    }


def write_index(name: str, title: str, results: list[dict]) -> Path:
    out = WORK_ROOT / name
    cards = []
    for result in results:
        rel = Path(result["html"]).relative_to(WORK_ROOT).as_posix()
        cards.append(
            f'<a class="item" href="{rel}"><strong>{esc(result["title"])}</strong><span>{esc(result["subject"])}</span><em>{result["pages"]} pages · {result["images"]} images</em></a>'
        )
    out.write_text(
        f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{esc(title)}</title><style>body{{font-family:"Segoe UI",Arial,"Microsoft YaHei",sans-serif;background:#f6f8fb;color:#172033;margin:0;padding:48px}}main{{max-width:980px;margin:auto}}h1{{font-size:40px;margin:0 0 8px}}p{{color:#667085}}.item{{display:block;background:#fff;border:1px solid #d8dee9;border-radius:8px;padding:18px 20px;margin:12px 0;text-decoration:none;color:#172033;box-shadow:0 8px 24px rgba(15,23,42,.05)}}.item:hover{{border-color:#0f766e}}strong{{display:block;color:#0f766e;font-size:18px}}span{{display:block;margin-top:4px}}em{{display:block;color:#667085;margin-top:4px}}</style><main><h1>{esc(title)}</h1><p>learn-from-materials 逐页伴读：页面截图、原文、中文逐行释义、概念拓展与双语自测。</p>{''.join(cards)}</main></html>''',
        encoding="utf-8",
    )
    return out


def write_all_courses_index() -> Path:
    out = WORK_ROOT / "all_courses_index.html"
    cards = [
        ("iis_index.html", "Intelligent Interactive Systems", "Week 1 + Week 2 逐页复习资料"),
        ("dia_index.html", "Data-Intensive Artificial Intelligence", "6 份 lecture notes 逐页复习资料"),
        ("cv_index.html", "Computer Vision and Imaging", "Week 1, Week 2, Week 3 逐页复习资料"),
        ("remaining_subjects_index.html", "本次新增剩余科目入口", "DIA + CV 的全部新增逐页版"),
    ]
    body = "".join(
        f'<a class="item" href="{href}"><strong>{esc(title)}</strong><span>{esc(desc)}</span></a>'
        for href, title, desc in cards
    )
    out.write_text(
        f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>UOB AI MSc Revision Notes</title><style>body{{font-family:"Segoe UI",Arial,"Microsoft YaHei",sans-serif;background:#f6f8fb;color:#172033;margin:0;padding:48px}}main{{max-width:920px;margin:auto}}h1{{font-size:42px;margin:0 0 8px}}p{{color:#667085}}.item{{display:block;background:#fff;border:1px solid #d8dee9;border-radius:8px;padding:20px;margin:14px 0;text-decoration:none;color:#172033;box-shadow:0 8px 24px rgba(15,23,42,.05)}}.item:hover{{border-color:#0f766e}}strong{{display:block;color:#0f766e;font-size:19px}}span{{display:block;margin-top:5px}}</style><main><h1>UOB AI MSc 复习资料总入口</h1><p>learn-from-materials 逐页复习资料：左侧目录、原页截图、原文、中文释义、概念拓展和双语自测。</p>{body}</main></html>''',
        encoding="utf-8",
    )
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description="Build page-by-page revision companions")
    parser.add_argument("--slug", action="append", help="Only build the named material slug; repeat for multiple materials")
    args = parser.parse_args()
    selected = [conf for conf in MATERIALS if not args.slug or conf["slug"] in args.slug]
    if not selected:
        raise SystemExit(f"Unknown material slug: {', '.join(args.slug or [])}")
    results = []
    for conf in selected:
        results.append(build_one(conf))
    if args.slug:
        indices = {"selected_only": True}
    else:
        dia = [r for r in results if r["subject"].startswith("Data-Intensive")]
        cv = [r for r in results if r["subject"].startswith("Computer Vision")]
        indices = {
            "dia": str(write_index("dia_index.html", "DIA 逐页复习资料", dia)),
            "cv": str(write_index("cv_index.html", "Computer Vision 逐页复习资料", cv)),
            "all_remaining": str(write_index("remaining_subjects_index.html", "其余科目逐页复习资料", results)),
            "all_courses": str(write_all_courses_index()),
        }
    print(json.dumps({"results": results, "indices": indices}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
