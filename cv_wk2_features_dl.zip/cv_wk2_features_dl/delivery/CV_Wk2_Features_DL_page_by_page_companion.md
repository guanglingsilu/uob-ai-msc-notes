# Feature Detection and Deep Learning

课程：Computer Vision and Imaging

## 第 1 页：特征 检测

Source ID: `src-a1c091bbcbc2-pdf_page-00001`

![PDF page 1](../assets/pages/page_001.jpg)

### 原文 / Original Text

```text
Feature Detection 
and Deep Learning

Jianbo Jiao

School of Computer Science
University of Birmingham

[Computer Vision and Imaging]
```

### 完整中文翻译

特征 检测
and 深度学习
Jianbo Jiao
计算机科学学院
伯明翰大学
[计算机视觉与成像]
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Feature Detection”展开。课件中的关键信息包括：特征 检测；and 深度学习；Jianbo Jiao；计算机科学学院。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Feature Detection'. The slide includes: Feature Detection; and Deep Learning; Jianbo Jiao; School of Computer Science. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。
- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“Feature Detection”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 1 页的核心主题是什么？
**答：** 本页围绕“Feature Detection”展开。课件中的关键信息包括：特征 检测；and 深度学习；Jianbo Jiao；计算机科学学院。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 1?
**Answer:** This page presents 'Feature Detection'. The slide includes: Feature Detection; and Deep Learning; Jianbo Jiao; School of Computer Science. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Feature Detection'. The slide includes: Feature Detection; and Deep Learning; Jianbo Jiao; School of Computer Science. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 2 页：特征检测与特征提取

Source ID: `src-a1c091bbcbc2-pdf_page-00002`

![PDF page 2](../assets/pages/page_002.jpg)

### 原文 / Original Text

```text
Feature Detection/Extraction

3
```

### 完整中文翻译

特征检测与特征提取
3
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Feature Detection/Extraction”展开。课件中的关键信息包括：特征检测与特征提取；3。复习时先抓住检测：同时判断目标类别与位置，通常输出边界框。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Feature Detection/Extraction'. The slide includes: Feature Detection/Extraction; 3. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。

拓展复习：把“Feature Detection/Extraction”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 2 页的核心主题是什么？
**答：** 本页围绕“Feature Detection/Extraction”展开。课件中的关键信息包括：特征检测与特征提取；3。复习时先抓住检测：同时判断目标类别与位置，通常输出边界框。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 2?
**Answer:** This page presents 'Feature Detection/Extraction'. The slide includes: Feature Detection/Extraction; 3. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：检测 / detection
**答：** 同时判断目标类别与位置，通常输出边界框。
**Q2 English:** Explain the concept on this page: detection
**Answer:** The page focuses on detection. This page presents 'Feature Detection/Extraction'. The slide includes: Feature Detection/Extraction; 3. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

## 第 3 页：特征检测与特征提取

Source ID: `src-a1c091bbcbc2-pdf_page-00003`

![PDF page 3](../assets/pages/page_003.jpg)

### 原文 / Original Text

```text
Feature Detection/Extraction

4
```

### 完整中文翻译

特征检测与特征提取
4
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Feature Detection/Extraction”展开。课件中的关键信息包括：特征检测与特征提取；4。复习时先抓住检测：同时判断目标类别与位置，通常输出边界框。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Feature Detection/Extraction'. The slide includes: Feature Detection/Extraction; 4. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。

拓展复习：把“Feature Detection/Extraction”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 3 页的核心主题是什么？
**答：** 本页围绕“Feature Detection/Extraction”展开。课件中的关键信息包括：特征检测与特征提取；4。复习时先抓住检测：同时判断目标类别与位置，通常输出边界框。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 3?
**Answer:** This page presents 'Feature Detection/Extraction'. The slide includes: Feature Detection/Extraction; 4. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：检测 / detection
**答：** 同时判断目标类别与位置，通常输出边界框。
**Q2 English:** Explain the concept on this page: detection
**Answer:** The page focuses on detection. This page presents 'Feature Detection/Extraction'. The slide includes: Feature Detection/Extraction; 4. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

## 第 4 页：基于深度学习的特征

Source ID: `src-a1c091bbcbc2-pdf_page-00004`

![PDF page 4](../assets/pages/page_004.jpg)

### 原文 / Original Text

```text
Deep Learning-based Features

Nvidia to train 100,000 developers on deep learning AI

5
```

### 完整中文翻译

基于深度学习的特征
Nvidia to train 100,000 developers on 深度学习 AI
5
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Deep Learning-based Features”展开。课件中的关键信息包括：基于深度学习的特征；Nvidia to train 100,000 developers on 深度学习 AI；5。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Deep Learning-based Features'. The slide includes: Deep Learning-based Features; Nvidia to train 100,000 developers on deep learning AI; 5. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“Deep Learning-based Features”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 4 页的核心主题是什么？
**答：** 本页围绕“Deep Learning-based Features”展开。课件中的关键信息包括：基于深度学习的特征；Nvidia to train 100,000 developers on 深度学习 AI；5。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 4?
**Answer:** This page presents 'Deep Learning-based Features'. The slide includes: Deep Learning-based Features; Nvidia to train 100,000 developers on deep learning AI; 5. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：深度学习 / deep learning
**答：** 用多层神经网络从数据中学习表示和映射，现代视觉任务常用。
**Q2 English:** Explain the concept on this page: deep learning
**Answer:** The page focuses on deep learning. This page presents 'Deep Learning-based Features'. The slide includes: Deep Learning-based Features; Nvidia to train 100,000 developers on deep learning AI; 5. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

## 第 5 页：提纲

Source ID: `src-a1c091bbcbc2-pdf_page-00005`

![PDF page 5](../assets/pages/page_005.jpg)

### 原文 / Original Text

```text
Outline

Traditional visual feature descriptors
□ Points and patches
□ Edges and contours
□ Lines

Deep learning-based visual feature extraction
□ How to?
□ Convolutional Neural Networks
□ DL4CV

6
```

### 完整中文翻译

提纲
传统视觉特征描述子
□ 点与图像块
□ 边缘与轮廓
□ 直线
基于深度学习的视觉特征提取
问题：□ How to？
□ Convolutional Neural Networks
□ DL4CV
6
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Outline”展开。课件中的关键信息包括：提纲；传统视觉特征描述子；□ 点与图像块；□ 边缘与轮廓。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Outline'. The slide includes: Outline; Traditional visual feature descriptors; □ Points and patches; □ Edges and contours. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“Outline”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 5 页的核心主题是什么？
**答：** 本页围绕“Outline”展开。课件中的关键信息包括：提纲；传统视觉特征描述子；□ 点与图像块；□ 边缘与轮廓。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 5?
**Answer:** This page presents 'Outline'. The slide includes: Outline; Traditional visual feature descriptors; □ Points and patches; □ Edges and contours. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：深度学习 / deep learning
**答：** 用多层神经网络从数据中学习表示和映射，现代视觉任务常用。
**Q2 English:** Explain the concept on this page: deep learning
**Answer:** The page focuses on deep learning. This page presents 'Outline'. The slide includes: Outline; Traditional visual feature descriptors; □ Points and patches; □ Edges and contours. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

## 第 6 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00006`

![PDF page 6](../assets/pages/page_006.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

7

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.
```

### 完整中文翻译

传统视觉特征描述子
7
Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；7；Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; 7; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 6 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；7；Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 6?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; 7; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; 7; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 7 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00007`

![PDF page 7](../assets/pages/page_007.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

Points and patches

8

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.
```

### 完整中文翻译

传统视觉特征描述子
点与图像块
8
Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；8；Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; 8; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 7 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；8；Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 7?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; 8; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; 8; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 8 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00008`

![PDF page 8](../assets/pages/page_008.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

Points and patches

9

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.
```

### 完整中文翻译

传统视觉特征描述子
点与图像块
9
Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；9；Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; 9; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 8 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；9；Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 8?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; 9; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; 9; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 9 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00009`

![PDF page 9](../assets/pages/page_009.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

Points and patches
Patches with gradients in at least two (significantly) 
different orientations are the easiest to localize 

10

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.
```

### 完整中文翻译

传统视觉特征描述子
点与图像块
Patches with gradients in at least two (significantly)
different orientations are the easiest to localize
10
Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；Patches with gradients in at least two (significantly)；different orientations are the easiest to localize。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Patches with gradients in at least two (significantly); different orientations are the easiest to localize. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 9 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；Patches with gradients in at least two (significantly)；different orientations are the easiest to localize。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 9?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Patches with gradients in at least two (significantly); different orientations are the easiest to localize. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Patches with gradients in at least two (significantly); different orientations are the easiest to localize. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 10 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00010`

![PDF page 10](../assets/pages/page_010.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

Points and patches
Adaptive non-maximal suppression 
(ANMS) 

11

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.
```

### 完整中文翻译

传统视觉特征描述子
点与图像块
Adaptive non-maximal suppression
(ANMS)
11
Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；Adaptive non-maximal suppression；(ANMS)。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Adaptive non-maximal suppression; (ANMS). The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 10 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；Adaptive non-maximal suppression；(ANMS)。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 10?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Adaptive non-maximal suppression; (ANMS). The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Adaptive non-maximal suppression; (ANMS). The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 11 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00011`

![PDF page 11](../assets/pages/page_011.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

Points and patches
Scale invariance

12

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.
```

### 完整中文翻译

传统视觉特征描述子
点与图像块
Scale invariance
12
Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；Scale invariance；12。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Scale invariance; 12. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 11 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；Scale invariance；12。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 11?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Scale invariance; 12. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Scale invariance; 12. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 12 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00012`

![PDF page 12](../assets/pages/page_012.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

Points and patches
Rotational invariance

13

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.
```

### 完整中文翻译

传统视觉特征描述子
点与图像块
Rotational invariance
13
Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；Rotational invariance；13。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Rotational invariance; 13. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 12 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；Rotational invariance；13。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 12?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Rotational invariance; 13. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Rotational invariance; 13. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 13 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00013`

![PDF page 13](../assets/pages/page_013.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

Points and patches
Affine invariance

14

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.
```

### 完整中文翻译

传统视觉特征描述子
点与图像块
Affine invariance
14
Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；Affine invariance；14。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Affine invariance; 14. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 13 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；Affine invariance；14。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 13?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Affine invariance; 14. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Affine invariance; 14. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 14 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00014`

![PDF page 14](../assets/pages/page_014.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

Points and patches
multi-scale oriented patches (MOPS) 

15

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.
```

### 完整中文翻译

传统视觉特征描述子
点与图像块
multi-scale oriented patches (MOPS)
15
Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；multi-scale oriented patches (MOPS)；15。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; multi-scale oriented patches (MOPS); 15. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 14 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；multi-scale oriented patches (MOPS)；15。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 14?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; multi-scale oriented patches (MOPS); 15. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; multi-scale oriented patches (MOPS); 15. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 15 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00015`

![PDF page 15](../assets/pages/page_015.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

Points and patches
Scale invariant feature transform (SIFT) 

16

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.
```

### 完整中文翻译

传统视觉特征描述子
点与图像块
Scale invariant 特征 transform (SIFT)
16
Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；Scale invariant 特征 transform (SIFT)；16。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Scale invariant feature transform (SIFT); 16. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 15 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；Scale invariant 特征 transform (SIFT)；16。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 15?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Scale invariant feature transform (SIFT); 16. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Scale invariant feature transform (SIFT); 16. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 16 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00016`

![PDF page 16](../assets/pages/page_016.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

Points and patches
Applications: Large-scale matching and retrieval

17

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.
```

### 完整中文翻译

传统视觉特征描述子
点与图像块
Applications: Large-scale matching and retrieval
17
Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；Applications: Large-scale matching and retrieval；17。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Applications: Large-scale matching and retrieval; 17. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 16 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；点与图像块；Applications: Large-scale matching and retrieval；17。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 16?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Applications: Large-scale matching and retrieval; 17. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Points and patches; Applications: Large-scale matching and retrieval; 17. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 17 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00017`

![PDF page 17](../assets/pages/page_017.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

Edges and contours

18

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.
```

### 完整中文翻译

传统视觉特征描述子
边缘与轮廓
18
Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；边缘与轮廓；18；Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; 18; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 17 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；边缘与轮廓；18；Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 17?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; 18; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; 18; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 18 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00018`

![PDF page 18](../assets/pages/page_018.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

Edges and contours
Gradient

Laplacian of Gaussian (LoG)

19

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.
```

### 完整中文翻译

传统视觉特征描述子
边缘与轮廓
Gradient
Laplacian of Gaussian (LoG)
19
Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；边缘与轮廓；Gradient；Laplacian of Gaussian (LoG)。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; Gradient; Laplacian of Gaussian (LoG). The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 18 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；边缘与轮廓；Gradient；Laplacian of Gaussian (LoG)。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 18?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; Gradient; Laplacian of Gaussian (LoG). The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; Gradient; Laplacian of Gaussian (LoG). The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 19 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00019`

![PDF page 19](../assets/pages/page_019.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

Edges and contours
Sobel edge detector/operator

20

https://en.wikipedia.org/wiki/Sobel_operator
```

### 完整中文翻译

传统视觉特征描述子
边缘与轮廓
Sobel edge detector/operator
20
参考链接：https://en.wikipedia.org/wiki/Sobel_operator
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；边缘与轮廓；Sobel edge detector/operator；20。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; Sobel edge detector/operator; 20. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 19 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；边缘与轮廓；Sobel edge detector/operator；20。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 19?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; Sobel edge detector/operator; 20. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; Sobel edge detector/operator; 20. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 20 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00020`

![PDF page 20](../assets/pages/page_020.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

Edges and contours
Sobel edge detector/operator

x

y

21

https://en.wikipedia.org/wiki/Sobel_operator
```

### 完整中文翻译

传统视觉特征描述子
边缘与轮廓
Sobel edge detector/operator
x
y
21
参考链接：https://en.wikipedia.org/wiki/Sobel_operator
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；边缘与轮廓；Sobel edge detector/operator；x。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; Sobel edge detector/operator; x. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 20 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；边缘与轮廓；Sobel edge detector/operator；x。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 20?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; Sobel edge detector/operator; x. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; Sobel edge detector/operator; x. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 21 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00021`

![PDF page 21](../assets/pages/page_021.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

Edges and contours
Canny edge detector

1.Apply Gaussian filter to smooth the image 
in order to remove the noise

2.Find the intensity gradients of the image

3.Apply gradient magnitude thresholding or 
lower bound cut-off suppression to get rid of 
spurious response to edge detection

4.Apply double threshold to determine 
potential edges

5.Track edge by hysteresis: Finalize the 
detection of edges by suppressing all the 
other edges that are weak and not 
connected to strong edges.

22

https://en.wikipedia.org/wiki/Canny_edge_detector
```

### 完整中文翻译

传统视觉特征描述子
边缘与轮廓
Canny edge detector
1.Apply 高斯滤波器 to smooth the image
in order to remove the noise
2.Find the intensity gradients of the image
3.Apply gradient magnitude thresholding or
lower bound cut-off suppression to get rid of
spurious response to edge 检测
4.Apply double threshold to determine
potential edges
5.Track edge by hysteresis: Finalize the
检测 of edges by suppressing all the
other edges that are weak and not
connected to strong edges.
22
参考链接：https://en.wikipedia.org/wiki/Canny_edge_detector
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；边缘与轮廓；Canny edge detector；1.Apply 高斯滤波器 to smooth the image。复习时先抓住检测：同时判断目标类别与位置，通常输出边界框。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; Canny edge detector; 1.Apply Gaussian filter to smooth the image. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 21 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；边缘与轮廓；Canny edge detector；1.Apply 高斯滤波器 to smooth the image。复习时先抓住检测：同时判断目标类别与位置，通常输出边界框。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 21?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; Canny edge detector; 1.Apply Gaussian filter to smooth the image. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：检测 / detection
**答：** 同时判断目标类别与位置，通常输出边界框。
**Q2 English:** Explain the concept on this page: detection
**Answer:** The page focuses on detection. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; Canny edge detector; 1.Apply Gaussian filter to smooth the image. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

## 第 22 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00022`

![PDF page 22](../assets/pages/page_022.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

Edges and contours
Contour detection

23

Edge and Contour Detection with OpenCV and Python
```

### 完整中文翻译

传统视觉特征描述子
边缘与轮廓
Contour 检测
23
Edge and Contour 检测 with OpenCV and Python
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；边缘与轮廓；Contour 检测；23。复习时先抓住检测：同时判断目标类别与位置，通常输出边界框。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; Contour detection; 23. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 22 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；边缘与轮廓；Contour 检测；23。复习时先抓住检测：同时判断目标类别与位置，通常输出边界框。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 22?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; Contour detection; 23. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：检测 / detection
**答：** 同时判断目标类别与位置，通常输出边界框。
**Q2 English:** Explain the concept on this page: detection
**Answer:** The page focuses on detection. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; Edges and contours; Contour detection; 23. The revision focus is detection; connect its definition, evidence, and use to the examples on the page.

## 第 23 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00023`

![PDF page 23](../assets/pages/page_023.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

(straight) Lines and vanishing points

24

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.
```

### 完整中文翻译

传统视觉特征描述子
(straight) 直线 and vanishing points
24
Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；(straight) 直线 and vanishing points；24；Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; (straight) Lines and vanishing points; 24; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 23 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；(straight) 直线 and vanishing points；24；Szeliski, R. (2022). 计算机视觉: algorithms and applications. Springer Nature.。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 23?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; (straight) Lines and vanishing points; 24; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; (straight) Lines and vanishing points; 24; Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 24 页：传统视觉特征描述子

Source ID: `src-a1c091bbcbc2-pdf_page-00024`

![PDF page 24](../assets/pages/page_024.jpg)

### 原文 / Original Text

```text
Traditional visual feature descriptors

(straight) Lines and vanishing points
Hough transforms: having edges “vote” for plausible 
line locations 

25

https://en.wikipedia.org/wiki/Hough_transform
```

### 完整中文翻译

传统视觉特征描述子
(straight) 直线 and vanishing points
Hough transforms: having edges “vote” for plausible
line locations
25
参考链接：https://en.wikipedia.org/wiki/Hough_transform
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；(straight) 直线 and vanishing points；Hough transforms: having edges “vote” for plausible；line locations。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; (straight) Lines and vanishing points; Hough transforms: having edges “vote” for plausible; line locations. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Traditional visual feature descriptors”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 24 页的核心主题是什么？
**答：** 本页围绕“Traditional visual feature descriptors”展开。课件中的关键信息包括：传统视觉特征描述子；(straight) 直线 and vanishing points；Hough transforms: having edges “vote” for plausible；line locations。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 24?
**Answer:** This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; (straight) Lines and vanishing points; Hough transforms: having edges “vote” for plausible; line locations. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Traditional visual feature descriptors'. The slide includes: Traditional visual feature descriptors; (straight) Lines and vanishing points; Hough transforms: having edges “vote” for plausible; line locations. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 25 页：Traditional Image Categorization: Training phase

Source ID: `src-a1c091bbcbc2-pdf_page-00025`

![PDF page 25](../assets/pages/page_025.jpg)

### 原文 / Original Text

```text
Traditional Image Categorization: Training phase

Slide credit:

Training 
Images

Training

Training 
Labels

Image 
Features

Classifier 
Training

Trained 
Classifier

26
```

### 完整中文翻译

Traditional Image Categorization: Training phase
Slide credit:
Training
Images
Training
Training
Labels
Image
Features
Classifier
Training
Trained
Classifier
26
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional Image Categorization: Training phase”展开。课件中的关键信息包括：Traditional Image Categorization: Training phase；Slide credit:；Training；Images。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional Image Categorization: Training phase'. The slide includes: Traditional Image Categorization: Training phase; Slide credit:; Training; Images. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Traditional Image Categorization: Training phase”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 25 页的核心主题是什么？
**答：** 本页围绕“Traditional Image Categorization: Training phase”展开。课件中的关键信息包括：Traditional Image Categorization: Training phase；Slide credit:；Training；Images。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 25?
**Answer:** This page presents 'Traditional Image Categorization: Training phase'. The slide includes: Traditional Image Categorization: Training phase; Slide credit:; Training; Images. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Traditional Image Categorization: Training phase'. The slide includes: Traditional Image Categorization: Training phase; Slide credit:; Training; Images. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 26 页：Traditional Image Categorization: Testing phase

Source ID: `src-a1c091bbcbc2-pdf_page-00026`

![PDF page 26](../assets/pages/page_026.jpg)

### 原文 / Original Text

```text
Traditional Image Categorization: Testing phase

Training 
Images

Training

Training 
Labels

Slide credit:

Image 
Features

Classifier 
Training

Trained 
Classifier

Testing

Image 
Features

Trained 
Classifier

Prediction

Outdoor

Test Image

27
```

### 完整中文翻译

Traditional Image Categorization: Testing phase
Training
Images
Training
Training
Labels
Slide credit:
Image
Features
Classifier
Training
Trained
Classifier
Testing
Image
Features
Trained
Classifier
Prediction
Outdoor
Test Image
27
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Traditional Image Categorization: Testing phase”展开。课件中的关键信息包括：Traditional Image Categorization: Testing phase；Training；Images；Training。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Traditional Image Categorization: Testing phase'. The slide includes: Traditional Image Categorization: Testing phase; Training; Images; Training. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Traditional Image Categorization: Testing phase”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 26 页的核心主题是什么？
**答：** 本页围绕“Traditional Image Categorization: Testing phase”展开。课件中的关键信息包括：Traditional Image Categorization: Testing phase；Training；Images；Training。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 26?
**Answer:** This page presents 'Traditional Image Categorization: Testing phase'. The slide includes: Traditional Image Categorization: Testing phase; Training; Images; Training. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Traditional Image Categorization: Testing phase'. The slide includes: Traditional Image Categorization: Testing phase; Training; Images; Training. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 27 页：Features are have been the key…

Source ID: `src-a1c091bbcbc2-pdf_page-00027`

![PDF page 27](../assets/pages/page_027.jpg)

### 原文 / Original Text

```text
Features are have been the key…

Slide credit:

SIFT [Loewe IJCV 04]

HOG [Dalal and Triggs CVPR 05]

Hand-crafted

DPM [Felzenszwalb et al. PAMI 10]

SPM [Lazebnik et al. CVPR 06]

Color Descriptor [Van De Sande et al. PAMI 10]

28
```

### 完整中文翻译

Features are have been the key…
Slide credit:
SIFT [Loewe IJCV 04]
HOG [Dalal and Triggs CVPR 05]
Hand-crafted
DPM [Felzenszwalb et al. PAMI 10]
SPM [Lazebnik et al. CVPR 06]
Color Descriptor [Van De Sande et al. PAMI 10]
28
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Features are have been the key…”展开。课件中的关键信息包括：Features are have been the key…；Slide credit:；SIFT [Loewe IJCV 04]；HOG [Dalal and Triggs CVPR 05]。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Features are have been the key…'. The slide includes: Features are have been the key…; Slide credit:; SIFT [Loewe IJCV 04]; HOG [Dalal and Triggs CVPR 05]. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Features are have been the key…”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 27 页的核心主题是什么？
**答：** 本页围绕“Features are have been the key…”展开。课件中的关键信息包括：Features are have been the key…；Slide credit:；SIFT [Loewe IJCV 04]；HOG [Dalal and Triggs CVPR 05]。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 27?
**Answer:** This page presents 'Features are have been the key…'. The slide includes: Features are have been the key…; Slide credit:; SIFT [Loewe IJCV 04]; HOG [Dalal and Triggs CVPR 05]. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Features are have been the key…'. The slide includes: Features are have been the key…; Slide credit:; SIFT [Loewe IJCV 04]; HOG [Dalal and Triggs CVPR 05]. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 28 页：问题：What about learning the features？

Source ID: `src-a1c091bbcbc2-pdf_page-00028`

![PDF page 28](../assets/pages/page_028.jpg)

### 原文 / Original Text

```text
What about learning the features?
• Learn a feature hierarchy all the way from pixels 

to classifier

• Each layer extracts features from the output of 

previous layer

• Layers have (nearly) the same structure
• Train all layers jointly (“end-to-end”)

Image/ 
Video
Pixels

Layer 1

Layer 2

Layer 3

Simple 
Classifier

29
```

### 完整中文翻译

问题：What about learning the features？
• Learn a 特征 hierarchy all the way from pixels
to classifier
• Each layer extracts features from the output of
previous layer
• Layers have (nearly) the same structure
• Train all layers jointly (“end-to-end”)
Image/
Video
Pixels
Layer 1
Layer 2
Layer 3
Simple
Classifier
29
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“What about learning the features?”展开。课件中的关键信息包括：问题：What about learning the features？；• Learn a 特征 hierarchy all the way from pixels；to classifier；• Each layer extracts features from the output of。复习时先抓住连接：按键把表横向组合；键的语义不一致时会产生看似正确但实际错误的数据视图。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'What about learning the features?'. The slide includes: What about learning the features?; • Learn a feature hierarchy all the way from pixels; to classifier; • Each layer extracts features from the output of. The revision focus is join; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **join / 连接**：按键把表横向组合；键的语义不一致时会产生看似正确但实际错误的数据视图。

拓展复习：把“What about learning the features?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 28 页的核心主题是什么？
**答：** 本页围绕“What about learning the features?”展开。课件中的关键信息包括：问题：What about learning the features？；• Learn a 特征 hierarchy all the way from pixels；to classifier；• Each layer extracts features from the output of。复习时先抓住连接：按键把表横向组合；键的语义不一致时会产生看似正确但实际错误的数据视图。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 28?
**Answer:** This page presents 'What about learning the features?'. The slide includes: What about learning the features?; • Learn a feature hierarchy all the way from pixels; to classifier; • Each layer extracts features from the output of. The revision focus is join; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：连接 / join
**答：** 按键把表横向组合；键的语义不一致时会产生看似正确但实际错误的数据视图。
**Q2 English:** Explain the concept on this page: join
**Answer:** The page focuses on join. This page presents 'What about learning the features?'. The slide includes: What about learning the features?; • Learn a feature hierarchy all the way from pixels; to classifier; • Each layer extracts features from the output of. The revision focus is join; connect its definition, evidence, and use to the examples on the page.

## 第 29 页：Learning 特征 Hierarchy

Source ID: `src-a1c091bbcbc2-pdf_page-00029`

![PDF page 29](../assets/pages/page_029.jpg)

### 原文 / Original Text

```text
Learning Feature Hierarchy

Goal: Learn useful higher-level features from images

Feature representation

Input data

[Lee et al., ICML
2009;  CACM 2011]

3rd layer  
“Objects”

2nd layer  
“Object parts”

1st layer  
“Edges”

Pixels

30

Slide credit: Rob Fergus
```

### 完整中文翻译

Learning 特征 Hierarchy
Goal: Learn useful higher-level features from images
特征 representation
Input data
[Lee et al., ICML
2009; CACM 2011]
3rd layer
“Objects”
2nd layer
“Object parts”
1st layer
“Edges”
Pixels
30
Slide credit: Rob Fergus
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Learning Feature Hierarchy”展开。课件中的关键信息包括：Learning 特征 Hierarchy；Goal: Learn useful higher-level features from images；特征 representation；Input data。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Learning Feature Hierarchy'. The slide includes: Learning Feature Hierarchy; Goal: Learn useful higher-level features from images; Feature representation; Input data. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Learning Feature Hierarchy”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 29 页的核心主题是什么？
**答：** 本页围绕“Learning Feature Hierarchy”展开。课件中的关键信息包括：Learning 特征 Hierarchy；Goal: Learn useful higher-level features from images；特征 representation；Input data。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 29?
**Answer:** This page presents 'Learning Feature Hierarchy'. The slide includes: Learning Feature Hierarchy; Goal: Learn useful higher-level features from images; Feature representation; Input data. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Learning Feature Hierarchy'. The slide includes: Learning Feature Hierarchy; Goal: Learn useful higher-level features from images; Feature representation; Input data. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 30 页：Learning 特征 Hierarchy

Source ID: `src-a1c091bbcbc2-pdf_page-00030`

![PDF page 30](../assets/pages/page_030.jpg)

### 原文 / Original Text

```text
Learning Feature Hierarchy

• Better performance

• Other domains (unclear how to hand engineer):

– Kinect
– Video
– Multi spectral

• Feature computation time

– Dozens of features now regularly used 
– Getting prohibitive for large datasets (10’s sec / image)

31

Slide credit: Rob Fergus
```

### 完整中文翻译

Learning 特征 Hierarchy
• Better performance
• Other domains (unclear how to hand engineer):
– Kinect
– Video
– Multi spectral
• 特征 computation time
– Dozens of features now regularly used
– Getting prohibitive for large datasets (10’s sec / image)
31
Slide credit: Rob Fergus
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Learning Feature Hierarchy”展开。课件中的关键信息包括：Learning 特征 Hierarchy；• Better performance；• Other domains (unclear how to hand engineer):；– Kinect。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Learning Feature Hierarchy'. The slide includes: Learning Feature Hierarchy; • Better performance; • Other domains (unclear how to hand engineer):; – Kinect. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Learning Feature Hierarchy”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 30 页的核心主题是什么？
**答：** 本页围绕“Learning Feature Hierarchy”展开。课件中的关键信息包括：Learning 特征 Hierarchy；• Better performance；• Other domains (unclear how to hand engineer):；– Kinect。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 30?
**Answer:** This page presents 'Learning Feature Hierarchy'. The slide includes: Learning Feature Hierarchy; • Better performance; • Other domains (unclear how to hand engineer):; – Kinect. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Learning Feature Hierarchy'. The slide includes: Learning Feature Hierarchy; • Better performance; • Other domains (unclear how to hand engineer):; – Kinect. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 31 页：“Shallow” vs. “Deep” architectures

Source ID: `src-a1c091bbcbc2-pdf_page-00031`

![PDF page 31](../assets/pages/page_031.jpg)

### 原文 / Original Text

```text
“Shallow” vs. “Deep” architectures

32

Slide credit: Yann LeCun
```

### 完整中文翻译

“Shallow” vs. “Deep” architectures
32
Slide credit: Yann LeCun
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕““Shallow” vs. “Deep” architectures”展开。课件中的关键信息包括：“Shallow” vs. “Deep” architectures；32；Slide credit: Yann LeCun。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents '“Shallow” vs. “Deep” architectures'. The slide includes: “Shallow” vs. “Deep” architectures; 32; Slide credit: Yann LeCun. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把““Shallow” vs. “Deep” architectures”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 31 页的核心主题是什么？
**答：** 本页围绕““Shallow” vs. “Deep” architectures”展开。课件中的关键信息包括：“Shallow” vs. “Deep” architectures；32；Slide credit: Yann LeCun。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 31?
**Answer:** This page presents '“Shallow” vs. “Deep” architectures'. The slide includes: “Shallow” vs. “Deep” architectures; 32; Slide credit: Yann LeCun. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents '“Shallow” vs. “Deep” architectures'. The slide includes: “Shallow” vs. “Deep” architectures; 32; Slide credit: Yann LeCun. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 32 页：“Shallow” vs. “Deep” architectures

Source ID: `src-a1c091bbcbc2-pdf_page-00032`

![PDF page 32](../assets/pages/page_032.jpg)

### 原文 / Original Text

```text
“Shallow” vs. “Deep” architectures

Layer 1

…

Layer k

33

Slide adapted from: Yann LeCun
```

### 完整中文翻译

“Shallow” vs. “Deep” architectures
Layer 1
…
Layer k
33
Slide adapted from: Yann LeCun
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕““Shallow” vs. “Deep” architectures”展开。课件中的关键信息包括：“Shallow” vs. “Deep” architectures；Layer 1；…；Layer k。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents '“Shallow” vs. “Deep” architectures'. The slide includes: “Shallow” vs. “Deep” architectures; Layer 1; …; Layer k. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把““Shallow” vs. “Deep” architectures”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 32 页的核心主题是什么？
**答：** 本页围绕““Shallow” vs. “Deep” architectures”展开。课件中的关键信息包括：“Shallow” vs. “Deep” architectures；Layer 1；…；Layer k。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 32?
**Answer:** This page presents '“Shallow” vs. “Deep” architectures'. The slide includes: “Shallow” vs. “Deep” architectures; Layer 1; …; Layer k. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents '“Shallow” vs. “Deep” architectures'. The slide includes: “Shallow” vs. “Deep” architectures; Layer 1; …; Layer k. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 33 页：Why 深度学习?

Source ID: `src-a1c091bbcbc2-pdf_page-00033`

![PDF page 33](../assets/pages/page_033.jpg)

### 原文 / Original Text

```text
Why deep learning?

https://towardsdatascience.com/what-is-deep-learning-and-how-does-it-work-2ce44bb692ac

Slide credit:

34
```

### 完整中文翻译

Why 深度学习?
参考链接：https://towardsdatascience.com/what-is-deep-learning-and-how-does-it-work-2ce44bb692ac
Slide credit:
34
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Why deep learning?”展开。课件中的关键信息包括：Why 深度学习?；参考链接：https://towardsdatascience.com/what-is-deep-learning-and-how-does-it-work-2ce44bb692ac；Slide credit:；34。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Why deep learning?'. The slide includes: Why deep learning?; https://towardsdatascience.com/what-is-deep-learning-and-how-does-it-work-2ce44bb692ac; Slide credit:; 34. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“Why deep learning?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 33 页的核心主题是什么？
**答：** 本页围绕“Why deep learning?”展开。课件中的关键信息包括：Why 深度学习?；参考链接：https://towardsdatascience.com/what-is-deep-learning-and-how-does-it-work-2ce44bb692ac；Slide credit:；34。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 33?
**Answer:** This page presents 'Why deep learning?'. The slide includes: Why deep learning?; https://towardsdatascience.com/what-is-deep-learning-and-how-does-it-work-2ce44bb692ac; Slide credit:; 34. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：深度学习 / deep learning
**答：** 用多层神经网络从数据中学习表示和映射，现代视觉任务常用。
**Q2 English:** Explain the concept on this page: deep learning
**Answer:** The page focuses on deep learning. This page presents 'Why deep learning?'. The slide includes: Why deep learning?; https://towardsdatascience.com/what-is-deep-learning-and-how-does-it-work-2ce44bb692ac; Slide credit:; 34. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

## 第 34 页：What is 深度学习?

Source ID: `src-a1c091bbcbc2-pdf_page-00034`

![PDF page 34](../assets/pages/page_034.jpg)

### 原文 / Original Text

```text
What is deep learning?
02
01

Classification

Detection

03

Matting

!!(#) = &

AlphaFold

05

06

Healthcare

04

Alpha GO

https://becominghuman.ai/building-an-image-classifier-using-deep-learning-in-python-totally-from-a-beginners-perspective-be8dbaf22dd8
https://towardsdatascience.com/deep-learning-method-for-object-detection-r-cnn-explained-ecdadd751d22?gi=51e5dd227143
https://www.befunky.com/learn/automatic-background-remover/, https://deepmind.com/research/case-studies/alphago-the-story-so-far

https://deepmind.com/blog/article/alphafold-a-solution-to-a-50-year-old-grand-challenge-in-biology,
https://stanfordmlgroup.github.io/projects/chexnet/

…

35
```

### 完整中文翻译

What is 深度学习?
02
01
分类
检测
03
Matting
!!(#) = &
AlphaFold
05
06
Healthcare
04
Alpha GO
参考链接：https://becominghuman.ai/building-an-image-classifier-using-deep-learning-in-python-totally-from-a-beginners-perspective-be8dbaf22dd8
参考链接：https://towardsdatascience.com/deep-learning-method-for-object-detection-r-cnn-explained-ecdadd751d22?gi=51e5dd227143
参考链接：https://www.befunky.com/learn/automatic-background-remover/, https://deepmind.com/research/case-studies/alphago-the-story-so-far
参考链接：https://deepmind.com/blog/article/alphafold-a-solution-to-a-50-year-old-grand-challenge-in-biology,
参考链接：https://stanfordmlgroup.github.io/projects/chexnet/
…
35
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“What is deep learning?”展开。课件中的关键信息包括：What is 深度学习?；02；01；分类。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'What is deep learning?'. The slide includes: What is deep learning?; 02; 01; Classification. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。
- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。
- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“What is deep learning?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 34 页的核心主题是什么？
**答：** 本页围绕“What is deep learning?”展开。课件中的关键信息包括：What is 深度学习?；02；01；分类。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 34?
**Answer:** This page presents 'What is deep learning?'. The slide includes: What is deep learning?; 02; 01; Classification. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：分类 / classification
**答：** 预测离散类别标签，例如图像类别或手写数字。
**Q2 English:** Explain the concept on this page: classification
**Answer:** The page focuses on classification. This page presents 'What is deep learning?'. The slide includes: What is deep learning?; 02; 01; Classification. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

## 第 35 页：A brief history

Source ID: `src-a1c091bbcbc2-pdf_page-00035`

![PDF page 35](../assets/pages/page_035.jpg)

### 原文 / Original Text

```text
A brief history

Brain

Supervised
learning

Unsupervised
learning

Modern
architectures

https://towardsdatascience.com/supervised-vs-unsupervised-learning-in-2-minutes-72dad148f242 https://medium.com/analytics-vidhya/cnns-architectures-lenet-alexnet-vgg-googlenet-resnet-and-more-666091488df5

36
```

### 完整中文翻译

A brief history
Brain
Supervised
learning
Unsupervised
learning
Modern
architectures
参考链接：https://towardsdatascience.com/supervised-vs-unsupervised-learning-in-2-minutes-72dad148f242 https://medium.com/analytics-vidhya/cnns-architectures-lenet-alexnet-vgg-googlenet-resnet-and-more-666091488df5
36
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“A brief history”展开。课件中的关键信息包括：A brief history；Brain；Supervised；learning。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'A brief history'. The slide includes: A brief history; Brain; Supervised; learning. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“A brief history”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 35 页的核心主题是什么？
**答：** 本页围绕“A brief history”展开。课件中的关键信息包括：A brief history；Brain；Supervised；learning。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 35?
**Answer:** This page presents 'A brief history'. The slide includes: A brief history; Brain; Supervised; learning. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'A brief history'. The slide includes: A brief history; Brain; Supervised; learning. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 36 页：A brief history

Source ID: `src-a1c091bbcbc2-pdf_page-00036`

![PDF page 36](../assets/pages/page_036.jpg)

### 原文 / Original Text

```text
A brief history

Slide credit:
```

### 完整中文翻译

A brief history
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“A brief history”展开。课件中的关键信息包括：A brief history；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'A brief history'. The slide includes: A brief history; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“A brief history”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 36 页的核心主题是什么？
**答：** 本页围绕“A brief history”展开。课件中的关键信息包括：A brief history；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 36?
**Answer:** This page presents 'A brief history'. The slide includes: A brief history; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'A brief history'. The slide includes: A brief history; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 37 页：A brief history

Source ID: `src-a1c091bbcbc2-pdf_page-00037`

![PDF page 37](../assets/pages/page_037.jpg)

### 原文 / Original Text

```text
A brief history

Slide credit:
```

### 完整中文翻译

A brief history
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“A brief history”展开。课件中的关键信息包括：A brief history；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'A brief history'. The slide includes: A brief history; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“A brief history”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 37 页的核心主题是什么？
**答：** 本页围绕“A brief history”展开。课件中的关键信息包括：A brief history；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 37?
**Answer:** This page presents 'A brief history'. The slide includes: A brief history; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'A brief history'. The slide includes: A brief history; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 38 页：A brief history

Source ID: `src-a1c091bbcbc2-pdf_page-00038`

![PDF page 38](../assets/pages/page_038.jpg)

### 原文 / Original Text

```text
A brief history

Slide adapted from:

FCN UNet YOLO

Generative Adversarial Network (GAN)

Mask R-CNN

Capsule Network

Graph Neural Network (GNN)

Vision Transformer (ViT)

Neural Radiance Field (NeRF)

Today
```

### 完整中文翻译

A brief history
Slide adapted from:
FCN UNet YOLO
Generative Adversarial Network (GAN)
Mask R-CNN
Capsule Network
Graph Neural Network (GNN)
Vision Transformer (ViT)
Neural Radiance Field (NeRF)
Today
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“A brief history”展开。课件中的关键信息包括：A brief history；Slide adapted from:；FCN UNet YOLO；Generative Adversarial Network (GAN)。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'A brief history'. The slide includes: A brief history; Slide adapted from:; FCN UNet YOLO; Generative Adversarial Network (GAN). The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“A brief history”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 38 页的核心主题是什么？
**答：** 本页围绕“A brief history”展开。课件中的关键信息包括：A brief history；Slide adapted from:；FCN UNet YOLO；Generative Adversarial Network (GAN)。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 38?
**Answer:** This page presents 'A brief history'. The slide includes: A brief history; Slide adapted from:; FCN UNet YOLO; Generative Adversarial Network (GAN). The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'A brief history'. The slide includes: A brief history; Slide adapted from:; FCN UNet YOLO; Generative Adversarial Network (GAN). The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 39 页：A brief history

Source ID: `src-a1c091bbcbc2-pdf_page-00039`

![PDF page 39](../assets/pages/page_039.jpg)

### 原文 / Original Text

```text
A brief history

Brain

Supervised
learning

Unsupervised
learning

Modern
architectures

https://towardsdatascience.com/supervised-vs-unsupervised-learning-in-2-minutes-72dad148f242 https://medium.com/analytics-vidhya/cnns-architectures-lenet-alexnet-vgg-googlenet-resnet-and-more-666091488df5

40
```

### 完整中文翻译

A brief history
Brain
Supervised
learning
Unsupervised
learning
Modern
architectures
参考链接：https://towardsdatascience.com/supervised-vs-unsupervised-learning-in-2-minutes-72dad148f242 https://medium.com/analytics-vidhya/cnns-architectures-lenet-alexnet-vgg-googlenet-resnet-and-more-666091488df5
40
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“A brief history”展开。课件中的关键信息包括：A brief history；Brain；Supervised；learning。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'A brief history'. The slide includes: A brief history; Brain; Supervised; learning. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“A brief history”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 39 页的核心主题是什么？
**答：** 本页围绕“A brief history”展开。课件中的关键信息包括：A brief history；Brain；Supervised；learning。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 39?
**Answer:** This page presents 'A brief history'. The slide includes: A brief history; Brain; Supervised; learning. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'A brief history'. The slide includes: A brief history; Brain; Supervised; learning. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 40 页：Basic definition

Source ID: `src-a1c091bbcbc2-pdf_page-00040`

![PDF page 40](../assets/pages/page_040.jpg)

### 原文 / Original Text

```text
Basic definition

Deep Learning

Deep Neural Network

Demo

Human Brain

Video

41

Image courtesy: https://medium.com/autonomous-agents/mathematical-foundation-for-activation-functions-in-artificial-neural-networks-a51c9dd7c089
```

### 完整中文翻译

Basic definition
深度学习
Deep Neural Network
Demo
Human Brain
Video
41
Image courtesy: https://medium.com/autonomous-agents/mathematical-foundation-for-activation-functions-in-artificial-neural-networks-a51c9dd7c089
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；深度学习；Deep Neural Network；Demo。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Basic definition'. The slide includes: Basic definition; Deep Learning; Deep Neural Network; Demo. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“Basic definition”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 40 页的核心主题是什么？
**答：** 本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；深度学习；Deep Neural Network；Demo。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 40?
**Answer:** This page presents 'Basic definition'. The slide includes: Basic definition; Deep Learning; Deep Neural Network; Demo. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：深度学习 / deep learning
**答：** 用多层神经网络从数据中学习表示和映射，现代视觉任务常用。
**Q2 English:** Explain the concept on this page: deep learning
**Answer:** The page focuses on deep learning. This page presents 'Basic definition'. The slide includes: Basic definition; Deep Learning; Deep Neural Network; Demo. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

## 第 41 页：Samuel Velasco/Quanta Magazine

Source ID: `src-a1c091bbcbc2-pdf_page-00041`

![PDF page 41](../assets/pages/page_041.jpg)

### 原文 / Original Text

```text
Samuel Velasco/Quanta Magazine

Basic definition

Deep Learning

Deep Neural Network

Demo

Human Brain

Video

42

Image courtesy: https://medium.com/autonomous-agents/mathematical-foundation-for-activation-functions-in-artificial-neural-networks-a51c9dd7c089
```

### 完整中文翻译

Samuel Velasco/Quanta Magazine
Basic definition
深度学习
Deep Neural Network
Demo
Human Brain
Video
42
Image courtesy: https://medium.com/autonomous-agents/mathematical-foundation-for-activation-functions-in-artificial-neural-networks-a51c9dd7c089
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Samuel Velasco/Quanta Magazine”展开。课件中的关键信息包括：Samuel Velasco/Quanta Magazine；Basic definition；深度学习；Deep Neural Network。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Samuel Velasco/Quanta Magazine'. The slide includes: Samuel Velasco/Quanta Magazine; Basic definition; Deep Learning; Deep Neural Network. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“Samuel Velasco/Quanta Magazine”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 41 页的核心主题是什么？
**答：** 本页围绕“Samuel Velasco/Quanta Magazine”展开。课件中的关键信息包括：Samuel Velasco/Quanta Magazine；Basic definition；深度学习；Deep Neural Network。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 41?
**Answer:** This page presents 'Samuel Velasco/Quanta Magazine'. The slide includes: Samuel Velasco/Quanta Magazine; Basic definition; Deep Learning; Deep Neural Network. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：深度学习 / deep learning
**答：** 用多层神经网络从数据中学习表示和映射，现代视觉任务常用。
**Q2 English:** Explain the concept on this page: deep learning
**Answer:** The page focuses on deep learning. This page presents 'Samuel Velasco/Quanta Magazine'. The slide includes: Samuel Velasco/Quanta Magazine; Basic definition; Deep Learning; Deep Neural Network. The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

## 第 42 页：Basic definition

Source ID: `src-a1c091bbcbc2-pdf_page-00042`

![PDF page 42](../assets/pages/page_042.jpg)

### 原文 / Original Text

```text
Basic definition

43
```

### 完整中文翻译

Basic definition
43
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；43。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Basic definition'. The slide includes: Basic definition; 43. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Basic definition”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 42 页的核心主题是什么？
**答：** 本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；43。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 42?
**Answer:** This page presents 'Basic definition'. The slide includes: Basic definition; 43. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Basic definition'. The slide includes: Basic definition; 43. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 43 页：Basic definition

Source ID: `src-a1c091bbcbc2-pdf_page-00043`

![PDF page 43](../assets/pages/page_043.jpg)

### 原文 / Original Text

```text
Basic definition

• Cascade neurons together

• Output from one layer is the input to the next

• Each layer has its own sets of weights

47
```

### 完整中文翻译

Basic definition
• Cascade neurons together
• Output from one layer is the input to the next
• Each layer has its own sets of weights
47
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；• Cascade neurons together；• Output from one layer is the input to the next；• Each layer has its own sets of weights。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Basic definition'. The slide includes: Basic definition; • Cascade neurons together; • Output from one layer is the input to the next; • Each layer has its own sets of weights. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Basic definition”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 43 页的核心主题是什么？
**答：** 本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；• Cascade neurons together；• Output from one layer is the input to the next；• Each layer has its own sets of weights。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 43?
**Answer:** This page presents 'Basic definition'. The slide includes: Basic definition; • Cascade neurons together; • Output from one layer is the input to the next; • Each layer has its own sets of weights. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Basic definition'. The slide includes: Basic definition; • Cascade neurons together; • Output from one layer is the input to the next; • Each layer has its own sets of weights. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 44 页：Basic definition

Source ID: `src-a1c091bbcbc2-pdf_page-00044`

![PDF page 44](../assets/pages/page_044.jpg)

### 原文 / Original Text

```text
Basic definition

•

Predictions are fed forward through the network
to classify

48
```

### 完整中文翻译

Basic definition
•
Predictions are fed forward through the network
to classify
48
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；•；Predictions are fed forward through the network；to classify。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Basic definition'. The slide includes: Basic definition; •; Predictions are fed forward through the network; to classify. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Basic definition”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 44 页的核心主题是什么？
**答：** 本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；•；Predictions are fed forward through the network；to classify。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 44?
**Answer:** This page presents 'Basic definition'. The slide includes: Basic definition; •; Predictions are fed forward through the network; to classify. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Basic definition'. The slide includes: Basic definition; •; Predictions are fed forward through the network; to classify. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 45 页：Basic definition

Source ID: `src-a1c091bbcbc2-pdf_page-00045`

![PDF page 45](../assets/pages/page_045.jpg)

### 原文 / Original Text

```text
Basic definition

•

Predictions are fed forward through the network
to classify

49
```

### 完整中文翻译

Basic definition
•
Predictions are fed forward through the network
to classify
49
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；•；Predictions are fed forward through the network；to classify。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Basic definition'. The slide includes: Basic definition; •; Predictions are fed forward through the network; to classify. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Basic definition”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 45 页的核心主题是什么？
**答：** 本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；•；Predictions are fed forward through the network；to classify。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 45?
**Answer:** This page presents 'Basic definition'. The slide includes: Basic definition; •; Predictions are fed forward through the network; to classify. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Basic definition'. The slide includes: Basic definition; •; Predictions are fed forward through the network; to classify. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 46 页：Basic definition

Source ID: `src-a1c091bbcbc2-pdf_page-00046`

![PDF page 46](../assets/pages/page_046.jpg)

### 原文 / Original Text

```text
Basic definition

•

Predictions are fed forward through the network
to classify

50
```

### 完整中文翻译

Basic definition
•
Predictions are fed forward through the network
to classify
50
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；•；Predictions are fed forward through the network；to classify。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Basic definition'. The slide includes: Basic definition; •; Predictions are fed forward through the network; to classify. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Basic definition”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 46 页的核心主题是什么？
**答：** 本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；•；Predictions are fed forward through the network；to classify。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 46?
**Answer:** This page presents 'Basic definition'. The slide includes: Basic definition; •; Predictions are fed forward through the network; to classify. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Basic definition'. The slide includes: Basic definition; •; Predictions are fed forward through the network; to classify. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 47 页：Basic definition

Source ID: `src-a1c091bbcbc2-pdf_page-00047`

![PDF page 47](../assets/pages/page_047.jpg)

### 原文 / Original Text

```text
Basic definition

•

Predictions are fed forward through the network
to classify

51
```

### 完整中文翻译

Basic definition
•
Predictions are fed forward through the network
to classify
51
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；•；Predictions are fed forward through the network；to classify。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Basic definition'. The slide includes: Basic definition; •; Predictions are fed forward through the network; to classify. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Basic definition”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 47 页的核心主题是什么？
**答：** 本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；•；Predictions are fed forward through the network；to classify。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 47?
**Answer:** This page presents 'Basic definition'. The slide includes: Basic definition; •; Predictions are fed forward through the network; to classify. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Basic definition'. The slide includes: Basic definition; •; Predictions are fed forward through the network; to classify. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 48 页：Basic definition

Source ID: `src-a1c091bbcbc2-pdf_page-00048`

![PDF page 48](../assets/pages/page_048.jpg)

### 原文 / Original Text

```text
Basic definition

•

Predictions are fed forward through the network
to classify

52
```

### 完整中文翻译

Basic definition
•
Predictions are fed forward through the network
to classify
52
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；•；Predictions are fed forward through the network；to classify。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Basic definition'. The slide includes: Basic definition; •; Predictions are fed forward through the network; to classify. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Basic definition”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 48 页的核心主题是什么？
**答：** 本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；•；Predictions are fed forward through the network；to classify。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 48?
**Answer:** This page presents 'Basic definition'. The slide includes: Basic definition; •; Predictions are fed forward through the network; to classify. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Basic definition'. The slide includes: Basic definition; •; Predictions are fed forward through the network; to classify. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 49 页：Basic definition

Source ID: `src-a1c091bbcbc2-pdf_page-00049`

![PDF page 49](../assets/pages/page_049.jpg)

### 原文 / Original Text

```text
Basic definition

•

Lots of hidden layers

• Depth = power (usually)

!
n
r
a
e
l

o
t
s
t
h
g
i
e
W

!
n
r
a
e
l

o
t
s
t
h
g
i
e
W

!
n
r
a
e
l

o
t
s
t
h
g
i
e
W

!
n
r
a
e
l

o
t
s
t
h
g
i
e
W

Figure from http://neuralnetworksanddeeplearning.com/chap5.html 

53
```

### 完整中文翻译

Basic definition
•
Lots of hidden layers
• Depth = power (usually)
!
n
r
a
e
l
o
t
s
t
h
g
i
e
W
!
n
r
a
e
l
o
t
s
t
h
g
i
e
W
!
n
r
a
e
l
o
t
s
t
h
g
i
e
W
!
n
r
a
e
l
o
t
s
t
h
g
i
e
W
Figure from http://neuralnetworksanddeeplearning.com/chap5.html
53
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；•；Lots of hidden layers；• Depth = power (usually)。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Basic definition'. The slide includes: Basic definition; •; Lots of hidden layers; • Depth = power (usually). The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Basic definition”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 49 页的核心主题是什么？
**答：** 本页围绕“Basic definition”展开。课件中的关键信息包括：Basic definition；•；Lots of hidden layers；• Depth = power (usually)。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 49?
**Answer:** This page presents 'Basic definition'. The slide includes: Basic definition; •; Lots of hidden layers; • Depth = power (usually). The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Basic definition'. The slide includes: Basic definition; •; Lots of hidden layers; • Depth = power (usually). The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 50 页：How to learn features from deep networks

Source ID: `src-a1c091bbcbc2-pdf_page-00050`

![PDF page 50](../assets/pages/page_050.jpg)

### 原文 / Original Text

```text
How to learn features from deep networks

Slide credit:

Deep
Neural
Network

65
```

### 完整中文翻译

How to learn features from deep networks
Slide credit:
Deep
Neural
Network
65
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“How to learn features from deep networks”展开。课件中的关键信息包括：How to learn features from deep networks；Slide credit:；Deep；Neural。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'How to learn features from deep networks'. The slide includes: How to learn features from deep networks; Slide credit:; Deep; Neural. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“How to learn features from deep networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 50 页的核心主题是什么？
**答：** 本页围绕“How to learn features from deep networks”展开。课件中的关键信息包括：How to learn features from deep networks；Slide credit:；Deep；Neural。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 50?
**Answer:** This page presents 'How to learn features from deep networks'. The slide includes: How to learn features from deep networks; Slide credit:; Deep; Neural. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'How to learn features from deep networks'. The slide includes: How to learn features from deep networks; Slide credit:; Deep; Neural. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 51 页：Deep network design

Source ID: `src-a1c091bbcbc2-pdf_page-00051`

![PDF page 51](../assets/pages/page_051.jpg)

### 原文 / Original Text

```text
Deep network design

Data

Convolution

Activation

Deep
Neural
Network

Pooling

Feature
maps

66
```

### 完整中文翻译

Deep network design
Data
Convolution
Activation
Deep
Neural
Network
Pooling
特征
maps
66
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Deep network design”展开。课件中的关键信息包括：Deep network design；Data；Convolution；Activation。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Deep network design'. The slide includes: Deep network design; Data; Convolution; Activation. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Deep network design”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 51 页的核心主题是什么？
**答：** 本页围绕“Deep network design”展开。课件中的关键信息包括：Deep network design；Data；Convolution；Activation。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 51?
**Answer:** This page presents 'Deep network design'. The slide includes: Deep network design; Data; Convolution; Activation. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Deep network design'. The slide includes: Deep network design; Data; Convolution; Activation. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 52 页：Deep network design

Source ID: `src-a1c091bbcbc2-pdf_page-00052`

![PDF page 52](../assets/pages/page_052.jpg)

### 原文 / Original Text

```text
Deep network design

Data

Convolution

Activation

Convolutional
Neural
Network

Pooling

Feature
maps

67
```

### 完整中文翻译

Deep network design
Data
Convolution
Activation
Convolutional
Neural
Network
Pooling
特征
maps
67
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Deep network design”展开。课件中的关键信息包括：Deep network design；Data；Convolution；Activation。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Deep network design'. The slide includes: Deep network design; Data; Convolution; Activation. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Deep network design”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 52 页的核心主题是什么？
**答：** 本页围绕“Deep network design”展开。课件中的关键信息包括：Deep network design；Data；Convolution；Activation。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 52?
**Answer:** This page presents 'Deep network design'. The slide includes: Deep network design; Data; Convolution; Activation. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Deep network design'. The slide includes: Deep network design; Data; Convolution; Activation. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 53 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00053`

![PDF page 53](../assets/pages/page_053.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Feature
maps

Pooling

Activation

Convolution

Data

68
```

### 完整中文翻译

Convolutional neural networks
特征
maps
Pooling
Activation
Convolution
Data
68
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Pooling。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 53 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Pooling。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 53?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 54 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00054`

![PDF page 54](../assets/pages/page_054.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Feature
maps

Pooling

Activation

Convolution

Data

• CNN = a multi-layer neural network 

with

• Local connectivity:

• Neurons in a layer are only 

connected to a small region 
of the layer before it 
• Share weight parameters across 

spatial positions:

• Learning shift-invariant 

filter kernels

69

Image credit: A. Karpathy
```

### 完整中文翻译

Convolutional neural networks
特征
maps
Pooling
Activation
Convolution
Data
• CNN = a multi-layer neural network
with
• Local connectivity:
• Neurons in a layer are only
connected to a small region
of the layer before it
• Share weight parameters across
spatial positions:
• Learning shift-invariant
filter kernels
69
Image credit: A. Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Pooling。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 54 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Pooling。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 54?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 55 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00055`

![PDF page 55](../assets/pages/page_055.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Feature
maps

Convolution

Data

70

Image credit: Ranzato
```

### 完整中文翻译

Convolutional neural networks
特征
maps
Convolution
Data
70
Image credit: Ranzato
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Convolution。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 55 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Convolution。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 55?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 56 页：计算机视觉应用

Source ID: `src-a1c091bbcbc2-pdf_page-00056`

![PDF page 56](../assets/pages/page_056.jpg)

### 原文 / Original Text

```text
Application to computer vision

Classification

Slide credit:

71

Slide credit:
```

### 完整中文翻译

计算机视觉应用
分类
Slide credit:
71
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；分类；Slide credit:；71。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Classification; Slide credit:; 71. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Computer Vision / 计算机视觉**：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。

拓展复习：把“Application to computer vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 56 页的核心主题是什么？
**答：** 本页围绕“Application to computer vision”展开。课件中的关键信息包括：计算机视觉应用；分类；Slide credit:；71。复习时先抓住计算机视觉：让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 56?
**Answer:** This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Classification; Slide credit:; 71. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：计算机视觉 / Computer Vision
**答：** 让机器从图像和视频中感知、理解、识别、定位和生成视觉信息的领域。
**Q2 English:** Explain the concept on this page: Computer Vision
**Answer:** The page focuses on Computer Vision. This page presents 'Application to computer vision'. The slide includes: Application to computer vision; Classification; Slide credit:; 71. The revision focus is Computer Vision; connect its definition, evidence, and use to the examples on the page.

## 第 57 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00057`

![PDF page 57](../assets/pages/page_057.jpg)

### 原文 / Original Text

```text
Slide credit:

72

Slide credit:
```

### 完整中文翻译

Slide credit:
72
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；72；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 72; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 57 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；72；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 57?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 72; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 72; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 58 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00058`

![PDF page 58](../assets/pages/page_058.jpg)

### 原文 / Original Text

```text
Slide credit:

73

Slide credit:
```

### 完整中文翻译

Slide credit:
73
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；73；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 73; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 58 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；73；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 58?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 73; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 73; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 59 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00059`

![PDF page 59](../assets/pages/page_059.jpg)

### 原文 / Original Text

```text
Slide credit:

74

Slide credit:
```

### 完整中文翻译

Slide credit:
74
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；74；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 74; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 59 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；74；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 59?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 74; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 74; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 60 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00060`

![PDF page 60](../assets/pages/page_060.jpg)

### 原文 / Original Text

```text
Slide credit:

75

Slide credit:
```

### 完整中文翻译

Slide credit:
75
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；75；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 75; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 60 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；75；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 60?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 75; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 75; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 61 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00061`

![PDF page 61](../assets/pages/page_061.jpg)

### 原文 / Original Text

```text
Slide credit:

76

Slide credit:
```

### 完整中文翻译

Slide credit:
76
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；76；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 76; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 61 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；76；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 61?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 76; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 76; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 62 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00062`

![PDF page 62](../assets/pages/page_062.jpg)

### 原文 / Original Text

```text
Slide credit:

77

Slide credit:
```

### 完整中文翻译

Slide credit:
77
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；77；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 77; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 62 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；77；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 62?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 77; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 77; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 63 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00063`

![PDF page 63](../assets/pages/page_063.jpg)

### 原文 / Original Text

```text
Slide credit:

78

Slide credit:
```

### 完整中文翻译

Slide credit:
78
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；78；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 78; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 63 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；78；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 63?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 78; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 78; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 64 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00064`

![PDF page 64](../assets/pages/page_064.jpg)

### 原文 / Original Text

```text
Slide credit:

79

Slide credit:
```

### 完整中文翻译

Slide credit:
79
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；79；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 79; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 64 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；79；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 64?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 79; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 79; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 65 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00065`

![PDF page 65](../assets/pages/page_065.jpg)

### 原文 / Original Text

```text
Slide credit:

80

Slide credit:
```

### 完整中文翻译

Slide credit:
80
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；80；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 80; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 65 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；80；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 65?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 80; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 80; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 66 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00066`

![PDF page 66](../assets/pages/page_066.jpg)

### 原文 / Original Text

```text
Slide credit:

81

Slide credit:
```

### 完整中文翻译

Slide credit:
81
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；81；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 81; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 66 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；81；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 66?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 81; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 81; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 67 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00067`

![PDF page 67](../assets/pages/page_067.jpg)

### 原文 / Original Text

```text
Slide credit:

82

Slide credit:
```

### 完整中文翻译

Slide credit:
82
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；82；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 82; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 67 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；82；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 67?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 82; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 82; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 68 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00068`

![PDF page 68](../assets/pages/page_068.jpg)

### 原文 / Original Text

```text
Slide credit:

83

Slide credit:
```

### 完整中文翻译

Slide credit:
83
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；83；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 83; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 68 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；83；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 68?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 83; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 83; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 69 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00069`

![PDF page 69](../assets/pages/page_069.jpg)

### 原文 / Original Text

```text
Slide credit:

84

Slide credit:
```

### 完整中文翻译

Slide credit:
84
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；84；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 84; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 69 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；84；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 69?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 84; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 84; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 70 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00070`

![PDF page 70](../assets/pages/page_070.jpg)

### 原文 / Original Text

```text
Slide credit:

85

Slide credit:
```

### 完整中文翻译

Slide credit:
85
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；85；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 85; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 70 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；85；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 70?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 85; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 85; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 71 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00071`

![PDF page 71](../assets/pages/page_071.jpg)

### 原文 / Original Text

```text
Slide credit:

86

Slide credit:
```

### 完整中文翻译

Slide credit:
86
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；86；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 86; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 71 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；86；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 71?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 86; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 86; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 72 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00072`

![PDF page 72](../assets/pages/page_072.jpg)

### 原文 / Original Text

```text
Slide credit:

87

Slide credit:
```

### 完整中文翻译

Slide credit:
87
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；87；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 87; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 72 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；87；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 72?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 87; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 87; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 73 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00073`

![PDF page 73](../assets/pages/page_073.jpg)

### 原文 / Original Text

```text
Slide credit:

88

Slide credit:
```

### 完整中文翻译

Slide credit:
88
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；88；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 88; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 73 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；88；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 73?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 88; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 88; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 74 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00074`

![PDF page 74](../assets/pages/page_074.jpg)

### 原文 / Original Text

```text
Slide credit:

89

Slide credit:
```

### 完整中文翻译

Slide credit:
89
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；89；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 89; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 74 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；89；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 74?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 89; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 89; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 75 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00075`

![PDF page 75](../assets/pages/page_075.jpg)

### 原文 / Original Text

```text
Slide credit:

90

Slide credit:
```

### 完整中文翻译

Slide credit:
90
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；90；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 90; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 75 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；90；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 75?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 90; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 90; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 76 页：Slide credit:

Source ID: `src-a1c091bbcbc2-pdf_page-00076`

![PDF page 76](../assets/pages/page_076.jpg)

### 原文 / Original Text

```text
Slide credit:

91

Slide credit:
```

### 完整中文翻译

Slide credit:
91
Slide credit:
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；91；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Slide credit:'. The slide includes: Slide credit:; 91; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Slide credit:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 76 页的核心主题是什么？
**答：** 本页围绕“Slide credit:”展开。课件中的关键信息包括：Slide credit:；91；Slide credit:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 76?
**Answer:** This page presents 'Slide credit:'. The slide includes: Slide credit:; 91; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Slide credit:'. The slide includes: Slide credit:; 91; Slide credit:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 77 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00077`

![PDF page 77](../assets/pages/page_077.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Feature
maps

Convolution

Kernel size

Stride

Padding

Data

Dilation

Image credit: https://towardsdatascience.com/types-of-convolutions-in-deep-learning-717013397f4d

92
```

### 完整中文翻译

Convolutional neural networks
特征
maps
Convolution
Kernel size
Stride
Padding
Data
Dilation
Image credit: https://towardsdatascience.com/types-of-convolutions-in-deep-learning-717013397f4d
92
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Convolution。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 77 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Convolution。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 77?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 78 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00078`

![PDF page 78](../assets/pages/page_078.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Feature
maps

Convolution

Kernel size = 3

Stride = 1

Padding = 1

Data

Dilation

Receptive field

93

Image credit: https://towardsdatascience.com/types-of-convolutions-in-deep-learning-717013397f4d
```

### 完整中文翻译

Convolutional neural networks
特征
maps
Convolution
Kernel size = 3
Stride = 1
Padding = 1
Data
Dilation
Receptive field
93
Image credit: https://towardsdatascience.com/types-of-convolutions-in-deep-learning-717013397f4d
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Convolution。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 78 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Convolution。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 78?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 79 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00079`

![PDF page 79](../assets/pages/page_079.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Feature
maps

Convolution

Kernel size = 3

Stride = 2

Padding = 0

Data

Dilation

Image credit: https://towardsdatascience.com/types-of-convolutions-in-deep-learning-717013397f4d

94
```

### 完整中文翻译

Convolutional neural networks
特征
maps
Convolution
Kernel size = 3
Stride = 2
Padding = 0
Data
Dilation
Image credit: https://towardsdatascience.com/types-of-convolutions-in-deep-learning-717013397f4d
94
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Convolution。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 79 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Convolution。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 79?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 80 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00080`

![PDF page 80](../assets/pages/page_080.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Feature
maps

Convolution

Kernel size = 3

Stride = 1

Padding = 0

Data

Dilation = 2

Image credit: https://towardsdatascience.com/types-of-convolutions-in-deep-learning-717013397f4d

95
```

### 完整中文翻译

Convolutional neural networks
特征
maps
Convolution
Kernel size = 3
Stride = 1
Padding = 0
Data
Dilation = 2
Image credit: https://towardsdatascience.com/types-of-convolutions-in-deep-learning-717013397f4d
95
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Convolution。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 80 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Convolution。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 80?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 81 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00081`

![PDF page 81](../assets/pages/page_081.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Feature
maps

Convolution

Kernel size

Input size S x S

Stride

Padding

Sin = 224, padding = 1, kernel size = 3,
stride = 1, dilation = 2

Data

Dilation

96
```

### 完整中文翻译

Convolutional neural networks
特征
maps
Convolution
Kernel size
Input size S x S
Stride
Padding
Sin = 224, padding = 1, kernel size = 3,
stride = 1, dilation = 2
Data
Dilation
96
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Convolution。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 81 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Convolution。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 81?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Convolution. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 82 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00082`

![PDF page 82](../assets/pages/page_082.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Convolution

• Weighted moving sum

.
.
.

Input

Feature Activation Map

97
```

### 完整中文翻译

Convolutional neural networks
Convolution
• Weighted moving sum
.
.
.
Input
特征 Activation Map
97
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Convolution；• Weighted moving sum；.。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Convolution; • Weighted moving sum; .. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 82 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Convolution；• Weighted moving sum；.。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 82?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Convolution; • Weighted moving sum; .. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Convolution; • Weighted moving sum; .. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 83 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00083`

![PDF page 83](../assets/pages/page_083.jpg)

### 原文 / Original Text

```text
Convolutional neural networks
Convolution • Few parameters (filter 

weights)

• Dependencies are local 
• Translation invariance

.
.
.

Input

Feature Activation Map

98
```

### 完整中文翻译

Convolutional neural networks
Convolution • Few parameters (filter
weights)
• Dependencies are local
• Translation invariance
.
.
.
Input
特征 Activation Map
98
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Convolution • Few parameters (filter；weights)；• Dependencies are local。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Convolution • Few parameters (filter; weights); • Dependencies are local. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 83 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Convolution • Few parameters (filter；weights)；• Dependencies are local。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 83?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Convolution • Few parameters (filter; weights); • Dependencies are local. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Convolution • Few parameters (filter; weights); • Dependencies are local. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 84 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00084`

![PDF page 84](../assets/pages/page_084.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Feature
maps

Pooling

Activation

Convolution

Data

.
.
.

Input

Feature Map

99
```

### 完整中文翻译

Convolutional neural networks
特征
maps
Pooling
Activation
Convolution
Data
.
.
.
Input
特征 Map
99
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Pooling。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 84 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Pooling。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 84?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 85 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00085`

![PDF page 85](../assets/pages/page_085.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Feature
maps

Pooling

Activation

Convolution

Data

100
```

### 完整中文翻译

Convolutional neural networks
特征
maps
Pooling
Activation
Convolution
Data
100
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Pooling。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 85 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Pooling。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 85?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 86 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00086`

![PDF page 86](../assets/pages/page_086.jpg)

### 原文 / Original Text

```text
Convolutional neural networks
Non-linear
Activation

•

Per-element (independent)

• Options:
Tanh (Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)
□ Makes learning faster
□
□

Simplifies backpropagation
Avoids saturation issues
à Preferred option

101
```

### 完整中文翻译

Convolutional neural networks
Non-linear
Activation
•
Per-element (independent)
• Options:
Tanh (Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)
□ Makes learning faster
□
□
Simplifies backpropagation
Avoids saturation issues
à Preferred option
101
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Non-linear；Activation；•。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; •. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 86 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Non-linear；Activation；•。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 86?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; •. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; •. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 87 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00087`

![PDF page 87](../assets/pages/page_087.jpg)

### 原文 / Original Text

```text
Convolutional neural networks
Non-linear
Activation

• Options:
Tanh(Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)

□ Dying ReLU problem

102

https://hmkcode.com/ai/backpropagation-step-by-step/
```

### 完整中文翻译

Convolutional neural networks
Non-linear
Activation
• Options:
Tanh(Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)
□ Dying ReLU problem
102
参考链接：https://hmkcode.com/ai/backpropagation-step-by-step/
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Non-linear；Activation；• Options:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; • Options:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 87 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Non-linear；Activation；• Options:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 87?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; • Options:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; • Options:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 88 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00088`

![PDF page 88](../assets/pages/page_088.jpg)

### 原文 / Original Text

```text
Convolutional neural networks
Non-linear
Activation

• Options:
Tanh(Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)
□

Leaky ReLU

103
```

### 完整中文翻译

Convolutional neural networks
Non-linear
Activation
• Options:
Tanh(Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)
□
Leaky ReLU
103
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Non-linear；Activation；• Options:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; • Options:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 88 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Non-linear；Activation；• Options:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 88?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; • Options:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; • Options:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 89 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00089`

![PDF page 89](../assets/pages/page_089.jpg)

### 原文 / Original Text

```text
Convolutional neural networks
Non-linear
Activation

• Options:
Tanh(Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)
□
□

Leaky ReLU
Parametric ReLU

104
```

### 完整中文翻译

Convolutional neural networks
Non-linear
Activation
• Options:
Tanh(Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)
□
□
Leaky ReLU
Parametric ReLU
104
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Non-linear；Activation；• Options:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; • Options:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 89 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Non-linear；Activation；• Options:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 89?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; • Options:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; • Options:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 90 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00090`

![PDF page 90](../assets/pages/page_090.jpg)

### 原文 / Original Text

```text
Convolutional neural networks
Non-linear
Activation

• Options:
Tanh(Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)
□
□
□

Leaky ReLU
Parametric ReLU
Exponential Linear Units (ELUs)

105
```

### 完整中文翻译

Convolutional neural networks
Non-linear
Activation
• Options:
Tanh(Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)
□
□
□
Leaky ReLU
Parametric ReLU
Exponential Linear Units (ELUs)
105
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Non-linear；Activation；• Options:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; • Options:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 90 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Non-linear；Activation；• Options:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 90?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; • Options:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; • Options:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 91 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00091`

![PDF page 91](../assets/pages/page_091.jpg)

### 原文 / Original Text

```text
Convolutional neural networks
Non-linear
Activation

• Options:
Tanh(Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)
□
□
□
□
□ …

Leaky ReLU
Parametric ReLU
Exponential Linear Units (ELUs)
Softmax

https://towardsdatascience.com/softmax-activation-function-explained-a7e1bc3ad60

106
```

### 完整中文翻译

Convolutional neural networks
Non-linear
Activation
• Options:
Tanh(Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)
□
□
□
□
□ …
Leaky ReLU
Parametric ReLU
Exponential Linear Units (ELUs)
Softmax
参考链接：https://towardsdatascience.com/softmax-activation-function-explained-a7e1bc3ad60
106
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Non-linear；Activation；• Options:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; • Options:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 91 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Non-linear；Activation；• Options:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 91?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; • Options:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Non-linear; Activation; • Options:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 92 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00092`

![PDF page 92](../assets/pages/page_092.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Feature
maps

Pooling

Activation

Convolution

Data

Max-pooling

Average-pooling

Max pooling

Max-pooling: a non-linear down-sampling

Provide translation invariance

107
```

### 完整中文翻译

Convolutional neural networks
特征
maps
Pooling
Activation
Convolution
Data
Max-pooling
Average-pooling
Max pooling
Max-pooling: a non-linear down-sampling
Provide translation invariance
107
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Pooling。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 92 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Pooling。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 92?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 93 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00093`

![PDF page 93](../assets/pages/page_093.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Feature
maps

Pooling

Activation

Convolution

Data

108
```

### 完整中文翻译

Convolutional neural networks
特征
maps
Pooling
Activation
Convolution
Data
108
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Pooling。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 93 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Pooling。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 93?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 94 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00094`

![PDF page 94](../assets/pages/page_094.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Feature
maps

Pooling

Activation

Convolution

Data

109
```

### 完整中文翻译

Convolutional neural networks
特征
maps
Pooling
Activation
Convolution
Data
109
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Pooling。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 94 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Pooling。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 94?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 95 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00095`

![PDF page 95](../assets/pages/page_095.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Max-pooling

Average-pooling

Feature
maps

Pooling

Activation

Convolution

Data

110

Image credit: Research gate
```

### 完整中文翻译

Convolutional neural networks
Max-pooling
Average-pooling
特征
maps
Pooling
Activation
Convolution
Data
110
Image credit: Research gate
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Max-pooling；Average-pooling；特征。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Max-pooling; Average-pooling; Feature. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 95 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Max-pooling；Average-pooling；特征。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 95?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Max-pooling; Average-pooling; Feature. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Max-pooling; Average-pooling; Feature. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 96 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00096`

![PDF page 96](../assets/pages/page_096.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Feature
maps

Pooling

Max-pooling

Average-pooling

•

Spatial pooling:

□ Average or max

Activation

□ Non-overlapping / overlapping regions

□ Role of pooling:

Convolution

Data

□

□

Invariance to small transformations

Larger receptive fields (see more of input)

111

Image credit: Research gate
```

### 完整中文翻译

Convolutional neural networks
特征
maps
Pooling
Max-pooling
Average-pooling
•
Spatial pooling:
□ Average or max
Activation
□ Non-overlapping / overlapping regions
□ Role of pooling:
Convolution
Data
□
□
Invariance to small transformations
Larger receptive fields (see more of input)
111
Image credit: Research gate
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Pooling。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 96 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；特征；maps；Pooling。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 96?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Feature; maps; Pooling. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 97 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00097`

![PDF page 97](../assets/pages/page_097.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Previous CNN success

•

•

Handwritten text/digits
□ MNIST (0.17% error [Ciresan et al. 2011])
□ Arabic & Chinese   [Ciresan et al. 2012]

Simpler recognition benchmarks
□ CIFAR-10 (9.3% error [Wan et al. 2013])
□

Traffic sign recognition
□

0.56% error vs 1.16% for humans 
[Ciresan et al. 2011]

112
```

### 完整中文翻译

Convolutional neural networks
Previous CNN success
•
•
Handwritten text/digits
□ MNIST (0.17% error [Ciresan et al. 2011])
□ Arabic & Chinese [Ciresan et al. 2012]
Simpler recognition benchmarks
□ CIFAR-10 (9.3% error [Wan et al. 2013])
□
Traffic sign recognition
□
0.56% error vs 1.16% for humans
[Ciresan et al. 2011]
112
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Previous CNN success；•；•。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Previous CNN success; •; •. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **MAR / 随机缺失**：缺失与其他可观测变量有关，但不直接由缺失值本身决定。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 97 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Previous CNN success；•；•。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 97?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Previous CNN success; •; •. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：随机缺失 / MAR
**答：** 缺失与其他可观测变量有关，但不直接由缺失值本身决定。
**Q2 English:** Explain the concept on this page: MAR
**Answer:** The page focuses on MAR. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Previous CNN success; •; •. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

## 第 98 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00098`

![PDF page 98](../assets/pages/page_098.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

LeNet [LeCun et al. 1998]

•
Stack multiple stages of feature extractors
• Higher stages compute more global, more 

invariant features
Classification layer at the end

•

LeNet-1 from 1993

113

Gradient-based learning applied to document recognition [LeCun, Bottou, Bengio, Haffner 1998]
```

### 完整中文翻译

Convolutional neural networks
LeNet [LeCun et al. 1998]
•
Stack multiple stages of 特征 extractors
• Higher stages compute more global, more
invariant features
分类 layer at the end
•
LeNet-1 from 1993
113
Gradient-based learning applied to document recognition [LeCun, Bottou, Bengio, Haffner 1998]
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；LeNet [LeCun et al. 1998]；•；Stack multiple stages of 特征 extractors。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; LeNet [LeCun et al. 1998]; •; Stack multiple stages of feature extractors. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 98 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；LeNet [LeCun et al. 1998]；•；Stack multiple stages of 特征 extractors。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 98?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; LeNet [LeCun et al. 1998]; •; Stack multiple stages of feature extractors. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：分类 / classification
**答：** 预测离散类别标签，例如图像类别或手写数字。
**Q2 English:** Explain the concept on this page: classification
**Answer:** The page focuses on classification. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; LeNet [LeCun et al. 1998]; •; Stack multiple stages of feature extractors. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

## 第 99 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00099`

![PDF page 99](../assets/pages/page_099.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

ImageNet Challenge 2012

•

•

•

•

~14 million labeled images, 20k classes

Images gathered from Internet

Human labels via Amazon’s Mechanical Turk

ImageNet Challenge: 1.2 million training 
images, 1000 classes

[Deng et al. CVPR 2009] 

114
```

### 完整中文翻译

Convolutional neural networks
ImageNet Challenge 2012
•
•
•
•
~14 million labeled images, 20k classes
Images gathered from Internet
Human labels via Amazon’s Mechanical Turk
ImageNet Challenge: 1.2 million training
images, 1000 classes
[Deng et al. CVPR 2009]
114
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；ImageNet Challenge 2012；•；•。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; ImageNet Challenge 2012; •; •. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 99 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；ImageNet Challenge 2012；•；•。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 99?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; ImageNet Challenge 2012; •; •. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; ImageNet Challenge 2012; •; •. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 100 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00100`

![PDF page 100](../assets/pages/page_100.jpg)

### 原文 / Original Text

```text
Convolutional neural networks
AlexNet •

Bigger model (7 hidden layers, 650,000 units, 60,000,000 params)

Similar framework to LeCun’98 but:
•
• More data (106 vs. 103 images)
• GPU implementation (50x speedup over CPU)
Trained on two GPUs for a week

•

A. Krizhevsky, I. Sutskever, and G. Hinton, ImageNet Classification with Deep Convolutional Neural Networks, NIPS 2012

115
```

### 完整中文翻译

Convolutional neural networks
AlexNet •
Bigger model (7 hidden layers, 650,000 units, 60,000,000 params)
Similar framework to LeCun’98 but:
•
• More data (106 vs. 103 images)
• GPU implementation (50x 加速比 over CPU)
Trained on two GPUs for a week
•
A. Krizhevsky, I. Sutskever, and G. Hinton, ImageNet 分类 with Deep Convolutional Neural Networks, NIPS 2012
115
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；AlexNet •；Bigger model (7 hidden layers, 650,000 units, 60,000,000 params)；Similar framework to LeCun’98 but:。复习时先抓住加速比：单处理器耗时除以 n 个处理器耗时，用来衡量并行化收益。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; AlexNet •; Bigger model (7 hidden layers, 650,000 units, 60,000,000 params); Similar framework to LeCun’98 but:. The revision focus is Speedup; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Speedup / 加速比**：单处理器耗时除以 n 个处理器耗时，用来衡量并行化收益。
- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 100 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；AlexNet •；Bigger model (7 hidden layers, 650,000 units, 60,000,000 params)；Similar framework to LeCun’98 but:。复习时先抓住加速比：单处理器耗时除以 n 个处理器耗时，用来衡量并行化收益。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 100?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; AlexNet •; Bigger model (7 hidden layers, 650,000 units, 60,000,000 params); Similar framework to LeCun’98 but:. The revision focus is Speedup; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：加速比 / Speedup
**答：** 单处理器耗时除以 n 个处理器耗时，用来衡量并行化收益。
**Q2 English:** Explain the concept on this page: Speedup
**Answer:** The page focuses on Speedup. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; AlexNet •; Bigger model (7 hidden layers, 650,000 units, 60,000,000 params); Similar framework to LeCun’98 but:. The revision focus is Speedup; connect its definition, evidence, and use to the examples on the page.

## 第 101 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00101`

![PDF page 101](../assets/pages/page_101.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

AlexNet for image classification

AlexNet

Fixed input size: 224x224x3

“car”

116

A. Krizhevsky, I. Sutskever, and G. Hinton, ImageNet Classification with Deep Convolutional Neural Networks, NIPS 2012
```

### 完整中文翻译

Convolutional neural networks
AlexNet for image 分类
AlexNet
Fixed input size: 224x224x3
“car”
116
A. Krizhevsky, I. Sutskever, and G. Hinton, ImageNet 分类 with Deep Convolutional Neural Networks, NIPS 2012
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；AlexNet for image 分类；AlexNet；Fixed input size: 224x224x3。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; AlexNet for image classification; AlexNet; Fixed input size: 224x224x3. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 101 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；AlexNet for image 分类；AlexNet；Fixed input size: 224x224x3。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 101?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; AlexNet for image classification; AlexNet; Fixed input size: 224x224x3. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：分类 / classification
**答：** 预测离散类别标签，例如图像类别或手写数字。
**Q2 English:** Explain the concept on this page: classification
**Answer:** The page focuses on classification. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; AlexNet for image classification; AlexNet; Fixed input size: 224x224x3. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

## 第 102 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00102`

![PDF page 102](../assets/pages/page_102.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

ImageNet 
Classification 
Challenge

AlexNet

http://image-net.org/challenges/talks/2016/ILSVRC2016_10_09_clsloc.pdf

117
```

### 完整中文翻译

Convolutional neural networks
ImageNet
分类
Challenge
AlexNet
参考链接：http://image-net.org/challenges/talks/2016/ILSVRC2016_10_09_clsloc.pdf
117
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；ImageNet；分类；Challenge。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; ImageNet; Classification; Challenge. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 102 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；ImageNet；分类；Challenge。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 102?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; ImageNet; Classification; Challenge. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：分类 / classification
**答：** 预测离散类别标签，例如图像类别或手写数字。
**Q2 English:** Explain the concept on this page: classification
**Answer:** The page focuses on classification. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; ImageNet; Classification; Challenge. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

## 第 103 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00103`

![PDF page 103](../assets/pages/page_103.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

ImageNet 
Classification 
Challenge

118

Slide credit: Samuel Albanie
```

### 完整中文翻译

Convolutional neural networks
ImageNet
分类
Challenge
118
Slide credit: Samuel Albanie
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；ImageNet；分类；Challenge。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; ImageNet; Classification; Challenge. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 103 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；ImageNet；分类；Challenge。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 103?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; ImageNet; Classification; Challenge. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：分类 / classification
**答：** 预测离散类别标签，例如图像类别或手写数字。
**Q2 English:** Explain the concept on this page: classification
**Answer:** The page focuses on classification. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; ImageNet; Classification; Challenge. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

## 第 104 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00104`

![PDF page 104](../assets/pages/page_104.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

119

Slide credit: Samuel Albanie
```

### 完整中文翻译

Convolutional neural networks
119
Slide credit: Samuel Albanie
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；119；Slide credit: Samuel Albanie。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; 119; Slide credit: Samuel Albanie. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 104 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；119；Slide credit: Samuel Albanie。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 104?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; 119; Slide credit: Samuel Albanie. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; 119; Slide credit: Samuel Albanie. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 105 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00105`

![PDF page 105](../assets/pages/page_105.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

120

Slide credit: Samuel Albanie
```

### 完整中文翻译

Convolutional neural networks
120
Slide credit: Samuel Albanie
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；120；Slide credit: Samuel Albanie。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; 120; Slide credit: Samuel Albanie. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 105 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；120；Slide credit: Samuel Albanie。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 105?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; 120; Slide credit: Samuel Albanie. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; 120; Slide credit: Samuel Albanie. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 106 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00106`

![PDF page 106](../assets/pages/page_106.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

121

Slide credit: Samuel Albanie
```

### 完整中文翻译

Convolutional neural networks
121
Slide credit: Samuel Albanie
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；121；Slide credit: Samuel Albanie。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; 121; Slide credit: Samuel Albanie. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 106 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；121；Slide credit: Samuel Albanie。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 106?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; 121; Slide credit: Samuel Albanie. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; 121; Slide credit: Samuel Albanie. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 107 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00107`

![PDF page 107](../assets/pages/page_107.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Visualise CNNs

What input pattern originally 
caused a given activation in 
the feature maps?

Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]

122
```

### 完整中文翻译

Convolutional neural networks
Visualise CNNs
What input pattern originally
caused a given activation in
the 特征 maps?
Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]
122
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Visualise CNNs；What input pattern originally；caused a given activation in。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Visualise CNNs; What input pattern originally; caused a given activation in. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 107 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Visualise CNNs；What input pattern originally；caused a given activation in。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 107?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Visualise CNNs; What input pattern originally; caused a given activation in. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Visualise CNNs; What input pattern originally; caused a given activation in. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 108 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00108`

![PDF page 108](../assets/pages/page_108.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Visualise CNNs

Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]

123
```

### 完整中文翻译

Convolutional neural networks
Visualise CNNs
Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]
123
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Visualise CNNs；Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]；123。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Visualise CNNs; Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]; 123. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 108 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Visualise CNNs；Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]；123。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 108?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Visualise CNNs; Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]; 123. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Visualise CNNs; Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]; 123. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 109 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00109`

![PDF page 109](../assets/pages/page_109.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Visualise CNNs

Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]

124
```

### 完整中文翻译

Convolutional neural networks
Visualise CNNs
Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]
124
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Visualise CNNs；Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]；124。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Visualise CNNs; Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]; 124. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 109 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Visualise CNNs；Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]；124。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 109?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Visualise CNNs; Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]; 124. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Visualise CNNs; Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]; 124. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 110 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00110`

![PDF page 110](../assets/pages/page_110.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Visualise CNNs

Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]

125
```

### 完整中文翻译

Convolutional neural networks
Visualise CNNs
Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]
125
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Visualise CNNs；Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]；125。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Visualise CNNs; Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]; 125. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 110 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Visualise CNNs；Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]；125。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 110?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Visualise CNNs; Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]; 125. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Visualise CNNs; Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]; 125. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 111 页：Convolutional neural networks

Source ID: `src-a1c091bbcbc2-pdf_page-00111`

![PDF page 111](../assets/pages/page_111.jpg)

### 原文 / Original Text

```text
Convolutional neural networks

Visualise CNNs

Demo

Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]

126
```

### 完整中文翻译

Convolutional neural networks
Visualise CNNs
Demo
Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]
126
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Visualise CNNs；Demo；Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Visualise CNNs; Demo; Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Convolutional neural networks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 111 页的核心主题是什么？
**答：** 本页围绕“Convolutional neural networks”展开。课件中的关键信息包括：Convolutional neural networks；Visualise CNNs；Demo；Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 111?
**Answer:** This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Visualise CNNs; Demo; Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Convolutional neural networks'. The slide includes: Convolutional neural networks; Visualise CNNs; Demo; Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 112 页：CNN training

Source ID: `src-a1c091bbcbc2-pdf_page-00112`

![PDF page 112](../assets/pages/page_112.jpg)

### 原文 / Original Text

```text
CNN training

Image credit: https://towardsdatascience.com/a-visual-explanation-of-gradient-descent-methods-momentum-adagrad-rmsprop-adam-f898b102325c

127
```

### 完整中文翻译

CNN training
Image credit: https://towardsdatascience.com/a-visual-explanation-of-gradient-descent-methods-momentum-adagrad-rmsprop-adam-f898b102325c
127
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training”展开。课件中的关键信息包括：CNN training；Image credit: https://towardsdatascience.com/a-visual-explanation-of-gradient-descent-methods-momentum-adagrad-rmsprop-adam-f898b102325c；127。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training'. The slide includes: CNN training; Image credit: https://towardsdatascience.com/a-visual-explanation-of-gradient-descent-methods-momentum-adagrad-rmsprop-adam-f898b102325c; 127. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 112 页的核心主题是什么？
**答：** 本页围绕“CNN training”展开。课件中的关键信息包括：CNN training；Image credit: https://towardsdatascience.com/a-visual-explanation-of-gradient-descent-methods-momentum-adagrad-rmsprop-adam-f898b102325c；127。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 112?
**Answer:** This page presents 'CNN training'. The slide includes: CNN training; Image credit: https://towardsdatascience.com/a-visual-explanation-of-gradient-descent-methods-momentum-adagrad-rmsprop-adam-f898b102325c; 127. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training'. The slide includes: CNN training; Image credit: https://towardsdatascience.com/a-visual-explanation-of-gradient-descent-methods-momentum-adagrad-rmsprop-adam-f898b102325c; 127. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 113 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00113`

![PDF page 113](../assets/pages/page_113.jpg)

### 原文 / Original Text

```text
CNN training, how?

•

•

•

•

The goal is to iteratively find a set of weights that allow the 
activations/outputs to match the desired output

For this, we will minimize a loss function

The loss function quantifies the agreement between the predicted scores 
and GT labels

First, let’s simplify and assume we have a single layer of weights in the 
network 

128
```

### 完整中文翻译

问题：CNN training, how？
•
•
•
•
The goal is to iteratively find a set of weights that allow the
activations/outputs to match the desired output
For this, we will minimize a loss function
The loss function quantifies the agreement between the predicted scores
and GT labels
First, let’s simplify and assume we have a single layer of weights in the
network
128
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；•；•；•。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; •; •; •. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 113 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；•；•；•。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 113?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; •; •; •. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; •; •; •. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 114 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00114`

![PDF page 114](../assets/pages/page_114.jpg)

### 原文 / Original Text

```text
CNN training, how?

Example dataset: CIFAR-10  
10 labels
50,000 training images  

each image is 32x32x3

10,000 test images.

129

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Example dataset: CIFAR-10
10 labels
50,000 training images
each image is 32x32x3
10,000 test images.
129
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Example dataset: CIFAR-10；10 labels；50,000 training images。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Example dataset: CIFAR-10; 10 labels; 50,000 training images. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 114 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Example dataset: CIFAR-10；10 labels；50,000 training images。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 114?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Example dataset: CIFAR-10; 10 labels; 50,000 training images. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Example dataset: CIFAR-10; 10 labels; 50,000 training images. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 115 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00115`

![PDF page 115](../assets/pages/page_115.jpg)

### 原文 / Original Text

```text
CNN training, how?

Classification scores

image parameters

+ b

f(x,W)

10 numbers,  
indicating class  
scores

[32x32x3]
array of numbers 0...1  
(3072 numbers total)

130

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
分类 scores
image parameters
+ b
f(x,W)
10 numbers,
indicating class
scores
[32x32x3]
array of numbers 0...1
(3072 numbers total)
130
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；分类 scores；image parameters；+ b。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Classification scores; image parameters; + b. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 115 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；分类 scores；image parameters；+ b。复习时先抓住分类：预测离散类别标签，例如图像类别或手写数字。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 115?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Classification scores; image parameters; + b. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：分类 / classification
**答：** 预测离散类别标签，例如图像类别或手写数字。
**Q2 English:** Explain the concept on this page: classification
**Answer:** The page focuses on classification. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Classification scores; image parameters; + b. The revision focus is classification; connect its definition, evidence, and use to the examples on the page.

## 第 116 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00116`

![PDF page 116](../assets/pages/page_116.jpg)

### 原文 / Original Text

```text
CNN training, how?

Linear classifier

3072x1

+b

10x1

10x1

10x3072

10 numbers,  
indicating class  
scores

[32x32x3]
array of numbers 0...1

parameters, or “weights”

131

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Linear classifier
3072x1
+b
10x1
10x1
10x3072
10 numbers,
indicating class
scores
[32x32x3]
array of numbers 0...1
parameters, or “weights”
131
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；3072x1；+b。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; 3072x1; +b. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 116 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；3072x1；+b。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 116?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; 3072x1; +b. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; 3072x1; +b. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 117 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00117`

![PDF page 117](../assets/pages/page_117.jpg)

### 原文 / Original Text

```text
CNN training, how?

Linear classifier

Example with an image with 4 pixels, and 3 classes (cat/dog/ship)

132

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Linear classifier
Example with an image with 4 pixels, and 3 classes (cat/dog/ship)
132
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；Example with an image with 4 pixels, and 3 classes (cat/dog/ship)；132。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Example with an image with 4 pixels, and 3 classes (cat/dog/ship); 132. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 117 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；Example with an image with 4 pixels, and 3 classes (cat/dog/ship)；132。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 117?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Example with an image with 4 pixels, and 3 classes (cat/dog/ship); 132. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Example with an image with 4 pixels, and 3 classes (cat/dog/ship); 132. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 118 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00118`

![PDF page 118](../assets/pages/page_118.jpg)

### 原文 / Original Text

```text
CNN training, how?

Linear classifier

-3.45
-8.87
0.09
2.9
4.48
8.02
3.78
1.06
-0.36
-0.72

-0.51
6.04
5.31
-4.22
-4.19
3.58
4.49
-4.37
-2.09
-2.93

3.42
4.64
2.65
5.1
2.64
5.55
-4.34
-1.5
-4.79
6.14

TODO:

1. Define a loss function  
that quantifies our  
unhappiness with the  
scores across the training  
data.

2. Come up with a way of  
efficiently finding the  
parameters that minimize  
the loss function.  
(optimization)

133

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Linear classifier
-3.45
-8.87
0.09
2.9
4.48
8.02
3.78
1.06
-0.36
-0.72
-0.51
6.04
5.31
-4.22
-4.19
3.58
4.49
-4.37
-2.09
-2.93
3.42
4.64
2.65
5.1
2.64
5.55
-4.34
-1.5
-4.79
6.14
TODO:
1. Define a loss function
that quantifies our
unhappiness with the
scores across the training
data.
2. Come up with a way of
efficiently finding the
parameters that minimize
the loss function.
(optimization)
133
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；-3.45；-8.87。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; -3.45; -8.87. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 118 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；-3.45；-8.87。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 118?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; -3.45; -8.87. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; -3.45; -8.87. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 119 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00119`

![PDF page 119](../assets/pages/page_119.jpg)

### 原文 / Original Text

```text
CNN training, how?

Linear classifier

Suppose: 3 training examples, 3 classes.  
With some W the scores

are:

cat

car

frog

3.2
5.1
-1.7

1.3
4.9
2.0

2.2
2.5
-3.1

134

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Linear classifier
Suppose: 3 training examples, 3 classes.
With some W the scores
are:
cat
car
frog
3.2
5.1
-1.7
1.3
4.9
2.0
2.2
2.5
-3.1
134
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；Suppose: 3 training examples, 3 classes.；With some W the scores。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 119 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；Suppose: 3 training examples, 3 classes.；With some W the scores。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 119?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 120 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00120`

![PDF page 120](../assets/pages/page_120.jpg)

### 原文 / Original Text

```text
CNN training, how?

Linear classifier

Suppose: 3 training examples, 3 classes.  
With some W the scores

are:

cat

car

frog

3.2
5.1
-1.7

1.3
4.9
2.0

2.2
2.5
-3.1

Hinge loss:

Given an example
where  
where

is the image and
is the (integer) label,

and using the shorthand for the  
scores vector:

the loss has the form:

Want: syi >= sj + 1
i.e. sj – syi + 1 <= 0

If true, loss is 0
If false, loss is magnitude of violation

135

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Linear classifier
Suppose: 3 training examples, 3 classes.
With some W the scores
are:
cat
car
frog
3.2
5.1
-1.7
1.3
4.9
2.0
2.2
2.5
-3.1
Hinge loss:
Given an example
where
where
is the image and
is the (integer) label,
and using the shorthand for the
scores vector:
the loss has the form:
Want: syi >= sj + 1
i.e. sj – syi + 1 <= 0
If true, loss is 0
If false, loss is magnitude of violation
135
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；Suppose: 3 training examples, 3 classes.；With some W the scores。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 120 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；Suppose: 3 training examples, 3 classes.；With some W the scores。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 120?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 121 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00121`

![PDF page 121](../assets/pages/page_121.jpg)

### 原文 / Original Text

```text
CNN training, how?

Linear classifier

Suppose: 3 training examples, 3 classes.  
With some W the scores

are:

cat

car

frog

3.2
5.1
-1.7

1.3
4.9
2.0

2.2
2.5
-3.1

Hinge loss:

Given an example
where  
where

is the image and
is the (integer) label,

and using the shorthand for the  
scores vector:

the loss has the form:

Want: syi >= sj + 1
i.e. sj – syi + 1 <= 0

If true, loss is 0
If false, loss is magnitude of violation

136

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Linear classifier
Suppose: 3 training examples, 3 classes.
With some W the scores
are:
cat
car
frog
3.2
5.1
-1.7
1.3
4.9
2.0
2.2
2.5
-3.1
Hinge loss:
Given an example
where
where
is the image and
is the (integer) label,
and using the shorthand for the
scores vector:
the loss has the form:
Want: syi >= sj + 1
i.e. sj – syi + 1 <= 0
If true, loss is 0
If false, loss is magnitude of violation
136
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；Suppose: 3 training examples, 3 classes.；With some W the scores。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 121 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；Suppose: 3 training examples, 3 classes.；With some W the scores。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 121?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 122 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00122`

![PDF page 122](../assets/pages/page_122.jpg)

### 原文 / Original Text

```text
CNN training, how?

Linear classifier

Suppose: 3 training examples, 3 classes.  
With some W the scores

are:

cat

car  

frog

Loss:

3.2
5.1
-1.7
2.9

1.3
4.9
2.0

2.2
2.5
-3.1

Hinge loss:

Given an example
where  
where

is the image and
is the (integer) label,

and using the shorthand for the  
scores vector:

the loss has the form:

= max(0, 5.1 - 3.2 + 1)

+max(0, -1.7 - 3.2 + 1)
= max(0, 2.9) + max(0, -3.9)
= 2.9 + 0
= 2.9

137

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Linear classifier
Suppose: 3 training examples, 3 classes.
With some W the scores
are:
cat
car
frog
Loss:
3.2
5.1
-1.7
2.9
1.3
4.9
2.0
2.2
2.5
-3.1
Hinge loss:
Given an example
where
where
is the image and
is the (integer) label,
and using the shorthand for the
scores vector:
the loss has the form:
= max(0, 5.1 - 3.2 + 1)
+max(0, -1.7 - 3.2 + 1)
= max(0, 2.9) + max(0, -3.9)
= 2.9 + 0
= 2.9
137
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；Suppose: 3 training examples, 3 classes.；With some W the scores。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 122 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；Suppose: 3 training examples, 3 classes.；With some W the scores。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 122?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 123 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00123`

![PDF page 123](../assets/pages/page_123.jpg)

### 原文 / Original Text

```text
CNN training, how?

Linear classifier

Suppose: 3 training examples, 3 classes.  
With some W the scores

are:

cat

car

frog

Loss:

3.2

5.1
-1.7
2.9

1.3
4.9
2.0
0

2.2
2.5
-3.1

Hinge loss:

Given an example
where  
where

is the image and
is the (integer) label,

and using the shorthand for the  
scores vector:

the loss has the form:

= max(0, 1.3 - 4.9 + 1)

+max(0, 2.0 - 4.9 + 1)

= max(0, -2.6) + max(0, -1.9)
= 0 + 0
= 0

138

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Linear classifier
Suppose: 3 training examples, 3 classes.
With some W the scores
are:
cat
car
frog
Loss:
3.2
5.1
-1.7
2.9
1.3
4.9
2.0
0
2.2
2.5
-3.1
Hinge loss:
Given an example
where
where
is the image and
is the (integer) label,
and using the shorthand for the
scores vector:
the loss has the form:
= max(0, 1.3 - 4.9 + 1)
+max(0, 2.0 - 4.9 + 1)
= max(0, -2.6) + max(0, -1.9)
= 0 + 0
= 0
138
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；Suppose: 3 training examples, 3 classes.；With some W the scores。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 123 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；Suppose: 3 training examples, 3 classes.；With some W the scores。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 123?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 124 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00124`

![PDF page 124](../assets/pages/page_124.jpg)

### 原文 / Original Text

```text
CNN training, how?

Linear classifier

Suppose: 3 training examples, 3 classes.  
With some W the scores

are:

cat

car  

frog

Loss:

3.2
5.1
-1.7
2.9

1.3
4.9
2.0
0

2.2
2.5
-3.1
12.9

Hinge loss:

Given an example
where  
where

is the image and
is the (integer) label,

and using the shorthand for the  
scores vector:

the loss has the form:

= max(0, 2.2 - (-3.1) + 1)

+max(0, 2.5 - (-3.1) + 1)

= max(0, 5.3 + 1) 

+ max(0, 5.6 + 1)

= 6.3 + 6.6 = 12.9

139

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Linear classifier
Suppose: 3 training examples, 3 classes.
With some W the scores
are:
cat
car
frog
Loss:
3.2
5.1
-1.7
2.9
1.3
4.9
2.0
0
2.2
2.5
-3.1
12.9
Hinge loss:
Given an example
where
where
is the image and
is the (integer) label,
and using the shorthand for the
scores vector:
the loss has the form:
= max(0, 2.2 - (-3.1) + 1)
+max(0, 2.5 - (-3.1) + 1)
= max(0, 5.3 + 1)
+ max(0, 5.6 + 1)
= 6.3 + 6.6 = 12.9
139
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；Suppose: 3 training examples, 3 classes.；With some W the scores。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 124 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；Suppose: 3 training examples, 3 classes.；With some W the scores。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 124?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 125 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00125`

![PDF page 125](../assets/pages/page_125.jpg)

### 原文 / Original Text

```text
CNN training, how?

Linear classifier

Suppose: 3 training examples, 3 classes.  
With some W the scores

are:

cat

car  

frog

Loss:

3.2
5.1
-1.7
2.9

1.3
4.9
2.0
0

2.2
2.5
-3.1
12.9

Hinge loss:

Given an example
where  
where

is the image and
is the (integer) label,

and using the shorthand for the  
scores vector:

the loss has the form:

and the full training loss is the mean  
over all examples in the training data:

L = (2.9 + 0 + 12.9)/3

= 15.8 / 3 = 5.3

140

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Linear classifier
Suppose: 3 training examples, 3 classes.
With some W the scores
are:
cat
car
frog
Loss:
3.2
5.1
-1.7
2.9
1.3
4.9
2.0
0
2.2
2.5
-3.1
12.9
Hinge loss:
Given an example
where
where
is the image and
is the (integer) label,
and using the shorthand for the
scores vector:
the loss has the form:
and the full training loss is the mean
over all examples in the training data:
L = (2.9 + 0 + 12.9)/3
= 15.8 / 3 = 5.3
140
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；Suppose: 3 training examples, 3 classes.；With some W the scores。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 125 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier；Suppose: 3 training examples, 3 classes.；With some W the scores。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 125?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier; Suppose: 3 training examples, 3 classes.; With some W the scores. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 126 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00126`

![PDF page 126](../assets/pages/page_126.jpg)

### 原文 / Original Text

```text
CNN training, how?

Linear classifier: Hinge loss

Weight Regularization

λ = regularization strength  
(hyperparameter)

In common use:  
L2 regularization  
L1 regularization
Dropout (will see later)

141

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Linear classifier: Hinge loss
Weight Regularization
λ = regularization strength
(hyperparameter)
In common use:
L2 regularization
L1 regularization
Dropout (will see later)
141
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier: Hinge loss；Weight Regularization；λ = regularization strength。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier: Hinge loss; Weight Regularization; λ = regularization strength. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 126 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Linear classifier: Hinge loss；Weight Regularization；λ = regularization strength。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 126?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier: Hinge loss; Weight Regularization; λ = regularization strength. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Linear classifier: Hinge loss; Weight Regularization; λ = regularization strength. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 127 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00127`

![PDF page 127](../assets/pages/page_127.jpg)

### 原文 / Original Text

```text
CNN training, how?

Another loss: Softmax
(cross-entropy)

scores = unnormalized log probabilities of the classes.

where

Want to maximize the log likelihood, or (for a loss function)  
to minimize the negative log likelihood of the correct class:

cat

car

frog

3.2
5.1
-1.7

142

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Another loss: Softmax
(cross-entropy)
scores = unnormalized log probabilities of the classes.
where
Want to maximize the log likelihood, or (for a loss function)
to minimize the negative log likelihood of the correct class:
cat
car
frog
3.2
5.1
-1.7
142
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Another loss: Softmax；(cross-entropy)；scores = unnormalized log probabilities of the classes.。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Another loss: Softmax; (cross-entropy); scores = unnormalized log probabilities of the classes.. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 127 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Another loss: Softmax；(cross-entropy)；scores = unnormalized log probabilities of the classes.。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 127?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Another loss: Softmax; (cross-entropy); scores = unnormalized log probabilities of the classes.. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Another loss: Softmax; (cross-entropy); scores = unnormalized log probabilities of the classes.. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 128 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00128`

![PDF page 128](../assets/pages/page_128.jpg)

### 原文 / Original Text

```text
CNN training, how?

Another loss: Softmax
(cross-entropy)

unnormalized probabilities

cat

car

frog

3.2
5.1
-1.7

exp

24.5
164.0
0.18

normalize

0.13
0.87
0.00

unnormalized log probabilities

probabilities

L_i = -log(0.13)
= 0.89

143

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Another loss: Softmax
(cross-entropy)
unnormalized probabilities
cat
car
frog
3.2
5.1
-1.7
exp
24.5
164.0
0.18
normalize
0.13
0.87
0.00
unnormalized log probabilities
probabilities
L_i = -log(0.13)
= 0.89
143
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Another loss: Softmax；(cross-entropy)；unnormalized probabilities。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Another loss: Softmax; (cross-entropy); unnormalized probabilities. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 128 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Another loss: Softmax；(cross-entropy)；unnormalized probabilities。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 128?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Another loss: Softmax; (cross-entropy); unnormalized probabilities. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Another loss: Softmax; (cross-entropy); unnormalized probabilities. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 129 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00129`

![PDF page 129](../assets/pages/page_129.jpg)

### 原文 / Original Text

```text
CNN training, how?

How to minimize the loss function?

Random search?

144

Photograph credit: Stewart Smith/Alamy, The Guardian
```

### 完整中文翻译

问题：CNN training, how？
问题：How to minimize the loss function？
问题：Random search？
144
Photograph credit: Stewart Smith/Alamy, The Guardian
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；问题：How to minimize the loss function？；问题：Random search？；144。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; How to minimize the loss function?; Random search?; 144. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 129 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；问题：How to minimize the loss function？；问题：Random search？；144。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 129?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; How to minimize the loss function?; Random search?; 144. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; How to minimize the loss function?; Random search?; 144. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 130 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00130`

![PDF page 130](../assets/pages/page_130.jpg)

### 原文 / Original Text

```text
CNN training, how?

How to minimize the loss function?

Random search?

Follow the slope!

145

Photograph credit: Stewart Smith/Alamy, The Guardian
```

### 完整中文翻译

问题：CNN training, how？
问题：How to minimize the loss function？
问题：Random search？
Follow the slope!
145
Photograph credit: Stewart Smith/Alamy, The Guardian
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；问题：How to minimize the loss function？；问题：Random search？；Follow the slope!。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; How to minimize the loss function?; Random search?; Follow the slope!. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 130 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；问题：How to minimize the loss function？；问题：Random search？；Follow the slope!。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 130?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; How to minimize the loss function?; Random search?; Follow the slope!. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; How to minimize the loss function?; Random search?; Follow the slope!. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 131 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00131`

![PDF page 131](../assets/pages/page_131.jpg)

### 原文 / Original Text

```text
CNN training, how?

How to minimize the loss function?

In 1-dimension, the derivative of a function:

In multiple dimensions, the gradient is the vector of (partial derivatives).

146

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
问题：How to minimize the loss function？
In 1-dimension, the derivative of a function:
In multiple dimensions, the gradient is the vector of (partial derivatives).
146
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；问题：How to minimize the loss function？；In 1-dimension, the derivative of a function:；In multiple dimensions, the gradient is the vector of (partial derivatives).。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; How to minimize the loss function?; In 1-dimension, the derivative of a function:; In multiple dimensions, the gradient is the vector of (partial derivatives).. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 131 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；问题：How to minimize the loss function？；In 1-dimension, the derivative of a function:；In multiple dimensions, the gradient is the vector of (partial derivatives).。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 131?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; How to minimize the loss function?; In 1-dimension, the derivative of a function:; In multiple dimensions, the gradient is the vector of (partial derivatives).. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; How to minimize the loss function?; In 1-dimension, the derivative of a function:; In multiple dimensions, the gradient is the vector of (partial derivatives).. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 132 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00132`

![PDF page 132](../assets/pages/page_132.jpg)

### 原文 / Original Text

```text
CNN training, how?

current W:

gradient dW:

[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347

[?,
?,
?,
?,
?,
?,
?,
?,
?,…]

147

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
current W:
gradient dW:
[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347
[?,
?,
?,
?,
?,
?,
?,
?,
?,…]
147
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；current W:；gradient dW:；[0.34,。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; gradient dW:; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 132 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；current W:；gradient dW:；[0.34,。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 132?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; gradient dW:; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; gradient dW:; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 133 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00133`

![PDF page 133](../assets/pages/page_133.jpg)

### 原文 / Original Text

```text
CNN training, how?

current W:

W + h (first dim):

[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347

[0.34 + 0.0001,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25322

gradient dW:

[?,
?,
?,
?,
?,
?,
?,
?,
?,…]

148

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
current W:
W + h (first dim):
[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347
[0.34 + 0.0001,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25322
gradient dW:
[?,
?,
?,
?,
?,
?,
?,
?,
?,…]
148
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；current W:；W + h (first dim):；[0.34,。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; W + h (first dim):; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 133 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；current W:；W + h (first dim):；[0.34,。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 133?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; W + h (first dim):; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; W + h (first dim):; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 134 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00134`

![PDF page 134](../assets/pages/page_134.jpg)

### 原文 / Original Text

```text
CNN training, how?

current W:

W + h (first dim):

[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347

[0.34 + 0.0001,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25322

gradient dW:

(1.25322 - 1.25347)/0.0001
= -2.5

[-2.5,
[
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,…]

149

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
current W:
W + h (first dim):
[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347
[0.34 + 0.0001,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25322
gradient dW:
(1.25322 - 1.25347)/0.0001
= -2.5
[-2.5,
[
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,…]
149
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；current W:；W + h (first dim):；[0.34,。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; W + h (first dim):; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 134 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；current W:；W + h (first dim):；[0.34,。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 134?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; W + h (first dim):; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; W + h (first dim):; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 135 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00135`

![PDF page 135](../assets/pages/page_135.jpg)

### 原文 / Original Text

```text
CNN training, how?

current W:

W + h (second dim):

[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347

[0.34,
-1.11 + 0.0001,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25353

gradient dW:

[-2.5,
[
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,…]

150

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
current W:
W + h (second dim):
[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347
[0.34,
-1.11 + 0.0001,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25353
gradient dW:
[-2.5,
[
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,…]
150
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；current W:；W + h (second dim):；[0.34,。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; W + h (second dim):; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 135 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；current W:；W + h (second dim):；[0.34,。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 135?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; W + h (second dim):; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; W + h (second dim):; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 136 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00136`

![PDF page 136](../assets/pages/page_136.jpg)

### 原文 / Original Text

```text
CNN training, how?

current W:

W + h (second dim):

[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347

[0.34,
-1.11 + 0.0001,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25353

gradient dW:

(1.25353 - 1.25347)/0.0001
= 0.6

[-2.5,
[
0.6,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,…]

151

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
current W:
W + h (second dim):
[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347
[0.34,
-1.11 + 0.0001,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25353
gradient dW:
(1.25353 - 1.25347)/0.0001
= 0.6
[-2.5,
[
0.6,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,…]
151
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；current W:；W + h (second dim):；[0.34,。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; W + h (second dim):; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 136 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；current W:；W + h (second dim):；[0.34,。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 136?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; W + h (second dim):; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; W + h (second dim):; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 137 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00137`

![PDF page 137](../assets/pages/page_137.jpg)

### 原文 / Original Text

```text
CNN training, how?

current W:

W + h (third dim):

[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347

[0.34,
-1.11,
0.78 + 0.0001,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347

gradient dW:

[-2.5,
[
0.6,
?,
?,
?,
?,
?,
?,
?,
?,…]

152

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
current W:
W + h (third dim):
[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347
[0.34,
-1.11,
0.78 + 0.0001,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347
gradient dW:
[-2.5,
[
0.6,
?,
?,
?,
?,
?,
?,
?,
?,…]
152
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；current W:；W + h (third dim):；[0.34,。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; W + h (third dim):; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 137 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；current W:；W + h (third dim):；[0.34,。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 137?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; W + h (third dim):; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; current W:; W + h (third dim):; [0.34,. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 138 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00138`

![PDF page 138](../assets/pages/page_138.jpg)

### 原文 / Original Text

```text
CNN training, how?

153

Credit: Justin Johnson
```

### 完整中文翻译

问题：CNN training, how？
153
Credit: Justin Johnson
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；153；Credit: Justin Johnson。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; 153; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 138 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；153；Credit: Justin Johnson。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 138?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; 153; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; 153; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 139 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00139`

![PDF page 139](../assets/pages/page_139.jpg)

### 原文 / Original Text

```text
CNN training, how?

154

Credit: Justin Johnson
```

### 完整中文翻译

问题：CNN training, how？
154
Credit: Justin Johnson
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；154；Credit: Justin Johnson。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; 154; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 139 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；154；Credit: Justin Johnson。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 139?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; 154; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; 154; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 140 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00140`

![PDF page 140](../assets/pages/page_140.jpg)

### 原文 / Original Text

```text
CNN training, how?

155

Credit: Justin Johnson
```

### 完整中文翻译

问题：CNN training, how？
155
Credit: Justin Johnson
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；155；Credit: Justin Johnson。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; 155; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 140 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；155；Credit: Justin Johnson。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 140?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; 155; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; 155; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 141 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00141`

![PDF page 141](../assets/pages/page_141.jpg)

### 原文 / Original Text

```text
CNN training, how?

Loss gradients

•

•

Denoted as (diff notations):

i.e. how the loss changes as a function of the weights

• We want to change the weights in such a way that makes the loss 

decrease as fast as possible  

156
```

### 完整中文翻译

问题：CNN training, how？
Loss gradients
•
•
Denoted as (diff notations):
i.e. how the loss changes as a function of the weights
• We want to change the weights in such a way that makes the loss
decrease as fast as possible
156
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Loss gradients；•；•。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Loss gradients; •; •. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 141 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Loss gradients；•；•。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 141?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Loss gradients; •; •. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Loss gradients; •; •. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 142 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00142`

![PDF page 142](../assets/pages/page_142.jpg)

### 原文 / Original Text

```text
CNN training, how?

Gradient descent

• We’ll update weights iteratively

• Move in direction opposite to gradient:

W_2

Time

L

Learning rate

loss function landscape

negative gradient direction

original W

W_1

157

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Gradient descent
• We’ll update weights iteratively
• Move in direction opposite to gradient:
W_2
Time
L
Learning rate
loss function landscape
negative gradient direction
original W
W_1
157
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Gradient descent；• We’ll update weights iteratively；• Move in direction opposite to gradient:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Gradient descent; • We’ll update weights iteratively; • Move in direction opposite to gradient:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 142 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Gradient descent；• We’ll update weights iteratively；• Move in direction opposite to gradient:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 142?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Gradient descent; • We’ll update weights iteratively; • Move in direction opposite to gradient:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Gradient descent; • We’ll update weights iteratively; • Move in direction opposite to gradient:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 143 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00143`

![PDF page 143](../assets/pages/page_143.jpg)

### 原文 / Original Text

```text
CNN training, how?

Gradient descent

•

•

•

•

Iteratively subtract the gradient with respect to the model 
parameters (w)

i.e. we’re moving in a direction opposite to the gradient of the loss

i.e. we’re moving towards smaller loss

The procedure of repeatedly evaluating the gradient 
and then performing a parameter update is called 
Gradient Descent

158
```

### 完整中文翻译

问题：CNN training, how？
Gradient descent
•
•
•
•
Iteratively subtract the gradient with respect to the model
parameters (w)
i.e. we’re moving in a direction opposite to the gradient of the loss
i.e. we’re moving towards smaller loss
The procedure of repeatedly evaluating the gradient
and then performing a parameter update is called
Gradient Descent
158
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Gradient descent；•；•。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Gradient descent; •; •. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 143 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Gradient descent；•；•。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 143?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Gradient descent; •; •. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Gradient descent; •; •. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 144 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00144`

![PDF page 144](../assets/pages/page_144.jpg)

### 原文 / Original Text

```text
CNN training, how?

Stochastic Gradient Descent
(SGD)

Gradient descent

Momentum

AdaGrad

RMSProp

Adam

https://towardsdatascience.com/a-visual-explanation-of-gradient-descent-methods-momentum-adagrad-rmsprop-adam-f898b102325c

160
```

### 完整中文翻译

问题：CNN training, how？
Stochastic Gradient Descent
(SGD)
Gradient descent
Momentum
AdaGrad
RMSProp
Adam
参考链接：https://towardsdatascience.com/a-visual-explanation-of-gradient-descent-methods-momentum-adagrad-rmsprop-adam-f898b102325c
160
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Stochastic Gradient Descent；(SGD)；Gradient descent。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Stochastic Gradient Descent; (SGD); Gradient descent. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 144 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Stochastic Gradient Descent；(SGD)；Gradient descent。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 144?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Stochastic Gradient Descent; (SGD); Gradient descent. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Stochastic Gradient Descent; (SGD); Gradient descent. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 145 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00145`

![PDF page 145](../assets/pages/page_145.jpg)

### 原文 / Original Text

```text
CNN training, how?

Stochastic Gradient Descent
(SGD)

https://www.kaggle.com/code/awsaf49/pytorch-sartorius-unet-strikes-back-train/notebook

161
```

### 完整中文翻译

问题：CNN training, how？
Stochastic Gradient Descent
(SGD)
参考链接：https://www.kaggle.com/code/awsaf49/pytorch-sartorius-unet-strikes-back-train/notebook
161
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Stochastic Gradient Descent；(SGD)；参考链接：https://www.kaggle.com/code/awsaf49/pytorch-sartorius-unet-strikes-back-train/notebook。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Stochastic Gradient Descent; (SGD); https://www.kaggle.com/code/awsaf49/pytorch-sartorius-unet-strikes-back-train/notebook. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 145 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Stochastic Gradient Descent；(SGD)；参考链接：https://www.kaggle.com/code/awsaf49/pytorch-sartorius-unet-strikes-back-train/notebook。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 145?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Stochastic Gradient Descent; (SGD); https://www.kaggle.com/code/awsaf49/pytorch-sartorius-unet-strikes-back-train/notebook. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Stochastic Gradient Descent; (SGD); https://www.kaggle.com/code/awsaf49/pytorch-sartorius-unet-strikes-back-train/notebook. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 146 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00146`

![PDF page 146](../assets/pages/page_146.jpg)

### 原文 / Original Text

```text
CNN training, how?

Learning rate selection

The effects of step size (or “learning rate”)

162

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Learning rate selection
The effects of step size (or “learning rate”)
162
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Learning rate selection；The effects of step size (or “learning rate”)；162。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Learning rate selection; The effects of step size (or “learning rate”); 162. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 146 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Learning rate selection；The effects of step size (or “learning rate”)；162。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 146?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Learning rate selection; The effects of step size (or “learning rate”); 162. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Learning rate selection; The effects of step size (or “learning rate”); 162. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 147 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00147`

![PDF page 147](../assets/pages/page_147.jpg)

### 原文 / Original Text

```text
CNN training, how?

GD in multi-layer nets

• We’ll update weights

• Move in direction opposite to gradient:

•

•

How to update the weights at all layers?

Answer: backpropagation of loss from higher layers to lower layers

163
```

### 完整中文翻译

问题：CNN training, how？
GD in multi-layer nets
• We’ll update weights
• Move in direction opposite to gradient:
•
•
问题：How to update the weights at all layers？
Answer: backpropagation of loss from higher layers to lower layers
163
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；GD in multi-layer nets；• We’ll update weights；• Move in direction opposite to gradient:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; GD in multi-layer nets; • We’ll update weights; • Move in direction opposite to gradient:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 147 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；GD in multi-layer nets；• We’ll update weights；• Move in direction opposite to gradient:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 147?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; GD in multi-layer nets; • We’ll update weights; • Move in direction opposite to gradient:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; GD in multi-layer nets; • We’ll update weights; • Move in direction opposite to gradient:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 148 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00148`

![PDF page 148](../assets/pages/page_148.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

First calculate error of output units and use this 

to change the top layer of weights.

Update weights into j

output

hidden

input

w(2)

w(1)

k

j

i

164

Adapted from Ray Mooney
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
First calculate error of output units and use this
to change the top layer of weights.
Update weights into j
output
hidden
input
w(2)
w(1)
k
j
i
164
Adapted from Ray Mooney
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；First calculate error of output units and use this；to change the top layer of weights.。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; First calculate error of output units and use this; to change the top layer of weights.. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 148 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；First calculate error of output units and use this；to change the top layer of weights.。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 148?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; First calculate error of output units and use this; to change the top layer of weights.. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; First calculate error of output units and use this; to change the top layer of weights.. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 149 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00149`

![PDF page 149](../assets/pages/page_149.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

Next calculate error for hidden units based on 

errors on the output units it feeds into.

output

hidden

input

k

j

i

165

Adapted from Ray Mooney
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
Next calculate error for hidden units based on
errors on the output units it feeds into.
output
hidden
input
k
j
i
165
Adapted from Ray Mooney
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；Next calculate error for hidden units based on；errors on the output units it feeds into.。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; Next calculate error for hidden units based on; errors on the output units it feeds into.. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 149 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；Next calculate error for hidden units based on；errors on the output units it feeds into.。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 149?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; Next calculate error for hidden units based on; errors on the output units it feeds into.. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; Next calculate error for hidden units based on; errors on the output units it feeds into.. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 150 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00150`

![PDF page 150](../assets/pages/page_150.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

Finally update bottom layer of weights based on 

errors calculated for hidden units.

output

Update weights into i

hidden

input

k

j

i

166

Adapted from Ray Mooney
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
Finally update bottom layer of weights based on
errors calculated for hidden units.
output
Update weights into i
hidden
input
k
j
i
166
Adapted from Ray Mooney
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；Finally update bottom layer of weights based on；errors calculated for hidden units.。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; Finally update bottom layer of weights based on; errors calculated for hidden units.. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 150 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；Finally update bottom layer of weights based on；errors calculated for hidden units.。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 150?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; Finally update bottom layer of weights based on; errors calculated for hidden units.. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; Finally update bottom layer of weights based on; errors calculated for hidden units.. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 151 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00151`

![PDF page 151](../assets/pages/page_151.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

•

Easier if we use computational graphs, especially when we have 
complicated functions typical in deep neural networks 

167

Figure from Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
•
Easier if we use computational graphs, especially when we have
complicated functions typical in deep neural networks
167
Figure from Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；•；Easier if we use computational graphs, especially when we have。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; •; Easier if we use computational graphs, especially when we have. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 151 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；•；Easier if we use computational graphs, especially when we have。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 151?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; •; Easier if we use computational graphs, especially when we have. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; •; Easier if we use computational graphs, especially when we have. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 152 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00152`

![PDF page 152](../assets/pages/page_152.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

168

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
e.g. x = -2, y = 5, z = -4
168
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；168。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; 168. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 152 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；168。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 152?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; 168. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; 168. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 153 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00153`

![PDF page 153](../assets/pages/page_153.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

169

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
e.g. x = -2, y = 5, z = -4
Want:
169
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 153 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 153?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 154 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00154`

![PDF page 154](../assets/pages/page_154.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

170

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
e.g. x = -2, y = 5, z = -4
Want:
170
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 154 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 154?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 155 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00155`

![PDF page 155](../assets/pages/page_155.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

171

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
e.g. x = -2, y = 5, z = -4
Want:
171
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 155 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 155?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 156 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00156`

![PDF page 156](../assets/pages/page_156.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

172

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
e.g. x = -2, y = 5, z = -4
Want:
172
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 156 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 156?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 157 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00157`

![PDF page 157](../assets/pages/page_157.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

173

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
e.g. x = -2, y = 5, z = -4
Want:
173
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 157 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 157?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 158 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00158`

![PDF page 158](../assets/pages/page_158.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

174

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
e.g. x = -2, y = 5, z = -4
Want:
174
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 158 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 158?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 159 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00159`

![PDF page 159](../assets/pages/page_159.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

175

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
e.g. x = -2, y = 5, z = -4
Want:
175
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 159 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 159?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 160 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00160`

![PDF page 160](../assets/pages/page_160.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

176

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
e.g. x = -2, y = 5, z = -4
Want:
176
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 160 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 160?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 161 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00161`

![PDF page 161](../assets/pages/page_161.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

Chain rule:

Upstream gradient

Local gradient

177

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
e.g. x = -2, y = 5, z = -4
Want:
Chain rule:
Upstream gradient
Local gradient
177
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 161 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 161?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 162 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00162`

![PDF page 162](../assets/pages/page_162.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

178

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
e.g. x = -2, y = 5, z = -4
Want:
178
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 162 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 162?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 163 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00163`

![PDF page 163](../assets/pages/page_163.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

Chain rule:

179

Credit: Andrej Karpathy
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
e.g. x = -2, y = 5, z = -4
Want:
Chain rule:
179
Credit: Andrej Karpathy
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 163 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；e.g. x = -2, y = 5, z = -4；Want:。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 163?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; e.g. x = -2, y = 5, z = -4; Want:. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 164 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00164`

![PDF page 164](../assets/pages/page_164.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

180

Credit: Justin Johnson
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
180
Credit: Justin Johnson
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；180；Credit: Justin Johnson。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 180; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 164 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；180；Credit: Justin Johnson。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 164?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 180; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 180; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 165 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00165`

![PDF page 165](../assets/pages/page_165.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

181

Credit: Justin Johnson
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
181
Credit: Justin Johnson
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；181；Credit: Justin Johnson。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 181; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 165 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；181；Credit: Justin Johnson。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 165?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 181; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 181; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 166 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00166`

![PDF page 166](../assets/pages/page_166.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

182

Credit: Justin Johnson
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
182
Credit: Justin Johnson
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；182；Credit: Justin Johnson。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 182; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 166 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；182；Credit: Justin Johnson。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 166?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 182; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 182; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 167 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00167`

![PDF page 167](../assets/pages/page_167.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

183

Credit: Justin Johnson
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
183
Credit: Justin Johnson
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；183；Credit: Justin Johnson。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 183; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 167 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；183；Credit: Justin Johnson。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 167?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 183; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 183; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 168 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00168`

![PDF page 168](../assets/pages/page_168.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

184

Credit: Justin Johnson
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
184
Credit: Justin Johnson
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；184；Credit: Justin Johnson。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 184; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 168 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；184；Credit: Justin Johnson。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 168?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 184; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 184; Credit: Justin Johnson. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 169 页：问题：CNN training, how？

Source ID: `src-a1c091bbcbc2-pdf_page-00169`

![PDF page 169](../assets/pages/page_169.jpg)

### 原文 / Original Text

```text
CNN training, how?

Backpropagation

185

https://youtu.be/Ilg3gGewQ5U
```

### 完整中文翻译

问题：CNN training, how？
Backpropagation
185
参考链接：https://youtu.be/Ilg3gGewQ5U
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；185；参考链接：https://youtu.be/Ilg3gGewQ5U。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 185; https://youtu.be/Ilg3gGewQ5U. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“CNN training, how?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 169 页的核心主题是什么？
**答：** 本页围绕“CNN training, how?”展开。课件中的关键信息包括：问题：CNN training, how？；Backpropagation；185；参考链接：https://youtu.be/Ilg3gGewQ5U。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 169?
**Answer:** This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 185; https://youtu.be/Ilg3gGewQ5U. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'CNN training, how?'. The slide includes: CNN training, how?; Backpropagation; 185; https://youtu.be/Ilg3gGewQ5U. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 170 页：问题：Do I have to use GPU？

Source ID: `src-a1c091bbcbc2-pdf_page-00170`

![PDF page 170](../assets/pages/page_170.jpg)

### 原文 / Original Text

```text
Do I have to use GPU?

186
```

### 完整中文翻译

问题：Do I have to use GPU？
186
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Do I have to use GPU?”展开。课件中的关键信息包括：问题：Do I have to use GPU？；186。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Do I have to use GPU?'. The slide includes: Do I have to use GPU?; 186. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Do I have to use GPU?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 170 页的核心主题是什么？
**答：** 本页围绕“Do I have to use GPU?”展开。课件中的关键信息包括：问题：Do I have to use GPU？；186。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 170?
**Answer:** This page presents 'Do I have to use GPU?'. The slide includes: Do I have to use GPU?; 186. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Do I have to use GPU?'. The slide includes: Do I have to use GPU?; 186. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 171 页：问题：Do I have to use GPU？

Source ID: `src-a1c091bbcbc2-pdf_page-00171`

![PDF page 171](../assets/pages/page_171.jpg)

### 原文 / Original Text

```text
Do I have to use GPU?

Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung

187
```

### 完整中文翻译

问题：Do I have to use GPU？
Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung
187
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Do I have to use GPU?”展开。课件中的关键信息包括：问题：Do I have to use GPU？；Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung；187。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Do I have to use GPU?'. The slide includes: Do I have to use GPU?; Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung; 187. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Do I have to use GPU?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 171 页的核心主题是什么？
**答：** 本页围绕“Do I have to use GPU?”展开。课件中的关键信息包括：问题：Do I have to use GPU？；Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung；187。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 171?
**Answer:** This page presents 'Do I have to use GPU?'. The slide includes: Do I have to use GPU?; Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung; 187. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Do I have to use GPU?'. The slide includes: Do I have to use GPU?; Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung; 187. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 172 页：问题：Do I have to use GPU？

Source ID: `src-a1c091bbcbc2-pdf_page-00172`

![PDF page 172](../assets/pages/page_172.jpg)

### 原文 / Original Text

```text
Do I have to use GPU?

Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung

188
```

### 完整中文翻译

问题：Do I have to use GPU？
Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung
188
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Do I have to use GPU?”展开。课件中的关键信息包括：问题：Do I have to use GPU？；Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung；188。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Do I have to use GPU?'. The slide includes: Do I have to use GPU?; Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung; 188. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Do I have to use GPU?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 172 页的核心主题是什么？
**答：** 本页围绕“Do I have to use GPU?”展开。课件中的关键信息包括：问题：Do I have to use GPU？；Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung；188。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 172?
**Answer:** This page presents 'Do I have to use GPU?'. The slide includes: Do I have to use GPU?; Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung; 188. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Do I have to use GPU?'. The slide includes: Do I have to use GPU?; Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung; 188. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 173 页：问题：Do I have to use GPU？

Source ID: `src-a1c091bbcbc2-pdf_page-00173`

![PDF page 173](../assets/pages/page_173.jpg)

### 原文 / Original Text

```text
Do I have to use GPU?

Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung

189
```

### 完整中文翻译

问题：Do I have to use GPU？
Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung
189
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Do I have to use GPU?”展开。课件中的关键信息包括：问题：Do I have to use GPU？；Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung；189。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Do I have to use GPU?'. The slide includes: Do I have to use GPU?; Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung; 189. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Do I have to use GPU?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 173 页的核心主题是什么？
**答：** 本页围绕“Do I have to use GPU?”展开。课件中的关键信息包括：问题：Do I have to use GPU？；Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung；189。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 173?
**Answer:** This page presents 'Do I have to use GPU?'. The slide includes: Do I have to use GPU?; Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung; 189. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Do I have to use GPU?'. The slide includes: Do I have to use GPU?; Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung; 189. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 174 页：问题：Do I have to use GPU？

Source ID: `src-a1c091bbcbc2-pdf_page-00174`

![PDF page 174](../assets/pages/page_174.jpg)

### 原文 / Original Text

```text
Do I have to use GPU?

Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung

190
```

### 完整中文翻译

问题：Do I have to use GPU？
Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung
190
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Do I have to use GPU?”展开。课件中的关键信息包括：问题：Do I have to use GPU？；Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung；190。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Do I have to use GPU?'. The slide includes: Do I have to use GPU?; Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung; 190. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Do I have to use GPU?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 174 页的核心主题是什么？
**答：** 本页围绕“Do I have to use GPU?”展开。课件中的关键信息包括：问题：Do I have to use GPU？；Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung；190。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 174?
**Answer:** This page presents 'Do I have to use GPU?'. The slide includes: Do I have to use GPU?; Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung; 190. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Do I have to use GPU?'. The slide includes: Do I have to use GPU?; Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung; 190. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 175 页：问题：Why GPU for DL (GPU vs. CPU)？

Source ID: `src-a1c091bbcbc2-pdf_page-00175`

![PDF page 175](../assets/pages/page_175.jpg)

### 原文 / Original Text

```text
Why GPU for DL (GPU vs. CPU)?

191
```

### 完整中文翻译

问题：Why GPU for DL (GPU vs. CPU)？
191
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Why GPU for DL (GPU vs. CPU)?”展开。课件中的关键信息包括：问题：Why GPU for DL (GPU vs. CPU)？；191。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Why GPU for DL (GPU vs. CPU)?'. The slide includes: Why GPU for DL (GPU vs. CPU)?; 191. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Why GPU for DL (GPU vs. CPU)?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 175 页的核心主题是什么？
**答：** 本页围绕“Why GPU for DL (GPU vs. CPU)?”展开。课件中的关键信息包括：问题：Why GPU for DL (GPU vs. CPU)？；191。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 175?
**Answer:** This page presents 'Why GPU for DL (GPU vs. CPU)?'. The slide includes: Why GPU for DL (GPU vs. CPU)?; 191. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Why GPU for DL (GPU vs. CPU)?'. The slide includes: Why GPU for DL (GPU vs. CPU)?; 191. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 176 页：(free) GPUs to play with

Source ID: `src-a1c091bbcbc2-pdf_page-00176`

![PDF page 176](../assets/pages/page_176.jpg)

### 原文 / Original Text

```text
(free) GPUs to play with

Google Colab

192
```

### 完整中文翻译

(free) GPUs to play with
Google Colab
192
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“(free) GPUs to play with”展开。课件中的关键信息包括：(free) GPUs to play with；Google Colab；192。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents '(free) GPUs to play with'. The slide includes: (free) GPUs to play with; Google Colab; 192. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“(free) GPUs to play with”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 176 页的核心主题是什么？
**答：** 本页围绕“(free) GPUs to play with”展开。课件中的关键信息包括：(free) GPUs to play with；Google Colab；192。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 176?
**Answer:** This page presents '(free) GPUs to play with'. The slide includes: (free) GPUs to play with; Google Colab; 192. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents '(free) GPUs to play with'. The slide includes: (free) GPUs to play with; Google Colab; 192. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 177 页：Coding with Vision

Source ID: `src-a1c091bbcbc2-pdf_page-00177`

![PDF page 177](../assets/pages/page_177.jpg)

### 原文 / Original Text

```text
Coding with Vision

193
```

### 完整中文翻译

Coding with Vision
193
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Coding with Vision”展开。课件中的关键信息包括：Coding with Vision；193。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Coding with Vision'. The slide includes: Coding with Vision; 193. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Coding with Vision”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 177 页的核心主题是什么？
**答：** 本页围绕“Coding with Vision”展开。课件中的关键信息包括：Coding with Vision；193。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 177?
**Answer:** This page presents 'Coding with Vision'. The slide includes: Coding with Vision; 193. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Coding with Vision'. The slide includes: Coding with Vision; 193. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 178 页：特征检测与深度学习 - Page 178

Source ID: `src-a1c091bbcbc2-pdf_page-00178`

![PDF page 178](../assets/pages/page_178.jpg)

### 原文 / Original Text

```text
194

https://fabienmaussion.info/scipro_ss2018/html/18-Scientific-Python.html
```

### 完整中文翻译

194
参考链接：https://fabienmaussion.info/scipro_ss2018/html/18-Scientific-Python.html
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“特征检测与深度学习 - Page 178 - Page 178”展开。课件中的关键信息包括：194；参考链接：https://fabienmaussion.info/scipro_ss2018/html/18-Scientific-Python.html。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents '特征检测与深度学习 - Page 178 - Page 178'. The slide includes: 194; https://fabienmaussion.info/scipro_ss2018/html/18-Scientific-Python.html. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“特征检测与深度学习 - Page 178 - Page 178”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 178 页的核心主题是什么？
**答：** 本页围绕“特征检测与深度学习 - Page 178 - Page 178”展开。课件中的关键信息包括：194；参考链接：https://fabienmaussion.info/scipro_ss2018/html/18-Scientific-Python.html。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 178?
**Answer:** This page presents '特征检测与深度学习 - Page 178 - Page 178'. The slide includes: 194; https://fabienmaussion.info/scipro_ss2018/html/18-Scientific-Python.html. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents '特征检测与深度学习 - Page 178 - Page 178'. The slide includes: 194; https://fabienmaussion.info/scipro_ss2018/html/18-Scientific-Python.html. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 179 页：特征检测与深度学习 - Page 179

Source ID: `src-a1c091bbcbc2-pdf_page-00179`

![PDF page 179](../assets/pages/page_179.jpg)

### 原文 / Original Text

```text
195

https://fabienmaussion.info/scipro_ss2018/html/18-Scientific-Python.html
```

### 完整中文翻译

195
参考链接：https://fabienmaussion.info/scipro_ss2018/html/18-Scientific-Python.html
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“特征检测与深度学习 - Page 179 - Page 179”展开。课件中的关键信息包括：195；参考链接：https://fabienmaussion.info/scipro_ss2018/html/18-Scientific-Python.html。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents '特征检测与深度学习 - Page 179 - Page 179'. The slide includes: 195; https://fabienmaussion.info/scipro_ss2018/html/18-Scientific-Python.html. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“特征检测与深度学习 - Page 179 - Page 179”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 179 页的核心主题是什么？
**答：** 本页围绕“特征检测与深度学习 - Page 179 - Page 179”展开。课件中的关键信息包括：195；参考链接：https://fabienmaussion.info/scipro_ss2018/html/18-Scientific-Python.html。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 179?
**Answer:** This page presents '特征检测与深度学习 - Page 179 - Page 179'. The slide includes: 195; https://fabienmaussion.info/scipro_ss2018/html/18-Scientific-Python.html. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents '特征检测与深度学习 - Page 179 - Page 179'. The slide includes: 195; https://fabienmaussion.info/scipro_ss2018/html/18-Scientific-Python.html. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 180 页：深度学习 Frameworks

Source ID: `src-a1c091bbcbc2-pdf_page-00180`

![PDF page 180](../assets/pages/page_180.jpg)

### 原文 / Original Text

```text
Deep Learning Frameworks

2019

(UC Berkeley)

(Facebook)

(Baidu)

(NYU / Facebook)

(Facebook)

(Amazon)

(Microsoft)

(U Montreal)

(Google)

(Google)

+ MatConvNet etc…

196
```

### 完整中文翻译

深度学习 Frameworks
2019
(UC Berkeley)
(Facebook)
(Baidu)
(NYU / Facebook)
(Facebook)
(Amazon)
(Microsoft)
(U Montreal)
(Google)
(Google)
+ MatConvNet etc…
196
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Deep Learning Frameworks”展开。课件中的关键信息包括：深度学习 Frameworks；2019；(UC Berkeley)；(Facebook)。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Deep Learning Frameworks'. The slide includes: Deep Learning Frameworks; 2019; (UC Berkeley); (Facebook). The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“Deep Learning Frameworks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 180 页的核心主题是什么？
**答：** 本页围绕“Deep Learning Frameworks”展开。课件中的关键信息包括：深度学习 Frameworks；2019；(UC Berkeley)；(Facebook)。复习时先抓住深度学习：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 180?
**Answer:** This page presents 'Deep Learning Frameworks'. The slide includes: Deep Learning Frameworks; 2019; (UC Berkeley); (Facebook). The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：深度学习 / deep learning
**答：** 用多层神经网络从数据中学习表示和映射，现代视觉任务常用。
**Q2 English:** Explain the concept on this page: deep learning
**Answer:** The page focuses on deep learning. This page presents 'Deep Learning Frameworks'. The slide includes: Deep Learning Frameworks; 2019; (UC Berkeley); (Facebook). The revision focus is deep learning; connect its definition, evidence, and use to the examples on the page.

## 第 181 页：Frameworks

Source ID: `src-a1c091bbcbc2-pdf_page-00181`

![PDF page 181](../assets/pages/page_181.jpg)

### 原文 / Original Text

```text
Frameworks

Now

197
```

### 完整中文翻译

Frameworks
Now
197
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Frameworks”展开。课件中的关键信息包括：Frameworks；Now；197。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Frameworks'. The slide includes: Frameworks; Now; 197. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Frameworks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 181 页的核心主题是什么？
**答：** 本页围绕“Frameworks”展开。课件中的关键信息包括：Frameworks；Now；197。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 181?
**Answer:** This page presents 'Frameworks'. The slide includes: Frameworks; Now; 197. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Frameworks'. The slide includes: Frameworks; Now; 197. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 182 页：Frameworks and tips

Source ID: `src-a1c091bbcbc2-pdf_page-00182`

![PDF page 182](../assets/pages/page_182.jpg)

### 原文 / Original Text

```text
Frameworks and tips

2019

https://towardsdatascience.com/which-deep-learning-framework-is-growing-fastest-3f77f14aa318

198
```

### 完整中文翻译

Frameworks and tips
2019
参考链接：https://towardsdatascience.com/which-deep-learning-framework-is-growing-fastest-3f77f14aa318
198
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；2019；参考链接：https://towardsdatascience.com/which-deep-learning-framework-is-growing-fastest-3f77f14aa318；198。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; 2019; https://towardsdatascience.com/which-deep-learning-framework-is-growing-fastest-3f77f14aa318; 198. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Frameworks and tips”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 182 页的核心主题是什么？
**答：** 本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；2019；参考链接：https://towardsdatascience.com/which-deep-learning-framework-is-growing-fastest-3f77f14aa318；198。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 182?
**Answer:** This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; 2019; https://towardsdatascience.com/which-deep-learning-framework-is-growing-fastest-3f77f14aa318; 198. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; 2019; https://towardsdatascience.com/which-deep-learning-framework-is-growing-fastest-3f77f14aa318; 198. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 183 页：Frameworks and tips

Source ID: `src-a1c091bbcbc2-pdf_page-00183`

![PDF page 183](../assets/pages/page_183.jpg)

### 原文 / Original Text

```text
Frameworks and tips

Now

199
```

### 完整中文翻译

Frameworks and tips
Now
199
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；Now；199。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Now; 199. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Frameworks and tips”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 183 页的核心主题是什么？
**答：** 本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；Now；199。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 183?
**Answer:** This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Now; 199. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Now; 199. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 184 页：Frameworks and tips

Source ID: `src-a1c091bbcbc2-pdf_page-00184`

![PDF page 184](../assets/pages/page_184.jpg)

### 原文 / Original Text

```text
Frameworks and tips

Now

200
```

### 完整中文翻译

Frameworks and tips
Now
200
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；Now；200。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Now; 200. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Frameworks and tips”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 184 页的核心主题是什么？
**答：** 本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；Now；200。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 184?
**Answer:** This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Now; 200. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Now; 200. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 185 页：Frameworks and tips

Source ID: `src-a1c091bbcbc2-pdf_page-00185`

![PDF page 185](../assets/pages/page_185.jpg)

### 原文 / Original Text

```text
Frameworks and tips

Suggestions?

ü For beginners – Keras
ü For Google Cloud Platform – Tensorflow
ü For research – PyTorch
ü For Amazon Web Services (AWS) – MXNET
ü For MS Azura – CNTK
ü For Java developers – DL4J
ü For IOS developers – CoreML
ü For Interoperability - ONNX

201
```

### 完整中文翻译

Frameworks and tips
问题：Suggestions？
ü For beginners – Keras
ü For Google Cloud Platform – Tensorflow
ü For research – PyTorch
ü For Amazon Web Services (AWS) – MXNET
ü For MS Azura – CNTK
ü For Java developers – DL4J
ü For IOS developers – CoreML
ü For Interoperability - ONNX
201
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；问题：Suggestions？；ü For beginners – Keras；ü For Google Cloud Platform – Tensorflow。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Suggestions?; ü For beginners – Keras; ü For Google Cloud Platform – Tensorflow. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Frameworks and tips”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 185 页的核心主题是什么？
**答：** 本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；问题：Suggestions？；ü For beginners – Keras；ü For Google Cloud Platform – Tensorflow。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 185?
**Answer:** This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Suggestions?; ü For beginners – Keras; ü For Google Cloud Platform – Tensorflow. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Suggestions?; ü For beginners – Keras; ü For Google Cloud Platform – Tensorflow. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 186 页：Frameworks and tips

Source ID: `src-a1c091bbcbc2-pdf_page-00186`

![PDF page 186](../assets/pages/page_186.jpg)

### 原文 / Original Text

```text
Frameworks and tips

Suggestions?

ü

ü

ü

ü

ü

ü

ü

Research-focused framework?

ü

industry-focused framework?

202
```

### 完整中文翻译

Frameworks and tips
问题：Suggestions？
ü
ü
ü
ü
ü
ü
ü
问题：Research-focused framework？
ü
问题：industry-focused framework？
202
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；问题：Suggestions？；ü；ü。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Suggestions?; ü; ü. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Frameworks and tips”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 186 页的核心主题是什么？
**答：** 本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；问题：Suggestions？；ü；ü。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 186?
**Answer:** This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Suggestions?; ü; ü. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Suggestions?; ü; ü. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 187 页：Frameworks

Source ID: `src-a1c091bbcbc2-pdf_page-00187`

![PDF page 187](../assets/pages/page_187.jpg)

### 原文 / Original Text

```text
Frameworks

Comparison

Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/

203
```

### 完整中文翻译

Frameworks
Comparison
参考链接：Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/
203
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Frameworks”展开。课件中的关键信息包括：Frameworks；Comparison；参考链接：Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/；203。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Frameworks'. The slide includes: Frameworks; Comparison; Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/; 203. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Frameworks”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 187 页的核心主题是什么？
**答：** 本页围绕“Frameworks”展开。课件中的关键信息包括：Frameworks；Comparison；参考链接：Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/；203。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 187?
**Answer:** This page presents 'Frameworks'. The slide includes: Frameworks; Comparison; Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/; 203. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Frameworks'. The slide includes: Frameworks; Comparison; Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/; 203. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 188 页：Frameworks and tips

Source ID: `src-a1c091bbcbc2-pdf_page-00188`

![PDF page 188](../assets/pages/page_188.jpg)

### 原文 / Original Text

```text
Frameworks and tips

Comparison

Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/

204
```

### 完整中文翻译

Frameworks and tips
Comparison
参考链接：Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/
204
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；Comparison；参考链接：Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/；204。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Comparison; Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/; 204. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Frameworks and tips”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 188 页的核心主题是什么？
**答：** 本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；Comparison；参考链接：Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/；204。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 188?
**Answer:** This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Comparison; Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/; 204. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Comparison; Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/; 204. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 189 页：Frameworks and tips

Source ID: `src-a1c091bbcbc2-pdf_page-00189`

![PDF page 189](../assets/pages/page_189.jpg)

### 原文 / Original Text

```text
Frameworks and tips

Comparison

Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/

205
```

### 完整中文翻译

Frameworks and tips
Comparison
参考链接：Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/
205
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；Comparison；参考链接：Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/；205。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Comparison; Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/; 205. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Frameworks and tips”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 189 页的核心主题是什么？
**答：** 本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；Comparison；参考链接：Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/；205。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 189?
**Answer:** This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Comparison; Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/; 205. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Comparison; Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/; 205. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 190 页：Frameworks and tips

Source ID: `src-a1c091bbcbc2-pdf_page-00190`

![PDF page 190](../assets/pages/page_190.jpg)

### 原文 / Original Text

```text
Frameworks and tips

Comparison

206

Credit: Fei-Fei Li & Justin Johnson & Serena Yeung
```

### 完整中文翻译

Frameworks and tips
Comparison
206
Credit: Fei-Fei Li & Justin Johnson & Serena Yeung
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；Comparison；206；Credit: Fei-Fei Li & Justin Johnson & Serena Yeung。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Comparison; 206; Credit: Fei-Fei Li & Justin Johnson & Serena Yeung. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Frameworks and tips”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 190 页的核心主题是什么？
**答：** 本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；Comparison；206；Credit: Fei-Fei Li & Justin Johnson & Serena Yeung。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 190?
**Answer:** This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Comparison; 206; Credit: Fei-Fei Li & Justin Johnson & Serena Yeung. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Comparison; 206; Credit: Fei-Fei Li & Justin Johnson & Serena Yeung. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 191 页：Frameworks and tips

Source ID: `src-a1c091bbcbc2-pdf_page-00191`

![PDF page 191](../assets/pages/page_191.jpg)

### 原文 / Original Text

```text
Frameworks and tips

Comparison

207
```

### 完整中文翻译

Frameworks and tips
Comparison
207
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；Comparison；207。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Comparison; 207. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Frameworks and tips”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 191 页的核心主题是什么？
**答：** 本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；Comparison；207。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 191?
**Answer:** This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Comparison; 207. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; Comparison; 207. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 192 页：Frameworks and tips

Source ID: `src-a1c091bbcbc2-pdf_page-00192`

![PDF page 192](../assets/pages/page_192.jpg)

### 原文 / Original Text

```text
Frameworks and tips
TensorFlow: Tensorboard

visualization

208
```

### 完整中文翻译

Frameworks and tips
TensorFlow: Tensorboard
visualization
208
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；TensorFlow: Tensorboard；visualization；208。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; TensorFlow: Tensorboard; visualization; 208. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Frameworks and tips”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 192 页的核心主题是什么？
**答：** 本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；TensorFlow: Tensorboard；visualization；208。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 192?
**Answer:** This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; TensorFlow: Tensorboard; visualization; 208. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; TensorFlow: Tensorboard; visualization; 208. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 193 页：Frameworks and tips

Source ID: `src-a1c091bbcbc2-pdf_page-00193`

![PDF page 193](../assets/pages/page_193.jpg)

### 原文 / Original Text

```text
Frameworks and tips

visualization

209
```

### 完整中文翻译

Frameworks and tips
visualization
209
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；visualization；209。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; visualization; 209. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Frameworks and tips”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 193 页的核心主题是什么？
**答：** 本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；visualization；209。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 193?
**Answer:** This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; visualization; 209. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; visualization; 209. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 194 页：Frameworks and tips

Source ID: `src-a1c091bbcbc2-pdf_page-00194`

![PDF page 194](../assets/pages/page_194.jpg)

### 原文 / Original Text

```text
Frameworks and tips

visualization

210
```

### 完整中文翻译

Frameworks and tips
visualization
210
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；visualization；210。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; visualization; 210. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Frameworks and tips”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 194 页的核心主题是什么？
**答：** 本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；visualization；210。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 194?
**Answer:** This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; visualization; 210. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; visualization; 210. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 195 页：Frameworks and tips

Source ID: `src-a1c091bbcbc2-pdf_page-00195`

![PDF page 195](../assets/pages/page_195.jpg)

### 原文 / Original Text

```text
Frameworks and tips

visualization

211

https://wandb.ai/site
```

### 完整中文翻译

Frameworks and tips
visualization
211
参考链接：https://wandb.ai/site
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；visualization；211；参考链接：https://wandb.ai/site。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; visualization; 211; https://wandb.ai/site. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Frameworks and tips”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 195 页的核心主题是什么？
**答：** 本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；visualization；211；参考链接：https://wandb.ai/site。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 195?
**Answer:** This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; visualization; 211; https://wandb.ai/site. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; visualization; 211; https://wandb.ai/site. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 196 页：Frameworks and tips

Source ID: `src-a1c091bbcbc2-pdf_page-00196`

![PDF page 196](../assets/pages/page_196.jpg)

### 原文 / Original Text

```text
Frameworks and tips

visualization

212

https://wandb.ai/site
```

### 完整中文翻译

Frameworks and tips
visualization
212
参考链接：https://wandb.ai/site
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；visualization；212；参考链接：https://wandb.ai/site。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; visualization; 212; https://wandb.ai/site. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Frameworks and tips”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 196 页的核心主题是什么？
**答：** 本页围绕“Frameworks and tips”展开。课件中的关键信息包括：Frameworks and tips；visualization；212；参考链接：https://wandb.ai/site。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 196?
**Answer:** This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; visualization; 212; https://wandb.ai/site. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Frameworks and tips'. The slide includes: Frameworks and tips; visualization; 212; https://wandb.ai/site. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 197 页：Coding with PyTorch

Source ID: `src-a1c091bbcbc2-pdf_page-00197`

![PDF page 197](../assets/pages/page_197.jpg)

### 原文 / Original Text

```text
Coding with PyTorch

213
```

### 完整中文翻译

Coding with PyTorch
213
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Coding with PyTorch”展开。课件中的关键信息包括：Coding with PyTorch；213。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Coding with PyTorch'. The slide includes: Coding with PyTorch; 213. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Coding with PyTorch”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 197 页的核心主题是什么？
**答：** 本页围绕“Coding with PyTorch”展开。课件中的关键信息包括：Coding with PyTorch；213。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 197?
**Answer:** This page presents 'Coding with PyTorch'. The slide includes: Coding with PyTorch; 213. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Coding with PyTorch'. The slide includes: Coding with PyTorch; 213. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 198 页：特征检测与深度学习 - Page 198

Source ID: `src-a1c091bbcbc2-pdf_page-00198`

![PDF page 198](../assets/pages/page_198.jpg)

### 原文 / Original Text

```text
https://youtu.be/u7x8RXwLKcA

https://pytorch.org/tutorials/beginner/deep_learning_60min_blitz.html

214
```

### 完整中文翻译

参考链接：https://youtu.be/u7x8RXwLKcA
参考链接：https://pytorch.org/tutorials/beginner/deep_learning_60min_blitz.html
214
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“特征检测与深度学习 - Page 198 - Page 198”展开。课件中的关键信息包括：参考链接：https://youtu.be/u7x8RXwLKcA；参考链接：https://pytorch.org/tutorials/beginner/deep_learning_60min_blitz.html；214。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents '特征检测与深度学习 - Page 198 - Page 198'. The slide includes: https://youtu.be/u7x8RXwLKcA; https://pytorch.org/tutorials/beginner/deep_learning_60min_blitz.html; 214. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“特征检测与深度学习 - Page 198 - Page 198”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 198 页的核心主题是什么？
**答：** 本页围绕“特征检测与深度学习 - Page 198 - Page 198”展开。课件中的关键信息包括：参考链接：https://youtu.be/u7x8RXwLKcA；参考链接：https://pytorch.org/tutorials/beginner/deep_learning_60min_blitz.html；214。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 198?
**Answer:** This page presents '特征检测与深度学习 - Page 198 - Page 198'. The slide includes: https://youtu.be/u7x8RXwLKcA; https://pytorch.org/tutorials/beginner/deep_learning_60min_blitz.html; 214. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents '特征检测与深度学习 - Page 198 - Page 198'. The slide includes: https://youtu.be/u7x8RXwLKcA; https://pytorch.org/tutorials/beginner/deep_learning_60min_blitz.html; 214. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 199 页：PyTorch

Source ID: `src-a1c091bbcbc2-pdf_page-00199`

![PDF page 199](../assets/pages/page_199.jpg)

### 原文 / Original Text

```text
PyTorch

An open source machine learning framework that accelerates the path from research 

prototyping to production deployment.

Website: https://pytorch.org/

215
```

### 完整中文翻译

PyTorch
An open source 机器学习 framework that accelerates the path from research
prototyping to production deployment.
Website: https://pytorch.org/
215
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“PyTorch”展开。课件中的关键信息包括：PyTorch；An open source 机器学习 framework that accelerates the path from research；prototyping to production deployment.；Website: https://pytorch.org/。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'PyTorch'. The slide includes: PyTorch; An open source machine learning framework that accelerates the path from research; prototyping to production deployment.; Website: https://pytorch.org/. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“PyTorch”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 199 页的核心主题是什么？
**答：** 本页围绕“PyTorch”展开。课件中的关键信息包括：PyTorch；An open source 机器学习 framework that accelerates the path from research；prototyping to production deployment.；Website: https://pytorch.org/。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 199?
**Answer:** This page presents 'PyTorch'. The slide includes: PyTorch; An open source machine learning framework that accelerates the path from research; prototyping to production deployment.; Website: https://pytorch.org/. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'PyTorch'. The slide includes: PyTorch; An open source machine learning framework that accelerates the path from research; prototyping to production deployment.; Website: https://pytorch.org/. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 200 页：PyTorch

Source ID: `src-a1c091bbcbc2-pdf_page-00200`

![PDF page 200](../assets/pages/page_200.jpg)

### 原文 / Original Text

```text
PyTorch

An open source machine learning framework that accelerates the path from research 

prototyping to production deployment.

Website: https://pytorch.org/

216
```

### 完整中文翻译

PyTorch
An open source 机器学习 framework that accelerates the path from research
prototyping to production deployment.
Website: https://pytorch.org/
216
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“PyTorch”展开。课件中的关键信息包括：PyTorch；An open source 机器学习 framework that accelerates the path from research；prototyping to production deployment.；Website: https://pytorch.org/。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'PyTorch'. The slide includes: PyTorch; An open source machine learning framework that accelerates the path from research; prototyping to production deployment.; Website: https://pytorch.org/. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“PyTorch”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 200 页的核心主题是什么？
**答：** 本页围绕“PyTorch”展开。课件中的关键信息包括：PyTorch；An open source 机器学习 framework that accelerates the path from research；prototyping to production deployment.；Website: https://pytorch.org/。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 200?
**Answer:** This page presents 'PyTorch'. The slide includes: PyTorch; An open source machine learning framework that accelerates the path from research; prototyping to production deployment.; Website: https://pytorch.org/. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'PyTorch'. The slide includes: PyTorch; An open source machine learning framework that accelerates the path from research; prototyping to production deployment.; Website: https://pytorch.org/. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 201 页：Load

Source ID: `src-a1c091bbcbc2-pdf_page-00201`

![PDF page 201](../assets/pages/page_201.jpg)

### 原文 / Original Text

```text
Load
data

Network
design

Training
(loss/optimization)

test/analysis/
deploy

217
```

### 完整中文翻译

Load
data
Network
design
Training
(loss/optimization)
test/analysis/
deploy
217
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Load”展开。课件中的关键信息包括：Load；data；Network；design。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Load'. The slide includes: Load; data; Network; design. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Load”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 201 页的核心主题是什么？
**答：** 本页围绕“Load”展开。课件中的关键信息包括：Load；data；Network；design。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 201?
**Answer:** This page presents 'Load'. The slide includes: Load; data; Network; design. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Load'. The slide includes: Load; data; Network; design. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

## 第 202 页：总结

Source ID: `src-a1c091bbcbc2-pdf_page-00202`

![PDF page 202](../assets/pages/page_202.jpg)

### 原文 / Original Text

```text
Summary

Traditional visual feature descriptors
□ MOPS, SIFT
□ Edges and contours detection
□ Hough transforms

Deep learning-based visual feature extraction
□ Network design
□ Convolutional Neural Networks
□ How to train DL4CV
```

### 完整中文翻译

总结
传统视觉特征描述子
□ MOPS, SIFT
□ 边缘与轮廓 检测
□ Hough transforms
基于深度学习的视觉特征提取
□ Network design
□ Convolutional Neural Networks
□ How to train DL4CV
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Summary”展开。课件中的关键信息包括：总结；传统视觉特征描述子；□ MOPS, SIFT；□ 边缘与轮廓 检测。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Summary'. The slide includes: Summary; Traditional visual feature descriptors; □ MOPS, SIFT; □ Edges and contours detection. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **MAR / 随机缺失**：缺失与其他可观测变量有关，但不直接由缺失值本身决定。
- **detection / 检测**：同时判断目标类别与位置，通常输出边界框。
- **deep learning / 深度学习**：用多层神经网络从数据中学习表示和映射，现代视觉任务常用。

拓展复习：把“Summary”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 202 页的核心主题是什么？
**答：** 本页围绕“Summary”展开。课件中的关键信息包括：总结；传统视觉特征描述子；□ MOPS, SIFT；□ 边缘与轮廓 检测。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 202?
**Answer:** This page presents 'Summary'. The slide includes: Summary; Traditional visual feature descriptors; □ MOPS, SIFT; □ Edges and contours detection. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：随机缺失 / MAR
**答：** 缺失与其他可观测变量有关，但不直接由缺失值本身决定。
**Q2 English:** Explain the concept on this page: MAR
**Answer:** The page focuses on MAR. This page presents 'Summary'. The slide includes: Summary; Traditional visual feature descriptors; □ MOPS, SIFT; □ Edges and contours detection. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

## 第 203 页：Q & A

Source ID: `src-a1c091bbcbc2-pdf_page-00203`

![PDF page 203](../assets/pages/page_203.jpg)

### 原文 / Original Text

```text
Q & A
```

### 完整中文翻译

Q & A
视觉补充：页面截图保留了图表、示意图和图片中的视觉信息；上方中文覆盖 PDF 可抽取文字。

### 中文释义

本页围绕“Q & A”展开。课件中的关键信息包括：Q & A。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Q & A'. The slide includes: Q & A. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Visual example / 视觉示例**：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。

拓展复习：把“Q & A”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。 对图像型 CV 页面，额外观察截图里的输入图像、输出标签/框/掩膜，以及它想展示的视觉难点。

### 自测问题 / Self-check

**Q1 中文：** 第 203 页的核心主题是什么？
**答：** 本页围绕“Q & A”展开。课件中的关键信息包括：Q & A。复习时先抓住视觉示例：本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 203?
**Answer:** This page presents 'Q & A'. The slide includes: Q & A. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：视觉示例 / Visual example
**答：** 本页主要依靠图片或示意图传达概念，复习时应结合截图观察目标、输入、输出和失败模式。
**Q2 English:** Explain the concept on this page: Visual example
**Answer:** The page focuses on Visual example. This page presents 'Q & A'. The slide includes: Q & A. The revision focus is Visual example; connect its definition, evidence, and use to the examples on the page.
