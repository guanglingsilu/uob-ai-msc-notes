# Data Quality I: Missing Values and Data Imputation

课程：Data-Intensive Artificial Intelligence

## 第 1 页：数据质量第一部分:

Source ID: `src-8d8a776bac61-pdf_page-00001`

![PDF page 1](../assets/pages/page_001.jpg)

### 原文 / Original Text

```text
Data Quality I:
missing values and data imputation

Prof. Paolo Missier
School of Computer Science
University of Birmingham, UK

Data-intensive AI
2026/27 Sem 1
```

### 完整中文翻译

数据质量第一部分:
缺失值与数据插补
教授 Paolo Missier
计算机科学学院
伯明翰大学, UK
数据密集型人工智能
2026/27 Sem 1

### 中文释义

本页围绕“Data Quality I:”展开。课件中的关键信息包括：数据质量第一部分:；缺失值与数据插补；教授 Paolo Missier；计算机科学学院。复习时先抓住插补：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data Quality I:'. The slide includes: Data Quality I:; missing values and data imputation; Prof. Paolo Missier; School of Computer Science. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **imputation / 插补**：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。

拓展复习：把“Data Quality I:”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 1 页的核心主题是什么？
**答：** 本页围绕“Data Quality I:”展开。课件中的关键信息包括：数据质量第一部分:；缺失值与数据插补；教授 Paolo Missier；计算机科学学院。复习时先抓住插补：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 1?
**Answer:** This page presents 'Data Quality I:'. The slide includes: Data Quality I:; missing values and data imputation; Prof. Paolo Missier; School of Computer Science. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：插补 / imputation
**答：** 用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。
**Q2 English:** Explain the concept on this page: imputation
**Answer:** The page focuses on imputation. This page presents 'Data Quality I:'. The slide includes: Data Quality I:; missing values and data imputation; Prof. Paolo Missier; School of Computer Science. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

## 第 2 页：本讲涉及的数据质量问题

Source ID: `src-8d8a776bac61-pdf_page-00002`

![PDF page 2](../assets/pages/page_002.jpg)

### 原文 / Original Text

```text
Data Quality Issues covered in this lecture

Structural
- Missing / null values
- Out-of-range values
- Duplicate records

Semantic
Skewed distributions

ML-Specific
- Class imbalance
- Data leakage
```

### 完整中文翻译

本讲涉及的数据质量问题
结构性问题
- 缺失值/空值
- 超出范围的值
- 重复记录
语义问题
偏斜分布
机器学习特有问题
- 类别不平衡
- 数据泄漏

### 中文释义

本页围绕“Data Quality Issues covered in this lecture”展开。课件中的关键信息包括：本讲涉及的数据质量问题；结构性问题；- 缺失值/空值；- 超出范围的值。复习时先抓住数据泄漏：训练特征包含目标或生产时不可获得的信息，使测试成绩虚高。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data Quality Issues covered in this lecture'. The slide includes: Data Quality Issues covered in this lecture; Structural; - Missing / null values; - Out-of-range values. The revision focus is data leakage; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **data leakage / 数据泄漏**：训练特征包含目标或生产时不可获得的信息，使测试成绩虚高。
- **class imbalance / 类别不平衡**：多数类远多于少数类，准确率会误导模型评估。

拓展复习：把“Data Quality Issues covered in this lecture”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 2 页的核心主题是什么？
**答：** 本页围绕“Data Quality Issues covered in this lecture”展开。课件中的关键信息包括：本讲涉及的数据质量问题；结构性问题；- 缺失值/空值；- 超出范围的值。复习时先抓住数据泄漏：训练特征包含目标或生产时不可获得的信息，使测试成绩虚高。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 2?
**Answer:** This page presents 'Data Quality Issues covered in this lecture'. The slide includes: Data Quality Issues covered in this lecture; Structural; - Missing / null values; - Out-of-range values. The revision focus is data leakage; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据泄漏 / data leakage
**答：** 训练特征包含目标或生产时不可获得的信息，使测试成绩虚高。
**Q2 English:** Explain the concept on this page: data leakage
**Answer:** The page focuses on data leakage. This page presents 'Data Quality Issues covered in this lecture'. The slide includes: Data Quality Issues covered in this lecture; Structural; - Missing / null values; - Out-of-range values. The revision focus is data leakage; connect its definition, evidence, and use to the examples on the page.

## 第 3 页：缺失数据 – I

Source ID: `src-8d8a776bac61-pdf_page-00003`

![PDF page 3](../assets/pages/page_003.jpg)

### 原文 / Original Text

```text
Missing data – I
```

### 完整中文翻译

缺失数据 – I

### 中文释义

本页围绕“Missing data – I”展开。课件中的关键信息包括：缺失数据 – I。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Missing data – I'. The slide includes: Missing data – I. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“Missing data – I”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 3 页的核心主题是什么？
**答：** 本页围绕“Missing data – I”展开。课件中的关键信息包括：缺失数据 – I。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 3?
**Answer:** This page presents 'Missing data – I'. The slide includes: Missing data – I. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'Missing data – I'. The slide includes: Missing data – I. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

## 第 4 页：缺失数据 - II

Source ID: `src-8d8a776bac61-pdf_page-00004`

![PDF page 4](../assets/pages/page_004.jpg)

### 原文 / Original Text

```text
Missing data - II
```

### 完整中文翻译

缺失数据 - II

### 中文释义

本页围绕“Missing data - II”展开。课件中的关键信息包括：缺失数据 - II。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Missing data - II'. The slide includes: Missing data - II. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“Missing data - II”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 4 页的核心主题是什么？
**答：** 本页围绕“Missing data - II”展开。课件中的关键信息包括：缺失数据 - II。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 4?
**Answer:** This page presents 'Missing data - II'. The slide includes: Missing data - II. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'Missing data - II'. The slide includes: Missing data - II. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

## 第 5 页：空值 or 缺失?

Source ID: `src-8d8a776bac61-pdf_page-00005`

![PDF page 5](../assets/pages/page_005.jpg)

### 原文 / Original Text

```text
Null or missing?

Source: NYPD Motor Vehicle Collision Dataset

Credits: https://www.residentmar.io/2016/06/12/null-and-missing-data-python.html
```

### 完整中文翻译

空值 or 缺失?
Source: NYPD Motor Vehicle Collision Dataset
参考链接：Credits: https://www.residentmar.io/2016/06/12/null-and-missing-data-python.html

### 中文释义

本页围绕“Null or missing?”展开。课件中的关键信息包括：空值 or 缺失?；Source: NYPD Motor Vehicle Collision Dataset；参考链接：Credits: https://www.residentmar.io/2016/06/12/null-and-missing-data-python.html。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Null or missing?'. The slide includes: Null or missing?; Source: NYPD Motor Vehicle Collision Dataset; Credits: https://www.residentmar.io/2016/06/12/null-and-missing-data-python.html. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **MAR / 随机缺失**：缺失与其他可观测变量有关，但不直接由缺失值本身决定。

拓展复习：把“Null or missing?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 5 页的核心主题是什么？
**答：** 本页围绕“Null or missing?”展开。课件中的关键信息包括：空值 or 缺失?；Source: NYPD Motor Vehicle Collision Dataset；参考链接：Credits: https://www.residentmar.io/2016/06/12/null-and-missing-data-python.html。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 5?
**Answer:** This page presents 'Null or missing?'. The slide includes: Null or missing?; Source: NYPD Motor Vehicle Collision Dataset; Credits: https://www.residentmar.io/2016/06/12/null-and-missing-data-python.html. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：随机缺失 / MAR
**答：** 缺失与其他可观测变量有关，但不直接由缺失值本身决定。
**Q2 English:** Explain the concept on this page: MAR
**Answer:** The page focuses on MAR. This page presents 'Null or missing?'. The slide includes: Null or missing?; Source: NYPD Motor Vehicle Collision Dataset; Credits: https://www.residentmar.io/2016/06/12/null-and-missing-data-python.html. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

## 第 6 页：空值 or 缺失?

Source ID: `src-8d8a776bac61-pdf_page-00006`

![PDF page 6](../assets/pages/page_006.jpg)

### 原文 / Original Text

```text
Null or missing?

Data missing at random (MAR)
- ad hoc imputation sometimes possible
- Makes descriptive analytics imprecise
- But may not be useful for modelling  

Data missing NOT at random (MNAR)
- May be an important feature for modelling
- Statistical approaches to imputation may work

Representing missing / null data:
- Python: None data type and value
- Numpy: np.nan (for numerical data)
- R: distinction between missing data (NA) and non-data (null)
```

### 完整中文翻译

空值 or 缺失?
Data 缺失 at random (随机缺失)
- ad hoc 插补 sometimes possible
- Makes descriptive analytics imprecise
- But may not be useful for modelling
Data 缺失 NOT at random (非随机缺失)
- May be an important 特征 for modelling
- Statistical approaches to 插补 may work
Representing 缺失 / 空值 data:
- Python: None data type and value
- Numpy: np.nan (for numerical data)
- R: distinction between 缺失数据 (NA) and non-data (空值)

### 中文释义

本页围绕“Null or missing?”展开。课件中的关键信息包括：空值 or 缺失?；Data 缺失 at random (随机缺失)；- ad hoc 插补 sometimes possible；- Makes descriptive analytics imprecise。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Null or missing?'. The slide includes: Null or missing?; Data missing at random (MAR); - ad hoc imputation sometimes possible; - Makes descriptive analytics imprecise. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **MAR / 随机缺失**：缺失与其他可观测变量有关，但不直接由缺失值本身决定。
- **MNAR / 非随机缺失**：缺失本身携带信息，可能与未观测值或特定人群/事件有关。
- **imputation / 插补**：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。

拓展复习：把“Null or missing?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 6 页的核心主题是什么？
**答：** 本页围绕“Null or missing?”展开。课件中的关键信息包括：空值 or 缺失?；Data 缺失 at random (随机缺失)；- ad hoc 插补 sometimes possible；- Makes descriptive analytics imprecise。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 6?
**Answer:** This page presents 'Null or missing?'. The slide includes: Null or missing?; Data missing at random (MAR); - ad hoc imputation sometimes possible; - Makes descriptive analytics imprecise. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：随机缺失 / MAR
**答：** 缺失与其他可观测变量有关，但不直接由缺失值本身决定。
**Q2 English:** Explain the concept on this page: MAR
**Answer:** The page focuses on MAR. This page presents 'Null or missing?'. The slide includes: Null or missing?; Data missing at random (MAR); - ad hoc imputation sometimes possible; - Makes descriptive analytics imprecise. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

## 第 7 页：缺失 vs 空值

Source ID: `src-8d8a776bac61-pdf_page-00007`

![PDF page 7](../assets/pages/page_007.jpg)

### 原文 / Original Text

```text
Missing vs Null Values

Type

MCAR

MAR

MNAR

Meaning
Missing Completely At Random
sensor noise
Missing At Random
conditional on other cols
Missing Not At Random
absence encodes info

Taxi Example

passenger_count = NULL (device glitch)

tip = NULL when payment = cash

fare = NULL → disputed / cancelled trip
```

### 完整中文翻译

缺失 vs 空值
Type
完全随机缺失
随机缺失
非随机缺失
Meaning
缺失 Completely At Random
sensor noise
缺失 At Random
conditional on other cols
缺失 Not At Random
absence encodes info
Taxi Example
passenger_count = 空值 (device glitch)
tip = 空值 when payment = cash
fare = 空值 → disputed / cancelled trip

### 中文释义

本页围绕“Missing vs Null Values”展开。课件中的关键信息包括：缺失 vs 空值；Type；完全随机缺失；随机缺失。复习时先抓住完全随机缺失：缺失与其他变量和自身值没有系统关系。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Missing vs Null Values'. The slide includes: Missing vs Null Values; Type; MCAR; MAR. The revision focus is MCAR; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **MCAR / 完全随机缺失**：缺失与其他变量和自身值没有系统关系。
- **MAR / 随机缺失**：缺失与其他可观测变量有关，但不直接由缺失值本身决定。
- **MNAR / 非随机缺失**：缺失本身携带信息，可能与未观测值或特定人群/事件有关。

拓展复习：把“Missing vs Null Values”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 7 页的核心主题是什么？
**答：** 本页围绕“Missing vs Null Values”展开。课件中的关键信息包括：缺失 vs 空值；Type；完全随机缺失；随机缺失。复习时先抓住完全随机缺失：缺失与其他变量和自身值没有系统关系。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 7?
**Answer:** This page presents 'Missing vs Null Values'. The slide includes: Missing vs Null Values; Type; MCAR; MAR. The revision focus is MCAR; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：完全随机缺失 / MCAR
**答：** 缺失与其他变量和自身值没有系统关系。
**Q2 English:** Explain the concept on this page: MCAR
**Answer:** The page focuses on MCAR. This page presents 'Missing vs Null Values'. The slide includes: Missing vs Null Values; Type; MCAR; MAR. The revision focus is MCAR; connect its definition, evidence, and use to the examples on the page.

## 第 8 页：缺失 vs 空值

Source ID: `src-8d8a776bac61-pdf_page-00008`

![PDF page 8](../assets/pages/page_008.jpg)

### 原文 / Original Text

```text
Missing vs Null Values

Column
pickup_datetime
fare_amount
passenger_count
trip_distance
pickup_borough

Value
2024-01-15 08:32
NULL
NULL
0.0
NULL

Status
✓ present
✗ target missing

feature missing
sentinel value

✗ join failure

Consequence for ML

• Most algorithms crash on NULL input features

• Dropping all incomplete rows can remove up to 30% of data

• Imputing wrongly introduces systematic bias
```

### 完整中文翻译

缺失 vs 空值
Column
pickup_datetime
fare_amount
passenger_count
trip_distance
pickup_borough
Value
2024-01-15 08:32
空值
空值
0.0
空值
Status
✓ present
✗ target 缺失
特征 缺失
sentinel value
✗ 连接 failure
Consequence for 机器学习
• Most algorithms crash on 空值 input features
• Dropping all incomplete rows can remove up to 30% of data
• Imputing wrongly introduces systematic bias

### 中文释义

本页围绕“Missing vs Null Values”展开。课件中的关键信息包括：缺失 vs 空值；Column；pickup_datetime；fare_amount。复习时先抓住连接：按键把表横向组合；键的语义不一致时会产生看似正确但实际错误的数据视图。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Missing vs Null Values'. The slide includes: Missing vs Null Values; Column; pickup_datetime; fare_amount. The revision focus is join; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **join / 连接**：按键把表横向组合；键的语义不一致时会产生看似正确但实际错误的数据视图。

拓展复习：把“Missing vs Null Values”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 8 页的核心主题是什么？
**答：** 本页围绕“Missing vs Null Values”展开。课件中的关键信息包括：缺失 vs 空值；Column；pickup_datetime；fare_amount。复习时先抓住连接：按键把表横向组合；键的语义不一致时会产生看似正确但实际错误的数据视图。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 8?
**Answer:** This page presents 'Missing vs Null Values'. The slide includes: Missing vs Null Values; Column; pickup_datetime; fare_amount. The revision focus is join; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：连接 / join
**答：** 按键把表横向组合；键的语义不一致时会产生看似正确但实际错误的数据视图。
**Q2 English:** Explain the concept on this page: join
**Answer:** The page focuses on join. This page presents 'Missing vs Null Values'. The slide includes: Missing vs Null Values; Column; pickup_datetime; fare_amount. The revision focus is join; connect its definition, evidence, and use to the examples on the page.

## 第 9 页：A 分类 of 缺失-ness

Source ID: `src-8d8a776bac61-pdf_page-00009`

![PDF page 9](../assets/pages/page_009.jpg)

### 原文 / Original Text

```text
A classification of missing-ness

Missing Completely at Random (MCAR) – No systematic relationship between the missing 
data and any other data or why the data is missing
•

There is no reason that makes some data more likely to be missing than other

Missing at Random (MAR) – There may be a systematic reason why some of the data is 
missing, but this knowledge does not help us with imputation
•

if men are more likely to tell you their weight than women, weight is MAR

Missing Not at Random (MNAR) – there is a relationship between the propensity of a value to 
be missing and its values
• Medical study: data more likely to be missing from some specific strata of the cohort

•
•

The sickest people may be more likely to drop out of the study
This correlation may suggest how to impute data from the dropout population

Source: https://www.theanalysisfactor.com/missing-data-mechanism/
```

### 完整中文翻译

A 分类 of 缺失-ness
缺失 Completely at Random (完全随机缺失) – No systematic relationship between the 缺失
data and any other data or why the data is 缺失
•
There is no reason that makes some data more likely to be 缺失 than other
缺失 at Random (随机缺失) – There may be a systematic reason why some of the data is
缺失, but this knowledge does not help us with 插补
•
if men are more likely to tell you their weight than women, weight is 随机缺失
缺失 Not at Random (非随机缺失) – there is a relationship between the propensity of a value to
be 缺失 and its values
• Medical study: data more likely to be 缺失 from some specific strata of the cohort
•
•
The sickest people may be more likely to drop out of the study
This correlation may suggest how to impute data from the dropout population
参考链接：Source: https://www.theanalysisfactor.com/missing-data-mechanism/

### 中文释义

本页围绕“A classification of missing-ness”展开。课件中的关键信息包括：A 分类 of 缺失-ness；缺失 Completely at Random (完全随机缺失) – No systematic relationship between the 缺失；data and any other data or why the data is 缺失；•。复习时先抓住完全随机缺失：缺失与其他变量和自身值没有系统关系。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'A classification of missing-ness'. The slide includes: A classification of missing-ness; Missing Completely at Random (MCAR) – No systematic relationship between the missing; data and any other data or why the data is missing; •. The revision focus is MCAR; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **MCAR / 完全随机缺失**：缺失与其他变量和自身值没有系统关系。
- **MAR / 随机缺失**：缺失与其他可观测变量有关，但不直接由缺失值本身决定。
- **MNAR / 非随机缺失**：缺失本身携带信息，可能与未观测值或特定人群/事件有关。
- **imputation / 插补**：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。
- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。

拓展复习：把“A classification of missing-ness”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 9 页的核心主题是什么？
**答：** 本页围绕“A classification of missing-ness”展开。课件中的关键信息包括：A 分类 of 缺失-ness；缺失 Completely at Random (完全随机缺失) – No systematic relationship between the 缺失；data and any other data or why the data is 缺失；•。复习时先抓住完全随机缺失：缺失与其他变量和自身值没有系统关系。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 9?
**Answer:** This page presents 'A classification of missing-ness'. The slide includes: A classification of missing-ness; Missing Completely at Random (MCAR) – No systematic relationship between the missing; data and any other data or why the data is missing; •. The revision focus is MCAR; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：完全随机缺失 / MCAR
**答：** 缺失与其他变量和自身值没有系统关系。
**Q2 English:** Explain the concept on this page: MCAR
**Answer:** The page focuses on MCAR. This page presents 'A classification of missing-ness'. The slide includes: A classification of missing-ness; Missing Completely at Random (MCAR) – No systematic relationship between the missing; data and any other data or why the data is missing; •. The revision focus is MCAR; connect its definition, evidence, and use to the examples on the page.

## 第 10 页：How to handle 缺失值?

Source ID: `src-8d8a776bac61-pdf_page-00010`

![PDF page 10](../assets/pages/page_010.jpg)

### 原文 / Original Text

```text
How to handle Missing Values?

The strategy depends on which column is null and why it is null.

1

2

3

4

5

Audit first: count NULLs per column and compute null-%. Columns with >60% 
missing are candidates for dropping entirely.

Target column (fare_amount): rows with NULL target cannot contribute to 
supervised learning → drop those rows.

Numerical features: impute with median (robust to outliers). Never use mean on 
skewed distributions like fare or distance.

Categorical features (borough): impute with sentinel string "Unknown" —
preserves the fact that location was missing as a signal.

Sentinel values (distance = 0.0): re-encode as NULL first, then apply median 
imputation — a zero-distance trip is physically impossible.

Spark Implementation Pattern

# 1. Audit
null_counts = trips.select([

F.sum(F.col(c).isNull().cast("int")).alias(c)

for c in trips.columns])

# 2. Drop rows missing the TARGET

trips = trips.filter(F.col("fare_amount").isNotNull())

# 3. Impute numerical features with median
trips = trips.fillna({

"passenger_count": median_passenger,
"trip_distance":   median_distance,

})

Key insight: approxQuantile() computes medians across all workers in a single scan 
— the result is two scalars sent to the driver, not millions of rows.
```

### 完整中文翻译

How to handle 缺失值?
The strategy depends on which column is 空值 and why it is 空值.
1
2
3
4
5
Audit first: count NULLs per column and compute 空值-%. Columns with >60%
缺失 are candidates for dropping entirely.
Target column (fare_amount): rows with 空值 target cannot contribute to
监督学习 → drop those rows.
Numerical features: impute with median (robust to outliers). Never use mean on
偏斜分布 like fare or distance.
Categorical features (borough): impute with sentinel string "Unknown" —
preserves the fact that location was 缺失 as a signal.
Sentinel values (distance = 0.0): re-encode as 空值 first, then apply median
插补 — a zero-distance trip is physically impossible.
Spark Implementation Pattern
# 1. Audit
空值_counts = trips.select([
F.sum(F.col(c).isNull().cast("int")).alias(c)
for c in trips.columns])
# 2. Drop rows 缺失 the TARGET
trips = trips.filter(F.col("fare_amount").isNotNull())
# 3. Impute numerical features with median
trips = trips.fillna({
"passenger_count": median_passenger,
"trip_distance": median_distance,
})
Key insight: approxQuantile() computes medians across all workers in a single scan
— the result is two scalars sent to the driver, not millions of rows.

### 中文释义

本页围绕“How to handle Missing Values?”展开。课件中的关键信息包括：How to handle 缺失值?；The strategy depends on which column is 空值 and why it is 空值.；1；2。复习时先抓住插补：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'How to handle Missing Values?'. The slide includes: How to handle Missing Values?; The strategy depends on which column is null and why it is null.; 1; 2. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **imputation / 插补**：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。

拓展复习：把“How to handle Missing Values?”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 10 页的核心主题是什么？
**答：** 本页围绕“How to handle Missing Values?”展开。课件中的关键信息包括：How to handle 缺失值?；The strategy depends on which column is 空值 and why it is 空值.；1；2。复习时先抓住插补：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 10?
**Answer:** This page presents 'How to handle Missing Values?'. The slide includes: How to handle Missing Values?; The strategy depends on which column is null and why it is null.; 1; 2. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：插补 / imputation
**答：** 用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。
**Q2 English:** Explain the concept on this page: imputation
**Answer:** The page focuses on imputation. This page presents 'How to handle Missing Values?'. The slide includes: How to handle Missing Values?; The strategy depends on which column is null and why it is null.; 1; 2. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

## 第 11 页：Univariate vs Multivariate 插补

Source ID: `src-8d8a776bac61-pdf_page-00011`

![PDF page 11](../assets/pages/page_011.jpg)

### 原文 / Original Text

```text
Univariate vs Multivariate Imputation

Model target variable using regression
Use other variables to train a model that 
can predict the missing values on the 
target variable
- Eg a regression model

Use the distribution of available values 
for a variable to impute the remaining 
values
- mean, median, …

Pros: very simple strategy
Cons:
- all imputed values are the same
- adds bias around the mean of the 

distribution

- Reduces natural variance in the data 

Scikit implementation:  SimpleImputer
```

### 完整中文翻译

Univariate vs Multivariate 插补
Model target variable using 回归
Use other variables to train a model that
can predict the 缺失值 on the
target variable
- Eg a 回归 model
Use the distribution of available values
for a variable to impute the remaining
values
- mean, median, …
Pros: very simple strategy
Cons:
- all imputed values are the same
- adds bias around the mean of the
distribution
- Reduces natural variance in the data
Scikit implementation: SimpleImputer

### 中文释义

本页围绕“Univariate vs Multivariate Imputation”展开。课件中的关键信息包括：Univariate vs Multivariate 插补；Model target variable using 回归；Use other variables to train a model that；can predict the 缺失值 on the。复习时先抓住插补：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Univariate vs Multivariate Imputation'. The slide includes: Univariate vs Multivariate Imputation; Model target variable using regression; Use other variables to train a model that; can predict the missing values on the. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **imputation / 插补**：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。

拓展复习：把“Univariate vs Multivariate Imputation”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 11 页的核心主题是什么？
**答：** 本页围绕“Univariate vs Multivariate Imputation”展开。课件中的关键信息包括：Univariate vs Multivariate 插补；Model target variable using 回归；Use other variables to train a model that；can predict the 缺失值 on the。复习时先抓住插补：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 11?
**Answer:** This page presents 'Univariate vs Multivariate Imputation'. The slide includes: Univariate vs Multivariate Imputation; Model target variable using regression; Use other variables to train a model that; can predict the missing values on the. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：插补 / imputation
**答：** 用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。
**Q2 English:** Explain the concept on this page: imputation
**Answer:** The page focuses on imputation. This page presents 'Univariate vs Multivariate Imputation'. The slide includes: Univariate vs Multivariate Imputation; Model target variable using regression; Use other variables to train a model that; can predict the missing values on the. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

## 第 12 页：K 近邻: nearest-neighbour 插补

Source ID: `src-8d8a776bac61-pdf_page-00012`

![PDF page 12](../assets/pages/page_012.jpg)

### 原文 / Original Text

```text
KNN: nearest-neighbour imputation

Key idea: 
- A distance function can be defined on the space of values for target variable X

- Eg Euclidean distance for numeric values

- K defines how many neighbours of a record with missing values will be consulted

- Each missing feature is imputed 
using values from K nearest 
neighbours that have a value for the 
feature

Scikit implementation:  
Nearest neighbors imputation,
```

### 完整中文翻译

K 近邻: nearest-neighbour 插补
Key idea:
- A distance function can be defined on the space of values for target variable X
- Eg Euclidean distance for numeric values
- K defines how many neighbours of a record with 缺失值 will be consulted
- Each 缺失 特征 is imputed
using values from K nearest
neighbours that have a value for the
特征
Scikit implementation:
Nearest neighbors 插补,

### 中文释义

本页围绕“KNN: nearest-neighbour imputation”展开。课件中的关键信息包括：K 近邻: nearest-neighbour 插补；Key idea:；- A distance function can be defined on the space of values for target variable X；- Eg Euclidean distance for numeric values。复习时先抓住插补：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'KNN: nearest-neighbour imputation'. The slide includes: KNN: nearest-neighbour imputation; Key idea:; - A distance function can be defined on the space of values for target variable X; - Eg Euclidean distance for numeric values. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **imputation / 插补**：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。

拓展复习：把“KNN: nearest-neighbour imputation”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 12 页的核心主题是什么？
**答：** 本页围绕“KNN: nearest-neighbour imputation”展开。课件中的关键信息包括：K 近邻: nearest-neighbour 插补；Key idea:；- A distance function can be defined on the space of values for target variable X；- Eg Euclidean distance for numeric values。复习时先抓住插补：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 12?
**Answer:** This page presents 'KNN: nearest-neighbour imputation'. The slide includes: KNN: nearest-neighbour imputation; Key idea:; - A distance function can be defined on the space of values for target variable X; - Eg Euclidean distance for numeric values. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：插补 / imputation
**答：** 用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。
**Q2 English:** Explain the concept on this page: imputation
**Answer:** The page focuses on imputation. This page presents 'KNN: nearest-neighbour imputation'. The slide includes: KNN: nearest-neighbour imputation; Key idea:; - A distance function can be defined on the space of values for target variable X; - Eg Euclidean distance for numeric values. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

## 第 13 页：链式方程多重插补: Multiple 插补 by chained equations

Source ID: `src-8d8a776bac61-pdf_page-00013`

![PDF page 13](../assets/pages/page_013.jpg)

### 原文 / Original Text

```text
MICE: Multiple imputation by chained equations

Key concepts:

- Extends the idea of using regression to impute missing values for one variable, to 
simultaneously imputing all missing values across the entire table

- Rather than performing one regression, MICE iteratively improves the imputed 
values through a sequence / chain of regression models

Note: works for data where missing data is MAR. Implementing MICE when data are not 
MAR could result in biased estimates (see [1,3] below)
```

### 完整中文翻译

链式方程多重插补: Multiple 插补 by chained equations
Key concepts:
- Extends the idea of using 回归 to impute 缺失值 for one variable, to
simultaneously imputing all 缺失值 across the entire table
- Rather than performing one 回归, 链式方程多重插补 iteratively improves the imputed
values through a sequence / chain of 回归 models
Note: works for data where 缺失数据 is 随机缺失. Implementing 链式方程多重插补 when data are not
随机缺失 could result in biased estimates (see [1,3] below)

### 中文释义

本页围绕“MICE: Multiple imputation by chained equations”展开。课件中的关键信息包括：链式方程多重插补: Multiple 插补 by chained equations；Key concepts:；- Extends the idea of using 回归 to impute 缺失值 for one variable, to；simultaneously imputing all 缺失值 across the entire table。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'MICE: Multiple imputation by chained equations'. The slide includes: MICE: Multiple imputation by chained equations; Key concepts:; - Extends the idea of using regression to impute missing values for one variable, to; simultaneously imputing all missing values across the entire table. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **MAR / 随机缺失**：缺失与其他可观测变量有关，但不直接由缺失值本身决定。
- **imputation / 插补**：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。
- **MICE / MICE**：链式方程多重插补，用多个回归模型迭代估计表中各列缺失值。

拓展复习：把“MICE: Multiple imputation by chained equations”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 13 页的核心主题是什么？
**答：** 本页围绕“MICE: Multiple imputation by chained equations”展开。课件中的关键信息包括：链式方程多重插补: Multiple 插补 by chained equations；Key concepts:；- Extends the idea of using 回归 to impute 缺失值 for one variable, to；simultaneously imputing all 缺失值 across the entire table。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 13?
**Answer:** This page presents 'MICE: Multiple imputation by chained equations'. The slide includes: MICE: Multiple imputation by chained equations; Key concepts:; - Extends the idea of using regression to impute missing values for one variable, to; simultaneously imputing all missing values across the entire table. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：随机缺失 / MAR
**答：** 缺失与其他可观测变量有关，但不直接由缺失值本身决定。
**Q2 English:** Explain the concept on this page: MAR
**Answer:** The page focuses on MAR. This page presents 'MICE: Multiple imputation by chained equations'. The slide includes: MICE: Multiple imputation by chained equations; Key concepts:; - Extends the idea of using regression to impute missing values for one variable, to; simultaneously imputing all missing values across the entire table. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

## 第 14 页：链式方程多重插补: key references

Source ID: `src-8d8a776bac61-pdf_page-00014`

![PDF page 14](../assets/pages/page_014.jpg)

### 原文 / Original Text

```text
MICE: key references

[1] Azur, Melissa J., Elizabeth A. Stuart, Constantine Frangakis, and Philip J. Leaf. ‘Multiple Imputation by Chained 
Equations: What Is It and How Does It Work?’ International Journal of Methods in Psychiatric Research 20, no. 1 (24 
February 2011): 40–49. https://doi.org/10.1002/mpr.329.

[2] Buuren, Stef van, and Karin Groothuis-Oudshoorn. ‘Mice: Multivariate Imputation by Chained Equations in R’. 
Journal of Statistical Software 45, no. 1 (12 December 2011): 1–67. https://doi.org/10.18637/jss.v045.i03.

[3] Graham, John W. "Missing data analysis: Making it work in the real world." Annual review of psychology 60.1 
(2009): 549-576. https://www.personal.psu.edu/jxb14/M554/articles/Graham2009.pdf
```

### 完整中文翻译

链式方程多重插补: key references
[1] Azur, Melissa J., Elizabeth A. Stuart, Constantine Frangakis, and Philip J. Leaf. ‘Multiple 插补 by Chained
Equations: What Is It and How Does It Work?’ International Journal of Methods in Psychiatric Research 20, no. 1 (24
参考链接：February 2011): 40–49. https://doi.org/10.1002/mpr.329.
[2] Buuren, Stef van, and Karin Groothuis-Oudshoorn. ‘链式方程多重插补: Multivariate 插补 by Chained Equations in R’.
参考链接：Journal of Statistical Software 45, no. 1 (12 December 2011): 1–67. https://doi.org/10.18637/jss.v045.i03.
[3] Graham, John W. "缺失数据 analysis: Making it work in the real world." Annual review of psychology 60.1
参考链接：(2009): 549-576. https://www.personal.psu.edu/jxb14/M554/articles/Graham2009.pdf

### 中文释义

本页围绕“MICE: key references”展开。课件中的关键信息包括：链式方程多重插补: key references；[1] Azur, Melissa J., Elizabeth A. Stuart, Constantine Frangakis, and Philip J. Leaf. ‘Multiple 插补 by Chained；Equations: What Is It and How Does It Work?’ International Journal of Methods in Psychiatric Research 20, no. 1 (24；参考链接：February 2011): 40–49. https://doi.org/10.1002/mpr.329.。复习时先抓住插补：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'MICE: key references'. The slide includes: MICE: key references; [1] Azur, Melissa J., Elizabeth A. Stuart, Constantine Frangakis, and Philip J. Leaf. ‘Multiple Imputation by Chained; Equations: What Is It and How Does It Work?’ International Journal of Methods in Psychiatric Research 20, no. 1 (24; February 2011): 40–49. https://doi.org/10.1002/mpr.329.. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **imputation / 插补**：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。
- **MICE / MICE**：链式方程多重插补，用多个回归模型迭代估计表中各列缺失值。

拓展复习：把“MICE: key references”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 14 页的核心主题是什么？
**答：** 本页围绕“MICE: key references”展开。课件中的关键信息包括：链式方程多重插补: key references；[1] Azur, Melissa J., Elizabeth A. Stuart, Constantine Frangakis, and Philip J. Leaf. ‘Multiple 插补 by Chained；Equations: What Is It and How Does It Work?’ International Journal of Methods in Psychiatric Research 20, no. 1 (24；参考链接：February 2011): 40–49. https://doi.org/10.1002/mpr.329.。复习时先抓住插补：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 14?
**Answer:** This page presents 'MICE: key references'. The slide includes: MICE: key references; [1] Azur, Melissa J., Elizabeth A. Stuart, Constantine Frangakis, and Philip J. Leaf. ‘Multiple Imputation by Chained; Equations: What Is It and How Does It Work?’ International Journal of Methods in Psychiatric Research 20, no. 1 (24; February 2011): 40–49. https://doi.org/10.1002/mpr.329.. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：插补 / imputation
**答：** 用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。
**Q2 English:** Explain the concept on this page: imputation
**Answer:** The page focuses on imputation. This page presents 'MICE: key references'. The slide includes: MICE: key references; [1] Azur, Melissa J., Elizabeth A. Stuart, Constantine Frangakis, and Philip J. Leaf. ‘Multiple Imputation by Chained; Equations: What Is It and How Does It Work?’ International Journal of Methods in Psychiatric Research 20, no. 1 (24; February 2011): 40–49. https://doi.org/10.1002/mpr.329.. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

## 第 15 页：The 链式方程多重插补 approach

Source ID: `src-8d8a776bac61-pdf_page-00015`

![PDF page 15](../assets/pages/page_015.jpg)

### 原文 / Original Text

```text
The MICE approach

Suppose you only have three variables A, B, C.

Start by a simple imputation of each of the missing values. - for example, the mean. These values are 
“place holders” as they will be replaced

Inner loop
1. Select one variable, say A, and build a regression model to predict A given B and C

Note: the model may not include all remaining variables

2. Use predictions from the model to impute the missing values in A
Repeat steps 1, 2 by choosing another variable (B or C in this example)

At the end of this loop, all missing variables have been imputed.

Outer loop:
Repeat the inner loop until the imputed values become stable – or a fixed number of iterations (10)
```

### 完整中文翻译

The 链式方程多重插补 approach
Suppose you only have three variables A, B, C.
Start by a simple 插补 of each of the 缺失值. - for example, the mean. These values are
“place holders” as they will be replaced
Inner loop
1. Select one variable, say A, and build a 回归 model to predict A given B and C
Note: the model may not include all remaining variables
2. Use predictions from the model to impute the 缺失值 in A
Repeat steps 1, 2 by choosing another variable (B or C in this example)
At the end of this loop, all 缺失 variables have been imputed.
Outer loop:
Repeat the inner loop until the imputed values become stable – or a fixed number of iterations (10)

### 中文释义

本页围绕“The MICE approach”展开。课件中的关键信息包括：The 链式方程多重插补 approach；Suppose you only have three variables A, B, C.；Start by a simple 插补 of each of the 缺失值. - for example, the mean. These values are；“place holders” as they will be replaced。复习时先抓住插补：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'The MICE approach'. The slide includes: The MICE approach; Suppose you only have three variables A, B, C.; Start by a simple imputation of each of the missing values. - for example, the mean. These values are; “place holders” as they will be replaced. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **imputation / 插补**：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。
- **MICE / MICE**：链式方程多重插补，用多个回归模型迭代估计表中各列缺失值。

拓展复习：把“The MICE approach”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 15 页的核心主题是什么？
**答：** 本页围绕“The MICE approach”展开。课件中的关键信息包括：The 链式方程多重插补 approach；Suppose you only have three variables A, B, C.；Start by a simple 插补 of each of the 缺失值. - for example, the mean. These values are；“place holders” as they will be replaced。复习时先抓住插补：用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 15?
**Answer:** This page presents 'The MICE approach'. The slide includes: The MICE approach; Suppose you only have three variables A, B, C.; Start by a simple imputation of each of the missing values. - for example, the mean. These values are; “place holders” as they will be replaced. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：插补 / imputation
**答：** 用统计量、邻近样本或模型估计缺失值；错误插补会引入偏差。
**Q2 English:** Explain the concept on this page: imputation
**Answer:** The page focuses on imputation. This page presents 'The MICE approach'. The slide includes: The MICE approach; Suppose you only have three variables A, B, C.; Start by a simple imputation of each of the missing values. - for example, the mean. These values are; “place holders” as they will be replaced. The revision focus is imputation; connect its definition, evidence, and use to the examples on the page.

## 第 16 页：The 链式方程多重插补 approach

Source ID: `src-8d8a776bac61-pdf_page-00016`

![PDF page 16](../assets/pages/page_016.jpg)

### 原文 / Original Text

```text
The MICE approach
```

### 完整中文翻译

The 链式方程多重插补 approach

### 中文释义

本页围绕“The MICE approach”展开。课件中的关键信息包括：The 链式方程多重插补 approach。复习时先抓住MICE：链式方程多重插补，用多个回归模型迭代估计表中各列缺失值。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'The MICE approach'. The slide includes: The MICE approach. The revision focus is MICE; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **MICE / MICE**：链式方程多重插补，用多个回归模型迭代估计表中各列缺失值。

拓展复习：把“The MICE approach”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 16 页的核心主题是什么？
**答：** 本页围绕“The MICE approach”展开。课件中的关键信息包括：The 链式方程多重插补 approach。复习时先抓住MICE：链式方程多重插补，用多个回归模型迭代估计表中各列缺失值。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 16?
**Answer:** This page presents 'The MICE approach'. The slide includes: The MICE approach. The revision focus is MICE; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：MICE / MICE
**答：** 链式方程多重插补，用多个回归模型迭代估计表中各列缺失值。
**Q2 English:** Explain the concept on this page: MICE
**Answer:** The page focuses on MICE. This page presents 'The MICE approach'. The slide includes: The MICE approach. The revision focus is MICE; connect its definition, evidence, and use to the examples on the page.

## 第 17 页：Issue: Out-of-Range / Physically Impossible Values

Source ID: `src-8d8a776bac61-pdf_page-00017`

![PDF page 17](../assets/pages/page_017.jpg)

### 原文 / Original Text

```text
Issue: Out-of-Range / Physically Impossible Values

Values that pass NULL checks but violate physical or business constraints. They are present but wrong.

Column
fare_amount
fare_amount
trip_distance
trip_distance
passenger_count
trip_duration
trip_duration

Impossible Value
−$12.50
$8,900
0.00 miles
847 miles
0
−5 mins
18 hours

Physical Reason
Fare cannot be negative
Exceeds any plausible NYC fare
A completed trip has distance > 0
No NYC trip crosses state lines
At least 1 passenger per trip
Dropoff before pickup
Meter left running overnight

These values pass schema validation but 
semantically implausible

Out-of-range values are not detectable 
from the schema alone

— the model learns a wrong 
baseline

zero distances: speed = distance/time --> NaN or Inf
```

### 完整中文翻译

Issue: Out-of-Range / Physically Impossible Values
Values that pass 空值 checks but violate physical or business constraints. They are present but wrong.
Column
fare_amount
fare_amount
trip_distance
trip_distance
passenger_count
trip_duration
trip_duration
Impossible Value
−$12.50
$8,900
0.00 miles
847 miles
0
−5 mins
18 hours
Physical Reason
Fare cannot be negative
Exceeds any plausible NYC fare
A completed trip has distance > 0
No NYC trip crosses state 直线
At least 1 passenger per trip
Dropoff before pickup
Meter left running overnight
These values pass 模式/表结构 validation but
语义问题ally implausible
超出范围的值 are not detectable
from the 模式/表结构 alone
— the model learns a wrong
baseline
zero distances: speed = distance/time --> NaN or Inf

### 中文释义

本页围绕“Issue: Out-of-Range / Physically Impossible Values”展开。课件中的关键信息包括：Issue: Out-of-Range / Physically Impossible Values；Values that pass 空值 checks but violate physical or business constraints. They are present but wrong.；Column；fare_amount。复习时先抓住模式：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Issue: Out-of-Range / Physically Impossible Values'. The slide includes: Issue: Out-of-Range / Physically Impossible Values; Values that pass NULL checks but violate physical or business constraints. They are present but wrong.; Column; fare_amount. The revision focus is Schema; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Schema / 模式**：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。

拓展复习：把“Issue: Out-of-Range / Physically Impossible Values”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 17 页的核心主题是什么？
**答：** 本页围绕“Issue: Out-of-Range / Physically Impossible Values”展开。课件中的关键信息包括：Issue: Out-of-Range / Physically Impossible Values；Values that pass 空值 checks but violate physical or business constraints. They are present but wrong.；Column；fare_amount。复习时先抓住模式：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 17?
**Answer:** This page presents 'Issue: Out-of-Range / Physically Impossible Values'. The slide includes: Issue: Out-of-Range / Physically Impossible Values; Values that pass NULL checks but violate physical or business constraints. They are present but wrong.; Column; fare_amount. The revision focus is Schema; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：模式 / Schema
**答：** 表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。
**Q2 English:** Explain the concept on this page: Schema
**Answer:** The page focuses on Schema. This page presents 'Issue: Out-of-Range / Physically Impossible Values'. The slide includes: Issue: Out-of-Range / Physically Impossible Values; Values that pass NULL checks but violate physical or business constraints. They are present but wrong.; Column; fare_amount. The revision focus is Schema; connect its definition, evidence, and use to the examples on the page.

## 第 18 页：Handling 重复记录

Source ID: `src-8d8a776bac61-pdf_page-00018`

![PDF page 18](../assets/pages/page_018.jpg)

### 原文 / Original Text

```text
Handling Duplicate Records

- The same real-world event appears more than once.
- Duplicates inflate counts, bias aggregations, and leaks training rows into the test set.

Exact duplicates: every column is identical
-

Typically caused by double-ingestion (ETL retry)

Why They Cause ML Failures

• If a duplicate row appears in both train and test sets, the model “memorises” it — test 

accuracy is artificially inflated

• Count aggregations (trips per hour, demand forecasting) are systematically wrong

• Fare total inflated in revenue reports
```

### 完整中文翻译

Handling 重复记录
- The same real-world event appears more than once.
- Duplicates inflate counts, bias aggregations, and leaks training rows into the test set.
Exact duplicates: every column is identical
-
Typically caused by double-ingestion (ETL retry)
Why They Cause 机器学习 Failures
• If a duplicate row appears in both train and test sets, the model “memorises” it — test
accuracy is artificially inflated
• Count aggregations (trips per hour, demand forecasting) are systematically wrong
• Fare total inflated in revenue reports

### 中文释义

本页围绕“Handling Duplicate Records”展开。课件中的关键信息包括：Handling 重复记录；- The same real-world event appears more than once.；- Duplicates inflate counts, bias aggregations, and leaks training rows into the test set.；Exact duplicates: every column is identical。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Handling Duplicate Records'. The slide includes: Handling Duplicate Records; - The same real-world event appears more than once.; - Duplicates inflate counts, bias aggregations, and leaks training rows into the test set.; Exact duplicates: every column is identical. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“Handling Duplicate Records”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 18 页的核心主题是什么？
**答：** 本页围绕“Handling Duplicate Records”展开。课件中的关键信息包括：Handling 重复记录；- The same real-world event appears more than once.；- Duplicates inflate counts, bias aggregations, and leaks training rows into the test set.；Exact duplicates: every column is identical。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 18?
**Answer:** This page presents 'Handling Duplicate Records'. The slide includes: Handling Duplicate Records; - The same real-world event appears more than once.; - Duplicates inflate counts, bias aggregations, and leaks training rows into the test set.; Exact duplicates: every column is identical. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'Handling Duplicate Records'. The slide includes: Handling Duplicate Records; - The same real-world event appears more than once.; - Duplicates inflate counts, bias aggregations, and leaks training rows into the test set.; Exact duplicates: every column is identical. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

## 第 19 页：Near-duplicates

Source ID: `src-8d8a776bac61-pdf_page-00019`

![PDF page 19](../assets/pages/page_019.jpg)

### 原文 / Original Text

```text
Near-duplicates

Ex: same pickup/dropoff location and overlapping times, minor column differences
–one record has a tip and one does not

Field
pickup_datetime
dropoff_datetime
pickup_location_id
dropoff_location_id
fare_amount
tip_amount
total_amount

Record A
08:32:00
08:47:00
132
79
$12.50
$2.00
$14.50

Record B
08:32:00
08:47:00
132
79
$12.50
$0.00
$12.50

Same trip — tip recorded in one system, not the other.
Neither record is wrong in isolation.
```

### 完整中文翻译

Near-duplicates
Ex: same pickup/dropoff location and overlapping times, minor column differences
–one record has a tip and one does not
Field
pickup_datetime
dropoff_datetime
pickup_location_id
dropoff_location_id
fare_amount
tip_amount
total_amount
Record A
08:32:00
08:47:00
132
79
$12.50
$2.00
$14.50
Record B
08:32:00
08:47:00
132
79
$12.50
$0.00
$12.50
Same trip — tip recorded in one system, not the other.
Neither record is wrong in isolation.

### 中文释义

本页围绕“Near-duplicates”展开。课件中的关键信息包括：Near-duplicates；Ex: same pickup/dropoff location and overlapping times, minor column differences；–one record has a tip and one does not；Field。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Near-duplicates'. The slide includes: Near-duplicates; Ex: same pickup/dropoff location and overlapping times, minor column differences; –one record has a tip and one does not; Field. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“Near-duplicates”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 19 页的核心主题是什么？
**答：** 本页围绕“Near-duplicates”展开。课件中的关键信息包括：Near-duplicates；Ex: same pickup/dropoff location and overlapping times, minor column differences；–one record has a tip and one does not；Field。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 19?
**Answer:** This page presents 'Near-duplicates'. The slide includes: Near-duplicates; Ex: same pickup/dropoff location and overlapping times, minor column differences; –one record has a tip and one does not; Field. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'Near-duplicates'. The slide includes: Near-duplicates; Ex: same pickup/dropoff location and overlapping times, minor column differences; –one record has a tip and one does not; Field. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

## 第 20 页：Canonical Mapping: values to labels

Source ID: `src-8d8a776bac61-pdf_page-00020`

![PDF page 20](../assets/pages/page_020.jpg)

### 原文 / Original Text

```text
Canonical Mapping: values to labels

Replace all raw encodings with a controlled vocabulary using an explicit, documented mapping. 

Raw Value(s)
1, 1.0
2, 2.0
3, 3.0
4, 4.0
99, NULL, other

Canonical Label
credit_card
cash
no_charge
dispute
unknown

Reason
Both encode same concept
—
—
—
Preserve as signal

trips = trips.withColumn(
"payment_type_label",

F.when(F.col("payment_type").isin(1, 1.0), "credit_card")
.when(F.col("payment_type").isin(2, 2.0), "cash")

.when(F.col("payment_type").isin(3, 3.0), "no_charge")

.when(F.col("payment_type").isin(4, 4.0), "dispute")
.otherwise("unknown")
```

### 完整中文翻译

Canonical Mapping: values to labels
Replace all raw encodings with a controlled vocabulary using an explicit, documented mapping.
Raw Value(s)
1, 1.0
2, 2.0
3, 3.0
4, 4.0
99, 空值, other
Canonical Label
credit_card
cash
no_charge
dispute
unknown
Reason
Both encode same concept
—
—
—
Preserve as signal
trips = trips.withColumn(
"payment_type_label",
F.when(F.col("payment_type").isin(1, 1.0), "credit_card")
.when(F.col("payment_type").isin(2, 2.0), "cash")
.when(F.col("payment_type").isin(3, 3.0), "no_charge")
.when(F.col("payment_type").isin(4, 4.0), "dispute")
.otherwise("unknown")

### 中文释义

本页围绕“Canonical Mapping: values to labels”展开。课件中的关键信息包括：Canonical Mapping: values to labels；Replace all raw encodings with a controlled vocabulary using an explicit, documented mapping.；Raw Value(s)；1, 1.0。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Canonical Mapping: values to labels'. The slide includes: Canonical Mapping: values to labels; Replace all raw encodings with a controlled vocabulary using an explicit, documented mapping.; Raw Value(s); 1, 1.0. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“Canonical Mapping: values to labels”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 20 页的核心主题是什么？
**答：** 本页围绕“Canonical Mapping: values to labels”展开。课件中的关键信息包括：Canonical Mapping: values to labels；Replace all raw encodings with a controlled vocabulary using an explicit, documented mapping.；Raw Value(s)；1, 1.0。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 20?
**Answer:** This page presents 'Canonical Mapping: values to labels'. The slide includes: Canonical Mapping: values to labels; Replace all raw encodings with a controlled vocabulary using an explicit, documented mapping.; Raw Value(s); 1, 1.0. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'Canonical Mapping: values to labels'. The slide includes: Canonical Mapping: values to labels; Replace all raw encodings with a controlled vocabulary using an explicit, documented mapping.; Raw Value(s); 1, 1.0. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

## 第 21 页：Canonical Mapping: values to labels

Source ID: `src-8d8a776bac61-pdf_page-00021`

![PDF page 21](../assets/pages/page_021.jpg)

### 原文 / Original Text

```text
Canonical Mapping: values to labels

Discover all distinct values first: groupBy(col).count() reveals every encoding variant — never 
assume you know them in advance.

Define the mapping as a data contract: version-controlled, shared across all notebooks. 
Updating it in one place propagates everywhere.

Never use otherwise(null): unknown codes carry information ("something went wrong"). A 
named "unknown" label preserves that signal.

Verify after mapping: re-run groupBy on the new column. The result should contain only the 
expected canonical labels.
```

### 完整中文翻译

Canonical Mapping: values to labels
Discover all distinct values first: groupBy(col).count() reveals every encoding variant — never
assume you know them in advance.
Define the mapping as a data contract: version-controlled, shared across all notebooks.
Updating it in one place propagates everywhere.
Never use otherwise(空值): unknown codes carry information ("something went wrong"). A
named "unknown" label preserves that signal.
Verify after mapping: re-run groupBy on the new column. The result should contain only the
expected canonical labels.

### 中文释义

本页围绕“Canonical Mapping: values to labels”展开。课件中的关键信息包括：Canonical Mapping: values to labels；Discover all distinct values first: groupBy(col).count() reveals every encoding variant — never；assume you know them in advance.；Define the mapping as a data contract: version-controlled, shared across all notebooks.。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Canonical Mapping: values to labels'. The slide includes: Canonical Mapping: values to labels; Discover all distinct values first: groupBy(col).count() reveals every encoding variant — never; assume you know them in advance.; Define the mapping as a data contract: version-controlled, shared across all notebooks.. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“Canonical Mapping: values to labels”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 21 页的核心主题是什么？
**答：** 本页围绕“Canonical Mapping: values to labels”展开。课件中的关键信息包括：Canonical Mapping: values to labels；Discover all distinct values first: groupBy(col).count() reveals every encoding variant — never；assume you know them in advance.；Define the mapping as a data contract: version-controlled, shared across all notebooks.。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 21?
**Answer:** This page presents 'Canonical Mapping: values to labels'. The slide includes: Canonical Mapping: values to labels; Discover all distinct values first: groupBy(col).count() reveals every encoding variant — never; assume you know them in advance.; Define the mapping as a data contract: version-controlled, shared across all notebooks.. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'Canonical Mapping: values to labels'. The slide includes: Canonical Mapping: values to labels; Discover all distinct values first: groupBy(col).count() reveals every encoding variant — never; assume you know them in advance.; Define the mapping as a data contract: version-controlled, shared across all notebooks.. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

## 第 22 页：Issue: 偏斜分布

Source ID: `src-8d8a776bac61-pdf_page-00022`

![PDF page 22](../assets/pages/page_022.jpg)

### 原文 / Original Text

```text
Issue: Skewed Distributions

A feature's values are heavily concentrated at one end.
Linear models assume approximate normality — a skewed input produces a biased model

fare_amount Distribution (Taxi Dataset)

$0–$5
$5–$15
$15–$30
$30–$100
>$100
Skewness ≈ +4.2 (strongly right-skewed). The mean ($12.80) 
is pulled far above the median ($9.50) by airport fares.

45%
38%
12%
4%
1%

Note: The transform matters most for linear models and neural networks.
```

### 完整中文翻译

Issue: 偏斜分布
A 特征's values are heavily concentrated at one end.
Linear models assume approximate normality — a skewed input produces a biased model
fare_amount Distribution (Taxi Dataset)
$0–$5
$5–$15
$15–$30
$30–$100
>$100
Skewness ≈ +4.2 (strongly right-skewed). The mean ($12.80)
is pulled far above the median ($9.50) by airport fares.
45%
38%
12%
4%
1%
Note: The transform matters most for linear models and neural networks.

### 中文释义

本页围绕“Issue: Skewed Distributions”展开。课件中的关键信息包括：Issue: 偏斜分布；A 特征's values are heavily concentrated at one end.；Linear models assume approximate normality — a skewed input produces a biased model；fare_amount Distribution (Taxi Dataset)。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Issue: Skewed Distributions'. The slide includes: Issue: Skewed Distributions; A feature's values are heavily concentrated at one end.; Linear models assume approximate normality — a skewed input produces a biased model; fare_amount Distribution (Taxi Dataset). The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“Issue: Skewed Distributions”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 22 页的核心主题是什么？
**答：** 本页围绕“Issue: Skewed Distributions”展开。课件中的关键信息包括：Issue: 偏斜分布；A 特征's values are heavily concentrated at one end.；Linear models assume approximate normality — a skewed input produces a biased model；fare_amount Distribution (Taxi Dataset)。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 22?
**Answer:** This page presents 'Issue: Skewed Distributions'. The slide includes: Issue: Skewed Distributions; A feature's values are heavily concentrated at one end.; Linear models assume approximate normality — a skewed input produces a biased model; fare_amount Distribution (Taxi Dataset). The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'Issue: Skewed Distributions'. The slide includes: Issue: Skewed Distributions; A feature's values are heavily concentrated at one end.; Linear models assume approximate normality — a skewed input produces a biased model; fare_amount Distribution (Taxi Dataset). The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

## 第 23 页：Log Transformations Reduce Skew

Source ID: `src-8d8a776bac61-pdf_page-00023`

![PDF page 23](../assets/pages/page_023.jpg)

### 原文 / Original Text

```text
Log Transformations Reduce Skew

Apply log(1 + x) to compress the right tail, making the distribution approximately symmetric.
Inverse with exp(x) − 1 to recover original units.

Before vs After — Skewness

Column
fare_amount
trip_distance
trip_duration_mins

Raw Skewness After log1p
+4.2
+6.1
+3.8

+0.4
+0.3
+0.2

trips = (trips

.withColumn("log_fare",

F.log1p(F.col("fare_amount")))

.withColumn("log_distance",

F.log1p(F.col("trip_distance")))

# Recover original scale after prediction:

predictions.withColumn("predicted_fare",

F.expm1(F.col("log_prediction")))
```

### 完整中文翻译

Log Transformations Reduce Skew
Apply log(1 + x) to compress the right tail, making the distribution approximately symmetric.
Inverse with exp(x) − 1 to recover original units.
Before vs After — Skewness
Column
fare_amount
trip_distance
trip_duration_mins
Raw Skewness After log1p
+4.2
+6.1
+3.8
+0.4
+0.3
+0.2
trips = (trips
.withColumn("log_fare",
F.log1p(F.col("fare_amount")))
.withColumn("log_distance",
F.log1p(F.col("trip_distance")))
# Recover original scale after prediction:
predictions.withColumn("predicted_fare",
F.expm1(F.col("log_prediction")))

### 中文释义

本页围绕“Log Transformations Reduce Skew”展开。课件中的关键信息包括：Log Transformations Reduce Skew；Apply log(1 + x) to compress the right tail, making the distribution approximately symmetric.；Inverse with exp(x) − 1 to recover original units.；Before vs After — Skewness。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Log Transformations Reduce Skew'. The slide includes: Log Transformations Reduce Skew; Apply log(1 + x) to compress the right tail, making the distribution approximately symmetric.; Inverse with exp(x) − 1 to recover original units.; Before vs After — Skewness. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“Log Transformations Reduce Skew”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 23 页的核心主题是什么？
**答：** 本页围绕“Log Transformations Reduce Skew”展开。课件中的关键信息包括：Log Transformations Reduce Skew；Apply log(1 + x) to compress the right tail, making the distribution approximately symmetric.；Inverse with exp(x) − 1 to recover original units.；Before vs After — Skewness。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 23?
**Answer:** This page presents 'Log Transformations Reduce Skew'. The slide includes: Log Transformations Reduce Skew; Apply log(1 + x) to compress the right tail, making the distribution approximately symmetric.; Inverse with exp(x) − 1 to recover original units.; Before vs After — Skewness. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'Log Transformations Reduce Skew'. The slide includes: Log Transformations Reduce Skew; Apply log(1 + x) to compress the right tail, making the distribution approximately symmetric.; Inverse with exp(x) − 1 to recover original units.; Before vs After — Skewness. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

## 第 24 页：Handling 类别不平衡

Source ID: `src-8d8a776bac61-pdf_page-00024`

![PDF page 24](../assets/pages/page_024.jpg)

### 原文 / Original Text

```text
Handling Class Imbalance

One class vastly outnumbers the other
A classifier that predicts the majority class on every row achieves high accuracy but zero utility.

Task: predict whether tip_amount > 20% of 
fare_amount.

Geographic skew: airport trips (JFK, LGA) have 
systemically higher tips.
Manhattan short trips have lower tips

Low tip (0)
High tip (1)

82%
18%

High-Tip Classification

Naïve classifier (predict 0) Value
Accuracy
Recall (class 1)

82%
0%

F1 score

0.00

Note
Looks good — is useless
Never detects a high tip
True measure of 
uselessness
```

### 完整中文翻译

Handling 类别不平衡
One class vastly outnumbers the other
A classifier that predicts the majority class on every row achieves high accuracy but zero utility.
Task: predict whether tip_amount > 20% of
fare_amount.
Geographic skew: airport trips (JFK, LGA) have
systemically higher tips.
Manhattan short trips have lower tips
Low tip (0)
High tip (1)
82%
18%
High-Tip 分类
Naïve classifier (predict 0) Value
Accuracy
Recall (class 1)
82%
0%
F1 score
0.00
Note
Looks good — is useless
Never detects a high tip
True measure of
uselessness

### 中文释义

本页围绕“Handling Class Imbalance”展开。课件中的关键信息包括：Handling 类别不平衡；One class vastly outnumbers the other；A classifier that predicts the majority class on every row achieves high accuracy but zero utility.；Task: predict whether tip_amount > 20% of。复习时先抓住类别不平衡：多数类远多于少数类，准确率会误导模型评估。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Handling Class Imbalance'. The slide includes: Handling Class Imbalance; One class vastly outnumbers the other; A classifier that predicts the majority class on every row achieves high accuracy but zero utility.; Task: predict whether tip_amount > 20% of. The revision focus is class imbalance; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **class imbalance / 类别不平衡**：多数类远多于少数类，准确率会误导模型评估。
- **classification / 分类**：预测离散类别标签，例如图像类别或手写数字。

拓展复习：把“Handling Class Imbalance”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 24 页的核心主题是什么？
**答：** 本页围绕“Handling Class Imbalance”展开。课件中的关键信息包括：Handling 类别不平衡；One class vastly outnumbers the other；A classifier that predicts the majority class on every row achieves high accuracy but zero utility.；Task: predict whether tip_amount > 20% of。复习时先抓住类别不平衡：多数类远多于少数类，准确率会误导模型评估。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 24?
**Answer:** This page presents 'Handling Class Imbalance'. The slide includes: Handling Class Imbalance; One class vastly outnumbers the other; A classifier that predicts the majority class on every row achieves high accuracy but zero utility.; Task: predict whether tip_amount > 20% of. The revision focus is class imbalance; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：类别不平衡 / class imbalance
**答：** 多数类远多于少数类，准确率会误导模型评估。
**Q2 English:** Explain the concept on this page: class imbalance
**Answer:** The page focuses on class imbalance. This page presents 'Handling Class Imbalance'. The slide includes: Handling Class Imbalance; One class vastly outnumbers the other; A classifier that predicts the majority class on every row achieves high accuracy but zero utility.; Task: predict whether tip_amount > 20% of. The revision focus is class imbalance; connect its definition, evidence, and use to the examples on the page.

## 第 25 页：Rebalancing: undersampling strategies

Source ID: `src-8d8a776bac61-pdf_page-00025`

![PDF page 25](../assets/pages/page_025.jpg)

### 原文 / Original Text

```text
Rebalancing: undersampling strategies

Three complementary approaches
the right choice depends on dataset size and the cost of false negatives vs false positives

A — Undersampling
Randomly remove majority-
class rows until ratio reaches 
target (e.g. 1:1 or 2:1).

B — Class Weights
Keep all rows
assign higher loss weight to 
minority-class rows. No data 
removed.

Evaluation rule: never use accuracy as the primary metric on imbalanced data.
Use F1 score, AUC-ROC, or precision-recall AUC
```

### 完整中文翻译

Rebalancing: undersampling strategies
Three complementary approaches
the right choice depends on dataset size and the cost of false negatives vs false positives
A — Undersampling
Randomly remove majority-
class rows until ratio reaches
target (e.g. 1:1 or 2:1).
B — Class Weights
Keep all rows
assign higher loss weight to
minority-class rows. No data
removed.
Evaluation rule: never use accuracy as the primary metric on imbalanced data.
Use F1 score, AUC-ROC, or precision-recall AUC

### 中文释义

本页围绕“Rebalancing: undersampling strategies”展开。课件中的关键信息包括：Rebalancing: undersampling strategies；Three complementary approaches；the right choice depends on dataset size and the cost of false negatives vs false positives；A — Undersampling。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Rebalancing: undersampling strategies'. The slide includes: Rebalancing: undersampling strategies; Three complementary approaches; the right choice depends on dataset size and the cost of false negatives vs false positives; A — Undersampling. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **MAR / 随机缺失**：缺失与其他可观测变量有关，但不直接由缺失值本身决定。

拓展复习：把“Rebalancing: undersampling strategies”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 25 页的核心主题是什么？
**答：** 本页围绕“Rebalancing: undersampling strategies”展开。课件中的关键信息包括：Rebalancing: undersampling strategies；Three complementary approaches；the right choice depends on dataset size and the cost of false negatives vs false positives；A — Undersampling。复习时先抓住随机缺失：缺失与其他可观测变量有关，但不直接由缺失值本身决定。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 25?
**Answer:** This page presents 'Rebalancing: undersampling strategies'. The slide includes: Rebalancing: undersampling strategies; Three complementary approaches; the right choice depends on dataset size and the cost of false negatives vs false positives; A — Undersampling. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：随机缺失 / MAR
**答：** 缺失与其他可观测变量有关，但不直接由缺失值本身决定。
**Q2 English:** Explain the concept on this page: MAR
**Answer:** The page focuses on MAR. This page presents 'Rebalancing: undersampling strategies'. The slide includes: Rebalancing: undersampling strategies; Three complementary approaches; the right choice depends on dataset size and the cost of false negatives vs false positives; A — Undersampling. The revision focus is MAR; connect its definition, evidence, and use to the examples on the page.

## 第 26 页：数据泄漏: outcome / covariate correlations

Source ID: `src-8d8a776bac61-pdf_page-00026`

![PDF page 26](../assets/pages/page_026.jpg)

### 原文 / Original Text

```text
Data Leakage: outcome / covariate correlations

A feature available at training time contains information derived from the target
- either directly or indirectly.
The model appears excellent but fails completely in production.

Feature

total_amount

tip_amount

Leakage 
Type
Direct

Why it leaks

total = fare + tip + tolls. Contains the target.

Direct

High-tip task: tip IS the target signal.

congestion_surcharge

Indirect

Added to the fare bill

A model with R² = 0.99 on the test set but R² = 0.42 in production is almost 
always a leakage problem. The test set was contaminated with target 
information.
```

### 完整中文翻译

数据泄漏: outcome / covariate correlations
A 特征 available at training time contains information derived from the target
- either directly or indirectly.
The model appears excellent but fails completely in production.
特征
total_amount
tip_amount
Leakage
Type
Direct
Why it leaks
total = fare + tip + tolls. Contains the target.
Direct
High-tip task: tip IS the target signal.
congestion_surcharge
Indirect
Added to the fare bill
A model with R² = 0.99 on the test set but R² = 0.42 in production is almost
always a leakage problem. The test set was contaminated with target
information.

### 中文释义

本页围绕“Data Leakage: outcome / covariate correlations”展开。课件中的关键信息包括：数据泄漏: outcome / covariate correlations；A 特征 available at training time contains information derived from the target；- either directly or indirectly.；The model appears excellent but fails completely in production.。复习时先抓住数据泄漏：训练特征包含目标或生产时不可获得的信息，使测试成绩虚高。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Data Leakage: outcome / covariate correlations'. The slide includes: Data Leakage: outcome / covariate correlations; A feature available at training time contains information derived from the target; - either directly or indirectly.; The model appears excellent but fails completely in production.. The revision focus is data leakage; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **data leakage / 数据泄漏**：训练特征包含目标或生产时不可获得的信息，使测试成绩虚高。

拓展复习：把“Data Leakage: outcome / covariate correlations”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 26 页的核心主题是什么？
**答：** 本页围绕“Data Leakage: outcome / covariate correlations”展开。课件中的关键信息包括：数据泄漏: outcome / covariate correlations；A 特征 available at training time contains information derived from the target；- either directly or indirectly.；The model appears excellent but fails completely in production.。复习时先抓住数据泄漏：训练特征包含目标或生产时不可获得的信息，使测试成绩虚高。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 26?
**Answer:** This page presents 'Data Leakage: outcome / covariate correlations'. The slide includes: Data Leakage: outcome / covariate correlations; A feature available at training time contains information derived from the target; - either directly or indirectly.; The model appears excellent but fails completely in production.. The revision focus is data leakage; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据泄漏 / data leakage
**答：** 训练特征包含目标或生产时不可获得的信息，使测试成绩虚高。
**Q2 English:** Explain the concept on this page: data leakage
**Answer:** The page focuses on data leakage. This page presents 'Data Leakage: outcome / covariate correlations'. The slide includes: Data Leakage: outcome / covariate correlations; A feature available at training time contains information derived from the target; - either directly or indirectly.; The model appears excellent but fails completely in production.. The revision focus is data leakage; connect its definition, evidence, and use to the examples on the page.

## 第 27 页：Detecting & Removing Leakage

Source ID: `src-8d8a776bac61-pdf_page-00027`

![PDF page 27](../assets/pages/page_027.jpg)

### 原文 / Original Text

```text
Detecting & Removing Leakage

Feature importance check: after training, inspect the model's feature importances. If a 
feature dominates (e.g. 85% importance), investigate whether it leaks the target.

Correlation audit: compute Pearson correlation between each feature and the target. Any |r| > 
0.9 with the target is a strong leakage signal — legitimate features rarely correlate this highly.

Allowable Features — Taxi Prediction

Available at trip start?
Yes
Yes

Feature
pickup_datetime
pickup_location_id
dropoff_location_id Yes (by driver)
passenger_count
rate_code_id
tip_amount
total_amount
trip_distance

Yes
Yes
No — paid at end
No — end of trip
Partial — GPS est.

Status
✓ Safe
✓ Safe
✓ Safe
✓ Safe
✓ Safe
✗ Leaks
✗ Leaks

Careful
```

### 完整中文翻译

Detecting & Removing Leakage
特征 importance check: after training, inspect the model's 特征 importances. If a
特征 dominates (e.g. 85% importance), investigate whether it leaks the target.
Correlation audit: compute Pearson correlation between each 特征 and the target. Any |r| >
0.9 with the target is a strong leakage signal — legitimate features rarely correlate this highly.
Allowable Features — Taxi Prediction
问题：Available at trip start？
Yes
Yes
特征
pickup_datetime
pickup_location_id
dropoff_location_id Yes (by driver)
passenger_count
rate_code_id
tip_amount
total_amount
trip_distance
Yes
Yes
No — paid at end
No — end of trip
Partial — GPS est.
Status
✓ Safe
✓ Safe
✓ Safe
✓ Safe
✓ Safe
✗ Leaks
✗ Leaks
Careful

### 中文释义

本页围绕“Detecting & Removing Leakage”展开。课件中的关键信息包括：Detecting & Removing Leakage；特征 importance check: after training, inspect the model's 特征 importances. If a；特征 dominates (e.g. 85% importance), investigate whether it leaks the target.；Correlation audit: compute Pearson correlation between each 特征 and the target. Any |r| >。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Detecting & Removing Leakage'. The slide includes: Detecting & Removing Leakage; Feature importance check: after training, inspect the model's feature importances. If a; feature dominates (e.g. 85% importance), investigate whether it leaks the target.; Correlation audit: compute Pearson correlation between each feature and the target. Any |r| >. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“Detecting & Removing Leakage”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 27 页的核心主题是什么？
**答：** 本页围绕“Detecting & Removing Leakage”展开。课件中的关键信息包括：Detecting & Removing Leakage；特征 importance check: after training, inspect the model's 特征 importances. If a；特征 dominates (e.g. 85% importance), investigate whether it leaks the target.；Correlation audit: compute Pearson correlation between each 特征 and the target. Any |r| >。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 27?
**Answer:** This page presents 'Detecting & Removing Leakage'. The slide includes: Detecting & Removing Leakage; Feature importance check: after training, inspect the model's feature importances. If a; feature dominates (e.g. 85% importance), investigate whether it leaks the target.; Correlation audit: compute Pearson correlation between each feature and the target. Any |r| >. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'Detecting & Removing Leakage'. The slide includes: Detecting & Removing Leakage; Feature importance check: after training, inspect the model's feature importances. If a; feature dominates (e.g. 85% importance), investigate whether it leaks the target.; Correlation audit: compute Pearson correlation between each feature and the target. Any |r| >. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.
