# 来源：Wk1_introduction-2.pdf

<!-- SOURCE: Wk1_introduction-2.pdf -->

<!-- PDF 页 1 -->

Introduction
to the Module

[Computer Vision and Imaging]

Jianbo Jiao

School of Computer Science
University of Birmingham

E-mail: j.jiao@bham.ac.uk
Office: MLC 140

<!-- PDF 页 2 -->

Schedule

2 Lectures / week
□ Monday @ 9 – 11 AM
□ 2 hours session with break
1 Lab (Tutorial) / week
□ 3 slots (Weds, Thurs)
□ Varies, and groups will be assigned
Module webpage/resources
□ Canvas

2

<!-- PDF 页 3 -->

3

<!-- PDF 页 4 -->

Schedule

4

<!-- PDF 页 5 -->

Assessment

Exam:
□ 80%
□ Date – TBA
Continuous Assignment:
□ 20%
□ Closed-book assessment (Wk9)
□

Lab sessions

5

<!-- PDF 页 6 -->

Labs

Submit lab reports for feedback
Does not count towards the final Module mark

All labs are Python based
See Canvas pages for self-tutorial in week 1
Lab support and exercises from week 2
□

6

<!-- PDF 页 7 -->

Advance Notice

Attendance will be monitored
Lectures
□
□ And Labs

7

<!-- PDF 页 8 -->

Module Description

Learning Outcomes
□ Understand what Computer Vision is
□ Make informed choices about which sort of algorithms to 

apply to solve specific problems

□ Use standard vision libraries or software to construct 

working vision systems

□ Apply algorithms to simplified problems by hand
□ Discuss the advantages and drawbacks of different 
methods, explaining their working mechanisms

8

<!-- PDF 页 9 -->

Computer Vision 
and Imaging

Jianbo Jiao

School of Computer Science
University of Birmingham

[Computer Vision and Imaging]

<!-- PDF 页 10 -->

Computer Vision?

Robot vision
Machine Vision

Human vision

10

<!-- PDF 页 11 -->

11

https://xkcd.com/1080

<!-- PDF 页 12 -->

Computer Vision?

Robot vision
Machine Vision

12

https://xkcd.com/1444

<!-- PDF 页 13 -->

Computer Vision?

Advanced?

13

<!-- PDF 页 14 -->

Computer Vision?

Advanced?

14

<!-- PDF 页 15 -->

Computer Vision?

Advanced?

15

<!-- PDF 页 16 -->

Computer Vision?

CAPTCHA

"Completely Automated Public 

Turing test to tell Computers 

and Humans Apart"

16

https://xkcd.com/2228/

<!-- PDF 页 17 -->

Computer Vision?

17

https://xkcd.com/2228/

<!-- PDF 页 18 -->

Computer Vision?

18

https://youtu.be/OnTgbN3uXvw

<!-- PDF 页 19 -->

Reference : https://images.app.goo.gl/NhwG91feT9Sv3H9R7

Reference : https://images.app.goo.gl/3Af75r96L7MFywXJ9

Reference : https://images.app.goo.gl/CtTdZ4eCg7hmGcL76

Reference : https://pxhere.com/ko/photo/695788

Reference : https://images.app.goo.gl/8ugbqynh8mahrhqZ9

Reference : https://images.app.goo.gl/TEh6T8JWLBntMU2B9

19

<!-- PDF 页 20 -->

Computer Vision

Reference : 
https://images.app.goo.gl/ubV3CEG7n8XLagS98

“50% of our neural tissue is directly or indirectly 
related to vision, which assists in visual learning”

S.B. Sells and Richard S. Fixott, “Evaluation of Research on Effects of 
Visual Training on Visual Functions”, American Journal of Ophthalmology

Reference : https://www.pngegg.com/en/png-pvjkt

Enable machines to “see” and “understand”
the visual world as we do

20

<!-- PDF 页 21 -->

Computer Vision

Block World

Larry Roberts 1963

Reference : 
https://images.app.goo.gl/8o
TfaBHirA3AUfaB9

Reference : 
https://images.app.goo.gl/JLWX1RUKs4aKvHTC6

Reference : 
https://www.researchgate.net/publication/220695992_M
achine_Perception_of_Three-Dimensional_Solids

21

Slide credit: Hyung Jin Chang

<!-- PDF 页 22 -->

Computer Vision

Reference : https://dspace.mit.edu/bitstream/handle/1721.1/6125/AIM-100.pdf?sequence=2&isAllowed=y

22

Slide credit: Hyung Jin Chang

<!-- PDF 页 23 -->

Computer Vision

David Marr, 1970s

Reference : https://dspace.mit.edu/bitstream/handle/1721.1/6125/AIM-100.pdf?sequence=2&isAllowed=y

Reference : https://images.app.goo.gl/okGikV8SHgMkn9Y19

23

Slide credit: Hyung Jin Chang

<!-- PDF 页 24 -->

Computer Vision

24

Slide credit: Fei-Fei Li

<!-- PDF 页 25 -->

Street scene

SVM

kNN

K-means
clustering

SIFT

SURF

Deep Learning

Bus

Pedestrian

category

Plants

20m

5m

depth

25

<!-- PDF 页 26 -->

Why is Vision Difficult?

26

<!-- PDF 页 27 -->

27

<!-- PDF 页 28 -->

28

https://youtu.be/pNe6fsaCVtI

<!-- PDF 页 29 -->

29

Image credit: Bev Doolittle

<!-- PDF 页 30 -->

30

Image credit: Bev Doolittle

<!-- PDF 页 31 -->

31

Image credit: Bev Doolittle

<!-- PDF 页 32 -->

32

Image credit: Bev Doolittle

<!-- PDF 页 33 -->

33

https://en.wikipedia.org/wiki/Optical_illusion

<!-- PDF 页 34 -->

34

https://en.wikipedia.org/wiki/Optical_illusion

<!-- PDF 页 35 -->

Illumination

Object pose

Clutter

Occlusions

Intra-class appearance

Viewpoint

Slide credit: Kristen Grauman

<!-- PDF 页 36 -->

Slide credit: Svetlana Lazebnik

<!-- PDF 页 37 -->

Slide credit: Fei-Fei, Fergus, Torralba

<!-- PDF 页 38 -->

Slide credit: Fei-Fei, Fergus, Torralba

<!-- PDF 页 39 -->

Outline

What is?
Why?
How to?

39

<!-- PDF 页 40 -->

Outline

Acknowledgement

Course materials are inherited/borrowed
from or inspired by the courses given by
other great researchers in the Computer
Vision community:

Introduction to CV and ML4CV
Feature detection and DL
Low-level vision
Image Registration and Segmentation
Dimensionality Reduction and its Link to DL
High-level vision
Motion and video
Self-supervised learning and Multi-modal Learning
Generative models

o Richard Szeliski
o Geoffrey Hinton
o Yann LeCun
o Alexei A. Efros
o Fei-Fei Li
o Samuel Albanie
o Been Kim
o Hamid Dehghani
o Hyung Jin Chang
o Ales Leonardis
o etc.

40

<!-- PDF 页 41 -->

Outline

Acknowledgement

Course materials are inherited/borrowed
from or inspired by the courses given by
other great researchers in the Computer
Vision community:

Introduction to CV and ML4CV
Feature detection and DL
Low-level vision
Image Registration and Segmentation
Dimensionality Reduction and its Link to DL
High-level vision
Motion and video
Self-supervised learning and Multi-modal Learning
Generative models

o Richard Szeliski
o Geoffrey Hinton
o Yann LeCun
o Alexei A. Efros
o Fei-Fei Li
o Samuel Albanie
o Been Kim
o Hamid Dehghani
o Hyung Jin Chang
o Ales Leonardis
o etc.

https://szeliski.org/Book

https://www.deeplearningbook.org/

41

<!-- PDF 页 42 -->

The techniques should be
used for Good, instead of
the other side of the coin.

42

<!-- PDF 页 43 -->

Digital image

43

<!-- PDF 页 44 -->

How digital image is formed?

44

<!-- PDF 页 45 -->

How digital image is formed?

Kylberg, G. (2014). Automatic virus identification using TEM: Image segmentation and texture analysis (Doctoral dissertation, Acta Universitatis Upsaliensis).
Image Formation and Pinhole Model of the Camera

45

<!-- PDF 页 46 -->

How digital image is formed?

46

<!-- PDF 页 47 -->

How digital image is formed?

Dimension

0-D

1-D

2-dimensional function

Pixel value = f(x, y)

2-D

n-D …

3-D

47

<!-- PDF 页 48 -->

How digital image is formed?

Grayscale image

Colour image

f(x, y)

f(x, y, c)

f(R, G, B)

48

https://en.wikipedia.org/wiki/Grayscale; https://en.wikipedia.org/wiki/RGB_color_spaces

<!-- PDF 页 49 -->

How digital image is formed?

Colour space

49

<!-- PDF 页 50 -->

Image processing

50

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.

<!-- PDF 页 51 -->

Image processing

Colour histogram

Image filtering

Transformations

Low-level tasks

□

□

□

□

□

□

Denoising

Super-resolution

De-blurring

Image matting

Inpainting

Etc.

51

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.

<!-- PDF 页 52 -->

Image processing

Colour histogram analysis and equalisation

52

https://sg.canon/en/support/8200330600

<!-- PDF 页 53 -->

Image processing

Colour histogram analysis and equalisation

53

https://www.pixelmator.com/support/guide/pixelmator-pro/689/

<!-- PDF 页 54 -->

Image processing

Colour histogram analysis and equalisation

54

https://www.pixelmator.com/support/guide/pixelmator-pro/689/

<!-- PDF 页 55 -->

Image processing

Colour histogram analysis and equalisation

55

https://mathr.co.uk/blog/2010-12-15_histogram_equalization.html

<!-- PDF 页 56 -->

Image processing

Image filtering

56

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.

<!-- PDF 页 57 -->

Image processing

Transformations – Geometric transform

He, K., Sun, J., & Tang, X. (2012). Guided image filtering. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.

57

<!-- PDF 页 58 -->

Image processing

Transformations – Geometric transform

He, K., Sun, J., & Tang, X. (2012). Guided image filtering. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.

58

<!-- PDF 页 59 -->

Image processing
Low-level tasks – image denoising

Mara, M., McGuire, M., Bitterli, B., & Jarosz, W. (2017). An efficient denoising algorithm for global illumination. High Performance Graphics, 10, 3105762-3105774.

59

<!-- PDF 页 60 -->

Image processing
Low-level tasks – image denoising

Image denoising is the process of removing noise from images

𝐼’ = 𝐼! + 𝑛

Observation, i.e. 
noisy image

noise

Latent clean image

ill-posed

60

<!-- PDF 页 61 -->

Image processing

Low-level tasks – image super-resolution (SR)

He, K., Sun, J., & Tang, X. (2012). Guided image filtering. IEEE transactions on pattern analysis and machine intelligence, 35(6), 1397-1409.

61

<!-- PDF 页 62 -->

Image processing

Low-level tasks – image super-resolution (SR)

Lai, Wei-Sheng, et al. "Fast and accurate image super-resolution with deep laplacian pyramid networks." IEEE transactions on pattern analysis and machine intelligence 41.11 (2018): 2599-2613.

62

<!-- PDF 页 63 -->

Image processing

Low-level tasks – image super-resolution (SR)

Grant-Jacob, James A., et al. "A neural lens for super-resolution biological imaging." Journal of Physics Communications 3.6 (2019): 065004.

63

<!-- PDF 页 64 -->

Image processing
Low-level tasks – image de-blur

• Shaky camera

• Wrong focus

• Etc.

64

https://knowtechie.com/deblur-photos-online-ease/

<!-- PDF 页 65 -->

Image processing
Low-level tasks – image matting

https://www.befunky.com/learn/automatic-background-remover/; https://www.youtube.com/watch?v=rUo0wuVyefU

65

<!-- PDF 页 66 -->

Image processing
Low-level tasks – image matting

https://www.befunky.com/learn/automatic-background-remover/; https://www.youtube.com/watch?v=rUo0wuVyefU

66

<!-- PDF 页 67 -->

Image processing
Low-level tasks – image inpainting

Liu, Guilin, et al. "Image inpainting for irregular holes using partial convolutions." Proceedings of the European conference on computer vision (ECCV). 2018.

67

<!-- PDF 页 68 -->

Image processing
Low-level tasks – image inpainting

Huang, Jia-Bin, et al. "Temporally coherent completion of dynamic video." ACM Transactions on Graphics (TOG) 35.6 (2016): 1-11.

68

<!-- PDF 页 69 -->

Machine Learning?

Deep Learning?

What?

How?

69

https://xkcd.com/1838

<!-- PDF 页 70 -->

Machine learning

70

https://youtu.be/PeMlggyqz0Y

<!-- PDF 页 71 -->

Machine learning – categories

Supervised learning

Ø Labeled data

Ø Predict outcome/future

Classification
predict categorical 
class labels
e.g. the handwritten 
digit (multi-class)

Regression
Prediction of continuous 
outcomes
e.g. students’ grade scores

71

<!-- PDF 页 72 -->

Machine learning – categories

Unsupervised learning

Ø No labels/targets

Ø Find hidden structure/insights in data

Dimensionality Reduction
reduce data sparsity
-
reduce computational cost
-

Clustering
Objectives within a cluster 
share a degree of similarity. 
e.g. product recommendation

72

<!-- PDF 页 73 -->

Machine learning – categories

Reinforcement learning

Ø Decision process

Ø Reward system

Ø Learn series of actions

Ø Applications: chess, video games, some robots, self-driving cars

73

<!-- PDF 页 74 -->

Machine learning – categories

Supervised learning

Unsupervised learning

Reinforcement learning

74

<!-- PDF 页 75 -->

Machine learning – supervised learning

Classification
predict categorical class labels

e.g. the handwritten digit (multi-
class)

75

<!-- PDF 页 76 -->

Machine learning – supervised learning

https://medium.com/analytics-vidhya/logistic-regression-from-scratch-multi-classification-with-onevsall-d5c2acf0c37c

76

<!-- PDF 页 77 -->

Machine learning – supervised learning

Regression
Prediction of continuous outcomes

e.g. students’ grade scores

77

<!-- PDF 页 78 -->

Machine learning – supervised learning

78

https://youtu.be/CtsRRUddV2s

<!-- PDF 页 79 -->

Machine learning – supervised learning

79

Google finance

<!-- PDF 页 80 -->

Machine learning – supervised learning

80

Google finance

<!-- PDF 页 81 -->

Machine learning – supervised learning

81

Google finance

<!-- PDF 页 82 -->

Machine learning – supervised learning

82

Google finance

<!-- PDF 页 83 -->

Machine learning – supervised learning

83

https://gbhat.com/machine_learning/polynomial_regression_2.html

<!-- PDF 页 84 -->

Machine learning – supervised learning

84

https://builtin.com/data-science/regression-machine-learning

<!-- PDF 页 85 -->

Machine learning – supervised learning

85

Google finance

<!-- PDF 页 86 -->

Machine learning – supervised learning

86

Google finance

<!-- PDF 页 87 -->

Machine learning – unsupervised learning

87

<!-- PDF 页 88 -->

Machine learning – unsupervised learning

https://towardsdatascience.com/supervised-vs-unsupervised-learning-in-2-minutes-72dad148f242

88

<!-- PDF 页 89 -->

Machine learning – reinforcement learning

89

https://rubikscode.net/2019/06/24/introduction-to-q-learning-with-python-and-open-ai-gym/

<!-- PDF 页 90 -->

Machine learning – reinforcement learning

Initial

After 15 minutes

After 30 minutes

90

https://deepsense.ai/what-is-reinforcement-learning-the-complete-guide/

<!-- PDF 页 91 -->

Machine learning – reinforcement learning

91

https://youtu.be/WXuK6gekU1Y?t=2841

<!-- PDF 页 92 -->

What is deep learning?
02
01

Classification

Detection

03

Matting

04

Alpha GO

05

AlphaFold

06

Healthcare

https://becominghuman.ai/building-an-image-classifier-using-deep-learning-in-python-totally-from-a-beginners-perspective-be8dbaf22dd8
https://towardsdatascience.com/deep-learning-method-for-object-detection-r-cnn-explained-ecdadd751d22?gi=51e5dd227143
https://www.befunky.com/learn/automatic-background-remover/, https://deepmind.com/research/case-studies/alphago-the-story-so-far

https://deepmind.com/blog/article/alphafold-a-solution-to-a-50-year-old-grand-challenge-in-biology,
https://stanfordmlgroup.github.io/projects/chexnet/

…

92

<!-- PDF 页 93 -->

What is deep learning?
02
01

Classification

Detection

03

Matting

04

Alpha GO

05

AlphaFold

06

Healthcare

https://becominghuman.ai/building-an-image-classifier-using-deep-learning-in-python-totally-from-a-beginners-perspective-be8dbaf22dd8
https://towardsdatascience.com/deep-learning-method-for-object-detection-r-cnn-explained-ecdadd751d22?gi=51e5dd227143
https://www.befunky.com/learn/automatic-background-remover/, https://deepmind.com/research/case-studies/alphago-the-story-so-far

https://deepmind.com/blog/article/alphafold-a-solution-to-a-50-year-old-grand-challenge-in-biology,
https://stanfordmlgroup.github.io/projects/chexnet/

…

93

<!-- PDF 页 94 -->

What is deep learning?
02
01

Classification

Detection

03

Matting

𝑓!(𝑥) = 𝑦

AlphaFold

05

06

Healthcare

…

04

Alpha GO

Prompt: Animated scene features a close-up of a short fluffy monster kneeling beside a melting red candle. The art style is 3D and 
realistic, with a focus on lighting and texture. The mood of the painting is one of wonder and curiosity, as the monster gazes at the flame 
with wide eyes and open mouth. Its pose and expression convey a sense of innocence and playfulness, as if it is exploring the world 
around it for the first time. The use of warm colors and dramatic lighting further enhances the cozy atmosphere of the image.

94

<!-- PDF 页 95 -->

Deep learning for computer vision
𝑓"(𝑥) = 𝑦

95

<!-- PDF 页 96 -->

Application to computer vision

Classification

Detection

Segmentation

Slide credit:

Low-level vision

3D vision

Vision + X

https://becominghuman.ai/building-an-image-classifier-using-deep-learning-in-python-totally-from-a-beginners-perspective-be8dbaf22dd8
https://towardsdatascience.com/deep-learning-method-for-object-detection-r-cnn-explained-ecdadd751d22?gi=51e5dd227143

https://www.befunky.com/learn/automatic-background-remover/, https://deepmind.com/research/case-studies/alphago-the-story-so-far
[J. Jiao et al. CVPR 2019], [Shubham Tulsiani 16-889: Learning for 3D Vision] [JB. Alayrac et al. NeurIPS 2020]

96

<!-- PDF 页 97 -->

Application to computer vision

Classification

Slide credit:

97

Slide credit: Samuel Albanie

<!-- PDF 页 98 -->

Application to computer vision

Detection

Localisation

Recognition

https://towardsdatascience.com/deep-learning-method-for-object-detection-r-cnn-explained-ecdadd751d22?gi=51e5dd227143

98

<!-- PDF 页 99 -->

Application to computer vision

Detection

(x, y)

W

H

Deep Neural
Network

Cat: (x, y, w, h)

Deep Neural
Network

Penguin: (x1, y1, w1, h1)
Penguin: (x2, y2, w2, h2)
…

99

Image courtesy: Sonsedska/Getty Images/iStockphoto; Laurie Goodman

<!-- PDF 页 100 -->

Application to computer vision

Segmentation

Slide credit:

100

Image credit: Fei-Fei Li et al. CS231n lecture

<!-- PDF 页 101 -->

Application to computer vision

Segmentation

Panoptic segmentation

Slide credit:

https://youtu.be/U9PAcWMX3LA

101

<!-- PDF 页 102 -->

Application to computer vision

Slide credit:

Low-level vision

Image denoising

Super-resolution

Inpainting

De-blur

colourisation

https://www.befunky.com/learn/automatic-background-remover/

Visual matting

…

102

<!-- PDF 页 103 -->

Application to computer vision

Low-level vision

Super-resolution

Slide credit:

Lai, Wei-Sheng, et al. "Fast and accurate image super-resolution with deep laplacian pyramid networks." IEEE transactions on pattern analysis and machine intelligence 41.11 (2018): 2599-2613.

103

<!-- PDF 页 104 -->

Application to computer vision

Low-level vision

Super-resolution

Slide credit:

https://youtu.be/ONZcjs1Pjmk?t=198

104

Wu, Hao-Yu, et al. "Eulerian video magnification for revealing subtle changes in the world." ACM transactions on graphics (TOG) 31.4 (2012): 1-8.

<!-- PDF 页 105 -->

Application to computer vision

3D vision

Slide credit:

Shubham Tulsiani, 16-889: Learning for 3D Vision, Carnegie Mellon University

105

<!-- PDF 页 106 -->

Application to computer vision

3D vision

Neural Radiance Field

Slide credit:

Mildenhall, B., et al. "Representing scenes as neural radiance fields for view synthesis." Proc. of European Conference on Computer Vision, Virtual. 2020.

106

<!-- PDF 页 107 -->

Application to computer vision

3D vision

3D Gaussian Splatting

Slide credit:

107

https://youtu.be/Tnij_xHEnXc

<!-- PDF 页 108 -->

Application to computer vision

Vision + X

Slide credit:

[Alayrac, Jean-Baptiste, et al. "Self-supervised multimodal versatile networks." Advances in Neural Information Processing Systems 33 (2020): 25-37.]

108

<!-- PDF 页 109 -->

Application to computer vision

Vision + X

X = language

https://openai.com/dall-e-2/

Slide credit:

109

<!-- PDF 页 110 -->

Application to computer vision

Vision + X

X = language

https://openai.com/dall-e-3/

Slide credit:

110

<!-- PDF 页 111 -->

Application to computer vision

Vision + X

X = language

https://openai.com/sora/

Slide credit:

111

<!-- PDF 页 112 -->

Top conferences and journals

Conferences

• CVPR (International Conference on Computer Vision

and Pattern Recognition)

•

ICCV (International Conference on Computer Vision)

• ECCV (European Conference on Computer Vision)

113

<!-- PDF 页 113 -->

Top conferences and journals

Conferences

• CVPR 2024

114

<!-- PDF 页 114 -->

Top conferences and journals

Conferences

•

ICCV 2025

115

<!-- PDF 页 115 -->

Top conferences and journals

Conferences

• ECCV 2026

116

<!-- PDF 页 116 -->

Top conferences and journals

Journals

•

IEEE T-PAMI (Transactions on Pattern Recognition and
Machine Intelligence)

• Springer IJCV (International Journal on Computer Vision)

• TMLR (Transactions on Machine Learning Research)📝📢

•

IEEE T-CSVT 📝📢

• Springer TVCJ 📝📢

117

<!-- PDF 页 117 -->

Summary

Computer Vision
□ Basics
□ What it can do

Machine learning
□ Basics
□ Deep learning in computer vision

<!-- PDF 页 118 -->

Q & A
