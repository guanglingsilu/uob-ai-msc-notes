# 来源：W01_L02_Ingredients_of_an_Intelligent_Interactive_System_v5_novideo.pdf

<!-- SOURCE: W01_L02_Ingredients_of_an_Intelligent_Interactive_System_v5_novideo.pdf -->

<!-- PDF 页 1 -->

Ingredients of an 
Intelligent Interactive 
Systems

Intelligent Interactive Systems  ·  Week 1  ·  Lecture 02
University of Birmingham

We will open the system and follow its interaction 
with a person.

• Apply the working definition to a system.

• Walk the spine to trace a failure to its layer.

<!-- PDF 页 2 -->

The mis-cropped page

Lecture 02 · Hook

A bad crop gives us a concrete failure to investigate.

• Your phone finds a page and crops it, but this 
scan includes a strip of table along one edge.

• For Interaction 1, vote for the layer responsible: 

sensing, context, model, action or feedback.

• Keep your first answer: we will return to this page 

with a method for diagnosing the mistake.

<!-- PDF 页 3 -->

From the frame to the box

Lecture 02 · Central question

Today we move from the user’s experience to the system’s ingredients.

• Lecture 01 used initiative, inference, visibility 
and reversibility to describe what a system 
does to a person.

• Central question: what must be present for a 

system to count as both intelligent and 
interactive, and how do we look inside one?

• The conceptual spine gives us a layer-by-layer 
checklist that you can apply now and defend 
later.

<!-- PDF 页 4 -->

The working definition

Lecture 02 · Definition

Intelligence must be designed into the interaction.

• The system senses, interprets, acts and 

adapts in a loop with a person and their context.

• Its model of intent, state or preference is an 

inference: it is a best interpretation of the signals, 
and it can be wrong.

• We judge quality by what the interaction does 
for human activity, alongside model accuracy.

<!-- PDF 页 5 -->

Four properties, all required

Lecture 02 · Definition

An intelligent interactive system must satisfy all four properties.

• 1. Sensing gathers signals beyond explicit 

commands. 

• 2. Interpretation under uncertainty infers an 

intent, preference or situation that was not 
literally stated, and can be wrong.

• 3. Action through an output channel means 

the system changes its behaviour with the 
inference and reaches the person through an 
informational, spatial or physical channel.

• 4. A closed loop with a human means the 
person’s response changes what the system 
does next. All four properties must hold together.

<!-- PDF 页 6 -->

The conceptual spine at a glance

Lecture 02 · The spine

The conceptual spine is a checklist for investigating a system.

• Start with human, sensing, context, memory, 
knowledge and model: who is involved, what 
arrives, what is retained and what is inferred?

• Continue through planning, tools and action, 
environment, feedback and adaptation: what 
happens next, and how does the person’s 
response change it?

• At every connection, examine control, 

uncertainty, verification, safety, privacy and 
evaluation. Use this as an analysis tool; an 
empty layer is a meaningful finding.

<!-- PDF 页 7 -->

Layers 1 and 2: the human and sensing

Lecture 02 · The spine on the scanner

Sensing starts with the person’s goal and the signals available.

• The person wants a clean copy of the page and 

brings a mental model shaped by the last 
scanner they used.

• In this example, the camera supplies thirty 
frames a second; motion and orientation 
sensors indicate whether the phone is steady 
and level.

• Touch adds shutter taps and corner drags. 

Property 1 holds because sensing goes beyond 
explicit commands: nobody has to say “this is a 
page”.

<!-- PDF 页 8 -->

Layers 3 to 5: context, memory and knowledge

Lecture 02 · The spine on the scanner

Context, memory and knowledge change how the same frame is interpreted.

• Context describes the current situation: is this 

the first page or the fifth, in portrait or landscape, 
under a lamp?

• Memory retains information between uses, such 

as your last page size, preferred filter and 
destination folder.

• Knowledge supplies language data for text 
recognition and standard page sizes. These 
layers add information beyond the current frame.

<!-- PDF 页 9 -->

Layer 6: the model

Lecture 02 · The spine on the scanner

The model turns signals into claims about the page.

• Edge detection identifies strong edges (Canny, 
1986). The scanner fits a quadrilateral: a four-
sided candidate for the page boundary.

• Perspective estimation computes the transform 

that flattens the tilted page. Text recognition
then reads its characters; Tesseract is one 
example (Smith, 2007).

• Property 2, interpretation under uncertainty, 

applies to every step: the boundary, tilt or 
recognised word can be wrong.

Canny (1986); Smith (2007).

<!-- PDF 页 10 -->

Layers 7 and 8: planning and action

Lecture 02 · The spine on the scanner

Planning chooses the next step; action makes it happen.

• Planning and decision determine whether to 
capture now, wait for a steadier frame, ask the 
person or make an assumption.

• Tools and action crop, rotate, flatten, enhance, 
recognise, save and share the page; the chosen 
inference changes what they do.

• The output channel carries the result to the 
person: a spatial overlay, an informational 
message or, in another system, a physical motor.

<!-- PDF 页 11 -->

Layers 9 to 11: closing the loop

Lecture 02 · The spine on the scanner

The person’s response closes the loop at two timescales.

• The environment now contains a cropped 

image, which may be right or wrong.

• Feedback closes the immediate loop: the person 
drags a corner, retakes or accepts the scan, and 
the system responds by re-cropping when 
needed.

• Adaptation changes behaviour over time as 

page size, filter and folder become defaults. This 
human response is Property 4; without it, the 
scanner is a pipeline.

<!-- PDF 页 12 -->

Tracing the mis-crop to its layer

Lecture 02 · Worked example

Trace the symptom to a layer before choosing a fix.

• Sensing, context and model suggest different 

causes: a blurred frame, a wrong page 
assumption or the detector choosing the wrong 
edge.

• Action and feedback suggest different repairs: 

delay premature auto-capture, or enlarge a 
corner handle that the person cannot drag.

• In my experience, most “the AI got it wrong”

complaints live in action or feedback. Test each 
diagnosis by tracing the evidence across all five 
layers.

<!-- PDF 页 13 -->

Intelligence can sit at any layer

Lecture 02 · The spine

Locate the inference, then inspect the layers around it.

• The document scanner infers the page 
boundary in the model layer; a learning 
thermostat infers your schedule through 
memory and adaptation.

• A coding agent uses inference in planning and 
tool use to decide which file to open, which test 
to run and whether to continue.

• The auto-brightness example adapts without 

interpreting your intent or task. Under our 
working definition, adaptation alone does not 
make it an intelligent interactive system.

<!-- PDF 页 14 -->

One scale of autonomy

Lecture 02 · Simple, agentic, multi-agent

Choose the simplest design that does the job.

• A simple system makes one inference in one 
turn, then the person decides what happens 
next.

• An agentic system observes, decides, acts with 
tools, checks the result and continues until it 
meets a goal or stops to ask.

• A multi-agent system coordinates several such 
loops. This is a structural choice whose added 
coordination must earn its place.

Russell & Norvig (2020); Anthropic (2024), practitioner guidance.

<!-- PDF 页 15 -->

The scanner at three points on the scale

Lecture 02 · Simple, agentic, multi-agent

Ask whether extra autonomy earns its cost.

• With the simple scanner, you point the phone, it 

finds and crops the page, and you correct a 
corner if needed.

• With an agentic scanner, you say “file this 

receipt”; it scans, reads, checks and files, asking 
when it is unsure.

• The multi-agent design assigns scanning, 

reading, policy checking, filing and reporting to 
five loops. Because each step depends on the 
previous one, five loops add hand-overs but no 
benefit.

<!-- PDF 页 16 -->

What moves along the scale

Lecture 02 · Simple, agentic, multi-agent

More autonomous steps create more work for inspection and recovery.

• In these scanner designs, initiative and 

inference rise: one proposal becomes several 
actions, and one inference becomes a chain of 
dependent inferences.

• Visibility and reversibility fall in the illustrated 

progression: inspecting one crop becomes 
reading a trace, while undoing one crop becomes 
undoing a sequence.

• The cost of being wrong rises too. Ask “would a 
simpler system do?” last, once you know the 
system, the control and the evidence.

<!-- PDF 页 17 -->

Your turn: place three systems

Lecture 02 · Interaction 2

Place each system on the scale and defend the smallest sufficient design.

• A is phone autocorrect, which replaces a word as 

you type. B reads your inbox, drafts replies, 
sends follow-ups approved in bulk and books 
meetings.

• C is a support “team”: separate bots route the 

query, search the manual, write the answer and 
check its tone.

• Take two minutes to classify each as simple, 
agentic or multi-agent and name the smallest 
design that would do. Then we will argue about 
B.

<!-- PDF 页 18 -->

Every inference is a bet

Lecture 02 · Uncertainty

Uncertainty is a design input whenever the system makes an inference.

• In this illustration, the detector holds a 

distribution over candidate quadrilaterals and 
shows the highest-scoring one: the person sees 
one confident-looking rectangle.

• Recognisers, recommenders and language 
models also choose among possible outputs. 
The person usually encounters the chosen 
inference without seeing all the alternatives.

• Intrinsic uncertainty means the system can still 
be wrong. Design what the person can see and 
do when its preferred interpretation fails.

<!-- PDF 页 19 -->

Each layer's story for being wrong

Lecture 02 · Uncertainty

Every layer needs a visible route from error to correction.

• For sensing, context and model, show signal 

quality, assumptions and inferences with 
confidence, so the person can retry or reject a 
wrong interpretation.

• For planning and action, show what the system 

is about to do and scope its services when in 
doubt; support approval, dismissal and 
correction.

• For feedback and adaptation, confirm that 
corrections were taken and provide global 
controls over what the system learns.

Course applications of Amershi et al. (2019).

<!-- PDF 页 20 -->

Reliable, safe, trustworthy: where this goes

Lecture 02 · Book anchor

Design for reliable, safe and trustworthy interaction.

• Reliable means the system repeatedly does 
what it should, with evidence. Safe means its 
failures are contained and the cost of being 
wrong is bounded.

• Trustworthy means people can see enough to 

calibrate their reliance: they can judge how much 
to depend on the system.

• Shneiderman’s two-dimensional framework

(2022) places computer automation and human 
control on separate axes, allowing a design to be 
high on both.

After Shneiderman (2022); illustrative placements.

<!-- PDF 页 21 -->

The twenty questions, shown once

Lecture 02 · The target

Use the twenty questions to examine an unfamiliar system.

1–2  Problem and intelligence
1.  What problem is it solving?
2.  What makes it intelligent?

3–6  Sensing, context, memory, knowledge
3.  What does it sense?
4.  What context does it receive?
5.  What does it remember?
6.  What knowledge does it retrieve?

7–11  Models, planning, tools, actions, loops
7.  What does the model infer or generate?
8.  Does it plan?
9.  Which tools can it use?
10.  What actions can it take?
11.  What loop or workflow coordinates those actions?

12–16  The human’s place and control
12.  Where is the human in that loop?
13.  What control does the human retain?
14.  What happens when the system is uncertain?
15.  What happens when something fails?
16.  How can the user recover?

17–20  Evidence, consequences, simplicity
17.  What evidence shows the system helps?
18.  What are the safety and privacy implications?
19.  What conclusions does the evaluation actually support?
20.  Would a simpler, non-agentic system have been sufficient?

The list returns as a release checklist (Lecture 27) and a self-audit (Lecture 28); question 20 is always 
asked last.

<!-- PDF 页 22 -->

Your project: draft its spine

Lecture 02 · Project connection

Your project starts with one page that makes its interaction explicit.

• For your intended system, mark which spine 

layers exist and which are stubbed: 
placeholders for components your prototype will 
simulate.

• Mark where the intelligence sits, name its 

output channel and state what the user sees. 
Complete the five-slot sentence below.

• This page is unmarked. It seeds the Phase 1 

problem statement and the Phase 2 architecture 
diagram.

<!-- PDF 页 23 -->

What must be present, and how to look inside

Lecture 02 · Synthesis

The four properties define the system; the spine helps you analyse it.

• It must sense signals beyond commands, 

interpret under uncertainty, act through an 
output channel and close the loop with a 
human. All four must hold together.

• Walk the conceptual spine to locate the 

intelligence and ask what happens at each layer 
when an inference is wrong.

• An empty layer is a result of the analysis. Judge 

the system by what the interaction does for 
human activity.

<!-- PDF 页 24 -->

References and further reading

Lecture 02 · References

These sources connect design claims to evidence.

Working definition, four properties, output channels and five-slot template: the module’s own definition, given on slides 4, 5, 10 and 22 of 
this lecture.

Shneiderman, B. (2022). Human-Centered AI. Oxford University Press. Read Part 1 (chapters 2–3); the reliable–safe–trustworthy goals and 
the two-dimensional human-centred AI (HCAI) framework follow in Part 2.

Russell, S., & Norvig, P. (2020). Artificial Intelligence: A Modern Approach (4th ed.). Pearson. Chapter 2: agents, environments, agent types.

Amershi, S., Weld, D., Vorvoreanu, M., Fourney, A., Nushi, B., Collisson, P., Suh, J., Iqbal, S., Bennett, P. N., Inkpen, K., Teevan, J., Kikin-
Gil, R., & Horvitz, E. (2019). Guidelines for Human-AI Interaction. CHI 2019, Paper 3.

Horvitz, E. (1999). Principles of Mixed-Initiative User Interfaces. CHI 1999, 159–166.

Anthropic (2024, 19 December). Building effective agents. anthropic.com/research/building-effective-agents (practitioner guidance; 
accessed 16 September 2026).

Canny, J. (1986). A Computational Approach to Edge Detection. IEEE Transactions on Pattern Analysis and Machine Intelligence, PAMI-
8(6), 679–698.

Smith, R. (2007). An Overview of the Tesseract OCR Engine. Proceedings of ICDAR 2007, 629–633.

<!-- PDF 页 25 -->

Optional viewing: agents acting alone

Follow what the system observes, plans and does, then examine human control.

• While watching, ask what it observed through 

its environment and sensing, and what 
context or memory mattered.

• Identify the tools and actions it could use. Ask 
where a human should see, stop or correct it 
through control and feedback.

• Discuss the implications of a system that can 
observe, plan, use tools, act and keep going 
beyond producing an answer.

Screenshot: Black Hat USA 2026 conference talk. Video, not part of the 50-minute lecture: 
youtube.com/watch?v=87DyyMV0kCY
