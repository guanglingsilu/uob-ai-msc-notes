# Memory, Mental Models and Cognitive Load

逐页完整翻译与复习笔记。

## 第 1 页：Memory, Mental Models and Cognitive Load

Source ID: `src-61512ca03394-pdf_page-00001`

![PDF page 1](../assets/pages/page_001.png)

### 原文
```text
Memory, Mental 
Models and Cognitive 
Load

Intelligent Interactive Systems  ·  Week 2  ·  Lecture 05
University of Birmingham

Course-own diagram. Four chunks in the head, and the model of the system 
beside them.
```

### 完整中文翻译
记忆、心理模型与认知负荷。

智能交互系统 - 第 2 周 - 第 5 讲。伯明翰大学。

课程自绘图：头脑中的四个组块，以及旁边的系统模型。

### 中文释义
本讲接在反馈之后：即使线索已经到达，人还要能记住、理解并形成正确系统模型。

### English Explanation
This lecture asks what happens after a cue arrives: what the person can hold and what model they form.

### 概念解析
- **Working memory / 工作记忆**：短时间保持和操作信息的有限心理资源。

### 自测问题
**Q1 中文：** 第 1 页的核心复习点是什么？
**答：** 本讲接在反馈之后：即使线索已经到达，人还要能记住、理解并形成正确系统模型。
**Q1 English:** What is the key revision point on page 1?
**Answer:** This lecture asks what happens after a cue arrives: what the person can hold and what model they form.

**Q2 中文：** 解释本页概念：Working memory / 工作记忆
**答：** 短时间保持和操作信息的有限心理资源。
**Q2 English:** Explain this concept: Working memory / 工作记忆
**Answer:** 短时间保持和操作信息的有限心理资源。

## 第 2 页：A phone number read aloud

Source ID: `src-61512ca03394-pdf_page-00002`

![PDF page 2](../assets/pages/page_002.png)

### 原文
```text
A phone number read aloud

Lecture 05 · Hook

Working memory is a short-lived store: 
after hearing eleven digits once, most 
people retain only a few without rehearsal.

Before writing, predict how many you will 
reproduce in order ten seconds later; the 
exercise makes the limit visible.

Grouping changes the result, because familiar 
chunks survive more readily than isolated 
digits.

Course-own diagram. The number is illustrative, not real.
```

### 完整中文翻译
被大声读出的电话号码。

第 5 讲 - 引入。

工作记忆是短暂存储：听一次 11 位数字后，如果没有复述，多数人只能保留少数几位。

写下前，预测十秒后你能按顺序复现多少位；这个练习让限制变得可见。

分组会改变结果，因为熟悉组块比孤立数字更容易保留下来。

课程自绘图：号码是示意，不是真实号码。

### 中文释义
这个练习展示工作记忆容量和时间都有限。chunking 能把多个项目压缩成少量有意义单位。

### English Explanation
The phone-number exercise makes working-memory limits and the value of chunking visible.

### 概念解析
- **Chunking / 组块化**：把多个信息项组织成一个熟悉单位，以减少工作记忆负担。

### 自测问题
**Q1 中文：** 第 2 页的核心复习点是什么？
**答：** 这个练习展示工作记忆容量和时间都有限。chunking 能把多个项目压缩成少量有意义单位。
**Q1 English:** What is the key revision point on page 2?
**Answer:** The phone-number exercise makes working-memory limits and the value of chunking visible.

**Q2 中文：** 解释本页概念：Chunking / 组块化
**答：** 把多个信息项组织成一个熟悉单位，以减少工作记忆负担。
**Q2 English:** Explain this concept: Chunking / 组块化
**Answer:** 把多个信息项组织成一个熟悉单位，以减少工作记忆负担。

## 第 3 页：After the cue arrives: two questions

Source ID: `src-61512ca03394-pdf_page-00003`

![PDF page 3](../assets/pages/page_003.png)

### 原文
```text
After the cue arrives: two questions

Lecture 05 · Central question

Lecture 04 established that the cue was 
noticed; now we ask what happens after it 
arrives.

Working memory, recognition, and cognitive 
load explain what the person can hold; mental 
models and explanations explain what they 
believe.

These processes interact: load can produce 
weaker models, and wrong models create 
further checking work.

Course-own diagram. Lecture 04 hands over to two questions and their theories.
```

### 完整中文翻译
线索到达之后：两个问题。

第 5 讲 - 中心问题。

第 4 讲确定线索已被注意到；现在我们问它到达后发生什么。

工作记忆、识别和认知负荷解释人能保持什么；心理模型和解释解释人相信什么。

这些过程相互作用：负荷会产生更弱的模型，错误模型会创造更多检查工作。

### 中文释义
中心问题分成两个：用户能保持多少信息？用户形成了什么系统理解？负荷和心理模型会互相影响。

### English Explanation
After attention, design must support both memory capacity and model formation.

### 概念解析
- **Cognitive load / 认知负荷**：任务和界面消耗工作记忆资源的程度。
- **Mental model / 心理模型**：用户对系统如何工作及会产生什么结果的理解。

### 自测问题
**Q1 中文：** 第 3 页的核心复习点是什么？
**答：** 中心问题分成两个：用户能保持多少信息？用户形成了什么系统理解？负荷和心理模型会互相影响。
**Q1 English:** What is the key revision point on page 3?
**Answer:** After attention, design must support both memory capacity and model formation.

**Q2 中文：** 解释本页概念：Cognitive load / 认知负荷
**答：** 任务和界面消耗工作记忆资源的程度。
**Q2 English:** Explain this concept: Cognitive load / 认知负荷
**Answer:** 任务和界面消耗工作记忆资源的程度。

## 第 4 页：Working memory: a small, fragile store

Source ID: `src-61512ca03394-pdf_page-00004`

![PDF page 4](../assets/pages/page_004.png)

### 原文
```text
Working memory: a small, fragile store

Lecture 05 · Working memory

Baddeley and Hitch's (1974) model treats 
working memory as a central executive 
coordinating the phonological loop and 
visuospatial sketchpad, with an episodic 
buffer added by Baddeley (2000).

Miller (1956) popularised "seven, plus or 
minus two"; Cowan (2001) later argued the 
limit is nearer four chunks once grouping and 
rehearsal are controlled, so design for about 
four.

EO1

Plainly, information fades within seconds, so 
the system should carry state rather than 
asking the person to remember it.

Course-own diagram after Baddeley and Hitch (1974) and Baddeley (2000).
```

### 完整中文翻译
工作记忆：小而脆弱的存储。

第 5 讲 - 工作记忆。

Baddeley 和 Hitch（1974）的模型把工作记忆看作中央执行系统协调语音环路和视觉空间画板；Baddeley（2000）后来加入情景缓冲。

Miller（1956）推广了“七加减二”；Cowan（2001）后来认为，在控制分组和复述后，限制更接近四个组块，所以设计时按大约四个来设计。

通俗地说，信息会在几秒内衰退，因此系统应承担状态，而不是要求人记住它。

课程自绘图，基于 Baddeley 和 Hitch（1974）及 Baddeley（2000）。

### 中文释义
设计含义很直接：不要让用户记住很多状态、参数或步骤。系统应该显示状态、保留上下文，并减少记忆负担。

### English Explanation
Working memory is small and fragile; systems should carry state instead of asking users to remember it.

### 概念解析
- **Four chunks / 四个组块**：课程采用的实用设计近似：工作记忆大约容纳四个有意义单位。

### 自测问题
**Q1 中文：** 第 4 页的核心复习点是什么？
**答：** 设计含义很直接：不要让用户记住很多状态、参数或步骤。系统应该显示状态、保留上下文，并减少记忆负担。
**Q1 English:** What is the key revision point on page 4?
**Answer:** Working memory is small and fragile; systems should carry state instead of asking users to remember it.

**Q2 中文：** 解释本页概念：Four chunks / 四个组块
**答：** 课程采用的实用设计近似：工作记忆大约容纳四个有意义单位。
**Q2 English:** Explain this concept: Four chunks / 四个组块
**Answer:** 课程采用的实用设计近似：工作记忆大约容纳四个有意义单位。

## 第 5 页：Slide 4 comment

Source ID: `src-61512ca03394-pdf_page-00005`

![PDF page 5](../assets/pages/page_005.png)

### 原文
```text
Slide 4

EO1 

Who? The 7? The 4?
Eyal Ofek, 2026-09-23T15:45:09.013
```

### 完整中文翻译
第 4 页批注。

EO1：谁？7？4？

Eyal Ofek，2026-09-23。

### 中文释义
这是课件批注，指出幻灯片中“七”和“四”的指代需要更清楚。正式知识点仍是：现代设计更保守地按约四个组块处理。

### English Explanation
This review comment asks for clearer wording around the seven-versus-four memory limit.

### 概念解析
- **Clarification comment / 澄清批注**：课件制作反馈，不是正式课程内容。

### 自测问题
**Q1 中文：** 第 5 页的核心复习点是什么？
**答：** 这是课件批注，指出幻灯片中“七”和“四”的指代需要更清楚。正式知识点仍是：现代设计更保守地按约四个组块处理。
**Q1 English:** What is the key revision point on page 5?
**Answer:** This review comment asks for clearer wording around the seven-versus-four memory limit.

**Q2 中文：** 解释本页概念：Clarification comment / 澄清批注
**答：** 课件制作反馈，不是正式课程内容。
**Q2 English:** Explain this concept: Clarification comment / 澄清批注
**Answer:** 课件制作反馈，不是正式课程内容。

## 第 6 页：Gone in seconds: why waiting costs

Source ID: `src-61512ca03394-pdf_page-00006`

![PDF page 6](../assets/pages/page_006.png)

### 原文
```text
Gone in seconds: why waiting costs

Lecture 05 · Working memory

Peterson and Peterson (1959) prevented 
rehearsal while participants recalled three 
letters after increasing delays.

Recall falls sharply during the first ten to 
fifteen seconds; the slide shows the study's 
shape, not exact data.

The link to the last lecture (Lecture 04) is 
practical: six seconds of silence can outlast 
the request in working memory, so 
acknowledge quickly.

Course-own schematic after Peterson and Peterson (1959); the curve shows the shape of the result, 
not the data.
```

### 完整中文翻译
几秒内消失：为什么等待有成本。

第 5 讲 - 工作记忆。

Peterson 和 Peterson（1959）在阻止复述的情况下，让参与者延迟回忆三个字母。

回忆在前 10 到 15 秒急剧下降；图中显示研究形状，不是精确数据。

与第 4 讲的联系很实际：六秒沉默可能已经超过请求在工作记忆中的保留时间，所以要快速确认。

课程自绘示意图，基于 Peterson 和 Peterson（1959）；曲线显示结果形状，不是数据。

### 中文释义
等待会消耗记忆。系统沉默太久，用户可能忘记自己刚刚要求了什么，或者重复请求。

### English Explanation
Waiting costs because unrehearsed information decays within seconds.

### 概念解析
- **Memory decay / 记忆衰退**：没有复述或外部提示时，短时信息很快消失。

### 自测问题
**Q1 中文：** 第 6 页的核心复习点是什么？
**答：** 等待会消耗记忆。系统沉默太久，用户可能忘记自己刚刚要求了什么，或者重复请求。
**Q1 English:** What is the key revision point on page 6?
**Answer:** Waiting costs because unrehearsed information decays within seconds.

**Q2 中文：** 解释本页概念：Memory decay / 记忆衰退
**答：** 没有复述或外部提示时，短时信息很快消失。
**Q2 English:** Explain this concept: Memory decay / 记忆衰退
**Answer:** 没有复述或外部提示时，短时信息很快消失。

## 第 7 页：Chunking: the same eleven digits, three ways

Source ID: `src-61512ca03394-pdf_page-00007`

![PDF page 7](../assets/pages/page_007.png)

### 原文
```text
Chunking: the same eleven digits, three ways

Lecture 05 · Working memory

A chunk is a unit the person can treat as 
one thing; eleven isolated digits overflow a 
store of about four chunks.

Three groups fit more easily, and a familiar 
group such as Birmingham's 0121 can be 
retrieved as one chunk.

Plainly, group information using existing 
knowledge and show more than about four 
items instead of asking the person to hold 
them.

Course-own diagram.
```

### 完整中文翻译
组块化：同样 11 位数字，三种方式。

第 5 讲 - 工作记忆。

组块是人可以当作一个东西处理的单位；11 个孤立数字会溢出约四个组块的存储。

三个分组更容易装下，熟悉组块如伯明翰区号 0121 可以作为一个组块被检索。

通俗地说，利用已有知识组织信息；如果超过约四个项目，就显示出来，而不是让人保持在脑中。

课程自绘图。

### 中文释义
设计时要把信息按用户熟悉结构分组。列表太长就放到界面上，而不是要求用户记忆。

### English Explanation
Chunking uses existing knowledge to reduce working-memory load.

### 概念解析
- **Familiar chunk / 熟悉组块**：用户已知的模式或单位，可以被当成一个信息项处理。

### 自测问题
**Q1 中文：** 第 7 页的核心复习点是什么？
**答：** 设计时要把信息按用户熟悉结构分组。列表太长就放到界面上，而不是要求用户记忆。
**Q1 English:** What is the key revision point on page 7?
**Answer:** Chunking uses existing knowledge to reduce working-memory load.

**Q2 中文：** 解释本页概念：Familiar chunk / 熟悉组块
**答：** 用户已知的模式或单位，可以被当成一个信息项处理。
**Q2 English:** Explain this concept: Familiar chunk / 熟悉组块
**Answer:** 用户已知的模式或单位，可以被当成一个信息项处理。

## 第 8 页：Recognition beats recall

Source ID: `src-61512ca03394-pdf_page-00008`

![PDF page 8](../assets/pages/page_008.png)

### 原文
```text
Recognition beats recall

Lecture 05 · Recognition versus recall

Recall requires producing a command 
without an environmental cue; recognition 
lets the person identify an option that is 
already visible.

Norman (2013) describes this as "knowledge 
in the head" versus "knowledge in the world".

Plainly, menus support novice recognition, 
while experts may prefer command lines 
when the command is already known.

Course-own diagram after Norman (2013), chapter 3.
```

### 完整中文翻译
识别胜过回忆。

第 5 讲 - 识别与回忆。

回忆要求人在没有环境线索的情况下产生命令；识别让人辨认已经可见的选项。

Norman（2013）把它描述为“头脑中的知识”与“世界中的知识”。

通俗地说，菜单支持新手识别；当专家已经知道命令时，他们可能更喜欢命令行。

课程自绘图，基于 Norman（2013）第 3 章。

### 中文释义
界面越能把选项放到世界中，用户越不必从记忆中召回。菜单、按钮、建议 chips 都是在支持识别。

### English Explanation
Recognition is easier than recall because visible cues reduce memory demand.

### 概念解析
- **Knowledge in the world / 世界中的知识**：界面中可见的提示、选项和状态，帮助用户识别而非回忆。

### 自测问题
**Q1 中文：** 第 8 页的核心复习点是什么？
**答：** 界面越能把选项放到世界中，用户越不必从记忆中召回。菜单、按钮、建议 chips 都是在支持识别。
**Q1 English:** What is the key revision point on page 8?
**Answer:** Recognition is easier than recall because visible cues reduce memory demand.

**Q2 中文：** 解释本页概念：Knowledge in the world / 世界中的知识
**答：** 界面中可见的提示、选项和状态，帮助用户识别而非回忆。
**Q2 English:** Explain this concept: Knowledge in the world / 世界中的知识
**Answer:** 界面中可见的提示、选项和状态，帮助用户识别而非回忆。

## 第 9 页：The blank chat box is a command line

Source ID: `src-61512ca03394-pdf_page-00009`

![PDF page 9](../assets/pages/page_009.png)

### 原文
```text
The blank chat box is a command line

Lecture 05 · Recognition versus recall

"Ask me anything" presents an empty 
command line: the person must recall 
capabilities and state that the interface 
never showed.

Suggestion chips, shown sources, and recent 
actions move those cues into the world, 
supporting recognition.

Plainly, every unnecessary recall consumes 
working-memory capacity, so showing should 
beat remembering.

Course-own diagram. The blank box against three recognition designs.
```

### 完整中文翻译
空白聊天框就是命令行。

第 5 讲 - 识别与回忆。

“问我任何事”呈现的是一个空命令行：人必须回忆界面从未显示过的能力和状态。

建议 chips、显示来源和最近行动把这些线索移到世界中，支持识别。

通俗地说，每一次不必要回忆都会消耗工作记忆容量，所以显示应优于记忆。

### 中文释义
这页很适合批判 AI 聊天界面。空白输入框让用户自己猜系统能力；建议、来源、最近行动能减少 recall burden。

### English Explanation
A blank chat box forces recall of capabilities; visible suggestions and state support recognition.

### 概念解析
- **Blank-box recall burden / 空白框回忆负担**：空输入框要求用户自己记住系统能做什么和当前状态。

### 自测问题
**Q1 中文：** 第 9 页的核心复习点是什么？
**答：** 这页很适合批判 AI 聊天界面。空白输入框让用户自己猜系统能力；建议、来源、最近行动能减少 recall burden。
**Q1 English:** What is the key revision point on page 9?
**Answer:** A blank chat box forces recall of capabilities; visible suggestions and state support recognition.

**Q2 中文：** 解释本页概念：Blank-box recall burden / 空白框回忆负担
**答：** 空输入框要求用户自己记住系统能做什么和当前状态。
**Q2 English:** Explain this concept: Blank-box recall burden / 空白框回忆负担
**Answer:** 空输入框要求用户自己记住系统能做什么和当前状态。

## 第 10 页：Cognitive load: three kinds, one budget

Source ID: `src-61512ca03394-pdf_page-00010`

![PDF page 10](../assets/pages/page_010.png)

### 原文
```text
Cognitive load: three kinds, one budget

Lecture 05 · Cognitive load

Cognitive load theory distinguishes 
intrinsic load from the task, germane load 
from schema-building effort, and 
extraneous load from the design (Sweller, 
1988; Sweller, van Merriënboer and Paas, 
1998).

All three compete for limited working-memory 
capacity, but extraneous load is the part a 
designer can remove.

Plainly, make the task's complexity visible 
without adding interface work that the task 
never required.

Course-own diagram after Sweller (1988) and Sweller, van Merriënboer and Paas (1998).
```

### 完整中文翻译
认知负荷：三种类型，一个预算。

第 5 讲 - 认知负荷。

认知负荷理论区分来自任务的内在负荷、来自建构 schema 的 germane load，以及来自设计的外在负荷（Sweller，1988；Sweller、van Merrienboer 和 Paas，1998）。

三者都竞争有限工作记忆容量，但外在负荷是设计者可以移除的部分。

通俗地说，让任务复杂性可见，但不要增加任务本来不需要的界面工作。

课程自绘图，基于 Sweller 等。

### 中文释义
认知负荷不是全部都坏。任务本身复杂无法完全消除，但界面额外制造的外在负荷应该减少。

### English Explanation
Cognitive load has one limited budget; designers can especially reduce extraneous load.

### 概念解析
- **Extraneous load / 外在负荷**：由界面或教学设计额外制造、不是任务本身必须的负担。

### 自测问题
**Q1 中文：** 第 10 页的核心复习点是什么？
**答：** 认知负荷不是全部都坏。任务本身复杂无法完全消除，但界面额外制造的外在负荷应该减少。
**Q1 English:** What is the key revision point on page 10?
**Answer:** Cognitive load has one limited budget; designers can especially reduce extraneous load.

**Q2 中文：** 解释本页概念：Extraneous load / 外在负荷
**答：** 由界面或教学设计额外制造、不是任务本身必须的负担。
**Q2 English:** Explain this concept: Extraneous load / 外在负荷
**Answer:** 由界面或教学设计额外制造、不是任务本身必须的负担。

## 第 11 页：The same request, two designs

Source ID: `src-61512ca03394-pdf_page-00011`

![PDF page 11](../assets/pages/page_011.png)

### 原文
```text
The same request, two designs

Lecture 05 · Worked example

Design A reads eight flights aloud and 
leaves the person to hold four fields for 
each one; Design B shows the same 
information.

The task and underlying model are 
unchanged, but Design B shifts retrieval from 
memory to recognition.

Plainly, present only a few spoken items, or 
show the full set so the person can compare 
it.

Course-own mock-ups; outcomes are illustrative and labelled as such.
```

### 完整中文翻译
同一个请求，两种设计。

第 5 讲 - worked example。

设计 A 大声读出 8 个航班，并让人记住每个航班的四个字段；设计 B 显示同样信息。

任务和底层模型不变，但设计 B 把提取信息从记忆转移到识别。

通俗地说，语音只呈现少数项目，或者显示完整集合让人比较。

课程自制 mock-up；结果为示意并已标注。

### 中文释义
同样模型可以因为界面不同而负荷差异巨大。显示可比较信息通常比逐条读出更适合复杂选择。

### English Explanation
The model is unchanged, but visual presentation shifts work from memory to recognition.

### 概念解析
- **Memory-to-recognition shift / 从记忆转向识别**：通过显示选项和状态，减少用户必须记住的信息。

### 自测问题
**Q1 中文：** 第 11 页的核心复习点是什么？
**答：** 同样模型可以因为界面不同而负荷差异巨大。显示可比较信息通常比逐条读出更适合复杂选择。
**Q1 English:** What is the key revision point on page 11?
**Answer:** The model is unchanged, but visual presentation shifts work from memory to recognition.

**Q2 中文：** 解释本页概念：Memory-to-recognition shift / 从记忆转向识别
**答：** 通过显示选项和状态，减少用户必须记住的信息。
**Q2 English:** Explain this concept: Memory-to-recognition shift / 从记忆转向识别
**Answer:** 通过显示选项和状态，减少用户必须记住的信息。

## 第 12 页：The same request under two load conditions

Source ID: `src-61512ca03394-pdf_page-00012`

![PDF page 12](../assets/pages/page_012.png)

### 原文
```text
The same request under two load conditions

Lecture 05 · Worked example

Intrinsic load changes with context: sitting 
at a desk may be low, while driving makes 
the same request high-risk.

Voice-only interaction competes with the 
driving task, and a screen cannot be safely 
inspected.

Plainly, offer at most a few items, then ask 
"more?"; the right design depends on what the 
person is doing now.

Course-own table; cells are illustrative, the direction of each effect follows the memory literature.
```

### 完整中文翻译
同一个请求在两种负荷条件下。

第 5 讲 - worked example。

内在负荷会随情境改变：坐在桌前可能低负荷，而驾驶时同一请求会变成高风险。

纯语音交互会与驾驶任务竞争，屏幕也不能安全查看。

通俗地说，最多提供少量项目，然后问“更多吗？”；正确设计取决于人现在正在做什么。

课程自制表格；单元格为示意，方向依据记忆文献。

### 中文释义
情境会改变设计。桌面上能显示长列表，驾驶时则要限制项目数并避免视觉检查。

### English Explanation
The right design depends on current task context; driving changes the load and safety profile.

### 概念解析
- **Context-dependent load / 情境依赖负荷**：同一界面在不同用户任务下可能带来不同认知负荷。

### 自测问题
**Q1 中文：** 第 12 页的核心复习点是什么？
**答：** 情境会改变设计。桌面上能显示长列表，驾驶时则要限制项目数并避免视觉检查。
**Q1 English:** What is the key revision point on page 12?
**Answer:** The right design depends on current task context; driving changes the load and safety profile.

**Q2 中文：** 解释本页概念：Context-dependent load / 情境依赖负荷
**答：** 同一界面在不同用户任务下可能带来不同认知负荷。
**Q2 English:** Explain this concept: Context-dependent load / 情境依赖负荷
**Answer:** 同一界面在不同用户任务下可能带来不同认知负荷。

## 第 13 页：Your turn: recall, recognition, load

Source ID: `src-61512ca03394-pdf_page-00013`

![PDF page 13](../assets/pages/page_013.png)

### 原文
```text
Your turn: recall, recognition, load

Lecture 05 · Interaction 2

Classify five interface moments as recall 
or recognition, then rate the extraneous 
load each one adds.

Redesign one moment so the relevant cue is 
visible rather than requiring the person to 
retrieve it.

Take two minutes, then defend the last 
judgement because context changes its cost.

Course-own worksheet.
```

### 完整中文翻译
轮到你：回忆、识别、负荷。

第 5 讲 - 互动 2。

把五个界面时刻分类为回忆或识别，然后评价每个时刻增加的外在负荷。

重新设计一个时刻，让相关线索可见，而不是要求人检索。

用两分钟完成，然后为最后一个判断辩护，因为情境会改变成本。

课程自制 worksheet。

### 中文释义
练习训练你识别界面是否要求 recall，以及如何把信息搬到世界中来降低外在负荷。

### English Explanation
The activity asks students to classify recall/recognition moments and redesign one cue to be visible.

### 概念解析
- **Recall vs recognition audit / 回忆-识别审计**：检查界面是否不必要地要求用户从记忆中取回信息。

### 自测问题
**Q1 中文：** 第 13 页的核心复习点是什么？
**答：** 练习训练你识别界面是否要求 recall，以及如何把信息搬到世界中来降低外在负荷。
**Q1 English:** What is the key revision point on page 13?
**Answer:** The activity asks students to classify recall/recognition moments and redesign one cue to be visible.

**Q2 中文：** 解释本页概念：Recall vs recognition audit / 回忆-识别审计
**答：** 检查界面是否不必要地要求用户从记忆中取回信息。
**Q2 English:** Explain this concept: Recall vs recognition audit / 回忆-识别审计
**Answer:** 检查界面是否不必要地要求用户从记忆中取回信息。

## 第 14 页：Mental models: Different representations

Source ID: `src-61512ca03394-pdf_page-00014`

![PDF page 14](../assets/pages/page_014.png)

### 原文
```text
Mental models:
Different representations

Everyone involved builds a different model of 
the same request, and none may match what 
the user wanted.
The 1973 tree-swing cartoon follows one swing 
from the sponsor's proposal through the 
specification, the analyst's design, the 
programmers and installation.
Plainly, each panel is a mental model; the next 
slide shows how the designer's model reaches 
the user only through the system image.

The O.G. Tire Swing Cartoon. The original cartoon 1973
```

### 完整中文翻译
心理模型：不同表示。

每个参与者都会建立同一请求的不同模型，而且它们都可能不符合用户真正想要的东西。

1973 年 tree-swing 漫画跟随一个秋千，从赞助方提案、规格说明、分析师设计、程序员、安装一路变化。

通俗地说，每一格都是一个心理模型；下一页展示设计师模型如何只能通过系统形象到达用户。

The O.G. Tire Swing Cartoon，原始漫画 1973。

### 中文释义
秋千漫画说明：不同角色对同一需求的理解会分叉。系统最终呈现出来的样子会塑造用户模型。

### English Explanation
The tree-swing cartoon shows that different stakeholders form different models of the same request.

### 概念解析
- **System image / 系统形象**：用户实际看到和接触到的系统表现，是设计师模型传递给用户的媒介。

### 自测问题
**Q1 中文：** 第 14 页的核心复习点是什么？
**答：** 秋千漫画说明：不同角色对同一需求的理解会分叉。系统最终呈现出来的样子会塑造用户模型。
**Q1 English:** What is the key revision point on page 14?
**Answer:** The tree-swing cartoon shows that different stakeholders form different models of the same request.

**Q2 中文：** 解释本页概念：System image / 系统形象
**答：** 用户实际看到和接触到的系统表现，是设计师模型传递给用户的媒介。
**Q2 English:** Explain this concept: System image / 系统形象
**Answer:** 用户实际看到和接触到的系统表现，是设计师模型传递给用户的媒介。

## 第 15 页：Mental models: the runnable theory in the head

Source ID: `src-61512ca03394-pdf_page-00015`

![PDF page 15](../assets/pages/page_015.png)

### 原文
```text
Mental models: the runnable theory in the head

Lecture 05 · Mental models

A mental model is a runnable theory: the 
designer's model, the system image, and 
the user's model meet through one visible 
channel.

Johnson-Laird (1983) argues that people 
reason by building and running small internal 
models.

Norman (2013) stresses that a user's model 
need not be technically accurate, but it must 
support useful predictions; cues and feedback 
build it.

Course-own diagram after Norman (2013), chapter 1, and Johnson-Laird (1983).
```

### 完整中文翻译
心理模型：头脑中的可运行理论。

第 5 讲 - 心理模型。

心理模型是一种可运行理论：设计师模型、系统形象和用户模型通过一个可见通道相遇。

Johnson-Laird（1983）认为，人通过构建和运行小型内部模型来推理。

Norman（2013）强调，用户模型不必技术上准确，但必须支持有用预测；线索和反馈会建立它。

课程自绘图，基于 Norman（2013）第 1 章和 Johnson-Laird（1983）。

### 中文释义
心理模型的标准不是工程准确，而是能否帮助用户预测系统。设计要通过线索和反馈塑造可用模型。

### English Explanation
A mental model is a runnable internal theory that supports prediction, even if it is not technically exact.

### 概念解析
- **Runnable theory / 可运行理论**：用户可以在脑中运行的系统理解，用来预测行动后果。

### 自测问题
**Q1 中文：** 第 15 页的核心复习点是什么？
**答：** 心理模型的标准不是工程准确，而是能否帮助用户预测系统。设计要通过线索和反馈塑造可用模型。
**Q1 English:** What is the key revision point on page 15?
**Answer:** A mental model is a runnable internal theory that supports prediction, even if it is not technically exact.

**Q2 中文：** 解释本页概念：Runnable theory / 可运行理论
**答：** 用户可以在脑中运行的系统理解，用来预测行动后果。
**Q2 English:** Explain this concept: Runnable theory / 可运行理论
**Answer:** 用户可以在脑中运行的系统理解，用来预测行动后果。

## 第 16 页：A model built from cues

Source ID: `src-61512ca03394-pdf_page-00016`

![PDF page 16](../assets/pages/page_016.png)

### 原文
```text
A model built from cues

Lecture 05 · Mental models

A cue such as a greeting can imply "it 
knows who I am", while a reference to 
yesterday can imply "it remembers 
everything".

If a system forgets a stated preference without 
explaining what it keeps, the user's model 
swings between extremes.

Plainly, visible and editable memory gives the 
person evidence about the system's 
boundaries and keeps the model calibrated.

Course-own diagram.
```

### 完整中文翻译
由线索建立的模型。

第 5 讲 - 心理模型。

一句问候可能暗示“它知道我是谁”，提到昨天可能暗示“它记得一切”。

如果系统忘记了用户说过的偏好，却不解释它保存什么，用户模型会在两个极端之间摇摆。

通俗地说，可见且可编辑的记忆能给人关于系统边界的证据，并保持模型校准。

课程自绘图。

### 中文释义
AI 系统的小线索会造成大期待。记忆必须可见可编辑，否则用户不知道系统到底记住什么。

### English Explanation
Cues such as greetings and references to yesterday shape assumptions about identity and memory.

### 概念解析
- **Visible memory / 可见记忆**：用户能查看、编辑和理解系统保存内容的设计。

### 自测问题
**Q1 中文：** 第 16 页的核心复习点是什么？
**答：** AI 系统的小线索会造成大期待。记忆必须可见可编辑，否则用户不知道系统到底记住什么。
**Q1 English:** What is the key revision point on page 16?
**Answer:** Cues such as greetings and references to yesterday shape assumptions about identity and memory.

**Q2 中文：** 解释本页概念：Visible memory / 可见记忆
**答：** 用户能查看、编辑和理解系统保存内容的设计。
**Q2 English:** Explain this concept: Visible memory / 可见记忆
**Answer:** 用户能查看、编辑和理解系统保存内容的设计。

## 第 17 页：Explanation dosage: what is just right?

Source ID: `src-61512ca03394-pdf_page-00017`

![PDF page 17](../assets/pages/page_017.png)

### 原文
```text
Explanation dosage: what is just right?

Lecture 05 · Explanations

Kulesza et al. (2013) varied the soundness 
and completeness of explanations for a 
recommender system.

Completeness mattered most for accurate 
mental models; incomplete or unsound 
explanations produced confidently wrong 
models.

The fullest explanations also cost effort, so 
provide enough evidence to shape prediction 
without overwhelming the person.

Course-own schematic of the two dimensions in Kulesza et al. (2013); the plot is not the study's data.
```

### 完整中文翻译
解释剂量：什么才刚刚好？

第 5 讲 - 解释。

Kulesza 等（2013）改变推荐系统解释的 soundness 和 completeness。

完整性对准确心理模型最重要；不完整或不可靠解释会产生自信但错误的模型。

最完整解释也会消耗努力，所以要提供足够证据来塑造预测，而不要压垮用户。

课程自绘示意图：Kulesza 等（2013）的两个维度；图不是研究数据。

### 中文释义
解释不是越多越好，也不是越少越好。目标是让用户形成能预测系统行为的模型。

### English Explanation
Explanation dosage must balance completeness, soundness, and cognitive effort.

### 概念解析
- **Soundness and completeness / 可靠性与完整性**：解释是否真实反映系统，以及是否覆盖形成正确模型所需信息。

### 自测问题
**Q1 中文：** 第 17 页的核心复习点是什么？
**答：** 解释不是越多越好，也不是越少越好。目标是让用户形成能预测系统行为的模型。
**Q1 English:** What is the key revision point on page 17?
**Answer:** Explanation dosage must balance completeness, soundness, and cognitive effort.

**Q2 中文：** 解释本页概念：Soundness and completeness / 可靠性与完整性
**答：** 解释是否真实反映系统，以及是否覆盖形成正确模型所需信息。
**Q2 English:** Explain this concept: Soundness and completeness / 可靠性与完整性
**Answer:** 解释是否真实反映系统，以及是否覆盖形成正确模型所需信息。

## 第 18 页：Three dosages of one explanation

Source ID: `src-61512ca03394-pdf_page-00018`

![PDF page 18](../assets/pages/page_018.png)

### 原文
```text
Three dosages of one explanation

Lecture 05 · Explanations

Too little—"recommended for you"—
leaves the person with the model "it 
guesses".

A just-right explanation states what it used, 
what it did not use, and how the person can 
change the result.

Too much, such as a list of thirty-nine feature 
weights, is far beyond the four chunks a 
person can hold; dosage depends on what 
shapes the next prediction.

EO1

Course-own mock-ups of three explanation dosages for a recommender.
```

### 完整中文翻译
一个解释的三种剂量。

第 5 讲 - 解释。

太少：“为你推荐”会让人形成“它在猜”的模型。

刚刚好：说明它使用了什么、没有使用什么，以及人如何改变结果。

太多：例如 39 个特征权重，远超人能保持的四个组块；剂量取决于什么会塑造下一次预测。

课程自制 mock-up：推荐器解释的三种剂量。

### 中文释义
好解释要说清输入、边界和控制路径。过少会让用户瞎猜，过多会制造外在负荷。

### English Explanation
A just-right explanation states what was used, what was not used, and how the user can change the result.

### 概念解析
- **Explanation dosage / 解释剂量**：解释信息量的设计，需要足以校准模型但不过载。

### 自测问题
**Q1 中文：** 第 18 页的核心复习点是什么？
**答：** 好解释要说清输入、边界和控制路径。过少会让用户瞎猜，过多会制造外在负荷。
**Q1 English:** What is the key revision point on page 18?
**Answer:** A just-right explanation states what was used, what was not used, and how the user can change the result.

**Q2 中文：** 解释本页概念：Explanation dosage / 解释剂量
**答：** 解释信息量的设计，需要足以校准模型但不过载。
**Q2 English:** Explain this concept: Explanation dosage / 解释剂量
**Answer:** 解释信息量的设计，需要足以校准模型但不过载。

## 第 19 页：Slide 17 comment

Source ID: `src-61512ca03394-pdf_page-00019`

![PDF page 19](../assets/pages/page_019.png)

### 原文
```text
Slide 17

EO1 

What does 39 mean? Just a large number?
Eyal Ofek, 2026-09-23T15:47:47.604
```

### 完整中文翻译
第 17 页批注。

EO1：39 是什么意思？只是一个很大的数字吗？

Eyal Ofek，2026-09-23。

### 中文释义
这是课件批注，指出“39 个权重”应解释为大量特征的例子，而不是一个特殊数字。

### English Explanation
This review comment asks whether 39 has a specific meaning or simply means too many features.

### 概念解析
- **Example magnitude / 示例数量**：用来表达过载的数量示例，需避免被误解为固定指标。

### 自测问题
**Q1 中文：** 第 19 页的核心复习点是什么？
**答：** 这是课件批注，指出“39 个权重”应解释为大量特征的例子，而不是一个特殊数字。
**Q1 English:** What is the key revision point on page 19?
**Answer:** This review comment asks whether 39 has a specific meaning or simply means too many features.

**Q2 中文：** 解释本页概念：Example magnitude / 示例数量
**答：** 用来表达过载的数量示例，需避免被误解为固定指标。
**Q2 English:** Explain this concept: Example magnitude / 示例数量
**Answer:** 用来表达过载的数量示例，需避免被误解为固定指标。

## 第 20 页：Human memory is not computer memory

Source ID: `src-61512ca03394-pdf_page-00020`

![PDF page 20](../assets/pages/page_020.png)

### 原文
```text
Human memory is not computer memory

Lecture 05 · The analogy

Human memory reconstructs a gist; a 
computer can return a stored copy, so the 
two systems do not fail in the same way.

Human forgetting and cue-based retrieval 
differ from machine deletion policies, keys, 
search, and similarity matching.

Plainly, use memory terminology carefully and 
state what the intelligent system keeps, 
forgets, and retrieves.

Course-own table.
```

### 完整中文翻译
人类记忆不是计算机记忆。

第 5 讲 - 类比。

人类记忆会重构要点；计算机可以返回存储副本，所以两者不会以同样方式失败。

人类遗忘和基于线索的检索不同于机器删除策略、键、搜索和相似性匹配。

通俗地说，要谨慎使用记忆术语，并说明智能系统保存、遗忘和检索什么。

课程自绘表格。

### 中文释义
不要把 AI memory 拟人化。人的记忆是重构性的，机器记忆是存储和检索策略；界面必须说明系统到底记住什么。

### English Explanation
Human and computer memory fail differently, so memory terminology must be precise.

### 概念解析
- **Machine memory / 机器记忆**：系统按存储策略、键、搜索或相似性检索保留信息，不等同人类记忆。

### 自测问题
**Q1 中文：** 第 20 页的核心复习点是什么？
**答：** 不要把 AI memory 拟人化。人的记忆是重构性的，机器记忆是存储和检索策略；界面必须说明系统到底记住什么。
**Q1 English:** What is the key revision point on page 20?
**Answer:** Human and computer memory fail differently, so memory terminology must be precise.

**Q2 中文：** 解释本页概念：Machine memory / 机器记忆
**答：** 系统按存储策略、键、搜索或相似性检索保留信息，不等同人类记忆。
**Q2 English:** Explain this concept: Machine memory / 机器记忆
**Answer:** 系统按存储策略、键、搜索或相似性检索保留信息，不等同人类记忆。

## 第 21 页：Phase 1: the model you want users to form

Source ID: `src-61512ca03394-pdf_page-00021`

![PDF page 21](../assets/pages/page_021.png)

### 原文
```text
Phase 1: the model you want users to form

Lecture 05 · Project connection

Write one sentence describing what the 
system senses, remembers, decides, and 
when it acts.

List the three cues in the system image that 
build that mental model, then name the wrong 
model users may bring and the cue that 
corrects it.

Define evidence that users formed the model: 
what they can predict or do without asking.

Course-own worksheet.
```

### 完整中文翻译
阶段 1：你希望用户形成的模型。

第 5 讲 - 项目连接。

写一句话说明系统感知什么、记住什么、决定什么，以及何时行动。

列出系统形象中建立该心理模型的三个线索，然后说出用户可能带来的错误模型，以及修正它的线索。

定义用户已经形成模型的证据：他们不用询问就能预测或做什么。

课程自制 worksheet。

### 中文释义
项目中不能只说“用户会理解”。你要明确想让用户形成什么模型、用哪些线索塑造它、如何证明他们形成了。

### English Explanation
The project task asks students to specify the intended user model, cues that build it, likely wrong models, and evidence of success.

### 概念解析
- **Evidence of model formation / 模型形成证据**：用户能预测或正确操作系统，说明他们形成了目标心理模型。

### 自测问题
**Q1 中文：** 第 21 页的核心复习点是什么？
**答：** 项目中不能只说“用户会理解”。你要明确想让用户形成什么模型、用哪些线索塑造它、如何证明他们形成了。
**Q1 English:** What is the key revision point on page 21?
**Answer:** The project task asks students to specify the intended user model, cues that build it, likely wrong models, and evidence of success.

**Q2 中文：** 解释本页概念：Evidence of model formation / 模型形成证据
**答：** 用户能预测或正确操作系统，说明他们形成了目标心理模型。
**Q2 English:** Explain this concept: Evidence of model formation / 模型形成证据
**Answer:** 用户能预测或正确操作系统，说明他们形成了目标心理模型。

## 第 22 页：What they hold, and what model they form

Source ID: `src-61512ca03394-pdf_page-00022`

![PDF page 22](../assets/pages/page_022.png)

### 原文
```text
What they hold, and what model they form

Lecture 05 · Synthesis and bridge

Working memory holds about four chunks 
for seconds, so the system carries state 
and shows what can otherwise be 
forgotten.

Extraneous load is a design cost; mental 
models come from cues and feedback, while 
explanations must be complete, sound, and 
sized for available capacity.

Plainly, a model the person cannot form is a 
system they cannot use, and human memory 
is not machine memory.

Course-own diagram. Six rules for what the person can hold and model.
```

### 完整中文翻译
他们能保持什么，以及形成什么模型。

第 5 讲 - 综合与过渡。

工作记忆只能在几秒内保持大约四个组块，所以系统要承担状态，并显示本来可能被遗忘的内容。

外在负荷是设计成本；心理模型来自线索和反馈，而解释必须完整、可靠，并按可用容量调整大小。

通俗地说，人无法形成模型的系统，就是他们无法使用的系统；人类记忆不是机器记忆。

课程自绘图：关于人能保持什么和形成什么模型的六条规则。

### 中文释义
总结页将本讲变成设计原则：少让用户记，减少外在负荷，显示状态，设计解释剂量，谨慎处理记忆隐喻。

### English Explanation
The synthesis links working memory limits, extraneous load, mental models, explanations, and memory terminology.

### 概念解析
- **State carried by system / 系统承担状态**：系统显示和保存必要上下文，而不是让用户在脑中保留。

### 自测问题
**Q1 中文：** 第 22 页的核心复习点是什么？
**答：** 总结页将本讲变成设计原则：少让用户记，减少外在负荷，显示状态，设计解释剂量，谨慎处理记忆隐喻。
**Q1 English:** What is the key revision point on page 22?
**Answer:** The synthesis links working memory limits, extraneous load, mental models, explanations, and memory terminology.

**Q2 中文：** 解释本页概念：State carried by system / 系统承担状态
**答：** 系统显示和保存必要上下文，而不是让用户在脑中保留。
**Q2 English:** Explain this concept: State carried by system / 系统承担状态
**Answer:** 系统显示和保存必要上下文，而不是让用户在脑中保留。

## 第 23 页：References and further reading

Source ID: `src-61512ca03394-pdf_page-00023`

![PDF page 23](../assets/pages/page_023.png)

### 原文
```text
References and further reading

Lecture 05 · References

Miller, G. A. (1956). The magical number seven, plus or minus two. Psychological Review, 63(2), 81–97.

Baddeley, A. D., & Hitch, G. (1974). Working memory. Psychology of Learning and Motivation, 8, 47–89.   ·   Baddeley, 
A. (2000). The episodic buffer. Trends in Cognitive Sciences, 4(11), 417–423.

Cowan, N. (2001). The magical number 4 in short-term memory. Behavioral and Brain Sciences, 24(1), 87–114.

Peterson, L. R., & Peterson, M. J. (1959). Short-term retention of individual verbal items. Journal of Experimental 
Psychology, 58(3), 193–198.

Sweller, J. (1988). Cognitive load during problem solving. Cognitive Science, 12(2), 257–285.   ·   Sweller, J., van 
Merriënboer, J. J. G., & Paas, F. (1998). Educational Psychology Review, 10(3), 251–296.

Johnson-Laird, P. N. (1983). Mental Models. Harvard University Press.

Kulesza, T., Stumpf, S., Burnett, M., Yang, S., Kwan, I., & Wong, W.-K. (2013). Too much, too little, or just right? Ways 
explanations impact end users' mental models. IEEE VL/HCC 2013, 3–10.

Norman, D. A. (2013). The Design of Everyday Things (revised and expanded edition). Basic Books, chapters 1–3.   ·   
Shneiderman, B. (2022). Human-Centered AI, explainability (previewed).

Full list with verification notes: W02_L05_references.md

Course-own diagram. The sources grouped by what they support.
```

### 完整中文翻译
参考文献与延伸阅读。

第 5 讲 - 参考文献。

Miller（1956）《神奇数字 7 加减 2》。Psychological Review, 63(2), 81-97。

Baddeley 与 Hitch（1974）《Working memory》；Baddeley（2000）《The episodic buffer》。

Cowan（2001）《The magical number 4 in short-term memory》。Behavioral and Brain Sciences, 24(1), 87-114。

Peterson 与 Peterson（1959）《Short-term retention of individual verbal items》。Journal of Experimental Psychology, 58(3), 193-198。

Sweller（1988）和 Sweller、van Merrienboer 与 Paas（1998）关于认知负荷。

Johnson-Laird（1983）《Mental Models》。Harvard University Press。

Kulesza 等（2013）《Too much, too little, or just right? Ways explanations impact end users' mental models》。IEEE VL/HCC 2013。

Norman（2013）《The Design of Everyday Things》第 1-3 章；Shneiderman（2022）关于 explainability。完整核验列表：W02_L05_references.md。

### 中文释义
参考页覆盖工作记忆、短时遗忘、认知负荷、心理模型、解释剂量和 Norman 的设计理论。

### English Explanation
The references anchor memory capacity, decay, cognitive load, mental models, explanation dosage, and design theory.

### 概念解析
- **Reference cluster / 参考文献群**：按概念分组的一组来源，用来支撑本讲机制。

### 自测问题
**Q1 中文：** 第 23 页的核心复习点是什么？
**答：** 参考页覆盖工作记忆、短时遗忘、认知负荷、心理模型、解释剂量和 Norman 的设计理论。
**Q1 English:** What is the key revision point on page 23?
**Answer:** The references anchor memory capacity, decay, cognitive load, mental models, explanation dosage, and design theory.

**Q2 中文：** 解释本页概念：Reference cluster / 参考文献群
**答：** 按概念分组的一组来源，用来支撑本讲机制。
**Q2 English:** Explain this concept: Reference cluster / 参考文献群
**Answer:** 按概念分组的一组来源，用来支撑本讲机制。

## 第 24 页：Optional viewing: Her (2013)

Source ID: `src-61512ca03394-pdf_page-00024`

![PDF page 24](../assets/pages/page_024.png)

### 原文
```text
Optional viewing: Her (2013)

Follow the interaction between the person and the system

Mental model — what does Theodore initially think this new OS is capable of?
System image — what cues does the interface give him about intelligence, personality, 
memory and autonomy?
Recognition vs recall — does the onboarding expose choices, or require Theodore to 
know what to ask?
Cognitive load — notice how little technical configuration Theodore has to 
understand; the interaction compresses a complex system into a short conversation.
User modelling / memory — the setup asks personal questions and uses the answers 
immediately. What does Theodore now assume will be remembered?
Explanation dosage — the system gives almost no technical explanation of what it is 
doing. Is that elegant simplification, or does it create an inaccurate mental model?
Human vs machine memory — does the human-like voice encourage Theodore to 
assume that Samantha remembers and understands in a human-like way?
Expectation formation — before Samantha has done very much, her voice and 
conversational fluency already establish expectations about what sort of entity she is.

Screenshot: Her (2013):  https://www.youtube.com/watch?v=f9Hg1x-Ctlw
```

### 完整中文翻译
可选观看：《Her》（2013）。

跟踪人与系统之间的互动。

心理模型：Theodore 起初认为这个新 OS 能做什么？
系统形象：界面给了他关于智能、人格、记忆和自主性的哪些线索？
识别与回忆：onboarding 展示选择，还是要求 Theodore 知道该问什么？
认知负荷：注意 Theodore 需要理解的技术配置很少；互动把复杂系统压缩成短对话。
用户建模/记忆：设置过程询问私人问题并立即使用答案。Theodore 现在会假设什么会被记住？
解释剂量：系统几乎不解释技术过程。这是优雅简化，还是制造了不准确心理模型？
人类与机器记忆：拟人化声音是否鼓励 Theodore 假设 Samantha 像人一样记得并理解？
期待形成：在 Samantha 做很多事之前，她的声音和对话流畅性已经建立了关于她是什么实体的期待。

截图：《Her》（2013），YouTube 链接。

### 中文释义
可选观看把本讲所有概念放进一个电影交互案例：心理模型、系统形象、记忆、解释剂量、拟人化和期待形成。

### English Explanation
The optional viewing applies the lecture concepts to a human-like conversational OS.

### 概念解析
- **Anthropomorphic cue / 拟人化线索**：声音、人格和对话流畅性等让用户把系统理解成人一样的线索。

### 自测问题
**Q1 中文：** 第 24 页的核心复习点是什么？
**答：** 可选观看把本讲所有概念放进一个电影交互案例：心理模型、系统形象、记忆、解释剂量、拟人化和期待形成。
**Q1 English:** What is the key revision point on page 24?
**Answer:** The optional viewing applies the lecture concepts to a human-like conversational OS.

**Q2 中文：** 解释本页概念：Anthropomorphic cue / 拟人化线索
**答：** 声音、人格和对话流畅性等让用户把系统理解成人一样的线索。
**Q2 English:** Explain this concept: Anthropomorphic cue / 拟人化线索
**Answer:** 声音、人格和对话流畅性等让用户把系统理解成人一样的线索。
