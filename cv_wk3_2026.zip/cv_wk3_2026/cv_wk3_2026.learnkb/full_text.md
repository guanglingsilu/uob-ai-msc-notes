# 来源：Week3_2026.pdf

<!-- SOURCE: Week3_2026.pdf -->

<!-- PDF 页 1 -->

Computer Vision
and Imaging

Week 3 - 1
Dr. Qingjie Meng
Assistant Professor in Medical AI
School of Computer Science

[Computer Vision and Imaging]

<!-- PDF 页 2 -->

“

Outline
▪ Fundamental steps in image processing
▪ Image formation and representation
▪ Arithmetic operations between images
▪ Single-pixel and neighbourhoodoperations
▪ Distance metrics
▪ Neighbourhoodsand connectivity
▪ Geometric transformations
▪ Histogram processing

1

<!-- PDF 页 3 -->

Output: images

Output: features

Transforms

Segmentation

Filtering and 
Enhancement

Image 
acquisition

Knowledge base

Feature 
extraction

Patterns 
classification

Figure. Fundamental steps in low-level digital image processing. [Gonzalez& Woods, 

2018]

2

<!-- PDF 页 4 -->

Preliminaries: Image formation model

𝑓 (𝑥, 𝑦)

𝑖(𝑥, 𝑦)

𝑟(𝑥, 𝑦)

𝑓 𝑥, 𝑦 : Digitised image
𝑖 𝑥, 𝑦 : Illumination
𝑟 𝑥, 𝑦 : Reflectance

𝑓 (𝑥, 𝑦) = 𝑖(𝑥, 𝑦)𝑟(𝑥, 𝑦)

Intensity levels

𝐿𝑚𝑖𝑛 ≤ ℓ ≤ 𝐿𝑚𝑎𝑥ℓ = 𝑓 𝑥, 𝑦

[𝐿𝑚𝑖𝑛, 𝐿𝑚𝑎𝑥]

[Gonzalez& Woods, 2018]

e.g., [0,1] or [0,255]

3

<!-- PDF 页 5 -->

Preliminaries: Representing Digital Images

Example:

𝑎𝑖𝑗 = 𝑓(𝑖, 𝑗)

4

<!-- PDF 页 6 -->

Arithmetic Operations

Operation

Expression

Application

Addition

Subtraction

Product

Division

Noise reduction

Intensity changes detection

Masking

Shading correction

5

<!-- PDF 页 7 -->

Arithmetic Operations: addition
If 
𝑓 𝑥, 𝑦 : noiseless image
𝜂(𝑥, 𝑦): additive noise function
𝑔(𝑥, 𝑦): corrupted image 
Then

𝒈(𝒙, 𝒚)

ഥ𝒈 with 𝑲 = 𝟓

ഥ𝒈 with 𝑲 = 𝟏𝟎

ഥ𝒈 with 𝑲 = 𝟐𝟎

ഥ𝒈 with 𝑲 = 𝟓0

ഥ𝒈 with 𝑲 = 𝟏𝟎𝟎

Example: Noise reduction

6

<!-- PDF 页 8 -->

Arithmetic Operations: subtraction

f(x,y)

g(x,y)

d(x,y) = f(x,y) - g(x,y)

Example: Image comparison

7

<!-- PDF 页 9 -->

Arithmetic Operations: product

f(x,y)

g(x,y)

d(x,y) = f(x,y) * g(x,y)

Example: Masking

8

<!-- PDF 页 10 -->

Arithmetic Operations: division

f(x,y)

g(x,y)

d(x,y) = f(x,y) 

g(x,y)

Example: Shading correction

9

<!-- PDF 页 11 -->

Single-pixel operations

Let 

z, s: pixels in [0,L-1]

T(z): L-1-z

L=255

e
v
i
t
a
g
e
N

Original

Original image

Negative image

10

<!-- PDF 页 12 -->

Neighbourhood operations

Let 

Sxy: a neighbourhood centred at x,y

f: input image

g(x,y): output pixel value

11

<!-- PDF 页 13 -->

Distance metrics

▪ Let p, q, and s be pixels with (x,y), (u,v), and (w,z), respectively. The D is a 

distance function if:

If and only if

▪ Types of distance metrics:

□ Euclidean
□ City-block
□ Chessboard

12

<!-- PDF 页 14 -->

Distance metrics

City-block 

Euclidean 

Chessboard

13

<!-- PDF 页 15 -->

Neighbourhoods and connectivity

Neighbourhood of a pixel pwith (x,y)coordinates:

▪ Horizontal and vertical neighbours:

▪ Diagonal neighbours:

▪ 8-neighbours of p:

𝑁8 𝑝 = {𝑁4 𝑝 , 𝑁𝐷 𝑝 }

14

<!-- PDF 页 16 -->

Neighbours and connectivity

Neighbourhood of a pixel p with 
coordinates (x,y)

15

<!-- PDF 页 17 -->

Neighbourhoods and connectivity

Let Vbe the set of intensity values used to define adjacency. 
In a binary image1, V = {1} if we are referring to adjacency of pixels 
with value 1.

We consider three types of adjacencies:

Connectivity: establishes the boundaries between components in an 
image according to adjacency criteria.
1 In a grayscale image, the idea is the same, but set V typically contains more elements.

16

<!-- PDF 页 18 -->

Neighbourhoods and connectivity

(a) An arrangement of pixels. (b) Pixels that are 8-adjacent 
(adjacency is shown by dashed lines). (c) m-adjacency (removes 
ambiguities from 8-adjacency)

17

<!-- PDF 页 19 -->

Neighbourhoods and connectivity

▪ A path from pixel pwith coordinates (x0, y0)to pixel q with 

coordinates (xn, yn)is a sequence of distinct pixels with coordinates:
▪ (x0, y0), (x1, y1), …, (xn, yn)

Where (xi, yi) and (xi-1, yi-1) are adjacent for 1<= i<= n

▪ Two pixels pand qin a subset Sare connected if there is a path 

between pand qwith all the connected pixels in S

▪ For any pixel pin S, the set of pixels that are connected to it in Sis 

called a connected component of S.

▪ Two regions, Ri and Rj are said to be adjacent if their union forms a 

connected set.

▪ Regions that are not adjacent are said to be disjoint.

18

<!-- PDF 页 20 -->

Neighbourhoods and connectivity

Suppose an image contains K disjoint regions:

Rk , k =1, 2,…, K.

And Ru the union of all the K regions, and let
(Ru)c denote its complement1. 

We call all the points in: 

Ru the foreground, and 

(Ru)c the background of the image.

1The complement of a set A is the set of points that are not in A

19

a) Ru representing the foreground.     b) (Ru)c the background of the image

<!-- PDF 页 21 -->

Contour

The contour (or boundary) of a region R is the set of pixels in R that are adjacent to pixels in (Ru)c. 

The contour of a region is the set of pixels in the region that have at least one background neighbour.

Is it part of the contour?

No, for a 4-adjacency.

Yes, if 8-adjacency is considered.

Region R 

Contour

20

<!-- PDF 页 22 -->

Contour

The contour (or boundary) of a region R is the set of pixels in R that are adjacent to pixels in (Ru)c. 

The contour of a region is the set of pixels in the region that have at least one background neighbour.

Region R

Contour with 
8-adjacency connectivity

Contour with 
4-adjacency connectivity

21

<!-- PDF 页 23 -->

Geometric transformations

T is a function that modifies the spatial arrangement 
of pixels in an image, and can be expressed as:

A 3x3 matrix is required to express translation

22

<!-- PDF 页 24 -->

Geometric 
transformations

23

<!-- PDF 页 25 -->

Histogram

Let rk , for k = 0,1, 2,…, L−1, denote the intensities of an L-level digital 
image, f (x, y). 
The unnormalized histogram of f is defined as:

And the normalised histogram of f is defined as:

With M and N being the width and height of f.

The components of p(rk) are estimates of the probabilities of intensity 
levels occurring in an image.

24

<!-- PDF 页 26 -->

Histogram

0                            L-1

Four image types and their corresponding histograms.

25

<!-- PDF 页 27 -->

Contrast stretching

Low contrast: several intensity 
values close to each other.

Solution:
Stretching the intensity values 
spanning the [0, L-1]

(a) Low-contrast image b) Contrast stretching

26

<!-- PDF 页 28 -->

Histogram equalization

Redistribution of intensity values in the [0,L-1] range.
Assuming:
1. T(k) is a monotonic† increasing function in the interval 0 ≤ r ≤ L − 1; and
2. 0 <= T(r) <= L-1 for r in [0, L-1]

Mapping function T is defined as:

)
k
r
(
T

rk

Low-contrast image

Mapping function

Histogram-equalized image

27

rk

<!-- PDF 页 29 -->

Histogram equalization

Dark

Bright

Low-contrast

High-contrast

Original

Output

Original

T(rk)

Equalized 
histogram

28

<!-- PDF 页 30 -->

“

Summary
▪ Fundamental steps in image processing
▪ Image formation and representation
▪ Arithmetic operations between images
▪ Single-pixel and neighbourhood

operations

▪ Distance metrics
▪ Neighbourhoodsand connectivity
▪ Geometric transformations
▪ Histogram processing

29

<!-- PDF 页 31 -->

“

Q & A

<!-- PDF 页 32 -->

Computer Vision
and Imaging

Week 3 - 2
Dr. Qingjie Meng

Assistant Professor in Medical AI
School of Computer Science

[Computer Vision and Imaging]

<!-- PDF 页 33 -->

“

Outline
▪ Spatial filtering mechanics

□ Correlation and Convolution

▪ Image degradation model
▪ Spatial Filtering Methods

□ Image smoothing (Low-pass filtering)

□ Mean, Gaussian and Order-

statistics filters

□ Image sharpening (High-pass filtering)

32

<!-- PDF 页 34 -->

Filtering

• Filtering refers to passing, modifying, or rejecting specified frequency components of 

an image.

• The name filter is borrowed from frequency domain processing
• Example: A low-pass filter produces a smoothed version of an image by blurring it.

Low-
pass

High-
pass

Band-pass

Band-reject

33

<!-- PDF 页 35 -->

Linear Spatial Filtering

• A linear spatial filter is a sum-of-products operation between an image f and a filter 

kernel, w. 

• The size of w (mxn) defines the neighbourhood of operation, and its coefficients 

determine the nature of the filter.

• The center coefficient w(0,0) aligns with f(x,y)

• General form:

34

<!-- PDF 页 36 -->

Linear Spatial Filtering

Kernel

Kernel coefficients

Pixel values when centred on (x,y)

35

<!-- PDF 页 37 -->

Spatial correlation vs convolution

Correlation: moving the centre of a kernel over an 
image and computing the sum of products at each 
location. 
Convolution: is the same, except that the correlation 
kernel is rotated by 180°.

Consider a 1-D example:

36

<!-- PDF 页 38 -->

Spatial correlation vs convolution

2-D example:

37

<!-- PDF 页 39 -->

Image degradation model
We model image degradation as:
Given 
• 𝑔(𝑥, 𝑦), 
• some knowledge about ℋ and η(𝑥, 𝑦), 
we want to estimate find መf(𝑥, 𝑦) (estimated restored image) original image.

38

<!-- PDF 页 40 -->

Image degradation model

If we assume1 that 
• noise is independent of spatial coordinates, and 
•

it is uncorrelated with respect to the image itself (that is, there is no correlation between 
pixel values and the values of noise components).

We have additive noise:

Considering 𝜂 𝑥, 𝑦 as a random variable with a probability density function (PDF) aids in 
filter design.

1Note: not realistic in some applications, such as X-ray and nuclear-medicine imaging.

39

<!-- PDF 页 41 -->

Noise models

Common additive noise models

PDF, 𝑝(𝑧)

Mean,  Ƹ𝑧

Variance, 𝜎 2

Random number generator,  𝑧

Otherwise

Gaussian

Log-normal

Uniform

Rayleigh

Exponential

Gamma

E1 +E2 +E3 + … + Eb
Where E’s are exponential 
random numbers

40

<!-- PDF 页 42 -->

Noise models

Probability density functions

41

<!-- PDF 页 43 -->

Noise models

Salt-and-pepper

• Salt-and-pepper noise randomly generates black and white pixels in an image 

within [0,L − 1]:

• P= Ps+Pp is the probability that a pixel is corrupted by salt or pepper noise.

42

<!-- PDF 页 44 -->

Images and histograms with additive noise

Original

Gaussian

Log-normal

Uniform

Rayleigh

Exponential

Gamma

Salt-and-pepper

43

<!-- PDF 页 45 -->

Images and histograms with additive noise

Original

Gaussian

Log-normal

Uniform

Rayleigh

Exponential

Gamma

Salt-and-pepper

0

L-1

44

<!-- PDF 页 46 -->

Mean filters

• Linear filters for noise reduction are implemented through spatial convolution.

• The sum of the kernel coefficients must be 1 to avoid introducing bias due to 

filtering1.

• The simplest filter is the arithmetic mean filter (also called box filter).

• The arithmetic mean filter computes the average value of the corrupted image, 

𝑔(𝑥, 𝑦), in the area defined by 𝑆𝑥𝑦.

1The sum of the pixels in the original and filtered images will be the same.

45

𝑆𝑥𝑦

<!-- PDF 页 47 -->

Mean filters

• The arithmetic mean filter computes the average value of the corrupted image, 

𝑔(𝑥, 𝑦), in the area defined by 𝑆𝑥𝑦.

𝑆𝑥𝑦

a) Original image and median filter outputs 
with b)5x5, c)11x11, and d)21x21

46

<!-- PDF 页 48 -->

Mean filters

We also have the 

• Geometric mean filter

• Harmonic mean filter

• Contraharmonic mean filter

Image levels must be between 0 and 1, and Q is the order of the filter.

Geometric mean filter

Harmonic mean filter

Contraharmonic mean filter

47

<!-- PDF 页 49 -->

Mean filters

• Geometric mean filter

Geometric mean filter

Image with Gaussian noise

Mean filter output (3x3)

Geometric Mean filter output (3x3)

48

<!-- PDF 页 50 -->

Mean filters

• Harmonic mean filter

Harmonic mean filter

Gaussian noise

Output

Salt noise

Output

49

<!-- PDF 页 51 -->

Mean filters
• Contraharmonic mean filter
Q is the order of the filter.

Contraharmonic mean filter

Salt-noise, Q = -3

Pepper-noise, Q = 3

Salt-noise, Q = 3

Pepper-noise, Q = -3

50

<!-- PDF 页 52 -->

Gaussian filter

• A Gaussian filter is an isotropic filter, i.e., the response is independent of orientation.

where 𝜎2 is the variance and k is the total sum of the kernel coefficients, such that, 

σ 𝑠,𝑡 ∈w 𝑤 𝑠, 𝑡 = 1
If 𝑠2 + 𝑡2 = 𝑟2, then

51

<!-- PDF 页 53 -->

Gaussian filter

Original image

Mean filter output

Gaussian filter output

52

<!-- PDF 页 54 -->

Order-statistics filters

• These filters are based on the idea of ranking.
• We rank the values in a region 𝑆𝑥𝑦.
• The central pixel is replaced by a certain value after sorting the rest of the pixels in 

𝑆𝑥𝑦.
• Median filter
• Max and Min filters
• Midpoint

The best-known order-statistic filter in image processing is the median filter. 
It replaces the value of a pixel by the median of the intensity levels in a predefined 
neighborhood 𝑆𝑥𝑦 of that pixel:

53

<!-- PDF 页 55 -->

Order-statistics filters
Median filter

Salt-and-pepper noise

Output

Gaussian noise

Output

Popular because they provide excellent noise-reduction capabilities, with less blurring than 
linear smoothing filters of similar size.

54

<!-- PDF 页 56 -->

Order-statistics filters
Max and min

• Using the 100th percentile results in the so-called max filter, 
•

It is useful for finding the brightest points in an image or for eroding dark regions 
adjacent to bright areas. 

• Reduces pepper noise

• The 0th percentile filter is the min filter.
• This filter is useful for finding the darkest points in an image or for eroding light 

regions adjacent to dark areas.

• Reduces salt noise

55

<!-- PDF 页 57 -->

Order-statistics filters
Max and min filters

Original image

Min filter output

Max filter output

56

<!-- PDF 页 58 -->

Order-statistics filters
Midpoint filter

• The midpoint filter computes the midpoint between the maximum and minimum 

values in the area encompassed by the filter.
It works best for randomly distributed noise, like Gaussian or uniform noise.

•

Gaussian      Output
noise

Uniform     Output
noise

57

<!-- PDF 页 59 -->

High-pass Spatial filter
Sharpening

• Sharpening operations highlight transitions in intensity.
• We saw that smoothing could be accomplished by spatial averaging in a 

•

neighbourhood.
If averaging is analogous to integration, then sharpening can be accomplished by 
spatial differentiation.

• The strength of the response of a derivative operator is proportional to the 

magnitude of the intensity discontinuity at the point at which the operator is applied.

• Main applications are in medical imaging and industrial inspection.

Image differentiation enhances edges and other discontinuities

58

<!-- PDF 页 60 -->

High-pass Spatial filter
Sharpening

Edges and other discontinuities

Step

Ramp

Impulse

Triangular

59

<!-- PDF 页 61 -->

High-pass Spatial filter
Sharpening

• Sharpening filters are based on first- and second-order derivatives.
• We are interested in the derivative values in:

• areas of constant intensity, 
• at the onset and end of discontinuities (step and ramp discontinuities), and 
• along intensity ramps

First derivative:
1. Must be zero in areas of constant intensity.
2. Must be nonzero at the onset of an intensity step or ramp.
3. Must be nonzero along intensity ramps.

Second derivative
1. Must be zero in areas of constant intensity.
2. Must be nonzero at the onset and end of an intensity step or ramp.
3. Must be zero along intensity ramps.

60

<!-- PDF 页 62 -->

High-pass Spatial filter
Sharpening

First-order derivative
1. Must be zero in areas of constant intensity.
2. Must be nonzero at the onset of an 
intensity step or ramp.
3. Must be nonzero along intensity ramps.

Second-order derivative

1. Must be zero in areas of constant intensity.
2. Must be nonzero at the onset and end of an 
intensity step or ramp.
3. Must be zero along intensity ramps.

61

<!-- PDF 页 63 -->

High-pass Spatial filter
Sharpening

The simplest isotropic derivative operator (kernel) is the Laplacian, which, for a 
function (image) f (x, y) of two variables, is defined as:

In the discrete form for x and y:

And then combining them:

Laplacian kernel

With diagonals

62

<!-- PDF 页 64 -->

High-pass Spatial filter
Sharpening

• The Laplacian filter will produce images with greyish edges superimposed on a dark, 

featureless background. 

• Background features can be “recovered” by adding the Laplacian image to the original.

Blurred image

Laplacian obtained
Without diagonals

Without 
diagonals

With 
diagonals

63

<!-- PDF 页 65 -->

“

Summary
▪ Spatial filtering mechanics

□ Correlation and Convolution

▪ Image degradation model
▪ Spatial Filtering Methods

□ Image smoothing (Low-pass filtering)

□ Mean, Gaussian and Order-

statistics filters

□ Image sharpening (High-pass filtering)

64

<!-- PDF 页 66 -->

“

Q & A
