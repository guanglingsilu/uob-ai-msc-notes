# Dataset Selection and Integration

课程：Data-Intensive Artificial Intelligence

## 第 1 页：数据集选择与整合

Source ID: `src-2f6570f71ed0-pdf_page-00001`

![PDF page 1](../assets/pages/page_001.jpg)

### 原文 / Original Text

```text
Dataset selection and integration

Prof. Paolo Missier
School of Computer Science
University of Birmingham, UK

Data-intensive AI
2026/27 Sem 1
```

### 完整中文翻译

数据集选择与整合
教授 Paolo Missier
计算机科学学院
伯明翰大学, UK
数据密集型人工智能
2026/27 Sem 1

### 中文释义

本页围绕“Dataset selection and integration”展开。课件中的关键信息包括：数据集选择与整合；教授 Paolo Missier；计算机科学学院；伯明翰大学, UK。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Dataset selection and integration'. The slide includes: Dataset selection and integration; Prof. Paolo Missier; School of Computer Science; University of Birmingham, UK. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“Dataset selection and integration”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 1 页的核心主题是什么？
**答：** 本页围绕“Dataset selection and integration”展开。课件中的关键信息包括：数据集选择与整合；教授 Paolo Missier；计算机科学学院；伯明翰大学, UK。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 1?
**Answer:** This page presents 'Dataset selection and integration'. The slide includes: Dataset selection and integration; Prof. Paolo Missier; School of Computer Science; University of Birmingham, UK. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'Dataset selection and integration'. The slide includes: Dataset selection and integration; Prof. Paolo Missier; School of Computer Science; University of Birmingham, UK. The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

## 第 2 页：本讲内容: 数据集选择与整合

Source ID: `src-2f6570f71ed0-pdf_page-00002`

![PDF page 2](../assets/pages/page_002.jpg)

### 原文 / Original Text

```text
In this lecture: Dataset selection and integration

We dive into the TAXI dataset example to illustrate the “Bronze” part of data preparation

Overall goal: 

I am a taxi fleet operator. I want to position my fleet at any point in time to maximise revenues 

A real data lake would contain hundreds of raw datasets

1. Dataset selection:
- Which datasets should I use to create a training set?

2. Dataset integration:

- how do I consolidate the selected tables into a viable “Bronze” starting point to create 
my training set?
```

### 完整中文翻译

本讲内容: 数据集选择与整合
We dive into the TAXI dataset example to illustrate the “铜牌层/原始可追溯层” part of data preparation
总体目标:
I am a taxi fleet operator. I want to position my fleet at any point in time to maximise revenues
A real 数据湖 would contain hundreds of raw datasets
1. Dataset selection:
问题：- Which datasets should I use to create a training set？
2. Dataset integration:
- how do I consolidate the selected tables into a viable “铜牌层/原始可追溯层” starting point to create
问题：my training set？

### 中文释义

本页围绕“In this lecture: Dataset selection and integration”展开。课件中的关键信息包括：本讲内容: 数据集选择与整合；We dive into the TAXI dataset example to illustrate the “铜牌层/原始可追溯层” part of data preparation；总体目标:；I am a taxi fleet operator. I want to position my fleet at any point in time to maximise revenues。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'In this lecture: Dataset selection and integration'. The slide includes: In this lecture: Dataset selection and integration; We dive into the TAXI dataset example to illustrate the “Bronze” part of data preparation; Overall goal:; I am a taxi fleet operator. I want to position my fleet at any point in time to maximise revenues. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Data lake / 数据湖**：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。

拓展复习：把“In this lecture: Dataset selection and integration”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 2 页的核心主题是什么？
**答：** 本页围绕“In this lecture: Dataset selection and integration”展开。课件中的关键信息包括：本讲内容: 数据集选择与整合；We dive into the TAXI dataset example to illustrate the “铜牌层/原始可追溯层” part of data preparation；总体目标:；I am a taxi fleet operator. I want to position my fleet at any point in time to maximise revenues。复习时先抓住数据湖：保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 2?
**Answer:** This page presents 'In this lecture: Dataset selection and integration'. The slide includes: In this lecture: Dataset selection and integration; We dive into the TAXI dataset example to illustrate the “Bronze” part of data preparation; Overall goal:; I am a taxi fleet operator. I want to position my fleet at any point in time to maximise revenues. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：数据湖 / Data lake
**答：** 保存结构化、半结构化和非结构化原始数据的存储架构，强调开放格式、读时定义模式和存算分离。
**Q2 English:** Explain the concept on this page: Data lake
**Answer:** The page focuses on Data lake. This page presents 'In this lecture: Dataset selection and integration'. The slide includes: In this lecture: Dataset selection and integration; We dive into the TAXI dataset example to illustrate the “Bronze” part of data preparation; Overall goal:; I am a taxi fleet operator. I want to position my fleet at any point in time to maximise revenues. The revision focus is Data lake; connect its definition, evidence, and use to the examples on the page.

## 第 3 页：铜牌层/原始可追溯层 层: TAXI dataset example

Source ID: `src-2f6570f71ed0-pdf_page-00003`

![PDF page 3](../assets/pages/page_003.jpg)

### 原文 / Original Text

```text
Bronze medallion: TAXI dataset example

Network 
analysis

Most popular pick up / drop off points, most profitable routes
Are these time-dependent? What else determines profitability?

Choice of Yellow vs Green datasets, or both
- What do I need to know about these datasets?

- How does each of them contribute to the learning task?

- What else do I need?

- Eg zone_lookup reference table

Reference notebook:
data_load_to_Delta_Tables
[Loading and integrate the TAXI datasets into Delta Tables]
```

### 完整中文翻译

铜牌层/原始可追溯层 层: TAXI dataset example
Network
analysis
Most popular pick up / drop off points, most profitable routes
问题：Are these time-dependent? What else determines profitability？
Choice of Yellow vs Green datasets, or both
问题：- What do I need to know about these datasets？
问题：- How does each of them contribute to the learning task？
问题：- What else do I need？
- Eg zone_lookup reference table
Reference notebook:
data_load_to_Delta_Tables
[Loading and integrate the TAXI datasets into Delta 表]

### 中文释义

本页围绕“Bronze medallion: TAXI dataset example”展开。课件中的关键信息包括：铜牌层/原始可追溯层 层: TAXI dataset example；Network；analysis；Most popular pick up / drop off points, most profitable routes。复习时先抓住奖牌架构：把数据从 Landing/Bronze 的原始层逐步提升到 Silver 的清洗整合层和 Gold 的可训练/可服务层。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Bronze medallion: TAXI dataset example'. The slide includes: Bronze medallion: TAXI dataset example; Network; analysis; Most popular pick up / drop off points, most profitable routes. The revision focus is Medallion; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Medallion / 奖牌架构**：把数据从 Landing/Bronze 的原始层逐步提升到 Silver 的清洗整合层和 Gold 的可训练/可服务层。

拓展复习：把“Bronze medallion: TAXI dataset example”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 3 页的核心主题是什么？
**答：** 本页围绕“Bronze medallion: TAXI dataset example”展开。课件中的关键信息包括：铜牌层/原始可追溯层 层: TAXI dataset example；Network；analysis；Most popular pick up / drop off points, most profitable routes。复习时先抓住奖牌架构：把数据从 Landing/Bronze 的原始层逐步提升到 Silver 的清洗整合层和 Gold 的可训练/可服务层。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 3?
**Answer:** This page presents 'Bronze medallion: TAXI dataset example'. The slide includes: Bronze medallion: TAXI dataset example; Network; analysis; Most popular pick up / drop off points, most profitable routes. The revision focus is Medallion; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：奖牌架构 / Medallion
**答：** 把数据从 Landing/Bronze 的原始层逐步提升到 Silver 的清洗整合层和 Gold 的可训练/可服务层。
**Q2 English:** Explain the concept on this page: Medallion
**Answer:** The page focuses on Medallion. This page presents 'Bronze medallion: TAXI dataset example'. The slide includes: Bronze medallion: TAXI dataset example; Network; analysis; Most popular pick up / drop off points, most profitable routes. The revision focus is Medallion; connect its definition, evidence, and use to the examples on the page.

## 第 4 页：Inspecting the available data

Source ID: `src-2f6570f71ed0-pdf_page-00004`

![PDF page 4](../assets/pages/page_004.jpg)

### 原文 / Original Text

```text
Inspecting the available data

Source

Yellow Taxi trips

Green Taxi trips

Taxi Zone Lookup

Format

Parquet

Parquet

CSV

Scale

~3M rows/month --> 36 M rows/year

~70K rows/month

265 zones

https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page

- How similar/different are the Yellow and Green datasets?
-
-
- How much data do I need?  (1 month --> 10 years??) 

Is there value in trying to create a unified view that includes both?
Is this technically feasible?
```

### 完整中文翻译

Inspecting the available data
Source
Yellow Taxi trips
Green Taxi trips
Taxi Zone Lookup
Format
Parquet 列式文件格式
Parquet 列式文件格式
CSV
Scale
~3M rows/month --> 36 M rows/year
~70K rows/month
265 zones
参考链接：https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page
问题：- How similar/different are the Yellow and Green datasets？
-
-
- How much data do I need? (1 month --> 10 years??)
问题：Is there value in trying to create a unified view that includes both？
问题：Is this technically feasible？

### 中文释义

本页围绕“Inspecting the available data”展开。课件中的关键信息包括：Inspecting the available data；Source；Yellow Taxi trips；Green Taxi trips。复习时先抓住Parquet：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Inspecting the available data'. The slide includes: Inspecting the available data; Source; Yellow Taxi trips; Green Taxi trips. The revision focus is Parquet; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Parquet / Parquet**：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。

拓展复习：把“Inspecting the available data”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 4 页的核心主题是什么？
**答：** 本页围绕“Inspecting the available data”展开。课件中的关键信息包括：Inspecting the available data；Source；Yellow Taxi trips；Green Taxi trips。复习时先抓住Parquet：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 4?
**Answer:** This page presents 'Inspecting the available data'. The slide includes: Inspecting the available data; Source; Yellow Taxi trips; Green Taxi trips. The revision focus is Parquet; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：Parquet / Parquet
**答：** 列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。
**Q2 English:** Explain the concept on this page: Parquet
**Answer:** The page focuses on Parquet. This page presents 'Inspecting the available data'. The slide includes: Inspecting the available data; Source; Yellow Taxi trips; Green Taxi trips. The revision focus is Parquet; connect its definition, evidence, and use to the examples on the page.

## 第 5 页：Step 1: loading data and metadata

Source ID: `src-2f6570f71ed0-pdf_page-00005`

![PDF page 5](../assets/pages/page_005.jpg)

### 原文 / Original Text

```text
Step 1: loading data and metadata

Refer to these notebooks:

0. databricks_taxi_read-into_DBFS

Load raw data into DataBricks File System (DBFS)

1. data_load_to_Delta_Tables

Load and integrate the TAXI datasets into Delta Tables

TLC 
site

DBFS

Add metadata 
to Catalog

Load data into 
Delta Table
```

### 完整中文翻译

Step 1: loading data and metadata
Refer to these notebooks:
0. databricks_taxi_read-into_DBFS
Load raw data into DataBricks File System (DBFS)
1. data_load_to_Delta_Tables
Load and integrate the TAXI datasets into Delta 表
TLC
site
DBFS
Add metadata
to Catalog
Load data into
Delta Table

### 中文释义

本页围绕“Step 1: loading data and metadata”展开。课件中的关键信息包括：Step 1: loading data and metadata；Refer to these notebooks:；0. databricks_taxi_read-into_DBFS；Load raw data into DataBricks File System (DBFS)。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Step 1: loading data and metadata'. The slide includes: Step 1: loading data and metadata; Refer to these notebooks:; 0. databricks_taxi_read-into_DBFS; Load raw data into DataBricks File System (DBFS). The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Core idea / 核心思想**：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。

拓展复习：把“Step 1: loading data and metadata”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 5 页的核心主题是什么？
**答：** 本页围绕“Step 1: loading data and metadata”展开。课件中的关键信息包括：Step 1: loading data and metadata；Refer to these notebooks:；0. databricks_taxi_read-into_DBFS；Load raw data into DataBricks File System (DBFS)。复习时先抓住核心思想：本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 5?
**Answer:** This page presents 'Step 1: loading data and metadata'. The slide includes: Step 1: loading data and metadata; Refer to these notebooks:; 0. databricks_taxi_read-into_DBFS; Load raw data into DataBricks File System (DBFS). The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：核心思想 / Core idea
**答：** 本页提供当前讲义段落的关键定义、步骤、例子或总结，应放回前后页理解。
**Q2 English:** Explain the concept on this page: Core idea
**Answer:** The page focuses on Core idea. This page presents 'Step 1: loading data and metadata'. The slide includes: Step 1: loading data and metadata; Refer to these notebooks:; 0. databricks_taxi_read-into_DBFS; Load raw data into DataBricks File System (DBFS). The revision focus is Core idea; connect its definition, evidence, and use to the examples on the page.

## 第 6 页：模式/表结构 inspection

Source ID: `src-2f6570f71ed0-pdf_page-00006`

![PDF page 6](../assets/pages/page_006.jpg)

### 原文 / Original Text

```text
Schema inspection

Analyse incompatibilities before attempting a union

Months to download : ['2024-01', '2024-02', '2024-03']

Green rows loaded: 167,585

Yellow rows loaded: 9,554,778
```

### 完整中文翻译

模式/表结构 inspection
Analyse incompatibilities before attempting a 并集/纵向合并
Months to download : ['2024-01', '2024-02', '2024-03']
Green rows loaded: 167,585
Yellow rows loaded: 9,554,778

### 中文释义

本页围绕“Schema inspection”展开。课件中的关键信息包括：模式/表结构 inspection；Analyse incompatibilities before attempting a 并集/纵向合并；Months to download : ['2024-01', '2024-02', '2024-03']；Green rows loaded: 167,585。复习时先抓住模式：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Schema inspection'. The slide includes: Schema inspection; Analyse incompatibilities before attempting a union; Months to download : ['2024-01', '2024-02', '2024-03']; Green rows loaded: 167,585. The revision focus is Schema; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Schema / 模式**：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。
- **union / 并集/纵向合并**：把结构兼容的数据表按行合并；如果语义不同，技术上成功也可能训练出错误模型。

拓展复习：把“Schema inspection”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 6 页的核心主题是什么？
**答：** 本页围绕“Schema inspection”展开。课件中的关键信息包括：模式/表结构 inspection；Analyse incompatibilities before attempting a 并集/纵向合并；Months to download : ['2024-01', '2024-02', '2024-03']；Green rows loaded: 167,585。复习时先抓住模式：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 6?
**Answer:** This page presents 'Schema inspection'. The slide includes: Schema inspection; Analyse incompatibilities before attempting a union; Months to download : ['2024-01', '2024-02', '2024-03']; Green rows loaded: 167,585. The revision focus is Schema; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：模式 / Schema
**答：** 表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。
**Q2 English:** Explain the concept on this page: Schema
**Answer:** The page focuses on Schema. This page presents 'Schema inspection'. The slide includes: Schema inspection; Analyse incompatibilities before attempting a union; Months to download : ['2024-01', '2024-02', '2024-03']; Green rows loaded: 167,585. The revision focus is Schema; connect its definition, evidence, and use to the examples on the page.

## 第 7 页：模式/表结构 compatibility analysis

Source ID: `src-2f6570f71ed0-pdf_page-00007`

![PDF page 7](../assets/pages/page_007.jpg)

### 原文 / Original Text

```text
Schema compatibility analysis

renaming timestamp columns

-
- adding null-filled columns for missing fields
- casting types

See harmonize_yellow() and harmonize_green() in notebook  data_load_to_Delta_Tables()
```

### 完整中文翻译

模式/表结构 compatibility analysis
renaming timestamp columns
-
- adding 空值-filled columns for 缺失 fields
- casting types
See harmonize_yellow() and harmonize_green() in notebook data_load_to_Delta_Tables()

### 中文释义

本页围绕“Schema compatibility analysis”展开。课件中的关键信息包括：模式/表结构 compatibility analysis；renaming timestamp columns；-；- adding 空值-filled columns for 缺失 fields。复习时先抓住模式：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Schema compatibility analysis'. The slide includes: Schema compatibility analysis; renaming timestamp columns; -; - adding null-filled columns for missing fields. The revision focus is Schema; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Schema / 模式**：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。

拓展复习：把“Schema compatibility analysis”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 7 页的核心主题是什么？
**答：** 本页围绕“Schema compatibility analysis”展开。课件中的关键信息包括：模式/表结构 compatibility analysis；renaming timestamp columns；-；- adding 空值-filled columns for 缺失 fields。复习时先抓住模式：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 7?
**Answer:** This page presents 'Schema compatibility analysis'. The slide includes: Schema compatibility analysis; renaming timestamp columns; -; - adding null-filled columns for missing fields. The revision focus is Schema; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：模式 / Schema
**答：** 表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。
**Q2 English:** Explain the concept on this page: Schema
**Answer:** The page focuses on Schema. This page presents 'Schema compatibility analysis'. The slide includes: Schema compatibility analysis; renaming timestamp columns; -; - adding null-filled columns for missing fields. The revision focus is Schema; connect its definition, evidence, and use to the examples on the page.

## 第 8 页：Creating an integrated view

Source ID: `src-2f6570f71ed0-pdf_page-00008`

![PDF page 8](../assets/pages/page_008.jpg)

### 原文 / Original Text

```text
Creating an integrated view

1. Union yellow_trips with green_trips (harmonized)
2.

Join the result with the zone_lookup table

Schema
mapping

yellow

yellow_h

union

join

green

green_h

zones

unionByName to 
combine Yellow 
and Green safely

Join with the zone CSV 
for borough names

Integrated
trips

Partitioned Parquet output

pickup_month, taxi_type

for efficient downstream reads
```

### 完整中文翻译

Creating an integrated view
1. 并集/纵向合并 yellow_trips with green_trips (harmonized)
2.
连接 the result with the zone_lookup table
模式/表结构
mapping
yellow
yellow_h
并集/纵向合并
连接
green
green_h
zones
unionByName to
combine Yellow
and Green safely
连接 with the zone CSV
for borough names
Integrated
trips
Partitioned Parquet 列式文件格式 output
pickup_month, taxi_type
for efficient downstream reads

### 中文释义

本页围绕“Creating an integrated view”展开。课件中的关键信息包括：Creating an integrated view；1. 并集/纵向合并 yellow_trips with green_trips (harmonized)；2.；连接 the result with the zone_lookup table。复习时先抓住Parquet：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Creating an integrated view'. The slide includes: Creating an integrated view; 1. Union yellow_trips with green_trips (harmonized); 2.; Join the result with the zone_lookup table. The revision focus is Parquet; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Parquet / Parquet**：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。
- **Schema / 模式**：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。
- **union / 并集/纵向合并**：把结构兼容的数据表按行合并；如果语义不同，技术上成功也可能训练出错误模型。
- **join / 连接**：按键把表横向组合；键的语义不一致时会产生看似正确但实际错误的数据视图。
- **partition / 分区**：把数据切分到不同 worker；分区均衡决定分布式任务是否会卡在慢节点。

拓展复习：把“Creating an integrated view”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 8 页的核心主题是什么？
**答：** 本页围绕“Creating an integrated view”展开。课件中的关键信息包括：Creating an integrated view；1. 并集/纵向合并 yellow_trips with green_trips (harmonized)；2.；连接 the result with the zone_lookup table。复习时先抓住Parquet：列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 8?
**Answer:** This page presents 'Creating an integrated view'. The slide includes: Creating an integrated view; 1. Union yellow_trips with green_trips (harmonized); 2.; Join the result with the zone_lookup table. The revision focus is Parquet; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：Parquet / Parquet
**答：** 列式、压缩、可统计跳读的开放文件格式，适合分析查询和机器学习输入。
**Q2 English:** Explain the concept on this page: Parquet
**Answer:** The page focuses on Parquet. This page presents 'Creating an integrated view'. The slide includes: Creating an integrated view; 1. Union yellow_trips with green_trips (harmonized); 2.; Join the result with the zone_lookup table. The revision focus is Parquet; connect its definition, evidence, and use to the examples on the page.

## 第 9 页：Integration pitfalls: structure and 语义问题s

Source ID: `src-2f6570f71ed0-pdf_page-00009`

![PDF page 9](../assets/pages/page_009.jpg)

### 原文 / Original Text

```text
Integration pitfalls: structure and semantics

Two datasets can be structurally incompatible even when they describe the same real-world entities

Schema-level heterogeneity: same concept, different names
 - tpep_pickup_datetime vs lpep_pickup_datetime, different types (DoubleType vs IntegerType)

Instance-level heterogeneity:
- same schema, different value conventions ("credit_card" vs 1 vs "CC").

Semantic heterogeneity: columns with the same name but different meaning (e.g., total_amount 
including or excluding tolls depending on the operator)

Reference: Rahm, E. & Bernstein, P.A. (2001).
A survey of approaches to automatic schema matching, The VLDB Journal, 10(4), 334–350.
https://doi.org/10.1007/s007780100057
```

### 完整中文翻译

Integration pitfalls: structure and 语义问题s
Two datasets can be 结构性问题ly incompatible even when they describe the same real-world entities
模式/表结构-level heterogeneity: same concept, different names
- tpep_pickup_datetime vs lpep_pickup_datetime, different types (DoubleType vs IntegerType)
Instance-level heterogeneity:
- same 模式/表结构, different value conventions ("credit_card" vs 1 vs "CC").
语义问题 heterogeneity: columns with the same name but different meaning (e.g., total_amount
including or excluding tolls depending on the operator)
Reference: Rahm, E. & Bernstein, P.A. (2001).
A survey of approaches to automatic 模式/表结构 matching, The VLDB Journal, 10(4), 334–350.
参考链接：https://doi.org/10.1007/s007780100057

### 中文释义

本页围绕“Integration pitfalls: structure and semantics”展开。课件中的关键信息包括：Integration pitfalls: structure and 语义问题s；Two datasets can be 结构性问题ly incompatible even when they describe the same real-world entities；模式/表结构-level heterogeneity: same concept, different names；- tpep_pickup_datetime vs lpep_pickup_datetime, different types (DoubleType vs IntegerType)。复习时先抓住模式：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Integration pitfalls: structure and semantics'. The slide includes: Integration pitfalls: structure and semantics; Two datasets can be structurally incompatible even when they describe the same real-world entities; Schema-level heterogeneity: same concept, different names; - tpep_pickup_datetime vs lpep_pickup_datetime, different types (DoubleType vs IntegerType). The revision focus is Schema; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Schema / 模式**：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。

拓展复习：把“Integration pitfalls: structure and semantics”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 9 页的核心主题是什么？
**答：** 本页围绕“Integration pitfalls: structure and semantics”展开。课件中的关键信息包括：Integration pitfalls: structure and 语义问题s；Two datasets can be 结构性问题ly incompatible even when they describe the same real-world entities；模式/表结构-level heterogeneity: same concept, different names；- tpep_pickup_datetime vs lpep_pickup_datetime, different types (DoubleType vs IntegerType)。复习时先抓住模式：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 9?
**Answer:** This page presents 'Integration pitfalls: structure and semantics'. The slide includes: Integration pitfalls: structure and semantics; Two datasets can be structurally incompatible even when they describe the same real-world entities; Schema-level heterogeneity: same concept, different names; - tpep_pickup_datetime vs lpep_pickup_datetime, different types (DoubleType vs IntegerType). The revision focus is Schema; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：模式 / Schema
**答：** 表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。
**Q2 English:** Explain the concept on this page: Schema
**Answer:** The page focuses on Schema. This page presents 'Integration pitfalls: structure and semantics'. The slide includes: Integration pitfalls: structure and semantics; Two datasets can be structurally incompatible even when they describe the same real-world entities; Schema-level heterogeneity: same concept, different names; - tpep_pickup_datetime vs lpep_pickup_datetime, different types (DoubleType vs IntegerType). The revision focus is Schema; connect its definition, evidence, and use to the examples on the page.

## 第 10 页：Example: unsafe 并集/纵向合并

Source ID: `src-2f6570f71ed0-pdf_page-00010`

![PDF page 10](../assets/pages/page_010.jpg)

### 原文 / Original Text

```text
Example: unsafe union 

Plot fare distribution against distance for Yellow taxi 2019-Q1 ∪ 2020-Q2  

- The union is schema-valid: it is just Yellow taxi over different time periods
- But you find that the fare distribution is bimodal:
```

### 完整中文翻译

Example: unsafe 并集/纵向合并
Plot fare distribution against distance for Yellow taxi 2019-Q1 ∪ 2020-Q2
- The 并集/纵向合并 is 模式/表结构-valid: it is just Yellow taxi over different time periods
- But you find that the fare distribution is bimodal:

### 中文释义

本页围绕“Example: unsafe union”展开。课件中的关键信息包括：Example: unsafe 并集/纵向合并；Plot fare distribution against distance for Yellow taxi 2019-Q1 ∪ 2020-Q2；- The 并集/纵向合并 is 模式/表结构-valid: it is just Yellow taxi over different time periods；- But you find that the fare distribution is bimodal:。复习时先抓住模式：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Example: unsafe union'. The slide includes: Example: unsafe union; Plot fare distribution against distance for Yellow taxi 2019-Q1 ∪ 2020-Q2; - The union is schema-valid: it is just Yellow taxi over different time periods; - But you find that the fare distribution is bimodal:. The revision focus is Schema; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Schema / 模式**：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。
- **union / 并集/纵向合并**：把结构兼容的数据表按行合并；如果语义不同，技术上成功也可能训练出错误模型。

拓展复习：把“Example: unsafe union”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 10 页的核心主题是什么？
**答：** 本页围绕“Example: unsafe union”展开。课件中的关键信息包括：Example: unsafe 并集/纵向合并；Plot fare distribution against distance for Yellow taxi 2019-Q1 ∪ 2020-Q2；- The 并集/纵向合并 is 模式/表结构-valid: it is just Yellow taxi over different time periods；- But you find that the fare distribution is bimodal:。复习时先抓住模式：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 10?
**Answer:** This page presents 'Example: unsafe union'. The slide includes: Example: unsafe union; Plot fare distribution against distance for Yellow taxi 2019-Q1 ∪ 2020-Q2; - The union is schema-valid: it is just Yellow taxi over different time periods; - But you find that the fare distribution is bimodal:. The revision focus is Schema; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：模式 / Schema
**答：** 表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。
**Q2 English:** Explain the concept on this page: Schema
**Answer:** The page focuses on Schema. This page presents 'Example: unsafe union'. The slide includes: Example: unsafe union; Plot fare distribution against distance for Yellow taxi 2019-Q1 ∪ 2020-Q2; - The union is schema-valid: it is just Yellow taxi over different time periods; - But you find that the fare distribution is bimodal:. The revision focus is Schema; connect its definition, evidence, and use to the examples on the page.

## 第 11 页：Example: unsafe 并集/纵向合并 (cont.)

Source ID: `src-2f6570f71ed0-pdf_page-00011`

![PDF page 11](../assets/pages/page_011.jpg)

### 原文 / Original Text

```text
Example: unsafe union (cont.)

WHY is this happening? Hint: 2020-Q2 is during COVID

--> Cost of taxi rides per mile in this period is not directly comparable with “normal” cost of taxi rides

Property
Monthly trip volume
Median trip distance
Median fare
Most common pickup borough Manhattan (92%)
Short trips < 0.5 miles

2019-Q1 (normal)
~8.5 M
1.7 miles
$10.50

18% of all trips

2020-Q2 (lockdown)
~1.0 M (−88%)
3.2 miles (+88%)
$14.80 (+41%)
Manhattan (61%)
3% of all trips
```

### 完整中文翻译

Example: unsafe 并集/纵向合并 (cont.)
WHY is this happening? Hint: 2020-Q2 is during COVID
--> Cost of taxi rides per mile in this period is not directly comparable with “normal” cost of taxi rides
Property
Monthly trip volume
Median trip distance
Median fare
Most common pickup borough Manhattan (92%)
Short trips < 0.5 miles
2019-Q1 (normal)
~8.5 M
1.7 miles
$10.50
18% of all trips
2020-Q2 (lockdown)
~1.0 M (−88%)
3.2 miles (+88%)
$14.80 (+41%)
Manhattan (61%)
3% of all trips

### 中文释义

本页围绕“Example: unsafe union (cont.)”展开。课件中的关键信息包括：Example: unsafe 并集/纵向合并 (cont.)；WHY is this happening? Hint: 2020-Q2 is during COVID；--> Cost of taxi rides per mile in this period is not directly comparable with “normal” cost of taxi rides；Property。复习时先抓住并集/纵向合并：把结构兼容的数据表按行合并；如果语义不同，技术上成功也可能训练出错误模型。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Example: unsafe union (cont.)'. The slide includes: Example: unsafe union (cont.); WHY is this happening? Hint: 2020-Q2 is during COVID; --> Cost of taxi rides per mile in this period is not directly comparable with “normal” cost of taxi rides; Property. The revision focus is union; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **union / 并集/纵向合并**：把结构兼容的数据表按行合并；如果语义不同，技术上成功也可能训练出错误模型。

拓展复习：把“Example: unsafe union (cont.)”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 11 页的核心主题是什么？
**答：** 本页围绕“Example: unsafe union (cont.)”展开。课件中的关键信息包括：Example: unsafe 并集/纵向合并 (cont.)；WHY is this happening? Hint: 2020-Q2 is during COVID；--> Cost of taxi rides per mile in this period is not directly comparable with “normal” cost of taxi rides；Property。复习时先抓住并集/纵向合并：把结构兼容的数据表按行合并；如果语义不同，技术上成功也可能训练出错误模型。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 11?
**Answer:** This page presents 'Example: unsafe union (cont.)'. The slide includes: Example: unsafe union (cont.); WHY is this happening? Hint: 2020-Q2 is during COVID; --> Cost of taxi rides per mile in this period is not directly comparable with “normal” cost of taxi rides; Property. The revision focus is union; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：并集/纵向合并 / union
**答：** 把结构兼容的数据表按行合并；如果语义不同，技术上成功也可能训练出错误模型。
**Q2 English:** Explain the concept on this page: union
**Answer:** The page focuses on union. This page presents 'Example: unsafe union (cont.)'. The slide includes: Example: unsafe union (cont.); WHY is this happening? Hint: 2020-Q2 is during COVID; --> Cost of taxi rides per mile in this period is not directly comparable with “normal” cost of taxi rides; Property. The revision focus is union; connect its definition, evidence, and use to the examples on the page.

## 第 12 页：Example: unsafe 连接

Source ID: `src-2f6570f71ed0-pdf_page-00012`

![PDF page 12](../assets/pages/page_012.jpg)

### 原文 / Original Text

```text
Example: unsafe join

Suppose we want to associate Census data to taxi pickup/dropoff zones (zone_ lookup)
- Census data is public and contains location geo_id
-

This joins “correctly” with pickup_location_id

However, the resulting view is wrong because Census and Taxi use 
the same codes purely by coincidence
```

### 完整中文翻译

Example: unsafe 连接
Suppose we want to associate Census data to taxi pickup/dropoff zones (zone_ lookup)
- Census data is public and contains location geo_id
-
This joins “correctly” with pickup_location_id
However, the resulting view is wrong because Census and Taxi use
the same codes purely by coincidence

### 中文释义

本页围绕“Example: unsafe join”展开。课件中的关键信息包括：Example: unsafe 连接；Suppose we want to associate Census data to taxi pickup/dropoff zones (zone_ lookup)；- Census data is public and contains location geo_id；-。复习时先抓住连接：按键把表横向组合；键的语义不一致时会产生看似正确但实际错误的数据视图。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Example: unsafe join'. The slide includes: Example: unsafe join; Suppose we want to associate Census data to taxi pickup/dropoff zones (zone_ lookup); - Census data is public and contains location geo_id; -. The revision focus is join; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **join / 连接**：按键把表横向组合；键的语义不一致时会产生看似正确但实际错误的数据视图。

拓展复习：把“Example: unsafe join”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 12 页的核心主题是什么？
**答：** 本页围绕“Example: unsafe join”展开。课件中的关键信息包括：Example: unsafe 连接；Suppose we want to associate Census data to taxi pickup/dropoff zones (zone_ lookup)；- Census data is public and contains location geo_id；-。复习时先抓住连接：按键把表横向组合；键的语义不一致时会产生看似正确但实际错误的数据视图。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 12?
**Answer:** This page presents 'Example: unsafe join'. The slide includes: Example: unsafe join; Suppose we want to associate Census data to taxi pickup/dropoff zones (zone_ lookup); - Census data is public and contains location geo_id; -. The revision focus is join; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：连接 / join
**答：** 按键把表横向组合；键的语义不一致时会产生看似正确但实际错误的数据视图。
**Q2 English:** Explain the concept on this page: join
**Answer:** The page focuses on join. This page presents 'Example: unsafe join'. The slide includes: Example: unsafe join; Suppose we want to associate Census data to taxi pickup/dropoff zones (zone_ lookup); - Census data is public and contains location geo_id; -. The revision focus is join; connect its definition, evidence, and use to the examples on the page.

## 第 13 页：Integration pitfalls: Data fusion, unbalancing

Source ID: `src-2f6570f71ed0-pdf_page-00013`

![PDF page 13](../assets/pages/page_013.jpg)

### 原文 / Original Text

```text
Integration pitfalls: Data fusion, unbalancing 

Multiple sources may provide conflicting values for the same attribute
- e.g., two data providers reporting different trip distances (or other attribute values) for 

what appears to be the same trip

- how do you decide which one is correct?

Integration can be technically correct but the resulting training set is unbalanced
Example:
The Yellow+Green union produces a training set where
- ~98% of rows are Yellow taxi trips (Manhattan-heavy)
- ~2% are Green (outer borough-heavy)

This strong bias will reflect in a fare prediction model trained on this raw union
- Expect the model to overfit on Green fares predictions

Reference: Dong, X.L. & Srivastava, D. (2015). Big Data Integration, Morgan & Claypool. (Synthesis Lectures on Data 
Management, Vol. 7, No. 1)
https://doi.org/10.2200/S00578ED1V01Y201404DTM040
```

### 完整中文翻译

Integration pitfalls: Data fusion, unbalancing
Multiple sources may provide conflicting values for the same attribute
- e.g., two data providers reporting different trip distances (or other attribute values) for
what appears to be the same trip
问题：- how do you decide which one is correct？
Integration can be technically correct but the resulting training set is unbalanced
Example:
The Yellow+Green 并集/纵向合并 produces a training set where
- ~98% of rows are Yellow taxi trips (Manhattan-heavy)
- ~2% are Green (outer borough-heavy)
This strong bias will reflect in a fare prediction model trained on this raw 并集/纵向合并
- Expect the model to overfit on Green fares predictions
Reference: Dong, X.L. & Srivastava, D. (2015). 大数据 Integration, Morgan & Claypool. (Synthesis Lectures on Data
Management, Vol. 7, No. 1)
参考链接：https://doi.org/10.2200/S00578ED1V01Y201404DTM040

### 中文释义

本页围绕“Integration pitfalls: Data fusion, unbalancing”展开。课件中的关键信息包括：Integration pitfalls: Data fusion, unbalancing；Multiple sources may provide conflicting values for the same attribute；- e.g., two data providers reporting different trip distances (or other attribute values) for；what appears to be the same trip。复习时先抓住并集/纵向合并：把结构兼容的数据表按行合并；如果语义不同，技术上成功也可能训练出错误模型。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Integration pitfalls: Data fusion, unbalancing'. The slide includes: Integration pitfalls: Data fusion, unbalancing; Multiple sources may provide conflicting values for the same attribute; - e.g., two data providers reporting different trip distances (or other attribute values) for; what appears to be the same trip. The revision focus is union; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **union / 并集/纵向合并**：把结构兼容的数据表按行合并；如果语义不同，技术上成功也可能训练出错误模型。

拓展复习：把“Integration pitfalls: Data fusion, unbalancing”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 13 页的核心主题是什么？
**答：** 本页围绕“Integration pitfalls: Data fusion, unbalancing”展开。课件中的关键信息包括：Integration pitfalls: Data fusion, unbalancing；Multiple sources may provide conflicting values for the same attribute；- e.g., two data providers reporting different trip distances (or other attribute values) for；what appears to be the same trip。复习时先抓住并集/纵向合并：把结构兼容的数据表按行合并；如果语义不同，技术上成功也可能训练出错误模型。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 13?
**Answer:** This page presents 'Integration pitfalls: Data fusion, unbalancing'. The slide includes: Integration pitfalls: Data fusion, unbalancing; Multiple sources may provide conflicting values for the same attribute; - e.g., two data providers reporting different trip distances (or other attribute values) for; what appears to be the same trip. The revision focus is union; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：并集/纵向合并 / union
**答：** 把结构兼容的数据表按行合并；如果语义不同，技术上成功也可能训练出错误模型。
**Q2 English:** Explain the concept on this page: union
**Answer:** The page focuses on union. This page presents 'Integration pitfalls: Data fusion, unbalancing'. The slide includes: Integration pitfalls: Data fusion, unbalancing; Multiple sources may provide conflicting values for the same attribute; - e.g., two data providers reporting different trip distances (or other attribute values) for; what appears to be the same trip. The revision focus is union; connect its definition, evidence, and use to the examples on the page.

## 第 14 页：总结

Source ID: `src-2f6570f71ed0-pdf_page-00014`

![PDF page 14](../assets/pages/page_014.jpg)

### 原文 / Original Text

```text
Summary

We introduced the following concepts:

Moving data from ”raw” to “Bronze” entails
- Selecting datasets from the lakehouse
- Harmonising their schema
-

Integrating, using union and join when appropriate

However: 
The blind application of these steps may lead to very wrong results!

- Both union and join look superficially correct, but are semantically wrong
- when the integrated dataset is used as a training set, the resulting model will be poor
```

### 完整中文翻译

总结
We introduced the following concepts:
Moving data from ”raw” to “铜牌层/原始可追溯层” entails
- Selecting datasets from the 湖仓一体
- Harmonising their 模式/表结构
-
Integrating, using 并集/纵向合并 and 连接 when appropriate
However:
The blind application of these steps may lead to very wrong results!
- Both 并集/纵向合并 and 连接 look superficially correct, but are 语义问题ally wrong
- when the integrated dataset is used as a training set, the resulting model will be poor

### 中文释义

本页围绕“Summary”展开。课件中的关键信息包括：总结；We introduced the following concepts:；Moving data from ”raw” to “铜牌层/原始可追溯层” entails；- Selecting datasets from the 湖仓一体。复习时先抓住湖仓一体：在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。，再说明这些定义、数据、公式或示例如何支持本页主题。

### English Explanation

This page presents 'Summary'. The slide includes: Summary; We introduced the following concepts:; Moving data from ”raw” to “Bronze” entails; - Selecting datasets from the lakehouse. The revision focus is Lakehouse; connect its definition, evidence, and use to the examples on the page.

### 概念解析与拓展

- **Lakehouse / 湖仓一体**：在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。
- **Schema / 模式**：表的字段、类型和约束；数据工程中要区分写入前固定和查询时解释。
- **union / 并集/纵向合并**：把结构兼容的数据表按行合并；如果语义不同，技术上成功也可能训练出错误模型。
- **join / 连接**：按键把表横向组合；键的语义不一致时会产生看似正确但实际错误的数据视图。
- **MAR / 随机缺失**：缺失与其他可观测变量有关，但不直接由缺失值本身决定。

拓展复习：把“Summary”放回课程主线，追问它解决什么问题、依赖什么假设、输出如何评价，以及失败时会出现什么现象。

### 自测问题 / Self-check

**Q1 中文：** 第 14 页的核心主题是什么？
**答：** 本页围绕“Summary”展开。课件中的关键信息包括：总结；We introduced the following concepts:；Moving data from ”raw” to “铜牌层/原始可追溯层” entails；- Selecting datasets from the 湖仓一体。复习时先抓住湖仓一体：在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。，再说明这些定义、数据、公式或示例如何支持本页主题。
**Q1 English:** What is the core topic of page 14?
**Answer:** This page presents 'Summary'. The slide includes: Summary; We introduced the following concepts:; Moving data from ”raw” to “Bronze” entails; - Selecting datasets from the lakehouse. The revision focus is Lakehouse; connect its definition, evidence, and use to the examples on the page.

**Q2 中文：** 解释本页概念：湖仓一体 / Lakehouse
**答：** 在对象存储和开放文件格式上加入事务日志、治理和性能优化，使数据湖获得接近数据仓库的管理能力。
**Q2 English:** Explain the concept on this page: Lakehouse
**Answer:** The page focuses on Lakehouse. This page presents 'Summary'. The slide includes: Summary; We introduced the following concepts:; Moving data from ”raw” to “Bronze” entails; - Selecting datasets from the lakehouse. The revision focus is Lakehouse; connect its definition, evidence, and use to the examples on the page.
