# 工作定义与四属性

## Page-by-page Notes

### 第 1 页：Ingredients of an Intelligent Interactive Systems

Source ID: `src-a5decf9f86a2-pdf_page-00001`

这一页给出本讲目标：从第 1 讲的用户体验框架转向系统内部结构。你要学会把一个智能交互系统拆成层次，并在系统出错时定位是哪一层导致失败。

#### Concepts
- **Conceptual spine / 概念脊柱**：一个逐层分析系统的检查表，用来追踪人、感知、上下文、模型、行动、反馈和适应之间的关系。

### 第 2 页：The mis-cropped page

Source ID: `src-a5decf9f86a2-pdf_page-00002`

这页用手机扫描裁剪错误作为贯穿案例。重点不是马上猜“AI 错了”，而是把症状追踪到具体层：是传感输入模糊、上下文假设错、模型边缘检测错，还是用户无法修正反馈。

#### Concepts
- **Failure diagnosis / 失败诊断**：先描述症状，再定位到系统层次，最后选择修复方案。不同层出错需要不同修复。

### 第 3 页：From the frame to the box

Source ID: `src-a5decf9f86a2-pdf_page-00003`

第 1 讲是外部评价：系统如何改变用户。第 2 讲是内部分析：系统由哪些层组成，智能放在哪里，失败如何穿过层传播。

#### Concepts
- **Initiative, inference, visibility, reversibility / 主动权、推断、可见性、可撤销性**：第 1 讲的用户侧框架，在第 2 讲中会与系统内部层次连接起来。

### 第 4 页：The working definition

Source ID: `src-a5decf9f86a2-pdf_page-00004`

这一页给出本课对智能交互系统的工作定义。关键是 loop：系统不是离线做预测，而是在人的情境中感知、解释、行动、适应。模型输出永远是可错的推断。

#### Concepts
- **Inference / 推断**：系统对信号作出的最佳解释，例如用户意图、当前状态或偏好；它不是事实本身，可能错误。

### 第 5 页：Four properties, all required

Source ID: `src-a5decf9f86a2-pdf_page-00005`

这是本讲最核心的定义页。只有感知、解释、行动、闭环同时存在，才算智能交互系统。单纯自动化、单次预测或没有人类反馈的流水线都不完整。

#### Concepts
- **Closed loop / 闭环**：系统输出影响人，人的反应又影响系统下一步行为。没有这个回路，系统只是 pipeline。
- **Output channel / 输出通道**：系统把行动或信息传给人的方式，可以是信息、空间或物理通道。
