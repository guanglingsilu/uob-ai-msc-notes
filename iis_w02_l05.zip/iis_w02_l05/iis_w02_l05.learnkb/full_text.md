# 来源：W02_L05_Memory_Mental_Models_and_Cognitive_Load.pdf

<!-- SOURCE: W02_L05_Memory_Mental_Models_and_Cognitive_Load.pdf -->

<!-- PDF 页 1 -->

Memory, Mental 
Models and Cognitive 
Load

Intelligent Interactive Systems  ·  Week 2  ·  Lecture 05
University of Birmingham

Course-own diagram. Four chunks in the head, and the model of the system 
beside them.

<!-- PDF 页 2 -->

A phone number read aloud

Lecture 05 · Hook

Working memory is a short-lived store: 
after hearing eleven digits once, most 
people retain only a few without rehearsal.

Before writing, predict how many you will 
reproduce in order ten seconds later; the 
exercise makes the limit visible.

Grouping changes the result, because familiar 
chunks survive more readily than isolated 
digits.

Course-own diagram. The number is illustrative, not real.

<!-- PDF 页 3 -->

After the cue arrives: two questions

Lecture 05 · Central question

Lecture 04 established that the cue was 
noticed; now we ask what happens after it 
arrives.

Working memory, recognition, and cognitive 
load explain what the person can hold; mental 
models and explanations explain what they 
believe.

These processes interact: load can produce 
weaker models, and wrong models create 
further checking work.

Course-own diagram. Lecture 04 hands over to two questions and their theories.

<!-- PDF 页 4 -->

Working memory: a small, fragile store

Lecture 05 · Working memory

Baddeley and Hitch's (1974) model treats 
working memory as a central executive 
coordinating the phonological loop and 
visuospatial sketchpad, with an episodic 
buffer added by Baddeley (2000).

Miller (1956) popularised "seven, plus or 
minus two"; Cowan (2001) later argued the 
limit is nearer four chunks once grouping and 
rehearsal are controlled, so design for about 
four.

EO1

Plainly, information fades within seconds, so 
the system should carry state rather than 
asking the person to remember it.

Course-own diagram after Baddeley and Hitch (1974) and Baddeley (2000).

<!-- PDF 页 5 -->

Slide 4

EO1 

Who? The 7? The 4?
Eyal Ofek, 2026-09-23T15:45:09.013

<!-- PDF 页 6 -->

Gone in seconds: why waiting costs

Lecture 05 · Working memory

Peterson and Peterson (1959) prevented 
rehearsal while participants recalled three 
letters after increasing delays.

Recall falls sharply during the first ten to 
fifteen seconds; the slide shows the study's 
shape, not exact data.

The link to the last lecture (Lecture 04) is 
practical: six seconds of silence can outlast 
the request in working memory, so 
acknowledge quickly.

Course-own schematic after Peterson and Peterson (1959); the curve shows the shape of the result, 
not the data.

<!-- PDF 页 7 -->

Chunking: the same eleven digits, three ways

Lecture 05 · Working memory

A chunk is a unit the person can treat as 
one thing; eleven isolated digits overflow a 
store of about four chunks.

Three groups fit more easily, and a familiar 
group such as Birmingham's 0121 can be 
retrieved as one chunk.

Plainly, group information using existing 
knowledge and show more than about four 
items instead of asking the person to hold 
them.

Course-own diagram.

<!-- PDF 页 8 -->

Recognition beats recall

Lecture 05 · Recognition versus recall

Recall requires producing a command 
without an environmental cue; recognition 
lets the person identify an option that is 
already visible.

Norman (2013) describes this as "knowledge 
in the head" versus "knowledge in the world".

Plainly, menus support novice recognition, 
while experts may prefer command lines 
when the command is already known.

Course-own diagram after Norman (2013), chapter 3.

<!-- PDF 页 9 -->

The blank chat box is a command line

Lecture 05 · Recognition versus recall

"Ask me anything" presents an empty 
command line: the person must recall 
capabilities and state that the interface 
never showed.

Suggestion chips, shown sources, and recent 
actions move those cues into the world, 
supporting recognition.

Plainly, every unnecessary recall consumes 
working-memory capacity, so showing should 
beat remembering.

Course-own diagram. The blank box against three recognition designs.

<!-- PDF 页 10 -->

Cognitive load: three kinds, one budget

Lecture 05 · Cognitive load

Cognitive load theory distinguishes 
intrinsic load from the task, germane load 
from schema-building effort, and 
extraneous load from the design (Sweller, 
1988; Sweller, van Merriënboer and Paas, 
1998).

All three compete for limited working-memory 
capacity, but extraneous load is the part a 
designer can remove.

Plainly, make the task's complexity visible 
without adding interface work that the task 
never required.

Course-own diagram after Sweller (1988) and Sweller, van Merriënboer and Paas (1998).

<!-- PDF 页 11 -->

The same request, two designs

Lecture 05 · Worked example

Design A reads eight flights aloud and 
leaves the person to hold four fields for 
each one; Design B shows the same 
information.

The task and underlying model are 
unchanged, but Design B shifts retrieval from 
memory to recognition.

Plainly, present only a few spoken items, or 
show the full set so the person can compare 
it.

Course-own mock-ups; outcomes are illustrative and labelled as such.

<!-- PDF 页 12 -->

The same request under two load conditions

Lecture 05 · Worked example

Intrinsic load changes with context: sitting 
at a desk may be low, while driving makes 
the same request high-risk.

Voice-only interaction competes with the 
driving task, and a screen cannot be safely 
inspected.

Plainly, offer at most a few items, then ask 
"more?"; the right design depends on what the 
person is doing now.

Course-own table; cells are illustrative, the direction of each effect follows the memory literature.

<!-- PDF 页 13 -->

Your turn: recall, recognition, load

Lecture 05 · Interaction 2

Classify five interface moments as recall 
or recognition, then rate the extraneous 
load each one adds.

Redesign one moment so the relevant cue is 
visible rather than requiring the person to 
retrieve it.

Take two minutes, then defend the last 
judgement because context changes its cost.

Course-own worksheet.

<!-- PDF 页 14 -->

Mental models:
Different representations

Everyone involved builds a different model of 
the same request, and none may match what 
the user wanted.
The 1973 tree-swing cartoon follows one swing 
from the sponsor's proposal through the 
specification, the analyst's design, the 
programmers and installation.
Plainly, each panel is a mental model; the next 
slide shows how the designer's model reaches 
the user only through the system image.

The O.G. Tire Swing Cartoon. The original cartoon 1973

<!-- PDF 页 15 -->

Mental models: the runnable theory in the head

Lecture 05 · Mental models

A mental model is a runnable theory: the 
designer's model, the system image, and 
the user's model meet through one visible 
channel.

Johnson-Laird (1983) argues that people 
reason by building and running small internal 
models.

Norman (2013) stresses that a user's model 
need not be technically accurate, but it must 
support useful predictions; cues and feedback 
build it.

Course-own diagram after Norman (2013), chapter 1, and Johnson-Laird (1983).

<!-- PDF 页 16 -->

A model built from cues

Lecture 05 · Mental models

A cue such as a greeting can imply "it 
knows who I am", while a reference to 
yesterday can imply "it remembers 
everything".

If a system forgets a stated preference without 
explaining what it keeps, the user's model 
swings between extremes.

Plainly, visible and editable memory gives the 
person evidence about the system's 
boundaries and keeps the model calibrated.

Course-own diagram.

<!-- PDF 页 17 -->

Explanation dosage: what is just right?

Lecture 05 · Explanations

Kulesza et al. (2013) varied the soundness 
and completeness of explanations for a 
recommender system.

Completeness mattered most for accurate 
mental models; incomplete or unsound 
explanations produced confidently wrong 
models.

The fullest explanations also cost effort, so 
provide enough evidence to shape prediction 
without overwhelming the person.

Course-own schematic of the two dimensions in Kulesza et al. (2013); the plot is not the study's data.

<!-- PDF 页 18 -->

Three dosages of one explanation

Lecture 05 · Explanations

Too little—"recommended for you"—
leaves the person with the model "it 
guesses".

A just-right explanation states what it used, 
what it did not use, and how the person can 
change the result.

Too much, such as a list of thirty-nine feature 
weights, is far beyond the four chunks a 
person can hold; dosage depends on what 
shapes the next prediction.

EO1

Course-own mock-ups of three explanation dosages for a recommender.

<!-- PDF 页 19 -->

Slide 17

EO1 

What does 39 mean? Just a large number?
Eyal Ofek, 2026-09-23T15:47:47.604

<!-- PDF 页 20 -->

Human memory is not computer memory

Lecture 05 · The analogy

Human memory reconstructs a gist; a 
computer can return a stored copy, so the 
two systems do not fail in the same way.

Human forgetting and cue-based retrieval 
differ from machine deletion policies, keys, 
search, and similarity matching.

Plainly, use memory terminology carefully and 
state what the intelligent system keeps, 
forgets, and retrieves.

Course-own table.

<!-- PDF 页 21 -->

Phase 1: the model you want users to form

Lecture 05 · Project connection

Write one sentence describing what the 
system senses, remembers, decides, and 
when it acts.

List the three cues in the system image that 
build that mental model, then name the wrong 
model users may bring and the cue that 
corrects it.

Define evidence that users formed the model: 
what they can predict or do without asking.

Course-own worksheet.

<!-- PDF 页 22 -->

What they hold, and what model they form

Lecture 05 · Synthesis and bridge

Working memory holds about four chunks 
for seconds, so the system carries state 
and shows what can otherwise be 
forgotten.

Extraneous load is a design cost; mental 
models come from cues and feedback, while 
explanations must be complete, sound, and 
sized for available capacity.

Plainly, a model the person cannot form is a 
system they cannot use, and human memory 
is not machine memory.

Course-own diagram. Six rules for what the person can hold and model.

<!-- PDF 页 23 -->

References and further reading

Lecture 05 · References

Miller, G. A. (1956). The magical number seven, plus or minus two. Psychological Review, 63(2), 81–97.

Baddeley, A. D., & Hitch, G. (1974). Working memory. Psychology of Learning and Motivation, 8, 47–89.   ·   Baddeley, 
A. (2000). The episodic buffer. Trends in Cognitive Sciences, 4(11), 417–423.

Cowan, N. (2001). The magical number 4 in short-term memory. Behavioral and Brain Sciences, 24(1), 87–114.

Peterson, L. R., & Peterson, M. J. (1959). Short-term retention of individual verbal items. Journal of Experimental 
Psychology, 58(3), 193–198.

Sweller, J. (1988). Cognitive load during problem solving. Cognitive Science, 12(2), 257–285.   ·   Sweller, J., van 
Merriënboer, J. J. G., & Paas, F. (1998). Educational Psychology Review, 10(3), 251–296.

Johnson-Laird, P. N. (1983). Mental Models. Harvard University Press.

Kulesza, T., Stumpf, S., Burnett, M., Yang, S., Kwan, I., & Wong, W.-K. (2013). Too much, too little, or just right? Ways 
explanations impact end users' mental models. IEEE VL/HCC 2013, 3–10.

Norman, D. A. (2013). The Design of Everyday Things (revised and expanded edition). Basic Books, chapters 1–3.   ·   
Shneiderman, B. (2022). Human-Centered AI, explainability (previewed).

Full list with verification notes: W02_L05_references.md

Course-own diagram. The sources grouped by what they support.

<!-- PDF 页 24 -->

Optional viewing: Her (2013)

Follow the interaction between the person and the system

Mental model — what does Theodore initially think this new OS is capable of?
System image — what cues does the interface give him about intelligence, personality, 
memory and autonomy?
Recognition vs recall — does the onboarding expose choices, or require Theodore to 
know what to ask?
Cognitive load — notice how little technical configuration Theodore has to 
understand; the interaction compresses a complex system into a short conversation.
User modelling / memory — the setup asks personal questions and uses the answers 
immediately. What does Theodore now assume will be remembered?
Explanation dosage — the system gives almost no technical explanation of what it is 
doing. Is that elegant simplification, or does it create an inaccurate mental model?
Human vs machine memory — does the human-like voice encourage Theodore to 
assume that Samantha remembers and understands in a human-like way?
Expectation formation — before Samantha has done very much, her voice and 
conversational fluency already establish expectations about what sort of entity she is.

Screenshot: Her (2013):  https://www.youtube.com/watch?v=f9Hg1x-Ctlw
