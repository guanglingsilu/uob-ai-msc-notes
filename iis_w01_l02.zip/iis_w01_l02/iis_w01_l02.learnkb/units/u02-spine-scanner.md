# 概念脊柱与扫描器案例

## Page-by-page Notes

### 第 6 页：The conceptual spine at a glance

Source ID: `src-a5decf9f86a2-pdf_page-00006`

概念脊柱不是必须每层都复杂，而是让你知道要查哪里。某层为空不是失败，而是分析结果：例如没有记忆、没有适应、没有工具，都说明系统边界。

#### Concepts
- **Empty layer / 空层**：某一层不存在或只是占位，同样是有意义的系统分析发现。
- **Verification / 验证**：检查系统推断或行动是否有证据支持、是否可被用户或设计者确认。

### 第 7 页：Layers 1 and 2: the human and sensing

Source ID: `src-a5decf9f86a2-pdf_page-00007`

这页把 scanner 的前两层展开。人带着目标和心理模型进入系统；系统通过相机、运动传感器、方向传感器和触摸收集信号。这里的智能不是用户明确命令，而是系统从信号中看出“页面”。

#### Concepts
- **Sensing beyond commands / 超越命令的感知**：系统收集环境、身体或行为信号，而不只是执行用户显式指令。
- **Mental model / 心理模型**：用户对扫描器如何工作的预期，会影响他们如何操作和理解错误。

### 第 8 页：Layers 3 to 5: context, memory and knowledge

Source ID: `src-a5decf9f86a2-pdf_page-00008`

同一张图像不只由像素决定。上下文告诉系统当前情况，记忆给出个人历史，知识提供一般规则。三者都会影响扫描器如何解释边界、方向和文字。

#### Concepts
- **Context / 上下文**：当前任务和环境条件，例如第几页、方向、光照。
- **Memory / 记忆**：系统跨次保留的用户偏好或历史。
- **Knowledge / 知识**：通用语言、页面尺寸或领域规则。

### 第 9 页：Layer 6: the model

Source ID: `src-a5decf9f86a2-pdf_page-00009`

模型层负责把传感数据变成判断：哪里是纸张边界、如何校正透视、文字是什么。每个判断都是概率性的，不是绝对真相，所以后续界面需要让用户检查和修正。

#### Concepts
- **Edge detection / 边缘检测**：识别图像中强烈变化的边界，用于找页面轮廓。
- **Perspective estimation / 透视估计**：计算如何把斜拍页面变换成平整视图。
- **OCR / 光学字符识别**：从图像中识别文字，Tesseract 是经典例子。

### 第 10 页：Layers 7 and 8: planning and action

Source ID: `src-a5decf9f86a2-pdf_page-00010`

模型只是提出解释，规划层决定怎么处理解释，行动层真正改变状态。扫描器可以等一等、自动拍摄、提示用户或直接裁剪。不同选择会改变用户控制感和错误成本。

#### Concepts
- **Planning / 规划**：根据目标、不确定性和上下文选择下一步。
- **Action / 行动**：系统实际改变图像、文件、界面或外部环境的操作。

### 第 11 页：Layers 9 to 11: closing the loop

Source ID: `src-a5decf9f86a2-pdf_page-00011`

闭环意味着用户不是最后的旁观者，而是能改变系统下一步。即时反馈是拖角、重拍、接受；长期适应是系统把偏好变成默认。

#### Concepts
- **Feedback / 反馈**：系统让人看到结果并允许回应。
- **Adaptation / 适应**：系统根据长期行为改变未来默认行为。
- **Pipeline / 流水线**：没有人的回应影响下一步的线性处理流程。

### 第 12 页：Tracing the mis-crop to its layer

Source ID: `src-a5decf9f86a2-pdf_page-00012`

同一个错误表象可以来自不同层，修复也完全不同。不要把所有问题归咎于模型。用户无法修正、系统过早行动、反馈控件太小，都可能被误认为“AI 错了”。

#### Concepts
- **Symptom vs cause / 症状与原因**：看到的错误只是表象，真正原因需要沿层追踪证据。
- **Action/feedback failure / 行动或反馈失败**：系统行动时机或用户修正路径设计不当，常被误报为模型失败。
