# Computer Vision and Imaging knowledge base

逐页覆盖，共 78 页。

- [Week 4: Edges, Hough Detection and Eigenfaces](units/cv_w4.md)