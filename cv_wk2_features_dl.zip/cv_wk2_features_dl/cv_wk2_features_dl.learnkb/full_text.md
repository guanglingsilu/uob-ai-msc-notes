# 来源：Wk2_feature_20and_20DL.pdf

<!-- SOURCE: Wk2_feature_20and_20DL.pdf -->

<!-- PDF 页 1 -->

Feature Detection 
and Deep Learning

Jianbo Jiao

School of Computer Science
University of Birmingham

[Computer Vision and Imaging]

<!-- PDF 页 2 -->

Feature Detection/Extraction

3

<!-- PDF 页 3 -->

Feature Detection/Extraction

4

<!-- PDF 页 4 -->

Deep Learning-based Features

Nvidia to train 100,000 developers on deep learning AI

5

<!-- PDF 页 5 -->

Outline

Traditional visual feature descriptors
□ Points and patches
□ Edges and contours
□ Lines

Deep learning-based visual feature extraction
□ How to?
□ Convolutional Neural Networks
□ DL4CV

6

<!-- PDF 页 6 -->

Traditional visual feature descriptors

7

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.

<!-- PDF 页 7 -->

Traditional visual feature descriptors

Points and patches

8

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.

<!-- PDF 页 8 -->

Traditional visual feature descriptors

Points and patches

9

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.

<!-- PDF 页 9 -->

Traditional visual feature descriptors

Points and patches
Patches with gradients in at least two (significantly) 
different orientations are the easiest to localize 

10

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.

<!-- PDF 页 10 -->

Traditional visual feature descriptors

Points and patches
Adaptive non-maximal suppression 
(ANMS) 

11

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.

<!-- PDF 页 11 -->

Traditional visual feature descriptors

Points and patches
Scale invariance

12

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.

<!-- PDF 页 12 -->

Traditional visual feature descriptors

Points and patches
Rotational invariance

13

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.

<!-- PDF 页 13 -->

Traditional visual feature descriptors

Points and patches
Affine invariance

14

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.

<!-- PDF 页 14 -->

Traditional visual feature descriptors

Points and patches
multi-scale oriented patches (MOPS) 

15

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.

<!-- PDF 页 15 -->

Traditional visual feature descriptors

Points and patches
Scale invariant feature transform (SIFT) 

16

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.

<!-- PDF 页 16 -->

Traditional visual feature descriptors

Points and patches
Applications: Large-scale matching and retrieval

17

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.

<!-- PDF 页 17 -->

Traditional visual feature descriptors

Edges and contours

18

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.

<!-- PDF 页 18 -->

Traditional visual feature descriptors

Edges and contours
Gradient

Laplacian of Gaussian (LoG)

19

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.

<!-- PDF 页 19 -->

Traditional visual feature descriptors

Edges and contours
Sobel edge detector/operator

20

https://en.wikipedia.org/wiki/Sobel_operator

<!-- PDF 页 20 -->

Traditional visual feature descriptors

Edges and contours
Sobel edge detector/operator

x

y

21

https://en.wikipedia.org/wiki/Sobel_operator

<!-- PDF 页 21 -->

Traditional visual feature descriptors

Edges and contours
Canny edge detector

1.Apply Gaussian filter to smooth the image 
in order to remove the noise

2.Find the intensity gradients of the image

3.Apply gradient magnitude thresholding or 
lower bound cut-off suppression to get rid of 
spurious response to edge detection

4.Apply double threshold to determine 
potential edges

5.Track edge by hysteresis: Finalize the 
detection of edges by suppressing all the 
other edges that are weak and not 
connected to strong edges.

22

https://en.wikipedia.org/wiki/Canny_edge_detector

<!-- PDF 页 22 -->

Traditional visual feature descriptors

Edges and contours
Contour detection

23

Edge and Contour Detection with OpenCV and Python

<!-- PDF 页 23 -->

Traditional visual feature descriptors

(straight) Lines and vanishing points

24

Szeliski, R. (2022). Computer vision: algorithms and applications. Springer Nature.

<!-- PDF 页 24 -->

Traditional visual feature descriptors

(straight) Lines and vanishing points
Hough transforms: having edges “vote” for plausible 
line locations 

25

https://en.wikipedia.org/wiki/Hough_transform

<!-- PDF 页 25 -->

Traditional Image Categorization: Training phase

Slide credit:

Training 
Images

Training

Training 
Labels

Image 
Features

Classifier 
Training

Trained 
Classifier

26

<!-- PDF 页 26 -->

Traditional Image Categorization: Testing phase

Training 
Images

Training

Training 
Labels

Slide credit:

Image 
Features

Classifier 
Training

Trained 
Classifier

Testing

Image 
Features

Trained 
Classifier

Prediction

Outdoor

Test Image

27

<!-- PDF 页 27 -->

Features are have been the key…

Slide credit:

SIFT [Loewe IJCV 04]

HOG [Dalal and Triggs CVPR 05]

Hand-crafted

DPM [Felzenszwalb et al. PAMI 10]

SPM [Lazebnik et al. CVPR 06]

Color Descriptor [Van De Sande et al. PAMI 10]

28

<!-- PDF 页 28 -->

What about learning the features?
• Learn a feature hierarchy all the way from pixels 

to classifier

• Each layer extracts features from the output of 

previous layer

• Layers have (nearly) the same structure
• Train all layers jointly (“end-to-end”)

Image/ 
Video
Pixels

Layer 1

Layer 2

Layer 3

Simple 
Classifier

29

<!-- PDF 页 29 -->

Learning Feature Hierarchy

Goal: Learn useful higher-level features from images

Feature representation

Input data

[Lee et al., ICML
2009;  CACM 2011]

3rd layer  
“Objects”

2nd layer  
“Object parts”

1st layer  
“Edges”

Pixels

30

Slide credit: Rob Fergus

<!-- PDF 页 30 -->

Learning Feature Hierarchy

• Better performance

• Other domains (unclear how to hand engineer):

– Kinect
– Video
– Multi spectral

• Feature computation time

– Dozens of features now regularly used 
– Getting prohibitive for large datasets (10’s sec / image)

31

Slide credit: Rob Fergus

<!-- PDF 页 31 -->

“Shallow” vs. “Deep” architectures

32

Slide credit: Yann LeCun

<!-- PDF 页 32 -->

“Shallow” vs. “Deep” architectures

Layer 1

…

Layer k

33

Slide adapted from: Yann LeCun

<!-- PDF 页 33 -->

Why deep learning?

https://towardsdatascience.com/what-is-deep-learning-and-how-does-it-work-2ce44bb692ac

Slide credit:

34

<!-- PDF 页 34 -->

What is deep learning?
02
01

Classification

Detection

03

Matting

!!(#) = &

AlphaFold

05

06

Healthcare

04

Alpha GO

https://becominghuman.ai/building-an-image-classifier-using-deep-learning-in-python-totally-from-a-beginners-perspective-be8dbaf22dd8
https://towardsdatascience.com/deep-learning-method-for-object-detection-r-cnn-explained-ecdadd751d22?gi=51e5dd227143
https://www.befunky.com/learn/automatic-background-remover/, https://deepmind.com/research/case-studies/alphago-the-story-so-far

https://deepmind.com/blog/article/alphafold-a-solution-to-a-50-year-old-grand-challenge-in-biology,
https://stanfordmlgroup.github.io/projects/chexnet/

…

35

<!-- PDF 页 35 -->

A brief history

Brain

Supervised
learning

Unsupervised
learning

Modern
architectures

https://towardsdatascience.com/supervised-vs-unsupervised-learning-in-2-minutes-72dad148f242 https://medium.com/analytics-vidhya/cnns-architectures-lenet-alexnet-vgg-googlenet-resnet-and-more-666091488df5

36

<!-- PDF 页 36 -->

A brief history

Slide credit:

<!-- PDF 页 37 -->

A brief history

Slide credit:

<!-- PDF 页 38 -->

A brief history

Slide adapted from:

FCN UNet YOLO

Generative Adversarial Network (GAN)

Mask R-CNN

Capsule Network

Graph Neural Network (GNN)

Vision Transformer (ViT)

Neural Radiance Field (NeRF)

Today

<!-- PDF 页 39 -->

A brief history

Brain

Supervised
learning

Unsupervised
learning

Modern
architectures

https://towardsdatascience.com/supervised-vs-unsupervised-learning-in-2-minutes-72dad148f242 https://medium.com/analytics-vidhya/cnns-architectures-lenet-alexnet-vgg-googlenet-resnet-and-more-666091488df5

40

<!-- PDF 页 40 -->

Basic definition

Deep Learning

Deep Neural Network

Demo

Human Brain

Video

41

Image courtesy: https://medium.com/autonomous-agents/mathematical-foundation-for-activation-functions-in-artificial-neural-networks-a51c9dd7c089

<!-- PDF 页 41 -->

Samuel Velasco/Quanta Magazine

Basic definition

Deep Learning

Deep Neural Network

Demo

Human Brain

Video

42

Image courtesy: https://medium.com/autonomous-agents/mathematical-foundation-for-activation-functions-in-artificial-neural-networks-a51c9dd7c089

<!-- PDF 页 42 -->

Basic definition

43

<!-- PDF 页 43 -->

Basic definition

• Cascade neurons together

• Output from one layer is the input to the next

• Each layer has its own sets of weights

47

<!-- PDF 页 44 -->

Basic definition

•

Predictions are fed forward through the network
to classify

48

<!-- PDF 页 45 -->

Basic definition

•

Predictions are fed forward through the network
to classify

49

<!-- PDF 页 46 -->

Basic definition

•

Predictions are fed forward through the network
to classify

50

<!-- PDF 页 47 -->

Basic definition

•

Predictions are fed forward through the network
to classify

51

<!-- PDF 页 48 -->

Basic definition

•

Predictions are fed forward through the network
to classify

52

<!-- PDF 页 49 -->

Basic definition

•

Lots of hidden layers

• Depth = power (usually)

!
n
r
a
e
l

o
t
s
t
h
g
i
e
W

!
n
r
a
e
l

o
t
s
t
h
g
i
e
W

!
n
r
a
e
l

o
t
s
t
h
g
i
e
W

!
n
r
a
e
l

o
t
s
t
h
g
i
e
W

Figure from http://neuralnetworksanddeeplearning.com/chap5.html 

53

<!-- PDF 页 50 -->

How to learn features from deep networks

Slide credit:

Deep
Neural
Network

65

<!-- PDF 页 51 -->

Deep network design

Data

Convolution

Activation

Deep
Neural
Network

Pooling

Feature
maps

66

<!-- PDF 页 52 -->

Deep network design

Data

Convolution

Activation

Convolutional
Neural
Network

Pooling

Feature
maps

67

<!-- PDF 页 53 -->

Convolutional neural networks

Feature
maps

Pooling

Activation

Convolution

Data

68

<!-- PDF 页 54 -->

Convolutional neural networks

Feature
maps

Pooling

Activation

Convolution

Data

• CNN = a multi-layer neural network 

with

• Local connectivity:

• Neurons in a layer are only 

connected to a small region 
of the layer before it 
• Share weight parameters across 

spatial positions:

• Learning shift-invariant 

filter kernels

69

Image credit: A. Karpathy

<!-- PDF 页 55 -->

Convolutional neural networks

Feature
maps

Convolution

Data

70

Image credit: Ranzato

<!-- PDF 页 56 -->

Application to computer vision

Classification

Slide credit:

71

Slide credit:

<!-- PDF 页 57 -->

Slide credit:

72

Slide credit:

<!-- PDF 页 58 -->

Slide credit:

73

Slide credit:

<!-- PDF 页 59 -->

Slide credit:

74

Slide credit:

<!-- PDF 页 60 -->

Slide credit:

75

Slide credit:

<!-- PDF 页 61 -->

Slide credit:

76

Slide credit:

<!-- PDF 页 62 -->

Slide credit:

77

Slide credit:

<!-- PDF 页 63 -->

Slide credit:

78

Slide credit:

<!-- PDF 页 64 -->

Slide credit:

79

Slide credit:

<!-- PDF 页 65 -->

Slide credit:

80

Slide credit:

<!-- PDF 页 66 -->

Slide credit:

81

Slide credit:

<!-- PDF 页 67 -->

Slide credit:

82

Slide credit:

<!-- PDF 页 68 -->

Slide credit:

83

Slide credit:

<!-- PDF 页 69 -->

Slide credit:

84

Slide credit:

<!-- PDF 页 70 -->

Slide credit:

85

Slide credit:

<!-- PDF 页 71 -->

Slide credit:

86

Slide credit:

<!-- PDF 页 72 -->

Slide credit:

87

Slide credit:

<!-- PDF 页 73 -->

Slide credit:

88

Slide credit:

<!-- PDF 页 74 -->

Slide credit:

89

Slide credit:

<!-- PDF 页 75 -->

Slide credit:

90

Slide credit:

<!-- PDF 页 76 -->

Slide credit:

91

Slide credit:

<!-- PDF 页 77 -->

Convolutional neural networks

Feature
maps

Convolution

Kernel size

Stride

Padding

Data

Dilation

Image credit: https://towardsdatascience.com/types-of-convolutions-in-deep-learning-717013397f4d

92

<!-- PDF 页 78 -->

Convolutional neural networks

Feature
maps

Convolution

Kernel size = 3

Stride = 1

Padding = 1

Data

Dilation

Receptive field

93

Image credit: https://towardsdatascience.com/types-of-convolutions-in-deep-learning-717013397f4d

<!-- PDF 页 79 -->

Convolutional neural networks

Feature
maps

Convolution

Kernel size = 3

Stride = 2

Padding = 0

Data

Dilation

Image credit: https://towardsdatascience.com/types-of-convolutions-in-deep-learning-717013397f4d

94

<!-- PDF 页 80 -->

Convolutional neural networks

Feature
maps

Convolution

Kernel size = 3

Stride = 1

Padding = 0

Data

Dilation = 2

Image credit: https://towardsdatascience.com/types-of-convolutions-in-deep-learning-717013397f4d

95

<!-- PDF 页 81 -->

Convolutional neural networks

Feature
maps

Convolution

Kernel size

Input size S x S

Stride

Padding

Sin = 224, padding = 1, kernel size = 3,
stride = 1, dilation = 2

Data

Dilation

96

<!-- PDF 页 82 -->

Convolutional neural networks

Convolution

• Weighted moving sum

.
.
.

Input

Feature Activation Map

97

<!-- PDF 页 83 -->

Convolutional neural networks
Convolution • Few parameters (filter 

weights)

• Dependencies are local 
• Translation invariance

.
.
.

Input

Feature Activation Map

98

<!-- PDF 页 84 -->

Convolutional neural networks

Feature
maps

Pooling

Activation

Convolution

Data

.
.
.

Input

Feature Map

99

<!-- PDF 页 85 -->

Convolutional neural networks

Feature
maps

Pooling

Activation

Convolution

Data

100

<!-- PDF 页 86 -->

Convolutional neural networks
Non-linear
Activation

•

Per-element (independent)

• Options:
Tanh (Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)
□ Makes learning faster
□
□

Simplifies backpropagation
Avoids saturation issues
à Preferred option

101

<!-- PDF 页 87 -->

Convolutional neural networks
Non-linear
Activation

• Options:
Tanh(Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)

□ Dying ReLU problem

102

https://hmkcode.com/ai/backpropagation-step-by-step/

<!-- PDF 页 88 -->

Convolutional neural networks
Non-linear
Activation

• Options:
Tanh(Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)
□

Leaky ReLU

103

<!-- PDF 页 89 -->

Convolutional neural networks
Non-linear
Activation

• Options:
Tanh(Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)
□
□

Leaky ReLU
Parametric ReLU

104

<!-- PDF 页 90 -->

Convolutional neural networks
Non-linear
Activation

• Options:
Tanh(Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)
□
□
□

Leaky ReLU
Parametric ReLU
Exponential Linear Units (ELUs)

105

<!-- PDF 页 91 -->

Convolutional neural networks
Non-linear
Activation

• Options:
Tanh(Hyperbolic Tangent)
□
Sigmoid: 1/(1+exp(-x))
□
□ Rectified linear unit (ReLU)
□
□
□
□
□ …

Leaky ReLU
Parametric ReLU
Exponential Linear Units (ELUs)
Softmax

https://towardsdatascience.com/softmax-activation-function-explained-a7e1bc3ad60

106

<!-- PDF 页 92 -->

Convolutional neural networks

Feature
maps

Pooling

Activation

Convolution

Data

Max-pooling

Average-pooling

Max pooling

Max-pooling: a non-linear down-sampling

Provide translation invariance

107

<!-- PDF 页 93 -->

Convolutional neural networks

Feature
maps

Pooling

Activation

Convolution

Data

108

<!-- PDF 页 94 -->

Convolutional neural networks

Feature
maps

Pooling

Activation

Convolution

Data

109

<!-- PDF 页 95 -->

Convolutional neural networks

Max-pooling

Average-pooling

Feature
maps

Pooling

Activation

Convolution

Data

110

Image credit: Research gate

<!-- PDF 页 96 -->

Convolutional neural networks

Feature
maps

Pooling

Max-pooling

Average-pooling

•

Spatial pooling:

□ Average or max

Activation

□ Non-overlapping / overlapping regions

□ Role of pooling:

Convolution

Data

□

□

Invariance to small transformations

Larger receptive fields (see more of input)

111

Image credit: Research gate

<!-- PDF 页 97 -->

Convolutional neural networks

Previous CNN success

•

•

Handwritten text/digits
□ MNIST (0.17% error [Ciresan et al. 2011])
□ Arabic & Chinese   [Ciresan et al. 2012]

Simpler recognition benchmarks
□ CIFAR-10 (9.3% error [Wan et al. 2013])
□

Traffic sign recognition
□

0.56% error vs 1.16% for humans 
[Ciresan et al. 2011]

112

<!-- PDF 页 98 -->

Convolutional neural networks

LeNet [LeCun et al. 1998]

•
Stack multiple stages of feature extractors
• Higher stages compute more global, more 

invariant features
Classification layer at the end

•

LeNet-1 from 1993

113

Gradient-based learning applied to document recognition [LeCun, Bottou, Bengio, Haffner 1998]

<!-- PDF 页 99 -->

Convolutional neural networks

ImageNet Challenge 2012

•

•

•

•

~14 million labeled images, 20k classes

Images gathered from Internet

Human labels via Amazon’s Mechanical Turk

ImageNet Challenge: 1.2 million training 
images, 1000 classes

[Deng et al. CVPR 2009] 

114

<!-- PDF 页 100 -->

Convolutional neural networks
AlexNet •

Bigger model (7 hidden layers, 650,000 units, 60,000,000 params)

Similar framework to LeCun’98 but:
•
• More data (106 vs. 103 images)
• GPU implementation (50x speedup over CPU)
Trained on two GPUs for a week

•

A. Krizhevsky, I. Sutskever, and G. Hinton, ImageNet Classification with Deep Convolutional Neural Networks, NIPS 2012

115

<!-- PDF 页 101 -->

Convolutional neural networks

AlexNet for image classification

AlexNet

Fixed input size: 224x224x3

“car”

116

A. Krizhevsky, I. Sutskever, and G. Hinton, ImageNet Classification with Deep Convolutional Neural Networks, NIPS 2012

<!-- PDF 页 102 -->

Convolutional neural networks

ImageNet 
Classification 
Challenge

AlexNet

http://image-net.org/challenges/talks/2016/ILSVRC2016_10_09_clsloc.pdf

117

<!-- PDF 页 103 -->

Convolutional neural networks

ImageNet 
Classification 
Challenge

118

Slide credit: Samuel Albanie

<!-- PDF 页 104 -->

Convolutional neural networks

119

Slide credit: Samuel Albanie

<!-- PDF 页 105 -->

Convolutional neural networks

120

Slide credit: Samuel Albanie

<!-- PDF 页 106 -->

Convolutional neural networks

121

Slide credit: Samuel Albanie

<!-- PDF 页 107 -->

Convolutional neural networks

Visualise CNNs

What input pattern originally 
caused a given activation in 
the feature maps?

Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]

122

<!-- PDF 页 108 -->

Convolutional neural networks

Visualise CNNs

Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]

123

<!-- PDF 页 109 -->

Convolutional neural networks

Visualise CNNs

Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]

124

<!-- PDF 页 110 -->

Convolutional neural networks

Visualise CNNs

Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]

125

<!-- PDF 页 111 -->

Convolutional neural networks

Visualise CNNs

Demo

Visualizing and Understanding Convolutional Networks [Zeiler and Fergus, ECCV 2014]

126

<!-- PDF 页 112 -->

CNN training

Image credit: https://towardsdatascience.com/a-visual-explanation-of-gradient-descent-methods-momentum-adagrad-rmsprop-adam-f898b102325c

127

<!-- PDF 页 113 -->

CNN training, how?

•

•

•

•

The goal is to iteratively find a set of weights that allow the 
activations/outputs to match the desired output

For this, we will minimize a loss function

The loss function quantifies the agreement between the predicted scores 
and GT labels

First, let’s simplify and assume we have a single layer of weights in the 
network 

128

<!-- PDF 页 114 -->

CNN training, how?

Example dataset: CIFAR-10  
10 labels
50,000 training images  

each image is 32x32x3

10,000 test images.

129

Credit: Andrej Karpathy

<!-- PDF 页 115 -->

CNN training, how?

Classification scores

image parameters

+ b

f(x,W)

10 numbers,  
indicating class  
scores

[32x32x3]
array of numbers 0...1  
(3072 numbers total)

130

Credit: Andrej Karpathy

<!-- PDF 页 116 -->

CNN training, how?

Linear classifier

3072x1

+b

10x1

10x1

10x3072

10 numbers,  
indicating class  
scores

[32x32x3]
array of numbers 0...1

parameters, or “weights”

131

Credit: Andrej Karpathy

<!-- PDF 页 117 -->

CNN training, how?

Linear classifier

Example with an image with 4 pixels, and 3 classes (cat/dog/ship)

132

Credit: Andrej Karpathy

<!-- PDF 页 118 -->

CNN training, how?

Linear classifier

-3.45
-8.87
0.09
2.9
4.48
8.02
3.78
1.06
-0.36
-0.72

-0.51
6.04
5.31
-4.22
-4.19
3.58
4.49
-4.37
-2.09
-2.93

3.42
4.64
2.65
5.1
2.64
5.55
-4.34
-1.5
-4.79
6.14

TODO:

1. Define a loss function  
that quantifies our  
unhappiness with the  
scores across the training  
data.

2. Come up with a way of  
efficiently finding the  
parameters that minimize  
the loss function.  
(optimization)

133

Credit: Andrej Karpathy

<!-- PDF 页 119 -->

CNN training, how?

Linear classifier

Suppose: 3 training examples, 3 classes.  
With some W the scores

are:

cat

car

frog

3.2
5.1
-1.7

1.3
4.9
2.0

2.2
2.5
-3.1

134

Credit: Andrej Karpathy

<!-- PDF 页 120 -->

CNN training, how?

Linear classifier

Suppose: 3 training examples, 3 classes.  
With some W the scores

are:

cat

car

frog

3.2
5.1
-1.7

1.3
4.9
2.0

2.2
2.5
-3.1

Hinge loss:

Given an example
where  
where

is the image and
is the (integer) label,

and using the shorthand for the  
scores vector:

the loss has the form:

Want: syi >= sj + 1
i.e. sj – syi + 1 <= 0

If true, loss is 0
If false, loss is magnitude of violation

135

Credit: Andrej Karpathy

<!-- PDF 页 121 -->

CNN training, how?

Linear classifier

Suppose: 3 training examples, 3 classes.  
With some W the scores

are:

cat

car

frog

3.2
5.1
-1.7

1.3
4.9
2.0

2.2
2.5
-3.1

Hinge loss:

Given an example
where  
where

is the image and
is the (integer) label,

and using the shorthand for the  
scores vector:

the loss has the form:

Want: syi >= sj + 1
i.e. sj – syi + 1 <= 0

If true, loss is 0
If false, loss is magnitude of violation

136

Credit: Andrej Karpathy

<!-- PDF 页 122 -->

CNN training, how?

Linear classifier

Suppose: 3 training examples, 3 classes.  
With some W the scores

are:

cat

car  

frog

Loss:

3.2
5.1
-1.7
2.9

1.3
4.9
2.0

2.2
2.5
-3.1

Hinge loss:

Given an example
where  
where

is the image and
is the (integer) label,

and using the shorthand for the  
scores vector:

the loss has the form:

= max(0, 5.1 - 3.2 + 1)

+max(0, -1.7 - 3.2 + 1)
= max(0, 2.9) + max(0, -3.9)
= 2.9 + 0
= 2.9

137

Credit: Andrej Karpathy

<!-- PDF 页 123 -->

CNN training, how?

Linear classifier

Suppose: 3 training examples, 3 classes.  
With some W the scores

are:

cat

car

frog

Loss:

3.2

5.1
-1.7
2.9

1.3
4.9
2.0
0

2.2
2.5
-3.1

Hinge loss:

Given an example
where  
where

is the image and
is the (integer) label,

and using the shorthand for the  
scores vector:

the loss has the form:

= max(0, 1.3 - 4.9 + 1)

+max(0, 2.0 - 4.9 + 1)

= max(0, -2.6) + max(0, -1.9)
= 0 + 0
= 0

138

Credit: Andrej Karpathy

<!-- PDF 页 124 -->

CNN training, how?

Linear classifier

Suppose: 3 training examples, 3 classes.  
With some W the scores

are:

cat

car  

frog

Loss:

3.2
5.1
-1.7
2.9

1.3
4.9
2.0
0

2.2
2.5
-3.1
12.9

Hinge loss:

Given an example
where  
where

is the image and
is the (integer) label,

and using the shorthand for the  
scores vector:

the loss has the form:

= max(0, 2.2 - (-3.1) + 1)

+max(0, 2.5 - (-3.1) + 1)

= max(0, 5.3 + 1) 

+ max(0, 5.6 + 1)

= 6.3 + 6.6 = 12.9

139

Credit: Andrej Karpathy

<!-- PDF 页 125 -->

CNN training, how?

Linear classifier

Suppose: 3 training examples, 3 classes.  
With some W the scores

are:

cat

car  

frog

Loss:

3.2
5.1
-1.7
2.9

1.3
4.9
2.0
0

2.2
2.5
-3.1
12.9

Hinge loss:

Given an example
where  
where

is the image and
is the (integer) label,

and using the shorthand for the  
scores vector:

the loss has the form:

and the full training loss is the mean  
over all examples in the training data:

L = (2.9 + 0 + 12.9)/3

= 15.8 / 3 = 5.3

140

Credit: Andrej Karpathy

<!-- PDF 页 126 -->

CNN training, how?

Linear classifier: Hinge loss

Weight Regularization

λ = regularization strength  
(hyperparameter)

In common use:  
L2 regularization  
L1 regularization
Dropout (will see later)

141

Credit: Andrej Karpathy

<!-- PDF 页 127 -->

CNN training, how?

Another loss: Softmax
(cross-entropy)

scores = unnormalized log probabilities of the classes.

where

Want to maximize the log likelihood, or (for a loss function)  
to minimize the negative log likelihood of the correct class:

cat

car

frog

3.2
5.1
-1.7

142

Credit: Andrej Karpathy

<!-- PDF 页 128 -->

CNN training, how?

Another loss: Softmax
(cross-entropy)

unnormalized probabilities

cat

car

frog

3.2
5.1
-1.7

exp

24.5
164.0
0.18

normalize

0.13
0.87
0.00

unnormalized log probabilities

probabilities

L_i = -log(0.13)
= 0.89

143

Credit: Andrej Karpathy

<!-- PDF 页 129 -->

CNN training, how?

How to minimize the loss function?

Random search?

144

Photograph credit: Stewart Smith/Alamy, The Guardian

<!-- PDF 页 130 -->

CNN training, how?

How to minimize the loss function?

Random search?

Follow the slope!

145

Photograph credit: Stewart Smith/Alamy, The Guardian

<!-- PDF 页 131 -->

CNN training, how?

How to minimize the loss function?

In 1-dimension, the derivative of a function:

In multiple dimensions, the gradient is the vector of (partial derivatives).

146

Credit: Andrej Karpathy

<!-- PDF 页 132 -->

CNN training, how?

current W:

gradient dW:

[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347

[?,
?,
?,
?,
?,
?,
?,
?,
?,…]

147

Credit: Andrej Karpathy

<!-- PDF 页 133 -->

CNN training, how?

current W:

W + h (first dim):

[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347

[0.34 + 0.0001,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25322

gradient dW:

[?,
?,
?,
?,
?,
?,
?,
?,
?,…]

148

Credit: Andrej Karpathy

<!-- PDF 页 134 -->

CNN training, how?

current W:

W + h (first dim):

[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347

[0.34 + 0.0001,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25322

gradient dW:

(1.25322 - 1.25347)/0.0001
= -2.5

[-2.5,
[
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,…]

149

Credit: Andrej Karpathy

<!-- PDF 页 135 -->

CNN training, how?

current W:

W + h (second dim):

[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347

[0.34,
-1.11 + 0.0001,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25353

gradient dW:

[-2.5,
[
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,…]

150

Credit: Andrej Karpathy

<!-- PDF 页 136 -->

CNN training, how?

current W:

W + h (second dim):

[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347

[0.34,
-1.11 + 0.0001,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25353

gradient dW:

(1.25353 - 1.25347)/0.0001
= 0.6

[-2.5,
[
0.6,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,
?,…]

151

Credit: Andrej Karpathy

<!-- PDF 页 137 -->

CNN training, how?

current W:

W + h (third dim):

[0.34,
-1.11,
0.78,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347

[0.34,
-1.11,
0.78 + 0.0001,
0.12,
0.55,
2.81,
-3.1,
-1.5,
0.33,…]
loss 1.25347

gradient dW:

[-2.5,
[
0.6,
?,
?,
?,
?,
?,
?,
?,
?,…]

152

Credit: Andrej Karpathy

<!-- PDF 页 138 -->

CNN training, how?

153

Credit: Justin Johnson

<!-- PDF 页 139 -->

CNN training, how?

154

Credit: Justin Johnson

<!-- PDF 页 140 -->

CNN training, how?

155

Credit: Justin Johnson

<!-- PDF 页 141 -->

CNN training, how?

Loss gradients

•

•

Denoted as (diff notations):

i.e. how the loss changes as a function of the weights

• We want to change the weights in such a way that makes the loss 

decrease as fast as possible  

156

<!-- PDF 页 142 -->

CNN training, how?

Gradient descent

• We’ll update weights iteratively

• Move in direction opposite to gradient:

W_2

Time

L

Learning rate

loss function landscape

negative gradient direction

original W

W_1

157

Credit: Andrej Karpathy

<!-- PDF 页 143 -->

CNN training, how?

Gradient descent

•

•

•

•

Iteratively subtract the gradient with respect to the model 
parameters (w)

i.e. we’re moving in a direction opposite to the gradient of the loss

i.e. we’re moving towards smaller loss

The procedure of repeatedly evaluating the gradient 
and then performing a parameter update is called 
Gradient Descent

158

<!-- PDF 页 144 -->

CNN training, how?

Stochastic Gradient Descent
(SGD)

Gradient descent

Momentum

AdaGrad

RMSProp

Adam

https://towardsdatascience.com/a-visual-explanation-of-gradient-descent-methods-momentum-adagrad-rmsprop-adam-f898b102325c

160

<!-- PDF 页 145 -->

CNN training, how?

Stochastic Gradient Descent
(SGD)

https://www.kaggle.com/code/awsaf49/pytorch-sartorius-unet-strikes-back-train/notebook

161

<!-- PDF 页 146 -->

CNN training, how?

Learning rate selection

The effects of step size (or “learning rate”)

162

Credit: Andrej Karpathy

<!-- PDF 页 147 -->

CNN training, how?

GD in multi-layer nets

• We’ll update weights

• Move in direction opposite to gradient:

•

•

How to update the weights at all layers?

Answer: backpropagation of loss from higher layers to lower layers

163

<!-- PDF 页 148 -->

CNN training, how?

Backpropagation

First calculate error of output units and use this 

to change the top layer of weights.

Update weights into j

output

hidden

input

w(2)

w(1)

k

j

i

164

Adapted from Ray Mooney

<!-- PDF 页 149 -->

CNN training, how?

Backpropagation

Next calculate error for hidden units based on 

errors on the output units it feeds into.

output

hidden

input

k

j

i

165

Adapted from Ray Mooney

<!-- PDF 页 150 -->

CNN training, how?

Backpropagation

Finally update bottom layer of weights based on 

errors calculated for hidden units.

output

Update weights into i

hidden

input

k

j

i

166

Adapted from Ray Mooney

<!-- PDF 页 151 -->

CNN training, how?

Backpropagation

•

Easier if we use computational graphs, especially when we have 
complicated functions typical in deep neural networks 

167

Figure from Karpathy

<!-- PDF 页 152 -->

CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

168

Credit: Andrej Karpathy

<!-- PDF 页 153 -->

CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

169

Credit: Andrej Karpathy

<!-- PDF 页 154 -->

CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

170

Credit: Andrej Karpathy

<!-- PDF 页 155 -->

CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

171

Credit: Andrej Karpathy

<!-- PDF 页 156 -->

CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

172

Credit: Andrej Karpathy

<!-- PDF 页 157 -->

CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

173

Credit: Andrej Karpathy

<!-- PDF 页 158 -->

CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

174

Credit: Andrej Karpathy

<!-- PDF 页 159 -->

CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

175

Credit: Andrej Karpathy

<!-- PDF 页 160 -->

CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

176

Credit: Andrej Karpathy

<!-- PDF 页 161 -->

CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

Chain rule:

Upstream gradient

Local gradient

177

Credit: Andrej Karpathy

<!-- PDF 页 162 -->

CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

178

Credit: Andrej Karpathy

<!-- PDF 页 163 -->

CNN training, how?

Backpropagation

e.g. x = -2, y = 5, z = -4

Want:

Chain rule:

179

Credit: Andrej Karpathy

<!-- PDF 页 164 -->

CNN training, how?

Backpropagation

180

Credit: Justin Johnson

<!-- PDF 页 165 -->

CNN training, how?

Backpropagation

181

Credit: Justin Johnson

<!-- PDF 页 166 -->

CNN training, how?

Backpropagation

182

Credit: Justin Johnson

<!-- PDF 页 167 -->

CNN training, how?

Backpropagation

183

Credit: Justin Johnson

<!-- PDF 页 168 -->

CNN training, how?

Backpropagation

184

Credit: Justin Johnson

<!-- PDF 页 169 -->

CNN training, how?

Backpropagation

185

https://youtu.be/Ilg3gGewQ5U

<!-- PDF 页 170 -->

Do I have to use GPU?

186

<!-- PDF 页 171 -->

Do I have to use GPU?

Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung

187

<!-- PDF 页 172 -->

Do I have to use GPU?

Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung

188

<!-- PDF 页 173 -->

Do I have to use GPU?

Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung

189

<!-- PDF 页 174 -->

Do I have to use GPU?

Slide credit: Fei-Fei Li & Justin Johnson & Serena Yeung

190

<!-- PDF 页 175 -->

Why GPU for DL (GPU vs. CPU)?

191

<!-- PDF 页 176 -->

(free) GPUs to play with

Google Colab

192

<!-- PDF 页 177 -->

Coding with Vision

193

<!-- PDF 页 178 -->

194

https://fabienmaussion.info/scipro_ss2018/html/18-Scientific-Python.html

<!-- PDF 页 179 -->

195

https://fabienmaussion.info/scipro_ss2018/html/18-Scientific-Python.html

<!-- PDF 页 180 -->

Deep Learning Frameworks

2019

(UC Berkeley)

(Facebook)

(Baidu)

(NYU / Facebook)

(Facebook)

(Amazon)

(Microsoft)

(U Montreal)

(Google)

(Google)

+ MatConvNet etc…

196

<!-- PDF 页 181 -->

Frameworks

Now

197

<!-- PDF 页 182 -->

Frameworks and tips

2019

https://towardsdatascience.com/which-deep-learning-framework-is-growing-fastest-3f77f14aa318

198

<!-- PDF 页 183 -->

Frameworks and tips

Now

199

<!-- PDF 页 184 -->

Frameworks and tips

Now

200

<!-- PDF 页 185 -->

Frameworks and tips

Suggestions?

ü For beginners – Keras
ü For Google Cloud Platform – Tensorflow
ü For research – PyTorch
ü For Amazon Web Services (AWS) – MXNET
ü For MS Azura – CNTK
ü For Java developers – DL4J
ü For IOS developers – CoreML
ü For Interoperability - ONNX

201

<!-- PDF 页 186 -->

Frameworks and tips

Suggestions?

ü

ü

ü

ü

ü

ü

ü

Research-focused framework?

ü

industry-focused framework?

202

<!-- PDF 页 187 -->

Frameworks

Comparison

Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/

203

<!-- PDF 页 188 -->

Frameworks and tips

Comparison

Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/

204

<!-- PDF 页 189 -->

Frameworks and tips

Comparison

Figure credit: https://www.assemblyai.com/blog/pytorch-vs-tensorflow-in-2022/

205

<!-- PDF 页 190 -->

Frameworks and tips

Comparison

206

Credit: Fei-Fei Li & Justin Johnson & Serena Yeung

<!-- PDF 页 191 -->

Frameworks and tips

Comparison

207

<!-- PDF 页 192 -->

Frameworks and tips
TensorFlow: Tensorboard

visualization

208

<!-- PDF 页 193 -->

Frameworks and tips

visualization

209

<!-- PDF 页 194 -->

Frameworks and tips

visualization

210

<!-- PDF 页 195 -->

Frameworks and tips

visualization

211

https://wandb.ai/site

<!-- PDF 页 196 -->

Frameworks and tips

visualization

212

https://wandb.ai/site

<!-- PDF 页 197 -->

Coding with PyTorch

213

<!-- PDF 页 198 -->

https://youtu.be/u7x8RXwLKcA

https://pytorch.org/tutorials/beginner/deep_learning_60min_blitz.html

214

<!-- PDF 页 199 -->

PyTorch

An open source machine learning framework that accelerates the path from research 

prototyping to production deployment.

Website: https://pytorch.org/

215

<!-- PDF 页 200 -->

PyTorch

An open source machine learning framework that accelerates the path from research 

prototyping to production deployment.

Website: https://pytorch.org/

216

<!-- PDF 页 201 -->

Load
data

Network
design

Training
(loss/optimization)

test/analysis/
deploy

217

<!-- PDF 页 202 -->

Summary

Traditional visual feature descriptors
□ MOPS, SIFT
□ Edges and contours detection
□ Hough transforms

Deep learning-based visual feature extraction
□ Network design
□ Convolutional Neural Networks
□ How to train DL4CV

<!-- PDF 页 203 -->

Q & A
