# 自测题

## 第 1 页：Perception, Attention and Feedback
- p001-q1 中文：第 1 页的核心复习点是什么？
  - 答案：本讲把“系统给了反馈”拆成“人是否注意到、是否能解释、是否及时收到”。智能系统沟通不是把消息放到界面上就结束，而要匹配人的任务、感官通道和注意资源。
  - English: What is the key revision point on page 1?
  - Answer: This lecture asks whether feedback actually reaches and can be interpreted by a person who is already doing something.
- p001-q2 中文：解释本页概念：Feedback / 反馈
  - 答案：系统向用户传达状态、结果或确认的信号；只有被注意并解释后才有效。
  - English: Explain this concept: Feedback / 反馈
  - Answer: 系统向用户传达状态、结果或确认的信号；只有被注意并解释后才有效。
## 第 2 页：Watch the video
- p002-q1 中文：第 2 页的核心复习点是什么？
  - 答案：这一页设置了经典注意力实验。任务要求你专注于计数，为后面解释“可见事件也可能被错过”做铺垫。
  - English: What is the key revision point on page 2?
  - Answer: The video primes students for inattentional blindness by giving them a counting task that consumes attention.
- p002-q2 中文：解释本页概念：Counting task / 计数任务
  - 答案：用一个明确目标占用注意力，从而显示未被关注事件如何被漏看。
  - English: Explain this concept: Counting task / 计数任务
  - Answer: 用一个明确目标占用注意力，从而显示未被关注事件如何被漏看。
## 第 3 页：Count the passes
- p003-q1 中文：第 3 页的核心复习点是什么？
  - 答案：关键概念是 inattentional blindness：看见不等于注意到。对设计来说，静态图标或颜色变化即使“在屏幕上”，也可能在高负荷任务中完全失败。
  - English: What is the key revision point on page 3?
  - Answer: A visible event can still be missed when attention is committed elsewhere; this creates a design risk for passive cues.
- p003-q2 中文：解释本页概念：Inattentional blindness / 非注意盲视
  - 答案：人在专注于一个任务时，可能漏掉明显可见但未被期待的事件。
  - English: Explain this concept: Inattentional blindness / 非注意盲视
  - Answer: 人在专注于一个任务时，可能漏掉明显可见但未被期待的事件。
## 第 4 页：The feedback arrow, taken seriously
- p004-q1 中文：第 4 页的核心复习点是什么？
  - 答案：这页给出本讲总问题：反馈不是一条抽象箭头，而要穿过注意、竞争、不确定性、感官整合、速度和确认机制。
  - English: What is the key revision point on page 4?
  - Answer: The central question is what makes a system message arrive, compete appropriately, and support action acknowledgement.
- p004-q2 中文：解释本页概念：Feedback arrow / 反馈箭头
  - 答案：从系统消息到人的感知和解释之间的设计路径。
  - English: Explain this concept: Feedback arrow / 反馈箭头
  - Answer: 从系统消息到人的感知和解释之间的设计路径。
## 第 5 页：Selective attention: one narrow channel
- p005-q1 中文：第 5 页的核心复习点是什么？
  - 答案：选择性注意告诉我们：人的处理能力有限，线索必须进入注意通道。强行捕获注意可能有效，但代价是打断当前任务。
  - English: What is the key revision point on page 5?
  - Answer: Selective attention limits sustained processing, so designers must decide whether a cue fits current attention or justifiably interrupts it.
- p005-q2 中文：解释本页概念：Selective attention / 选择性注意
  - 答案：人在多个输入中优先处理某些输入的机制。
  - English: Explain this concept: Selective attention / 选择性注意
  - Answer: 人在多个输入中优先处理某些输入的机制。
## 第 6 页：Inattentional blindness as a design problem
- p006-q1 中文：第 6 页的核心复习点是什么？
  - 答案：这页把心理学实验转成设计判断：线索是否会被注意取决于任务环境。设计师要权衡注意捕获与打断成本。
  - English: What is the key revision point on page 6?
  - Answer: Visibility alone is not enough. A cue must be designed for the person's current task and disruption tolerance.
- p006-q2 中文：解释本页概念：Disruption cost / 打断成本
  - 答案：线索捕获注意时对当前任务造成的干扰。
  - English: Explain this concept: Disruption cost / 打断成本
  - Answer: 线索捕获注意时对当前任务造成的干扰。
## 第 7 页：Multiple resources: use a free channel
- p007-q1 中文：第 7 页的核心复习点是什么？
  - 答案：如果当前任务占用视觉空间资源，就不要再用视觉地图塞给用户；可以考虑听觉语言。但通道不同不等于零成本。
  - English: What is the key revision point on page 7?
  - Answer: Multiple-resource theory helps choose a less competing channel, while reminding us that every channel still has costs.
- p007-q2 中文：解释本页概念：Multiple-resource theory / 多资源理论
  - 答案：不同任务会占用不同模态、编码和处理阶段资源；资源重叠越多，干扰越大。
  - English: Explain this concept: Multiple-resource theory / 多资源理论
  - Answer: 不同任务会占用不同模态、编码和处理阶段资源；资源重叠越多，干扰越大。
## 第 8 页：Three perceptual limits every system runs into
- p008-q1 中文：第 8 页的核心复习点是什么？
  - 答案：三条设计约束：反馈要快；细节要放在用户看得到的地方；变化不能只靠用户自己发现。XR 和智能界面尤其受延迟影响。
  - English: What is the key revision point on page 8?
  - Answer: Latency, foveal resolution, and change blindness create concrete constraints for feedback and interface design.
- p008-q2 中文：解释本页概念：Latency / 延迟
  - 答案：用户动作和系统反馈之间的时间差。
  - English: Explain this concept: Latency / 延迟
  - Answer: 用户动作和系统反馈之间的时间差。
## 第 9 页：Change blindness
- p009-q1 中文：第 9 页的核心复习点是什么？
  - 答案：这是课堂活动页，用来让学生亲身体验变化盲视。设计含义是：如果系统状态变化很重要，就不要只依赖细微视觉变化。
  - English: What is the key revision point on page 9?
  - Answer: This activity makes change blindness experiential: students list noticed changes and then compare with what they missed.
- p009-q2 中文：解释本页概念：Flicker paradigm / 闪烁范式
  - 答案：通过视觉中断展示人对变化的感知依赖注意力。
  - English: Explain this concept: Flicker paradigm / 闪烁范式
  - Answer: 通过视觉中断展示人对变化的感知依赖注意力。
## 第 10 页：Signal detection: four outcomes, two quantities
- p010-q1 中文：第 10 页的核心复习点是什么？
  - 答案：这一页非常重要：模型证据质量和报警阈值是两件事。调低阈值可以减少漏报，但会增加误报；不是免费提升。
  - English: What is the key revision point on page 10?
  - Answer: Signal detection separates evidence quality from warning criterion, making error trade-offs explicit.
- p010-q2 中文：解释本页概念：Signal detection theory / 信号检测理论
  - 答案：分析系统在信号存在/不存在时做出警告/不警告决定的框架。
  - English: Explain this concept: Signal detection theory / 信号检测理论
  - Answer: 分析系统在信号存在/不存在时做出警告/不警告决定的框架。
## 第 11 页：The same evidence, two criteria
- p011-q1 中文：第 11 页的核心复习点是什么？
  - 答案：这页防止一个常见误解：阈值调节不能让模型更懂世界，只能改变错误类型。真正提高证据质量要改善传感器或模型。
  - English: What is the key revision point on page 11?
  - Answer: Moving the criterion changes the balance of misses and false alarms; improving sensitivity requires better evidence.
- p011-q2 中文：解释本页概念：Sensitivity / 敏感度
  - 答案：证据区分有危险与无危险的能力。
  - English: Explain this concept: Sensitivity / 敏感度
  - Answer: 证据区分有危险与无危险的能力。
## 第 12 页：A collision warning at three criteria
- p012-q1 中文：第 12 页的核心复习点是什么？
  - 答案：碰撞警告不能只追求 hit rate。误报过多会使用户习惯性忽略警告，最终损害系统有效性。
  - English: What is the key revision point on page 12?
  - Answer: Higher hit rates can come with many more false alarms, which may reduce practical benefit by changing user response.
- p012-q2 中文：解释本页概念：False alarm cost / 误报成本
  - 答案：不该警告时警告造成的打扰、信任下降或行为疲劳。
  - English: Explain this concept: False alarm cost / 误报成本
  - Answer: 不该警告时警告造成的打扰、信任下降或行为疲劳。
## 第 13 页：Cry wolf: what false alarms do over time
- p013-q1 中文：第 13 页的核心复习点是什么？
  - 答案：误报是长期交互问题，不只是一次错误。它会改变用户对未来警告的信任和响应。
  - English: What is the key revision point on page 13?
  - Answer: False alarms can train people to ignore later warnings, so evaluation must include responses over time.
- p013-q2 中文：解释本页概念：Cry-wolf effect / 狼来了效应
  - 答案：警报频繁不可靠后，用户对后续警报响应降低。
  - English: Explain this concept: Cry-wolf effect / 狼来了效应
  - Answer: 警报频繁不可靠后，用户对后续警报响应降低。
## 第 14 页：Every threshold is a criterion
- p014-q1 中文：第 14 页的核心复习点是什么？
  - 答案：阈值不只是技术参数，而是人机互动决策。必须先定义要检测什么，再讨论 miss/false alarm，并说明成本由谁承担。
  - English: What is the key revision point on page 14?
  - Answer: Every threshold is a criterion with human costs, whether in wake words, classifiers, retrieval, planning, or feedback.
- p014-q2 中文：解释本页概念：Threshold / 阈值
  - 答案：系统把连续证据转化为行动或不行动的决策边界。
  - English: Explain this concept: Threshold / 阈值
  - Answer: 系统把连续证据转化为行动或不行动的决策边界。
## 第 15 页：Your turn: set the criterion for three systems
- p015-q1 中文：第 15 页的核心复习点是什么？
  - 答案：练习要求你把 criterion 变成设计论证。不同系统错误成本不同，所以阈值也应该不同。
  - English: What is the key revision point on page 15?
  - Answer: The activity asks students to justify criteria by comparing the cost of misses and false alarms.
- p015-q2 中文：解释本页概念：Cost-based criterion setting / 基于成本的判据设置
  - 答案：根据漏报和误报的相对代价选择阈值。
  - English: Explain this concept: Cost-based criterion setting / 基于成本的判据设置
  - Answer: 根据漏报和误报的相对代价选择阈值。
## 第 16 页：Cue integration: weighting by reliability
- p016-q1 中文：第 16 页的核心复习点是什么？
  - 答案：人会综合多个线索，并倾向依赖更可靠的线索。设计中可以借用这个思想，但不要把实验结果直接当作所有信任判断公式。
  - English: What is the key revision point on page 16?
  - Answer: Cue integration combines estimates and can weight more reliable cues more heavily; applying it to trust is an analogy.
- p016-q2 中文：解释本页概念：Cue integration / 线索整合
  - 答案：把多个感官或信息线索组合成一个估计。
  - English: Explain this concept: Cue integration / 线索整合
  - Answer: 把多个感官或信息线索组合成一个估计。
## 第 17 页：Slide 16 comment
- p017-q1 中文：第 17 页的核心复习点是什么？
  - 答案：这是课件批注，不是正式知识点。它提示 cue integration 与触觉研究有关，尤其是视觉如何改变触觉渲染。
  - English: What is the key revision point on page 17?
  - Answer: This is a review comment noting that haptics research can illustrate visual influence on haptic rendering.
- p017-q2 中文：解释本页概念：Haptic rendering / 触觉渲染
  - 答案：通过设备生成触觉反馈，让用户感到接触、纹理或力。
  - English: Explain this concept: Haptic rendering / 触觉渲染
  - Answer: 通过设备生成触觉反馈，让用户感到接触、纹理或力。
## 第 18 页：Feedback timing: three thresholds
- p018-q1 中文：第 18 页的核心复习点是什么？
  - 答案：速度本身就是反馈设计。即使最终结果很慢，也要先让用户知道系统听到了、正在做、下一步是什么。
  - English: What is the key revision point on page 18?
  - Answer: Prompt acknowledgement prevents uncertainty while slower processing continues.
- p018-q2 中文：解释本页概念：Response-time thresholds / 响应时间阈值
  - 答案：0.1s、1s、10s 等大致时间界限，用于判断反馈是否及时。
  - English: Explain this concept: Response-time thresholds / 响应时间阈值
  - Answer: 0.1s、1s、10s 等大致时间界限，用于判断反馈是否及时。
## 第 19 页：Feedback modality: which channel?
- p019-q1 中文：第 19 页的核心复习点是什么？
  - 答案：反馈通道要根据任务资源选择：视觉适合细节，声音适合快速提醒，触觉适合低调确认。但每个通道都有竞争成本。
  - English: What is the key revision point on page 19?
  - Answer: Modality choice combines attention resources, error costs, and timing requirements.
- p019-q2 中文：解释本页概念：Feedback modality / 反馈模态
  - 答案：视觉、声音、语音、触觉等反馈通道。
  - English: Explain this concept: Feedback modality / 反馈模态
  - Answer: 视觉、声音、语音、触觉等反馈通道。
## 第 20 页：The cost of a late or missing acknowledgement
- p020-q1 中文：第 20 页的核心复习点是什么？
  - 答案：这页说明很多错误不是模型错，而是反馈晚造成用户重复行动。确认消息能减少不确定性。
  - English: What is the key revision point on page 20?
  - Answer: Late acknowledgement can cause repeated requests and duplicate actions even when the model's final answer is fine.
- p020-q2 中文：解释本页概念：Acknowledgement / 确认反馈
  - 答案：系统及时告知用户行动已被接收或正在处理。
  - English: Explain this concept: Acknowledgement / 确认反馈
  - Answer: 系统及时告知用户行动已被接收或正在处理。
## 第 21 页：Phase 1: your channel and the cost of a miss
- p021-q1 中文：第 21 页的核心复习点是什么？
  - 答案：项目任务把本讲工具落地：你必须为一个 cue 说明通道、用户当前任务、资源竞争、漏报/误报成本和判据选择。
  - English: What is the key revision point on page 21?
  - Answer: The project task asks students to justify one cue and channel using current task resources and error costs.
- p021-q2 中文：解释本页概念：Cue-channel justification / 线索-通道论证
  - 答案：说明某个消息为什么通过某个通道传达，并如何权衡错误成本。
  - English: Explain this concept: Cue-channel justification / 线索-通道论证
  - Answer: 说明某个消息为什么通过某个通道传达，并如何权衡错误成本。
## 第 22 页：What a person can notice, and how fast
- p022-q1 中文：第 22 页的核心复习点是什么？
  - 答案：总结页把本讲三个部分连起来：注意力决定能否注意，信号检测决定何时警告，反馈时机决定是否及时解除不确定。
  - English: What is the key revision point on page 22?
  - Answer: The synthesis links attention, detection, integration, false alarms over time, and timely feedback.
- p022-q2 中文：解释本页概念：Attention-resource-feedback chain / 注意-资源-反馈链
  - 答案：线索设计必须同时考虑注意、资源竞争、证据可靠性和反馈时机。
  - English: Explain this concept: Attention-resource-feedback chain / 注意-资源-反馈链
  - Answer: 线索设计必须同时考虑注意、资源竞争、证据可靠性和反馈时机。
## 第 23 页：References and further reading
- p023-q1 中文：第 23 页的核心复习点是什么？
  - 答案：参考页把本讲机制对应到来源：注意力、非注意盲视、多资源、信号检测、误报心理、线索整合、变化盲视、反馈时机和 Norman 反馈理论。
  - English: What is the key revision point on page 23?
  - Answer: The references anchor the mechanisms behind the design rules: attention, signal detection, cue integration, timing, and feedback.
- p023-q2 中文：解释本页概念：Primary mechanism source / 机制一手来源
  - 答案：用于追溯设计原则背后心理或感知机制的原始研究。
  - English: Explain this concept: Primary mechanism source / 机制一手来源
  - Answer: 用于追溯设计原则背后心理或感知机制的原始研究。