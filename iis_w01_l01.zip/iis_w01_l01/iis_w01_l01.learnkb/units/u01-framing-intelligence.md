# 智能定义与目标导向导航

## Core Idea
本单元围绕以下页面建立学习路径：第 1 页、第 2 页、第 3 页、第 4 页。

## Page-by-page Learning Notes
### 第 1 页：From Calculators to Copilots: A History of Intelligent Interaction

- Source ID: `src-ba38b47b419c-pdf_page-00001`
- Core: 这一页给出整讲课的核心范围：不是单纯讲 AI 技术史，而是讲技术能力如何改变人与系统的互动方式。标题里的 calculators 指早期可计算、可自动化的机器形象；copilots 指现代能建议、生成、执行和协作的智能系统。课程关心的是从“工具帮我算”到“系统和我一起做，甚至替我行动”的转变。
- Extension: 复习时把这门课和传统 AI 课区分开：传统 AI 常问模型准确率、算法结构、训练数据；IIS 更常问用户能否理解、控制、纠错、信任系统。

#### Key Concepts
- **Intelligent interaction / 智能交互**：人与具备推断、学习、推荐、感知或生成能力的系统共同完成任务的互动过程。重点不是机器有多聪明，而是互动结构如何改变。
- **Copilot / 副驾驶式系统**：一种协作型智能系统隐喻：系统不是完全自动驾驶，而是在人的任务中提供建议、补全、执行或纠错。

### 第 2 页：What we usually mean by 'intelligence'

- Source ID: `src-ba38b47b419c-pdf_page-00002`
- Core: 这一页先拆掉两个直觉包袱。我们往往把智能想成“越像人越智能”，还默认智能必须装在大脑里。课程提醒你：如果带着这两个假设看系统，你会过早把注意力放在类人程度，而不是放在系统在具体任务空间里做了什么、对用户造成了什么影响。
- Extension: 考试或项目里遇到“智能”定义时，不要只写类人能力。可以补一句：本课更关心智能能力进入互动后如何改变人的行动条件。

#### Key Concepts
- **Anthropocentric / 以人类为中心**：把人类当作智能的标准和顶点，容易忽略动物、细胞、组织、机器或集体系统中的不同能力。
- **Brain-centric / 以大脑为中心**：认为智能必须由大脑产生。IIS 课程会把智能看作更广泛的目标导向能力。
- **Reasoning, problem solving, flexibility, intuition, learning / 推理、问题解决、灵活性、直觉、学习**：常见智能清单，但它们不是唯一入口，也不一定都能直接指导交互设计。

### 第 3 页：Intelligence as goal-directed navigation

- Source ID: `src-ba38b47b419c-pdf_page-00003`
- Core: 这一页给出本讲最重要的替代定义。智能不是固定等于像人思考，而是“为了目标，在某个空间中调整路径”。这里的空间可以是物理空间、概念空间、社会空间、身体形态空间，也可以是数字任务空间。这个定义让我们能比较细胞、动物、人和软件系统。
- Extension: 在 HCI/IIS 中，这个定义很有用，因为交互系统经常不是“独立智能体”，而是在用户任务空间中辅助导航。比如推荐系统导航偏好空间，地图导航交通空间，Copilot 导航代码空间。

#### Key Concepts
- **Goal-directed navigation / 目标导向导航**：系统保留目标，同时调整达到目标的路径或手段。
- **Fixed ends with varying means / 固定终点、变化手段**：William James 的表达，强调智能体遇到阻碍后可以换方法。
- **Problem space / 问题空间**：系统行动、搜索、推断或适应发生的空间。评价智能时要先问空间是什么。

### 第 4 页：Different spaces, different intelligences

- Source ID: `src-ba38b47b419c-pdf_page-00004`
- Core: 这一页把第 3 页的定义展开为多尺度例子。细胞、器官、动物、人和数字系统都可以被看作在不同空间中追求目标。关键不是谁“更高级”，而是谁在自己的空间里更擅长。对交互系统来说，系统导航的是数字空间，但它旁边总有用户，所以设计要看人机共同活动。
- Extension: 这页能帮助你避免“通用智能崇拜”。项目分析时可以写：系统能力必须放回具体空间和任务中评价，例如医疗分诊系统不是“像医生”，而是在症状、风险和流程空间中导航。

#### Key Concepts
- **Morphogenetic space / 形态发生空间**：生物体形成形状和结构的空间，例如肢体再生中细胞如何达到正确形态。
- **Physiological space / 生理空间**：器官维持内部状态和功能的空间，例如调节血糖、温度或组织修复。
- **Narrow intelligence / 狭窄智能**：在特定任务空间中表现很强，但不代表在所有空间都强。黑猩猩数字记忆例子体现这一点。
