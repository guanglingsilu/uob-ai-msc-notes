# 五次能力迁移

## Core Idea
本单元围绕以下页面建立学习路径：第 9 页、第 10 页、第 11 页、第 12 页、第 13 页、第 14 页、第 15 页。

## Page-by-page Learning Notes
### 第 9 页：Shift 1: symbolic rules and ELIZA (1966)

- Source ID: `src-ba38b47b419c-pdf_page-00009`
- Core: ELIZA 是早期聊天式互动的代表，但它的“智能”很浅。它会接话，但不理解语义、世界或用户处境。它体现的是交互形式上的第一步：机器可以轮到自己说话了。
- Extension: ELIZA 对今天的启发不是“早期 AI 很弱”，而是“很弱的机制也能制造强交互错觉”。这直接连到第 21 页的 ELIZA effect。

#### Key Concepts
- **Symbolic rules / 符号规则**：用明确规则和模式来处理输入，而不是从数据中学习隐含表示。
- **Keyword spotting / 关键词发现**：在输入中寻找触发词，用它选择回应模板。
- **Decomposition and reassembly / 分解与重组**：把用户句子拆成部分，再按模板重组为系统回应。

### 第 10 页：Shift 2: direct manipulation and the GUI

- Source ID: `src-ba38b47b419c-pdf_page-00010`
- Core: GUI 和直接操控是本讲中最“设计导向”的迁移。系统状态通过图形界面持续显示，用户通过鼠标、拖拽、选择等动作直接操作对象，并且能撤销。这一页强调：可见性和可撤销性不是技术进步自然带来的，而是设计者主动加入的。
- Extension: 今天设计 AI 系统时，要把 GUI 的教训带回来：即使模型很复杂，也应尽量显示状态、来源、置信度、操作范围和撤销路径。

#### Key Concepts
- **Direct Manipulation / 直接操控**：Shneiderman 提出的交互原则：对象持续可见，用户通过物理化动作操作对象，操作可以撤销。
- **Continuous representation / 连续表示**：系统对象和状态持续显示，用户无需记住隐藏命令或内部状态。
- **Reversible operations / 可撤销操作**：用户可以恢复先前状态，降低探索和错误成本。
- **GUI / 图形用户界面**：通过窗口、图标、菜单、指针等视觉对象组织交互。

### 第 11 页：Shift 3: learning and recommendation

- Source ID: `src-ba38b47b419c-pdf_page-00011`
- Core: 推荐系统改变了互动：用户不一定先问，系统会根据数据主动排序和建议。它能推断偏好，但理由通常不可见。你看到的是推荐结果，不一定看到模型如何利用相似用户、历史行为或物品关系。
- Extension: 推荐系统的设计难题包括解释性、过滤泡泡、公平性、用户自主性和反馈循环。IIS 角度特别关心：用户是否知道自己为什么看到这些内容。

#### Key Concepts
- **Collaborative Filtering / 协同过滤**：根据相似用户或相似物品的行为来预测用户偏好。
- **Item-to-item filtering / 物品到物品过滤**：Amazon 推广的推荐方法，基于物品之间的相似关系进行大规模推荐。
- **Preference inference / 偏好推断**：系统从行为数据中推测用户可能喜欢什么，即使用户没有明说。

### 第 12 页：Shift 4: deep learning and perception

- Source ID: `src-ba38b47b419c-pdf_page-00012`
- Core: 深度学习把交互输入从键盘和鼠标扩展到真实世界信号。系统不只处理文本，而是识别声音、脸、图像场景和身体动作。它让界面能感知世界，但也让误识别、隐私和不可见推断变得重要。
- Extension: 感知型界面常见设计问题：误识别如何纠正？用户是否知道自己被识别了什么？系统是否显示置信度？数据采集是否被用户理解和同意？

#### Key Concepts
- **Deep learning / 深度学习**：通过多层模型从数据中学习特征表示，减少对人工特征工程的依赖。
- **ImageNet**：大型图像识别数据集和竞赛，2012 年 AlexNet 的表现成为深度学习视觉突破的标志。
- **Top-5 error / 前五错误率**：正确标签不在模型前五个预测中的比例，是图像分类常用指标。
- **Perception as input / 感知作为输入**：语音、图像、人脸、场景、手势等成为交互输入。

### 第 13 页：Shift 5: large language models and agents

- Source ID: `src-ba38b47b419c-pdf_page-00013`
- Core: LLM 迁移有两层：先是语言流畅和跨任务泛化，再是工具使用和 agentic loops 带来的真实行动。风险也随之升级：文本错了可以改，但系统如果发邮件、改代码、下单、删文件，可撤销性就复杂得多。
- Extension: 设计 agent 时常用防线包括权限分级、预览、确认、日志、沙盒、回滚、速率限制和人类批准。它们本质上都在重建可见性和可撤销性。

#### Key Concepts
- **Transformer**：2017 年提出的神经网络架构，使用 attention 机制，成为现代 LLM 的核心基础。
- **Few-shot prompting / 少样本提示**：在提示词中给少量示例，模型就能迁移到新任务。
- **Agentic loop / 智能体循环**：模型观察状态、计划、调用工具、检查结果并继续行动的循环。
- **Tool use / 工具使用**：模型通过外部工具读写文件、运行代码、浏览网页或操作应用。

### 第 14 页：The reading frame: four interaction variables

- Source ID: `src-ba38b47b419c-pdf_page-00014`
- Core: 这一页是可背诵页。四个变量可以作为评估任何 IIS 的统一框架。注意每个变量都不是纯技术指标，而是人与系统之间的关系指标。
- Extension: 写项目 proposal 时可以把研究问题改写成：我的系统在哪些变量上改变了用户体验？我如何测量这种改变？

#### Key Concepts
- **Turn / 互动轮次**：一次系统或用户发起并推进任务的行动单位。
- **System state / 系统状态**：系统当前知道、判断、准备做或已经做了什么。
- **Reasoning visibility / 推理可见性**：用户能否看到系统为什么得出某个建议或行动。
- **Undo cost / 撤销成本**：恢复原状所需时间、努力、风险和是否完全可恢复。

### 第 15 页：Five shifts scored on four variables

- Source ID: `src-ba38b47b419c-pdf_page-00015`
- Core: 这一页给出全讲主线：能力越强，不代表交互越好。推荐、感知、LLM 和 agent 都让系统更主动、更会推断，但同时常常让用户更难看见理由、更难撤销后果。设计任务就是缩短能力与可控性之间的距离。
- Extension: 这页可以作为论文论证句：AI interaction design is not just about increasing capability; it is about restoring visibility and reversibility as capability rises.

#### Key Concepts
- **Capability-control gap / 能力-控制差距**：系统能做的事情越来越多，但用户能看见、理解和撤销的部分没有同步增长。
- **Peak visibility/reversibility / 可见性与可撤销性峰值**：GUI 时代因设计选择达到高点，之后的智能系统未自然继承。
