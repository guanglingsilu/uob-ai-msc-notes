# 来源：5. Scalable Distributed Data Processing - Lecture Notes.pdf

<!-- SOURCE: 5. Scalable Distributed Data Processing - Lecture Notes.pdf -->

<!-- PDF 页 1 -->

Scalable Distributed data processing:
fundamental concepts

Prof. Paolo Missier
School of Computer Science
University of Birmingham, UK

Data-intensive AI
2026/27 Sem 1

<!-- PDF 页 2 -->

Key concepts in this lecture

“Big Data”: datasets that are large enough to benefit a distributed computing architecture
- If you run a distributed algorithm on a small dataset, the overhead associated with managing the data 
allocation to the resources may be larger than the theoretical benefit

- Speedup: the ratio of the time taken to complete a task on a single processor to the time taken on a 

parallel system with $n$ processors

- embarrassing parallelism: an ideal situation where there are no dependencies between elements of the 

input dataset when executing the task

- Amdahl's Law and Gustafson's Law: quantifying the limitations on available parallelism for a specific 

processing task

<!-- PDF 页 3 -->

Scalable Distributed data processing

Distributed computing involves using multiple machines to run an algorithm.

Here we focus specifically on distributed data processing
- We have seen some of the target algorithms in previous lectures:

- Checking and improving data quality (missingness, anomalies)
- Data analytics through aggregation and visualisation

- We will see that graph algorithms may also benefit from a multi-machine computing infrastructure

<!-- PDF 页 4 -->

Scalability: Definitions and Key Questions

Context: “Big Data” : 
Key conceps: scalability. Given an algorithm/processing task, this relates size of the input dataset 
with the size of the resources allocated to complete the task.

Here “performance” = latency: the time it takes for the algorithm to process the entire input

1. Fixed size input, increasing resources:
- How does performance increase as a function of the size of the computing resources? When 

does adding more resources stop being beneficial?

2. Fixed size resources, increasing input size:
- How does performance decrease as a function of the size of the computing resources?

3. Considering the input size / resource size envelope, what are the cost/benefits trade-offs?

<!-- PDF 页 5 -->

Speedup

The speedup 𝑆 n  achieved when using 𝑛 > 1 processors is the ratio of the time taken to 
complete a task on a single processor to the time taken on a parallel system with 𝑛 
processors:

𝑆 n =

𝑇1
𝑇n

Where  𝑇1  is the wall-clock time (latency) measured when using one processor (the baseline) and 𝑇n is the 
latency when 𝑛 processors are deployed to solve the task

Ideal (linear) speedup:
If every processor does exactly 
exactly 𝑛:

1

𝑛

And 

 of the total work and there is no overhead, the speedup is 

𝑇𝑛 =

𝑇1
𝑛

𝑆 𝑛 =

𝑇1
𝑛

  =  𝑛

<!-- PDF 页 6 -->

Factors that reduce ideal speedup

1. Communication overhead: Processors must exchange intermediate results; this takes time 

proportional to the volume of data transferred

2. Serial sections in the execution: Some fraction of the task cannot be parallelised 
- typically, loops that build a result incrementally at each iteration

3. Load imbalance: If some processors finish their share earlier than others, they sit idle while the 
slowest one completes — the job's wall-clock time is always determined by the slowest 
participant

<!-- PDF 页 7 -->

Realistic speedup with communication overhead

We will be working with “share-nothing” processors
- Each processor has a local memory and the only way for processors to share data is to move it across a (local) 

network.

- This data movement incurs a communication overhead.
- We denote the total communication overhead between any pair of processors over the entire processing with 𝑇𝑐

We simply add 𝑇𝑐 to the total wall-clock time for the 𝑛 processors configuration:

The speedup is then expressed as:

𝑇𝑛 =

𝑇1
𝑛

+ 𝑇𝑐

𝑆 𝑛 =

𝑇1
𝑇𝑛

=

𝑛

1 + 𝑛 ⋅

𝑇𝑐
𝑇1

High communication overhead / large 𝑇𝑐 → smaller speedup
Low communication overhead / small 𝑇𝑐 → larger speedup

<!-- PDF 页 8 -->

Efficiency

Efficiency = speedup / number of processors     (speedup per processor)

𝐸 𝑛 =

𝑆 𝑛
𝑛

=

1

1 + 𝑛 ⋅

𝑇𝑐
𝑇1

Max efficiency 𝐸 𝑛 = 1 is achieved when 𝑇𝑐 = 0 (no overhead).

In practice, efficiency decreases with the number 𝑛 of processors, because 
more communication is required, increasing 𝑇𝑐

<!-- PDF 页 9 -->

Realistic speedup with serial execution

<!-- PDF 页 10 -->

Speedup with Serial Sections: Amdahl’s law

Let 0 ≤ 𝛼 ≤ 1 denote the serial fraction of the task, and let us assume there is no overhead (𝑇𝑐 = 0)
This means that a fraction 𝛼 of the computation cannot be divided into concurrent sub-tasks.
The remaining  1 − 𝛼  can be apportioned to the 𝑛 processors.
This gives:

𝑇𝑛 = 𝛼𝑇1 + 1 − 𝛼

𝑇1
𝑛

The resulting speedup is:

𝑆 𝑛 =

𝑇1
𝑇𝑛

=

𝛼 +

1
1 − 𝛼
𝑛

Efficiency:  𝐸 𝑛 =

𝑆 𝑛

𝑛

=

1

𝑛𝛼+1–𝛼

Thus, the max speedup when using 𝑛 processors is limited by the serial fraction 𝛼:

lim
𝑛→∞

𝑆 𝑛 =

1
𝛼

<!-- PDF 页 11 -->

Amdahl’s law: examples

Serial fraction α

Max possible speedup Meaning

50%

20%

5%

1%

0%

2×

5×

20×

100×

∞

Half the job is serial; a thousand processors give at most a 2× 
improvement

Even with unlimited hardware, you cannot go faster than 5×

A well-parallelised job; 20× is achievable with ~100 
processors

Near-ideal; requires very careful engineering to achieve

Purely embarrassingly parallel; linear speedup holds

Quick exercise 
For 𝛼 = 50%, calculate the achievable speedup for 
n = 4, 8, 16
Comment on those figures

<!-- PDF 页 12 -->

Amdahl’s law with communication overhead

𝑇𝑛 = 𝛼𝑇1 + 1 − 𝛼

+ 𝑇𝑐

𝑇1
𝑛

1

𝑆 𝑛 =

𝑇1
𝑇𝑛

=

𝛼 𝑛 − 1 + 1 + 𝑛

𝑇𝑐
𝑇1

As before, maximum speedup factor is determined not by the number of parallel processors 
employed but 
→ by the fraction of the computation that is not parallelized and the communication overhead

lim
𝑛→∞

𝑆 𝑛 =

1

𝛼 +

𝑇𝑐
𝑇1

<!-- PDF 页 13 -->

Gustafson's Law 

Suppose we keep increasing 𝑛. 

Amdahl’s law quantifies the max speedup given a fixed input size and a task with serial fraction 𝛼.
It provides a limit in latency reduction as a function of 𝑛.

Gustafson's Law provides a complementary perspective: 
it quantifies the increase in input size that can be processed in the same time by a larger number 𝑛’ > 𝑛 of 
processors
“if I increase 𝑛, I can use the extra capacity to process a larger input in the same time”

<!-- PDF 页 14 -->

Gustafson’s Law: Example and Exercise

Example:
I use 𝑛 processors to run a Climate prediction model. 
By increasing 𝑛 to 𝑛’, I can either:
- Run the same model in slightly less time, or 
- Run a bigger model in the same time

𝑆𝑠𝑐𝑎𝑙𝑒𝑑 𝑛 = 𝛼 + 𝑛 − 𝛼𝑛

Quick exercise 
For 𝛼 = 50%, calculate the achievable scaled 
speedup for  n = 4, 8, 16
Comment on those figures

<!-- PDF 页 15 -->

Embarrassingly Parallel Computation

This is the ideal case where 𝛼 = 0:

The input data can be partitioned into independent subsets such that:

1. Each subset can be processed in isolation — no processor needs any result from another processor's 

subset to do its own work

2. The final result is obtained by combining the per-subset outputs, and that combination step is cheap 

relative to the processing

𝑆 𝑛 = 𝑛

Serial section at the end

<!-- PDF 页 16 -->

Examples Relevant to Data Engineering

Task

Why it is embarrassingly parallel

Applying a transformation to every row of a 
DataFrame (.map, .withColumn)

Each row is processed independently; no row 
needs any other row's value

Computing per-partition statistics

Each partition is self-contained

Training separate models on different data folds 
(cross-validation)

Each fold is independent

Compressing or encoding a collection of files

Each file is independent

Applying a filter predicate to a large dataset

Each row is tested independently

<!-- PDF 页 17 -->

The final serial section can be a bottleneck

Consider computing the median over a large set of 𝑁 records (eg median taxi fare) using 𝑛 processors

Each worker processes 𝑁/𝑛 records and produces a sorted list of  𝑁/𝑛 values

Sorting each list of 𝑁/𝑛 elements requires 𝑂 𝑁/𝑛 log 𝑁 /𝑛  steps
This cost is only counted once, since they all occur in parallel

To find the median, these lists must then be merged (why?).

Merging 𝑛 sorted lists of 𝑁/𝑛 elements each requires 𝑂 𝑛 ⋅ 𝑁/𝑛 log 𝑛 = 𝑂 𝑁 log 𝑛  steps

In total, the cost when using 𝑛 processors is 𝑂 𝑁/𝑛 log 𝑁 /𝑛  + 𝑂 𝑁 log 𝑛

Using one single processor, the cost is sorting + scanning: 𝑂 𝑁 log N + 𝑂 𝑁

Thus, there is no real advantage in this case in using 𝑛 > 1 processors

<!-- PDF 页 18 -->

Data partition and Load balancing

The third cause of loss of performance is workloads that are not balanced across processors

This happens when some data partitions are much larger than others

A good partition is one where every worker gets roughly the same amount of work
A skewed partition where one worker gets disproportionately more data is the most common cause of jobs 
that are 99% complete and then
stall — the other workers are just idle waiting for the slowest worker to finish
- Remember that we measure wall-clock time

<!-- PDF 页 19 -->

Common Partitioning Strategies

Common partitioning strategies:

Strategy

How it works

Best for

Range partitioning

Rows with keys in [0, k) → partition 
1, [k, 2k) → partition 2, …

Ordered data, range queries

Hash partitioning

Partition index = hash(key) mod p

Random (round-robin)

Rows assigned cyclically or 
uniformly at random

GroupBy, joins — guarantees 
rows with the same key end up on 
the same worker

Embarrassingly parallel map 
tasks where key co-location is 
irrelevant

<!-- PDF 页 20 -->

Scaling up/out 

• Scaling out: “Horizontal scaling”

• Adding more nodes to a distributed system

• Scaling up:  “Vertical scaling”

• Adding more resources to a single node in a system

…or a combination of the two

<!-- PDF 页 21 -->

System Scalability

Two complementary ways to scale a system architecture:

• Scaling out: “Horizontal scaling”

• By adding more nodes to a distributed system

• Scaling up:  “Vertical scaling”

• By adding more resources to a single node in a system

…or a combination of the two

<!-- PDF 页 22 -->

Scaling Up vs Scaling Out: Scale Up

When you need more resources, you have two main options:
Scale Up (Vertical Scaling): Replace the existing machine with one that has more resources (CPU cores, 
RAM, faster disks, faster network card)
Main Advantages: 
- No SW changes required
- No data transfers or additional overheads 
- No dedicated worlload management required
Disadvantages:
- Expensive
- Will reach a scalability limit (see above)

<!-- PDF 页 23 -->

Scaling Up vs Scaling Out: Scale Out

Scale Out (Horizontal Scaling): Add more machines of the same size and distribute the work across them 
using a coordination framework such as Spark
Main Advantage: an arbitrary number of relatively cheap machines can be added incrementally

- Fits the cloud computing model very nicely (VMs allocated on demand)

Disadvantages:

- share-nothing architecture that requires a dedicated data partitioning and workload allocation 

framework (eg Spark)

- Communication overhead due to data transfers

<!-- PDF 页 24 -->

Comparing the Two Strategies (1/2)

Dimension

Unit cost

Ceiling

Scale Up

Scale Out

Superlinear — a machine with 2× 
RAM typically costs 4–8× more

Near-linear — adding a node 
costs roughly the same per node

Hard physical limit (max 
cores/RAM per 
motherboard/chassis)

Effectively unlimited (thousands 
of nodes in cloud clusters)

High — requires a distributed 
programming model (Spark, MPI, 
etc.)

Software complexity

None — existing single-threaded 
code works as-is

Fault tolerance

Single point of failure — if the 
machine crashes, everything is 
lost

Resilient by design — failed 
nodes are replaced; tasks are 
retried

<!-- PDF 页 25 -->

Comparing the Two Strategies (2/2)

Dimension

Scale Up

Scale Out

Data transfer overhead

Latency

Operational complexity

Elasticity

Zero inter-node communication 
— all memory is shared

Network is the bottleneck; 
shuffle operations transfer data 
between nodes

Very low (shared memory, no 
serialisation)

Higher (serialisation + network 
round-trip per shuffle)

Low — one machine to monitor 
and maintain

High — cluster management, 
networking, storage 
orchestration

Poor — provisioning a larger 
machine takes hours or days

Good — cloud clusters can add 
or remove nodes in minutes

<!-- PDF 页 26 -->

Summary

<!-- PDF 页 27 -->

Further reading

Amdahl, G.M. (1967). "Validity of the single processor approach to
achieving large scale computing capabilities." Proceedings of AFIPS, pp.
483–485. https://doi.org/10.1145/1465482.1465560
Gustafson, J.L. (1988). "Reevaluating Amdahl's Law." Communications
of the ACM, 31(5), 532–533. https://doi.org/10.1145/42411.42415
Zaharia, M. et al. (2012). "Resilient Distributed Datasets: A
Fault-Tolerant Abstraction for In-Memory Cluster Computing." NSDI 2012.
https://www.usenix.org/system/files/conference/nsdi12/nsdi12-final138.pdf
Dean, J. & Ghemawat, S. (2004). "MapReduce: Simplified Data Processing
on Large Clusters." OSDI 2004.
https://research.google/pubs/pub62/
Armbrust, M. et al. (2010). "A View of Cloud Computing." Communications
of the ACM, 53(4), 50–58. https://doi.org/10.1145/1721654.1721672
