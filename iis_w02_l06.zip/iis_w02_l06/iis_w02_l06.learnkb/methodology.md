# 整体方法论

对 Action, Error, Agency and Decision 逐页保留原文、翻译、解释、概念和自测，并绑定 PDF 页来源。
