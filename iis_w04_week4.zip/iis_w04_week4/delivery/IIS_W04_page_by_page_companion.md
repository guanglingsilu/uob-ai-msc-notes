# Intelligent Interactive Systems Week 4 逐页双语复习资料

# Context Engineering and Memory / 上下文工程与记忆

## 第 1 页：Context Engineering and Memory

![PDF page 1](../assets/l10/pages/page_001.png)

### 原文 / Original Text
```text
Context Engineering 
and Memory
Intelligent Interactive Systems  ·  Week 4  ·  Lecture 10
University of Birmingham
```

### 完整中文翻译
上下文工程与记忆。Intelligent Interactive Systems 第 4 周第 10 讲。

### 中文释义
本页的核心是：上下文工程与记忆。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 上下文工程与记忆。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：上下文工程与记忆。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 1 页如何帮助理解 context engineering and memory？
  - 答案：上下文工程与记忆。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 1 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 2 页：Learning outcomes

![PDF page 2](../assets/l10/pages/page_002.png)

### 原文 / Original Text
```text
What you will be able to do
Lecture 10 · Context Engineering and Memory
Course-own diagram. The four outcomes this lecture is accountable for.
```

### 完整中文翻译
学习目标：理解一次模型调用中的上下文构成；设计可检查的上下文组装；区分不同记忆类型；讨论可查看、可编辑、可遗忘的记忆要求。

### 中文释义
本页的核心是：学习目标：理解一次模型调用中的上下文构成；设计可检查的上下文组装；区分不同记忆类型；讨论可查看、可编辑、可遗忘的记忆要求。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 学习目标：理解一次模型调用中的上下文构成；设计可检查的上下文组装；区分不同记忆类型；讨论可查看、可编辑、可遗忘的记忆要求。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：学习目标：理解一次模型调用中的上下文构成；设计可检查的上下文组装；区分不同记忆类型；讨论可查看、可编辑、可遗忘的记忆要求。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 2 页如何帮助理解 context engineering and memory？
  - 答案：学习目标：理解一次模型调用中的上下文构成；设计可检查的上下文组装；区分不同记忆类型；讨论可查看、可编辑、可遗忘的记忆要求。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 2 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 3 页：The same prompt, two contexts

![PDF page 3](../assets/l10/pages/page_003.png)

### 原文 / Original Text
```text
The same prompt, two contexts
The same prompt and model give different 
answers when the context differs.
Context A correctly refuses, because the booking record 
was never sent.
Context B answers correctly once the booking record is in 
the window.
Activity: name three things that could be missing from 
your system's context.
Lecture 10 · Context Engineering and Memory
Course-own mock-up; both contexts are composed for teaching.
```

### 完整中文翻译
同一个 prompt 和同一个模型，在上下文不同的时候会给出不同答案。没有发送 booking record 时应拒绝；把记录放入窗口后才能正确回答。系统上下文中可能缺少状态、证据、权限等信息。

### 中文释义
本页的核心是：同一个 prompt 和同一个模型，在上下文不同的时候会给出不同答案。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 同一个 prompt 和同一个模型，在上下文不同的时候会给出不同答案。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：同一个 prompt 和同一个模型，在上下文不同的时候会给出不同答案。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 3 页如何帮助理解 context engineering and memory？
  - 答案：同一个 prompt 和同一个模型，在上下文不同的时候会给出不同答案。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 3 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 4 页：Twelve things that can be in one call

![PDF page 4](../assets/l10/pages/page_004.png)

### 原文 / Original Text
```text
Twelve things that can be in one call
A single call can contain twelve kinds 
of content from four sources.
Written in advance: system instructions, project 
instructions, policies. From the person: 
conversation, task, user state.
Assembled per call: memory, retrieved documents, 
sensor observations. Machinery: environment 
state, tool definitions, prior tool outputs.
Context engineering decides which are 
present, how much, and in what order.
Lecture 10 · Context Engineering and Memory
```

### 完整中文翻译
一次调用可包含十二类内容：预先写好的 system/project instructions 与 policies；用户的 conversation、task、user state；逐次组装的 memory、retrieved documents、sensor observations；以及 environment state、tool definitions、prior tool outputs。上下文工程决定哪些内容进入、各放多少以及顺序。

### 中文释义
本页的核心是：一次调用可包含十二类内容：预先写好的 system/project instructions 与 policies；用户的 conversation、task、user state；逐次组装的 memory、retrieved documents、sensor observations；以及 environment state、tool definitions、prior tool outputs。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 一次调用可包含十二类内容：预先写好的 system/project instructions 与 policies；用户的 conversation、task、user state；逐次组装的 memory、retrieved documents、sensor observations；以及 environment state、tool definitions、prior tool outputs。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：一次调用可包含十二类内容：预先写好的 system/project instructions 与 policies；用户的 conversation、task、user state；逐次组装的 memory、retrieved documents、sensor observations；以及 environment state、tool definitions、prior tool outputs。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 4 页如何帮助理解 context engineering and memory？
  - 答案：一次调用可包含十二类内容：预先写好的 system/project instructions 与 policies；用户的 conversation、task、user state；逐次组装的 memory、retrieved documents、sensor observations；以及 environment state、tool definitions、prior tool outputs。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 4 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 5 页：Who writes it, and how far to trust it

![PDF page 5](../assets/l10/pages/page_005.png)

### 原文 / Original Text
```text
Who writes it, and how far to trust it
Trust in each part of the context 
follows who wrote it.
Instructions are the designer's and are 
versioned like code; conversation is input, 
never a command.
Memory is only as reliable as the write that 
created it, and becomes stale.
Retrieved text is an input, never an instruction; 
Lecture 12 covers the attack.
Lecture 10 · Context Engineering and Memory
Course-own diagram. Trust follows authorship.
```

### 完整中文翻译
上下文各部分的可信度取决于作者。指令由设计者编写并像代码一样版本化；对话是输入而不是命令；memory 取决于写入它的事实并会过时；retrieved text 是输入而不是指令。

### 中文释义
本页的核心是：上下文各部分的可信度取决于作者。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 上下文各部分的可信度取决于作者。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：上下文各部分的可信度取决于作者。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 5 页如何帮助理解 context engineering and memory？
  - 答案：上下文各部分的可信度取决于作者。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 5 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 6 页：Everything competes for the same room

![PDF page 6](../assets/l10/pages/page_006.png)

### 原文 / Original Text
```text
Everything competes for the same room
The context window is a 
budget, and every part added 
spends it.
After forty turns, conversation history 
can crowd out the evidence retrieved 
for the question.
The failure is silent: no reply reports 
that less evidence was available.
Cap each part, summarise 
deliberately, and measure what was 
actually sent.
Lecture 10 · Context Engineering and Memory
```

### 完整中文翻译
所有内容都竞争同一个 context window 预算。长对话可能挤掉本次检索到的证据，而且系统不会自动报告证据变少。应为各部分设上限、主动摘要并记录实际发送了什么。

### 中文释义
本页的核心是：所有内容都竞争同一个 context window 预算。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 所有内容都竞争同一个 context window 预算。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：所有内容都竞争同一个 context window 预算。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 6 页如何帮助理解 context engineering and memory？
  - 答案：所有内容都竞争同一个 context window 预算。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 6 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 7 页：Position matters: lost in the middle

![PDF page 7](../assets/l10/pages/page_007.png)

### 原文 / Original Text
```text
Position matters: lost in the middle
The position of information in the 
context affects whether the model 
uses it.
Liu et al. (2024): accuracy was highest at the 
beginning or end, lowest in the middle.
Performance also degraded as the context 
grew longer.
This is a measured tendency, not a law; place 
important material where it is read.
Lecture 10 · Context Engineering and Memory
Course-own diagram after Liu et al. (2024).
```

### 完整中文翻译
信息在上下文中的位置会影响模型是否使用它。Liu 等人发现长上下文中开头和结尾通常比中间位置更容易被利用，且上下文越长性能可能越差；这是测得的倾向，不是绝对定律。

### 中文释义
本页的核心是：信息在上下文中的位置会影响模型是否使用它。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 信息在上下文中的位置会影响模型是否使用它。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：信息在上下文中的位置会影响模型是否使用它。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 7 页如何帮助理解 context engineering and memory？
  - 答案：信息在上下文中的位置会影响模型是否使用它。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 7 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 8 页：Context assembly is a function you write

![PDF page 8](../assets/l10/pages/page_008.png)

### 原文 / Original Text
```text
Context assembly is a function you write
Context assembly is a function the 
designer writes, with four stages.
Select what goes in, order it, budget each 
part, and record what was sent.
State the task first and restate it after the 
evidence; keep the window small.
Without a record, missing, buried and 
ignored evidence cannot be told apart.
Lecture 10 · Context Engineering and Memory
```

### 完整中文翻译
上下文组装是设计者要写出的函数：选择内容、排序、分配预算、记录发送内容。先写明任务，再放证据，必要时在证据后重述任务；没有记录就无法区分证据缺失、被埋没还是被忽略。

### 中文释义
本页的核心是：上下文组装是设计者要写出的函数：选择内容、排序、分配预算、记录发送内容。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 上下文组装是设计者要写出的函数：选择内容、排序、分配预算、记录发送内容。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：上下文组装是设计者要写出的函数：选择内容、排序、分配预算、记录发送内容。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 8 页如何帮助理解 context engineering and memory？
  - 答案：上下文组装是设计者要写出的函数：选择内容、排序、分配预算、记录发送内容。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 8 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 9 页：The word we are stuck with

![PDF page 9](../assets/l10/pages/page_009.png)

### 原文 / Original Text
```text
The word we are stuck with
The word memory is useful, but it 
misleads in a specific way.
The borrowing from psychology gets the kinds 
and lifetimes of stored information roughly right.
It is wrong about decay, forgetting and capacity: 
a file does not fade or reconstruct.
Users hear ‘remembers’ and assume a 
person's discretion about what to raise.
Lecture 10 · Context Engineering and Memory
```

### 完整中文翻译
memory 这个词有用但会误导。心理学类比大致能提示信息种类和生命周期，却不能照搬人的衰减、遗忘和容量：文件不会自然淡化或重构，用户却会把‘记得’理解成人一样知道什么时候主动提起。

### 中文释义
本页的核心是：memory 这个词有用但会误导。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: memory 这个词有用但会误导。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：memory 这个词有用但会误导。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 9 页如何帮助理解 context engineering and memory？
  - 答案：memory 这个词有用但会误导。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 9 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 10 页：Four kinds of memory

![PDF page 10](../assets/l10/pages/page_010.png)

### 原文 / Original Text
```text
Four kinds of memory, and what each is
Each of the four kinds of 
memory is an ordinary system 
component.
Working memory is the context window; 
episodic memory is a dated run history.
Semantic memory holds facts about the 
person or domain; procedural memory 
holds instructions and routines.
Only two of the four kinds are ever 
visible to the user.
Lecture 10 · Context Engineering and Memory
```

### 完整中文翻译
四类记忆分别是：working memory，即 context window；episodic memory，即带日期的运行历史；semantic memory，即关于人或领域的事实；procedural memory，即指令和惯例。它们本质上都是系统组件。

### 中文释义
本页的核心是：四类记忆分别是：working memory，即 context window；episodic memory，即带日期的运行历史；semantic memory，即关于人或领域的事实；procedural memory，即指令和惯例。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 四类记忆分别是：working memory，即 context window；episodic memory，即带日期的运行历史；semantic memory，即关于人或领域的事实；procedural memory，即指令和惯例。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：四类记忆分别是：working memory，即 context window；episodic memory，即带日期的运行历史；semantic memory，即关于人或领域的事实；procedural memory，即指令和惯例。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 10 页如何帮助理解 context engineering and memory？
  - 答案：四类记忆分别是：working memory，即 context window；episodic memory，即带日期的运行历史；semantic memory，即关于人或领域的事实；procedural memory，即指令和惯例。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 10 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 11 页：The analogy, policed

![PDF page 11](../assets/l10/pages/page_011.png)

### 原文 / Original Text
```text
The analogy, policed
The system appears better than 
a person in every row, which is 
the trap.
A person holds about four chunks 
(Cowan, 2001), decays, and recalls 
reconstructively.
A system has a chosen budget, 
deletion rather than decay, and exact 
lookup.
Human forgetting does social work that a 
stored file will not do.
Lecture 10 · Context Engineering and Memory
Course-own diagram. The system column is better in every row. That is the trap.
```

### 完整中文翻译
人与系统的记忆类比必须受到约束。人只能同时保持有限的 chunk，会衰减并重构回忆；系统有明确预算、删除机制和精确查找。人的遗忘还会承担社会功能，而保存的文件不会自动完成这种工作。

### 中文释义
本页的核心是：人与系统的记忆类比必须受到约束。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 人与系统的记忆类比必须受到约束。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：人与系统的记忆类比必须受到约束。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 11 页如何帮助理解 context engineering and memory？
  - 答案：人与系统的记忆类比必须受到约束。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 11 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 12 页：If it remembers, three requirements

![PDF page 12](../assets/l10/pages/page_012.png)

### 原文 / Original Text
```text
If it remembers, three requirements
A system that remembers a person 
owes that person three things.
Inspectable: the person can see what is held, in 
their own words.
Editable: the person can correct it in one action, 
and the correction survives.
Forgettable: deletion removes the derived copies 
too, such as summaries, embeddings and cached 
profiles.
Lecture 10 · Context Engineering and Memory
```

### 完整中文翻译
如果系统说自己记得一个人，它至少应提供三点：inspectable，用户能看到以自己语言写出的内容；editable，用户能一次修改且修改能保留；forgettable，删除要连同 summaries、embeddings、cached profiles 等派生副本一起移除。

### 中文释义
本页的核心是：如果系统说自己记得一个人，它至少应提供三点：inspectable，用户能看到以自己语言写出的内容；editable，用户能一次修改且修改能保留；forgettable，删除要连同 summaries、embeddings、cached profiles 等派生副本一起移除。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 如果系统说自己记得一个人，它至少应提供三点：inspectable，用户能看到以自己语言写出的内容；editable，用户能一次修改且修改能保留；forgettable，删除要连同 summaries、embeddings、cached profiles 等派生副本一起移除。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：如果系统说自己记得一个人，它至少应提供三点：inspectable，用户能看到以自己语言写出的内容；editable，用户能一次修改且修改能保留；forgettable，删除要连同 summaries、embeddings、cached profiles 等派生副本一起移除。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 12 页如何帮助理解 context engineering and memory？
  - 答案：如果系统说自己记得一个人，它至少应提供三点：inspectable，用户能看到以自己语言写出的内容；editable，用户能一次修改且修改能保留；forgettable，删除要连同 summaries、embeddings、cached profiles 等派生副本一起移除。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 12 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 13 页：A study assistant that remembers

![PDF page 13](../assets/l10/pages/page_013.png)

### 原文 / Original Text
```text
A study assistant that remembers
A study assistant stores three kinds of memory 
about one student.
Semantic: weak and confident topics, and a preference. Episodic: 
dated observations of questions and errors.
Procedural: give a worked example first; never give the answer 
early.
Every highlighted line is an inference, not something the 
student said.
Lecture 10 · Context Engineering and Memory
Course-own mock-up; the assistant is composed for teaching.
```

### 完整中文翻译
学习助手可以保存三类信息：semantic，例如薄弱/有把握的主题和偏好；episodic，例如带日期的问题和错误；procedural，例如先给 worked example、不要过早给答案。页面强调这些关于学生的陈述都是推断，不是学生原话。

### 中文释义
本页的核心是：学习助手可以保存三类信息：semantic，例如薄弱/有把握的主题和偏好；episodic，例如带日期的问题和错误；procedural，例如先给 worked example、不要过早给答案。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 学习助手可以保存三类信息：semantic，例如薄弱/有把握的主题和偏好；episodic，例如带日期的问题和错误；procedural，例如先给 worked example、不要过早给答案。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：学习助手可以保存三类信息：semantic，例如薄弱/有把握的主题和偏好；episodic，例如带日期的问题和错误；procedural，例如先给 worked example、不要过早给答案。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 13 页如何帮助理解 context engineering and memory？
  - 答案：学习助手可以保存三类信息：semantic，例如薄弱/有把握的主题和偏好；episodic，例如带日期的问题和错误；procedural，例如先给 worked example、不要过早给答案。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 13 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 14 页：What the student can see and change

![PDF page 14](../assets/l10/pages/page_014.png)

### 原文 / Original Text
```text
What the student can see and change
Show the student what is held, 
in their words, when it is used.
The claim reads ‘you find recursion hard’, 
not a confidence score against a topic 
identifier.
Each claim carries its evidence: from three 
wrong answers, on 3 October.
Edit and forget controls sit beside the 
claim, not in a settings page.
Lecture 10 · Context Engineering and Memory
Course-own mock-up of the memory panel; composed for teaching.
```

### 完整中文翻译
应在使用记忆时以用户语言展示持有什么。‘你觉得 recursion 很难’比 topic ID 的 confidence score 更可检查；每条 claim 还应带证据，例如 10 月 3 日的三次错误。编辑和忘记按钮应就在 claim 旁边。

### 中文释义
本页的核心是：应在使用记忆时以用户语言展示持有什么。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 应在使用记忆时以用户语言展示持有什么。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：应在使用记忆时以用户语言展示持有什么。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 14 页如何帮助理解 context engineering and memory？
  - 答案：应在使用记忆时以用户语言展示持有什么。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 14 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 15 页：And then the student gets better

![PDF page 15](../assets/l10/pages/page_015.png)

### 原文 / Original Text
```text
And then the student gets better
A stored note stays 
unchanged when the 
student improves.
The note was correct when written 
and is wrong now, because a file 
does not decay.
The student experiences this as not 
being allowed to change.
Fixes: expire the note, date it, let 
new evidence overwrite it, or ask.
Lecture 10 · Context Engineering and Memory
```

### 完整中文翻译
学生进步后，旧笔记可能仍保持不变。它当时可能正确，现在却错误，造成系统不允许改变用户的感觉。解决方案包括设置过期、加日期、让新证据覆盖旧证据，或直接询问用户。

### 中文释义
本页的核心是：学生进步后，旧笔记可能仍保持不变。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 学生进步后，旧笔记可能仍保持不变。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：学生进步后，旧笔记可能仍保持不变。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 15 页如何帮助理解 context engineering and memory？
  - 答案：学生进步后，旧笔记可能仍保持不变。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 15 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 16 页：Your turn: would you store it?

![PDF page 16](../assets/l10/pages/page_016.png)

### 原文 / Original Text
```text
Your turn: would you store it?
Decide what you would store, 
and be ready to defend each 
decision.
A: preferred name. B: seemed frustrated 
last session. C: three recent constraints. 
D: probably a first-year.
For each item, choose: store it, do not 
store it, or store with an expiry.
B and D are inferences about a person, 
not facts they gave.
Lecture 10 · Context Engineering and Memory
```

### 完整中文翻译
练习：是否保存 A preferred name、B 上次似乎很沮丧、C 最近三个约束、D 可能是一年级学生？每项选择保存、不保存或带 expiry 保存；B 和 D 是系统推断而不是用户直接提供的事实。

### 中文释义
本页的核心是：练习：是否保存 A preferred name、B 上次似乎很沮丧、C 最近三个约束、D 可能是一年级学生？每项选择保存、不保存或带 expiry 保存；B 和 D 是系统推断而不是用户直接提供的事实。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 练习：是否保存 A preferred name、B 上次似乎很沮丧、C 最近三个约束、D 可能是一年级学生？每项选择保存、不保存或带 expiry 保存；B 和 D 是系统推断而不是用户直接提供的事实。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：练习：是否保存 A preferred name、B 上次似乎很沮丧、C 最近三个约束、D 可能是一年级学生？每项选择保存、不保存或带 expiry 保存；B 和 D 是系统推断而不是用户直接提供的事实。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 16 页如何帮助理解 context engineering and memory？
  - 答案：练习：是否保存 A preferred name、B 上次似乎很沮丧、C 最近三个约束、D 可能是一年级学生？每项选择保存、不保存或带 expiry 保存；B 和 D 是系统推断而不是用户直接提供的事实。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 16 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 17 页：What users think ‘it remembers’ means, and Phase 1

![PDF page 17](../assets/l10/pages/page_017.png)

### 原文 / Original Text
```text
What users think ‘it remembers’ means, and Phase 1
Users assume ‘it remembers’ 
means remembering as a person 
would.
Two failures follow: the unpleasant surprise, 
and the silent limitation of assumed memory.
One fix addresses both: show what is held, in 
their words, when used.
Phase 1: draw your context assembly, mark 
each source's origin and trust, and store less.
Lecture 10 · Context Engineering and Memory
```

### 完整中文翻译
用户以为‘记得’意味着像人一样记得，于是会遇到意外和未声明的限制。一个共同修复是：在使用时用用户能理解的语言展示持有的内容。Phase 1 要画出 context assembly，标明每个来源的作者和可信度，并少存一些。

### 中文释义
本页的核心是：用户以为‘记得’意味着像人一样记得，于是会遇到意外和未声明的限制。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 用户以为‘记得’意味着像人一样记得，于是会遇到意外和未声明的限制。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：用户以为‘记得’意味着像人一样记得，于是会遇到意外和未声明的限制。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 17 页如何帮助理解 context engineering and memory？
  - 答案：用户以为‘记得’意味着像人一样记得，于是会遇到意外和未声明的限制。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 17 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 18 页：What you can now do

![PDF page 18](../assets/l10/pages/page_018.png)

### 原文 / Original Text
```text
What you can now do
Lecture 10 · Context Engineering and Memory
Course-own diagram. The four outcomes, and where each was answered.
```

### 完整中文翻译
本讲结果：你应能组装有预算和记录的上下文，区分四类记忆，解释人类记忆类比的边界，并为记忆提供查看、编辑和删除控制。

### 中文释义
本页的核心是：本讲结果：你应能组装有预算和记录的上下文，区分四类记忆，解释人类记忆类比的边界，并为记忆提供查看、编辑和删除控制。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 本讲结果：你应能组装有预算和记录的上下文，区分四类记忆，解释人类记忆类比的边界，并为记忆提供查看、编辑和删除控制。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：本讲结果：你应能组装有预算和记录的上下文，区分四类记忆，解释人类记忆类比的边界，并为记忆提供查看、编辑和删除控制。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 18 页如何帮助理解 context engineering and memory？
  - 答案：本讲结果：你应能组装有预算和记录的上下文，区分四类记忆，解释人类记忆类比的边界，并为记忆提供查看、编辑和删除控制。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 18 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 19 页：References and further reading

![PDF page 19](../assets/l10/pages/page_019.png)

### 原文 / Original Text
```text
References and further reading
Liu, N. F., Lin, K., Hewitt, J., Paranjape, A., Bevilacqua, M., Petroni, F., & Liang, P. (2024).
Lost in the Middle: How Language Models Use Long Contexts.
Transactions of the Association for Computational Linguistics, 12, 157–173.
→ Position and context length affect whether relevant information is used. ACL Anthology
Baddeley, A. D., & Hitch, G. (1974).
Working Memory.
In Psychology of Learning and Motivation, Vol. 8, 47–89.
→ Original working-memory framework; useful for explaining where the analogy with system “memory” begins. DOI
Tulving, E. (1972).
Episodic and Semantic Memory.
In E. Tulving & W. Donaldson (Eds.), Organization of Memory.
→ Foundational distinction between episodic and semantic memory.
Cowan, N. (2001).
The Magical Number 4 in Short-Term Memory: A Reconsideration of Mental Storage Capacity.
Behavioral and Brain Sciences, 24(1), 87–114.
→ Evidence for a central capacity of roughly four chunks in human short-term memory. Cambridge University Press
Shneiderman, B. (2022).
Human-Centered AI. Oxford University Press.
→ Human control, responsibility, privacy, and inspectability in intelligent systems.
Lecture 10 · Context Engineering and Memory
```

### 完整中文翻译
参考文献包括 Liu 等关于 long context 的研究、Baddeley 与 Hitch 的 working memory、Tulving 的 episodic/semantic memory、Cowan 的容量研究以及 Shneiderman 的 Human-Centered AI。

### 中文释义
本页的核心是：参考文献包括 Liu 等关于 long context 的研究、Baddeley 与 Hitch 的 working memory、Tulving 的 episodic/semantic memory、Cowan 的容量研究以及 Shneiderman 的 Human-Centered AI。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 参考文献包括 Liu 等关于 long context 的研究、Baddeley 与 Hitch 的 working memory、Tulving 的 episodic/semantic memory、Cowan 的容量研究以及 Shneiderman 的 Human-Centered AI。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Context Engineering And Memory**：参考文献包括 Liu 等关于 long context 的研究、Baddeley 与 Hitch 的 working memory、Tulving 的 episodic/semantic memory、Cowan 的容量研究以及 Shneiderman 的 Human-Centered AI。
- **Context window / 上下文窗口**：一次调用可用的有限内容预算。
- **Memory types / 记忆类型**：working、episodic、semantic、procedural 四种系统组件。

### 自测问题 / Self-check
- 中文问题：第 19 页如何帮助理解 context engineering and memory？
  - 答案：参考文献包括 Liu 等关于 long context 的研究、Baddeley 与 Hitch 的 working memory、Tulving 的 episodic/semantic memory、Cowan 的容量研究以及 Shneiderman 的 Human-Centered AI。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 19 help explain context engineering and memory?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.


# Retrieval, Grounding and Provenance / 检索、落地与来源追踪

## 第 1 页：Retrieval, Grounding and Provenance

![PDF page 1](../assets/l11/pages/page_001.png)

### 原文 / Original Text
```text
Retrieval, Grounding 
and Provenance
Intelligent Interactive Systems  ·  Week 4  ·  Lecture 11
University of Birmingham
```

### 完整中文翻译
检索、落地与来源追踪。Intelligent Interactive Systems 第 4 周第 11 讲。

### 中文释义
本页的核心是：检索、落地与来源追踪。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 检索、落地与来源追踪。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：检索、落地与来源追踪。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 1 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：检索、落地与来源追踪。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 1 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 2 页：Learning outcomes

![PDF page 2](../assets/l11/pages/page_002.png)

### 原文 / Original Text
```text
What you will be able to do
Lecture 11 · Retrieval, Grounding and Provenance
Course-own diagram. The four outcomes this lecture is accountable for.
```

### 完整中文翻译
学习目标：区分 parametric knowledge 和 retrieved knowledge；画出 RAG 流程；判断相似性、相关性、正确性和覆盖率的差别；设计诚实且可核查的 provenance。

### 中文释义
本页的核心是：学习目标：区分 parametric knowledge 和 retrieved knowledge；画出 RAG 流程；判断相似性、相关性、正确性和覆盖率的差别；设计诚实且可核查的 provenance。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 学习目标：区分 parametric knowledge 和 retrieved knowledge；画出 RAG 流程；判断相似性、相关性、正确性和覆盖率的差别；设计诚实且可核查的 provenance。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：学习目标：区分 parametric knowledge 和 retrieved knowledge；画出 RAG 流程；判断相似性、相关性、正确性和覆盖率的差别；设计诚实且可核查的 provenance。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 2 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：学习目标：区分 parametric knowledge 和 retrieved knowledge；画出 RAG 流程；判断相似性、相关性、正确性和覆盖率的差别；设计诚实且可核查的 provenance。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 2 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 3 页：A citation that does not exist

![PDF page 3](../assets/l11/pages/page_003.png)

### 原文 / Original Text
```text
A citation that does not exist
A citation can look correct in 
every respect and still not exist.
The citation is fluent, specific and 
formatted exactly like a real one.
Section 4.3 has a different title, and the 
handbook has no page 12.
Interaction 1: decide which of three causes 
applies, and how you would tell.
Lecture 11 · Retrieval, Grounding and Provenance
```

### 完整中文翻译
一条引用可以在格式、具体性和流畅度上都像真的，却根本不存在。Section 4.3 的标题不同，handbook 也没有第 12 页；设计者要判断是生成错误、检索错误还是原文边界问题，并说明如何验证。

### 中文释义
本页的核心是：一条引用可以在格式、具体性和流畅度上都像真的，却根本不存在。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 一条引用可以在格式、具体性和流畅度上都像真的，却根本不存在。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：一条引用可以在格式、具体性和流畅度上都像真的，却根本不存在。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 3 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：一条引用可以在格式、具体性和流畅度上都像真的，却根本不存在。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 3 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 4 页：Two sources of knowledge in one answer

![PDF page 4](../assets/l11/pages/page_004.png)

### 原文 / Original Text
```text
Two sources of knowledge in one answer
Every answer draws on two sources of 
knowledge that the reader cannot tell 
apart.
Parametric knowledge was absorbed in training, is 
vast, and has no address.
Retrieved knowledge was fetched for this call, is 
specific, and has an address.
In the answer both appear as the same fluent prose 
(Lewis et al., 2020).
Lecture 11 · Retrieval, Grounding and Provenance
```

### 完整中文翻译
答案中的知识有两个来源。Parametric knowledge 在训练中吸收，范围广但没有地址；retrieved knowledge 为本次调用取得，具体且有地址。两者在最终答案中都可能表现为同样流畅的文字。

### 中文释义
本页的核心是：答案中的知识有两个来源。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 答案中的知识有两个来源。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：答案中的知识有两个来源。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 4 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：答案中的知识有两个来源。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 4 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 5 页：Different sources, different failures

![PDF page 5](../assets/l11/pages/page_005.png)

### 原文 / Original Text
```text
Different sources, different failures
The two sources fail differently, 
yet every failure arrives as fluent 
prose.
Parametric knowledge is out of date, or 
never contained your handbook.
Retrieval fails when the passage is not 
found, wrong, or stale.
An answer can also ignore the passage it 
cites, which your system must catch.
Lecture 11 · Retrieval, Grounding and Provenance
```

### 完整中文翻译
两种来源有不同失败：参数知识可能过时或从未包含你的 handbook；检索可能找错、找不到或找到旧版本；模型还可能忽略它引用的 passage。所有失败都会以流畅文字出现。

### 中文释义
本页的核心是：两种来源有不同失败：参数知识可能过时或从未包含你的 handbook；检索可能找错、找不到或找到旧版本；模型还可能忽略它引用的 passage。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 两种来源有不同失败：参数知识可能过时或从未包含你的 handbook；检索可能找错、找不到或找到旧版本；模型还可能忽略它引用的 passage。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：两种来源有不同失败：参数知识可能过时或从未包含你的 handbook；检索可能找错、找不到或找到旧版本；模型还可能忽略它引用的 passage。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 5 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：两种来源有不同失败：参数知识可能过时或从未包含你的 handbook；检索可能找错、找不到或找到旧版本；模型还可能忽略它引用的 passage。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 5 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 6 页：The pipeline, and the two steps that matter

![PDF page 6](../assets/l11/pages/page_006.png)

### 原文 / Original Text
```text
The pipeline, and the two steps that matter
The pipeline has six steps, and 
provenance depends on how 
passages are stored.
The steps are chunk, embed, store, retrieve 
top-k, augment and generate.
Step 3 must store source, section and date, 
or no citation can be shown.
Step 5 is the assembly from Lecture 10, and 
step 6 is unchanged from Lecture 08.
Lecture 11 · Retrieval, Grounding and Provenance
```

### 完整中文翻译
典型 RAG 流程是 chunk、embed、store、retrieve top-k、augment、generate。存储阶段必须保留 source、section 和 date，否则生成时无法给出可核查引用；augment 也是上下文组装的一部分。

### 中文释义
本页的核心是：典型 RAG 流程是 chunk、embed、store、retrieve top-k、augment、generate。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 典型 RAG 流程是 chunk、embed、store、retrieve top-k、augment、generate。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：典型 RAG 流程是 chunk、embed、store、retrieve top-k、augment、generate。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 6 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：典型 RAG 流程是 chunk、embed、store、retrieve top-k、augment、generate。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 6 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 7 页：What ‘similar’ means, and does not

![PDF page 7](../assets/l11/pages/page_007.png)

### 原文 / Original Text
```text
What ‘similar’ means, and does not
Similarity is a mathematical 
property, not relevance, 
correctness or coverage.
It matches meaning without shared words, 
so 'late' finds 'after the deadline'.
The retriever always returns k passages 
and has no 'nothing found' state.
Three settings change the interaction: 
chunk size, number retrieved, and 
freshness.
Lecture 11 · Retrieval, Grounding and Provenance
```

### 完整中文翻译
similarity 是数学性质，不等于 relevance、correctness 或 coverage。它能让‘late’找到‘after the deadline’；retriever 通常总会返回 k 个 passage，没有 nothing found 状态。chunk size、top-k 和 freshness 会改变交互结果。

### 中文释义
本页的核心是：similarity 是数学性质，不等于 relevance、correctness 或 coverage。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: similarity 是数学性质，不等于 relevance、correctness 或 coverage。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：similarity 是数学性质，不等于 relevance、correctness 或 coverage。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 7 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：similarity 是数学性质，不等于 relevance、correctness 或 coverage。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 7 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 8 页：What grounding does and does not guarantee

![PDF page 8](../assets/l11/pages/page_008.png)

### 原文 / Original Text
```text
What grounding does and does not guarantee
Grounding provides real benefits, 
but fewer than most people 
assume.
It provides an address, a claim that can be 
checked, and a corpus you can correct.
It does not guarantee truth, currency, or that 
the passage was actually used.
'Answer only from the passages' is an 
instruction, not a mechanism.
Lecture 11 · Retrieval, Grounding and Provenance
```

### 完整中文翻译
grounding 能提供地址、可检查的 claim 和可修正的 corpus，但不能保证真相、时效性，也不能保证模型真的使用了该 passage。‘只根据 passages 回答’是指令，不是机制。

### 中文释义
本页的核心是：grounding 能提供地址、可检查的 claim 和可修正的 corpus，但不能保证真相、时效性，也不能保证模型真的使用了该 passage。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: grounding 能提供地址、可检查的 claim 和可修正的 corpus，但不能保证真相、时效性，也不能保证模型真的使用了该 passage。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：grounding 能提供地址、可检查的 claim 和可修正的 corpus，但不能保证真相、时效性，也不能保证模型真的使用了该 passage。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 8 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：grounding 能提供地址、可检查的 claim 和可修正的 corpus，但不能保证真相、时效性，也不能保证模型真的使用了该 passage。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 8 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 9 页：Shown, not just cited

![PDF page 9](../assets/l11/pages/page_009.png)

### 原文 / Original Text
```text
Shown, not just cited
Citing a source and showing a 
source are different acts.
An unshown source must be trusted, while a 
shown source can be recognised.
A reference below the answer remains a 
recall task that few readers perform.
The quoted sentence beside the claim makes 
checking cost one glance.
Lecture 11 · Retrieval, Grounding and Provenance
```

### 完整中文翻译
引用 source 和展示 source 是两件事。隐藏的 source 要求读者信任；展示紧挨 claim 的原句则让读者一眼检查。把引用只放在答案底部会把检查变成读者很少执行的回忆任务。

### 中文释义
本页的核心是：引用 source 和展示 source 是两件事。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 引用 source 和展示 source 是两件事。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：引用 source 和展示 source 是两件事。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 9 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：引用 source 和展示 source 是两件事。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 9 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 10 页：Four things a citation has to do

![PDF page 10](../assets/l11/pages/page_010.png)

### 原文 / Original Text
```text
Four things a citation has to do
A citation must meet four 
requirements before it is worth 
anything.
Resolvable: one click reaches the passage, 
not a ninety-page PDF.
Specific and honest about coverage: the 
quoted sentence, and which part it supports.
Dated, with a route for the reader to report 
'this looks wrong'.
Lecture 11 · Retrieval, Grounding and Provenance
```

### 完整中文翻译
有用的 citation 至少要可解析，一次点击能到具体 passage；具体且诚实地说明 quoted sentence 支持哪一部分；带日期；并提供读者报告‘这看起来不对’的路径。

### 中文释义
本页的核心是：有用的 citation 至少要可解析，一次点击能到具体 passage；具体且诚实地说明 quoted sentence 支持哪一部分；带日期；并提供读者报告‘这看起来不对’的路径。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 有用的 citation 至少要可解析，一次点击能到具体 passage；具体且诚实地说明 quoted sentence 支持哪一部分；带日期；并提供读者报告‘这看起来不对’的路径。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：有用的 citation 至少要可解析，一次点击能到具体 passage；具体且诚实地说明 quoted sentence 支持哪一部分；带日期；并提供读者报告‘这看起来不对’的路径。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 10 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：有用的 citation 至少要可解析，一次点击能到具体 passage；具体且诚实地说明 quoted sentence 支持哪一部分；带日期；并提供读者报告‘这看起来不对’的路径。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 10 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 11 页：Case 1: the answer it should give

![PDF page 11](../assets/l11/pages/page_011.png)

### 原文 / Original Text
```text
Case 1: the answer it should give
Case 1 is the baseline: a 
supported, current answer 
with nothing added.
Every clause in the answer appears 
in the retrieved passage (score 
0.88).
The citation is specific, dated, and 
one click from the words it 
supports.
No invented email address, office or 
deadline is added to the answer.
Lecture 11 · Retrieval, Grounding and Provenance
```

### 完整中文翻译
Case 1 是正确基线：答案每个 clause 都出现在当前 retrieved passage 中，引用具体、有日期且一步可达，没有添加不存在的 email、office 或 deadline。

### 中文释义
本页的核心是：Case 1 是正确基线：答案每个 clause 都出现在当前 retrieved passage 中，引用具体、有日期且一步可达，没有添加不存在的 email、office 或 deadline。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: Case 1 是正确基线：答案每个 clause 都出现在当前 retrieved passage 中，引用具体、有日期且一步可达，没有添加不存在的 email、office 或 deadline。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：Case 1 是正确基线：答案每个 clause 都出现在当前 retrieved passage 中，引用具体、有日期且一步可达，没有添加不存在的 email、office 或 deadline。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 11 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：Case 1 是正确基线：答案每个 clause 都出现在当前 retrieved passage 中，引用具体、有日期且一步可达，没有添加不存在的 email、office 或 deadline。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 11 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 12 页：Case 2: confident, cited, and out of date

![PDF page 12](../assets/l11/pages/page_012.png)

### 原文 / Original Text
```text
Case 2: confident, cited, and out of date
In Case 2 every internal check 
passes and the answer is still 
wrong.
The answer is faithful to its source, and the 
citation resolves (score 0.91).
It quotes the 2024 handbook, but the rule 
changed in 2026.
Grounding cannot catch this failure, 
whereas a visible document date can.
Lecture 11 · Retrieval, Grounding and Provenance
```

### 完整中文翻译
Case 2 即使内部检查都通过也可能错误：答案忠实于 2024 handbook，引用也可解析，但规则在 2026 已更改。grounding 本身抓不住时效错误，文档日期可以帮助暴露它。

### 中文释义
本页的核心是：Case 2 即使内部检查都通过也可能错误：答案忠实于 2024 handbook，引用也可解析，但规则在 2026 已更改。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: Case 2 即使内部检查都通过也可能错误：答案忠实于 2024 handbook，引用也可解析，但规则在 2026 已更改。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：Case 2 即使内部检查都通过也可能错误：答案忠实于 2024 handbook，引用也可解析，但规则在 2026 已更改。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 12 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：Case 2 即使内部检查都通过也可能错误：答案忠实于 2024 handbook，引用也可解析，但规则在 2026 已更改。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 12 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 13 页：Case 3: nothing in the corpus answers this

![PDF page 13](../assets/l11/pages/page_013.png)

### 原文 / Original Text
```text
Case 3: nothing in the corpus answers this
In Case 3 the system should decline, 
yet it is often built to answer.
The corpus has no AI-use policy, but k passages 
are returned anyway.
The best passage scores only 0.42, and the 
model never sees that score.
Say the corpus has no answer, show what was 
found, and hand over to a person.
Lecture 11 · Retrieval, Grounding and Provenance
```

### 完整中文翻译
Case 3 语料库没有回答 AI-use policy，但系统仍会返回 k 个 passage。最高相似度只有 0.42。系统应声明 corpus 没有答案、展示找到的内容，并把问题交给人处理，而不是编造答案。

### 中文释义
本页的核心是：Case 3 语料库没有回答 AI-use policy，但系统仍会返回 k 个 passage。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: Case 3 语料库没有回答 AI-use policy，但系统仍会返回 k 个 passage。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：Case 3 语料库没有回答 AI-use policy，但系统仍会返回 k 个 passage。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 13 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：Case 3 语料库没有回答 AI-use policy，但系统仍会返回 k 个 passage。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 13 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 14 页：Your turn: design the three screens

![PDF page 14](../assets/l11/pages/page_014.png)

### 原文 / Original Text
```text
Your turn: design the three screens
Sketch one screen for each case, then 
state what the reader does differently.
Case 1: decide what is placed beside the claim.
Case 2: decide what warns the reader about the date, 
and where it sits.
Case 3: decide what the system says and offers in 
place of an answer.
Lecture 11 · Retrieval, Grounding and Provenance
```

### 完整中文翻译
练习是为三种案例设计三张屏幕：Case 1 把什么放在 claim 旁边；Case 2 如何提醒文档日期；Case 3 在没有答案时说什么、提供什么替代路径。

### 中文释义
本页的核心是：练习是为三种案例设计三张屏幕：Case 1 把什么放在 claim 旁边；Case 2 如何提醒文档日期；Case 3 在没有答案时说什么、提供什么替代路径。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 练习是为三种案例设计三张屏幕：Case 1 把什么放在 claim 旁边；Case 2 如何提醒文档日期；Case 3 在没有答案时说什么、提供什么替代路径。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：练习是为三种案例设计三张屏幕：Case 1 把什么放在 claim 旁边；Case 2 如何提醒文档日期；Case 3 在没有答案时说什么、提供什么替代路径。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 14 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：练习是为三种案例设计三张屏幕：Case 1 把什么放在 claim 旁边；Case 2 如何提醒文档日期；Case 3 在没有答案时说什么、提供什么替代路径。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 14 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 15 页：Retrieval is a detection problem

![PDF page 15](../assets/l11/pages/page_015.png)

### 原文 / Original Text
```text
Retrieval is a detection problem
Retrieval is a detection problem, 
described by the framework from 
Week 2.
The four cells are hits, misses, false 
alarms and correct rejections.
Raising k turns misses into false alarms, and 
lowering k does the reverse.
Which error is worse depends on the task, 
not on the index.
Lecture 11 · Retrieval, Grounding and Provenance
```

### 完整中文翻译
检索可以视为 Week 2 的 detection problem：hits、misses、false alarms、correct rejections。提高 k 可能减少 miss 却增加 false alarm；哪种错误更严重取决于任务。

### 中文释义
本页的核心是：检索可以视为 Week 2 的 detection problem：hits、misses、false alarms、correct rejections。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 检索可以视为 Week 2 的 detection problem：hits、misses、false alarms、correct rejections。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：检索可以视为 Week 2 的 detection problem：hits、misses、false alarms、correct rejections。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 15 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：检索可以视为 Week 2 的 detection problem：hits、misses、false alarms、correct rejections。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 15 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 16 页：Irrelevant context makes the answer worse

![PDF page 16](../assets/l11/pages/page_016.png)

### 原文 / Original Text
```text
Irrelevant context makes the answer worse
Adding more context does not 
make an answer safer, and 
often makes it worse.
Irrelevant context measurably reduces 
accuracy (Shi et al., 2023).
Position in a long context also matters 
(Liu et al., Lecture 10).
Retrieve fewer passages, rank them 
properly, and place the best one first.
Lecture 11 · Retrieval, Grounding and Provenance
```

### 完整中文翻译
更多上下文不一定更安全，irrelevant context 还会降低准确率。应检索更少、排序更好、把最好 passage 放前面，同时考虑长上下文中的位置效应。

### 中文释义
本页的核心是：更多上下文不一定更安全，irrelevant context 还会降低准确率。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 更多上下文不一定更安全，irrelevant context 还会降低准确率。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：更多上下文不一定更安全，irrelevant context 还会降低准确率。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 16 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：更多上下文不一定更安全，irrelevant context 还会降低准确率。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 16 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 17 页：Your turn, and Phase 1

![PDF page 17](../assets/l11/pages/page_017.png)

### 原文 / Original Text
```text
Your turn, and Phase 1
Name the earliest layer that catches 
each failure, then decide whether your 
project needs retrieval.
Failures: irrelevant real section; last year's penalty; 
uncovered question answered anyway; deadline 
read from a photograph.
Mitigation is layered: instruction, context, 
grounding, tools, structure, validation, execution, 
human review.
Phase 1: state whether you need retrieval, from 
which corpus, and how provenance appears.
Lecture 11 · Retrieval, Grounding and Provenance
```

### 完整中文翻译
练习要求为每种失败找到最早能捕获它的层，并决定项目是否需要 retrieval。Phase 1 要写清是否需要检索、来自哪个 corpus，以及 provenance 在界面上如何出现。

### 中文释义
本页的核心是：练习要求为每种失败找到最早能捕获它的层，并决定项目是否需要 retrieval。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 练习要求为每种失败找到最早能捕获它的层，并决定项目是否需要 retrieval。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：练习要求为每种失败找到最早能捕获它的层，并决定项目是否需要 retrieval。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 17 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：练习要求为每种失败找到最早能捕获它的层，并决定项目是否需要 retrieval。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 17 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 18 页：What you can now do

![PDF page 18](../assets/l11/pages/page_018.png)

### 原文 / Original Text
```text
What you can now do
Lecture 11 · Retrieval, Grounding and Provenance
Course-own diagram. The four outcomes, and where each was answered.
```

### 完整中文翻译
本讲结果：你应能画出 RAG 与 provenance 流程，解释 retrieval 的检测错误，区分 grounding 的收益与保证，并在缺少答案时诚实拒答。

### 中文释义
本页的核心是：本讲结果：你应能画出 RAG 与 provenance 流程，解释 retrieval 的检测错误，区分 grounding 的收益与保证，并在缺少答案时诚实拒答。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 本讲结果：你应能画出 RAG 与 provenance 流程，解释 retrieval 的检测错误，区分 grounding 的收益与保证，并在缺少答案时诚实拒答。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：本讲结果：你应能画出 RAG 与 provenance 流程，解释 retrieval 的检测错误，区分 grounding 的收益与保证，并在缺少答案时诚实拒答。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 18 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：本讲结果：你应能画出 RAG 与 provenance 流程，解释 retrieval 的检测错误，区分 grounding 的收益与保证，并在缺少答案时诚实拒答。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 18 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 19 页：References and further reading

![PDF page 19](../assets/l11/pages/page_019.png)

### 原文 / Original Text
```text
References and further reading
Lewis, P., Perez, E., Piktus, A., et al. (2020).
Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks.
Advances in Neural Information Processing Systems, 33.
→ Foundational RAG architecture: retrieval plus generation.
Karpukhin, V., Oğuz, B., Min, S., et al. (2020).
Dense Passage Retrieval for Open-Domain Question Answering.
EMNLP 2020, 6769–6781.
→ Dense retrieval and embedding-based passage selection. ACL Anthology
Liu, N. F., Lin, K., Hewitt, J., et al. (2024).
Lost in the Middle: How Language Models Use Long Contexts.
Transactions of the Association for Computational Linguistics, 12, 157–173.
→ Relevant information is often used less reliably when buried in the middle of long contexts. ACL Anthology
Shi, F., Chen, X., Misra, K., et al. (2023).
Large Language Models Can Be Easily Distracted by Irrelevant Context.
Proceedings of ICML 2023.
→ Irrelevant context can reduce answer accuracy, supporting the “retrieve less, rank better” argument.
If you have room for a fifth, I would add:
Shneiderman, B. (2022).
Human-Centered AI. Oxford University Press.
→ Human control, auditability, provenance and inspectable evidence.
Lecture 11 · Retrieval, Grounding and Provenance
```

### 完整中文翻译
参考文献包括 Lewis 等的 RAG、Karpukhin 等的 Dense Passage Retrieval、Liu 等的 Lost in the Middle、Shi 等关于 irrelevant context 的研究以及 Human-Centered AI。

### 中文释义
本页的核心是：参考文献包括 Lewis 等的 RAG、Karpukhin 等的 Dense Passage Retrieval、Liu 等的 Lost in the Middle、Shi 等关于 irrelevant context 的研究以及 Human-Centered AI。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 参考文献包括 Lewis 等的 RAG、Karpukhin 等的 Dense Passage Retrieval、Liu 等的 Lost in the Middle、Shi 等关于 irrelevant context 的研究以及 Human-Centered AI。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：参考文献包括 Lewis 等的 RAG、Karpukhin 等的 Dense Passage Retrieval、Liu 等的 Lost in the Middle、Shi 等关于 irrelevant context 的研究以及 Human-Centered AI。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 19 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：参考文献包括 Lewis 等的 RAG、Karpukhin 等的 Dense Passage Retrieval、Liu 等的 Lost in the Middle、Shi 等关于 irrelevant context 的研究以及 Human-Centered AI。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 19 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 20 页：Optional viewing: The Right Question

![PDF page 20](../assets/l11/pages/page_020.png)

### 原文 / Original Text
```text
Optional viewing: The Right Question (I, Robot - 2004)
Screenshot: I, Robot (2004): https://www.youtube.com/watch?v=ZKxr0wyIic4
Screenshot: I, Robot (2004): https://www.youtube.com/watch?v=ZKxr0wyIic4
Identify the boundary of the system knowledge
Corpus boundary — what information is actually stored in the 
hologram?
Query formulation — Spooner has to ask questions in a way the 
system can answer.
Retrieval failure — does the system fail because the answer is 
absent, or because the query did not retrieve it?
Abstention — when the answer is outside its stored knowledge, 
the system does not invent a plausible one.
Grounding — each response is implicitly grounded in Lanning’s 
recorded information.
Provenance — what evidence does Spooner have about where 
the answer came from?
Coverage — a system can be accurate within its corpus while 
still being incomplete.
```

### 完整中文翻译
可选视频用于辨认系统边界：corpus 中实际存了什么、问题是否被正确表达、检索是否失败、何时应 abstain，以及答案的 provenance 和 coverage 如何判断。

### 中文释义
本页的核心是：可选视频用于辨认系统边界：corpus 中实际存了什么、问题是否被正确表达、检索是否失败、何时应 abstain，以及答案的 provenance 和 coverage 如何判断。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 可选视频用于辨认系统边界：corpus 中实际存了什么、问题是否被正确表达、检索是否失败、何时应 abstain，以及答案的 provenance 和 coverage 如何判断。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Retrieval, Grounding And Provenance**：可选视频用于辨认系统边界：corpus 中实际存了什么、问题是否被正确表达、检索是否失败、何时应 abstain，以及答案的 provenance 和 coverage 如何判断。
- **Grounding / 落地**：让回答中的 claim 指向可检查的外部证据。
- **Provenance / 来源追踪**：记录证据来自哪里、何时取得以及读者如何核查。

### 自测问题 / Self-check
- 中文问题：第 20 页如何帮助理解 retrieval, grounding and provenance？
  - 答案：可选视频用于辨认系统边界：corpus 中实际存了什么、问题是否被正确表达、检索是否失败、何时应 abstain，以及答案的 provenance 和 coverage 如何判断。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 20 help explain retrieval, grounding and provenance?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.


# Tools, Connectors, Structured Output and the Boundary / 工具、连接器、结构化输出与系统边界

## 第 1 页：Tools, Connectors and the Boundary

![PDF page 1](../assets/l12/pages/page_001.png)

### 原文 / Original Text
```text
Tools, Connectors 
and the Boundary
Intelligent Interactive Systems  ·  Week 4  ·  Lecture 12
University of Birmingham
```

### 完整中文翻译
工具、连接器、结构化输出与系统边界。Intelligent Interactive Systems 第 4 周第 12 讲。

### 中文释义
本页的核心是：工具、连接器、结构化输出与系统边界。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 工具、连接器、结构化输出与系统边界。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：工具、连接器、结构化输出与系统边界。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 1 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：工具、连接器、结构化输出与系统边界。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 1 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 2 页：Learning outcomes

![PDF page 2](../assets/l12/pages/page_002.png)

### 原文 / Original Text
```text
What you will be able to do
Lecture 12 · Tools, Connectors and the Boundary
Course-own diagram. The four outcomes this lecture is accountable for.
```

### 完整中文翻译
学习目标：区分模型提出的 tool call 与真正执行；设计 schema 和执行前检查；理解 connector、MCP、structured output 的边界；为不可逆行动设计确认与可见性。

### 中文释义
本页的核心是：学习目标：区分模型提出的 tool call 与真正执行；设计 schema 和执行前检查；理解 connector、MCP、structured output 的边界；为不可逆行动设计确认与可见性。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 学习目标：区分模型提出的 tool call 与真正执行；设计 schema 和执行前检查；理解 connector、MCP、structured output 的边界；为不可逆行动设计确认与可见性。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：学习目标：区分模型提出的 tool call 与真正执行；设计 schema 和执行前检查；理解 connector、MCP、structured output 的边界；为不可逆行动设计确认与可见性。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 2 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：学习目标：区分模型提出的 tool call 与真正执行；设计 schema 和执行前检查；理解 connector、MCP、structured output 的边界；为不可逆行动设计确认与可见性。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 2 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 3 页：‘Done’ — but was it?

![PDF page 3](../assets/l12/pages/page_003.png)

### 原文 / Original Text
```text
‘Done’ — but was it?
‘Done’ is a sentence that four 
different systems can produce.
The assistant reports a moved meeting, 
yet the calendar is unchanged and no 
message was sent.
No tool called, a failed call, a wrong action 
and a correct action all read identically.
The user cannot tell these cases apart, 
which is an interface problem.
Lecture 12 · Tools, Connectors and the Boundary
```

### 完整中文翻译
‘Done’ 可能来自四种完全不同的系统：没有调用工具、调用失败、执行了错误行动、执行了正确行动。它们在自然语言中都可能只显示‘完成’，所以这是一个界面和可验证性问题。

### 中文释义
本页的核心是：‘Done’ 可能来自四种完全不同的系统：没有调用工具、调用失败、执行了错误行动、执行了正确行动。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: ‘Done’ 可能来自四种完全不同的系统：没有调用工具、调用失败、执行了错误行动、执行了正确行动。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：‘Done’ 可能来自四种完全不同的系统：没有调用工具、调用失败、执行了错误行动、执行了正确行动。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 3 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：‘Done’ 可能来自四种完全不同的系统：没有调用工具、调用失败、执行了错误行动、执行了正确行动。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 3 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 4 页：A tool is a bounded capability

![PDF page 4](../assets/l12/pages/page_004.png)

### 原文 / Original Text
```text
A tool is a bounded capability
A tool is a bounded external 
capability with stated limits.
Examples: calculator, search, code 
execution, image processing, database 
query, file access, API call.
Each tool has one operation, named 
arguments, a declared return value and 
a limit.
Six kinds read the world; the API call 
changes it.
Lecture 12 · Tools, Connectors and the Boundary
```

### 完整中文翻译
工具是有明确边界的外部能力，例如 calculator、search、code execution、image processing、database query、file access 或 API call。每个工具应声明一个操作、命名参数、返回值和限制；六类工具读取世界，API call 会改变世界。

### 中文释义
本页的核心是：工具是有明确边界的外部能力，例如 calculator、search、code execution、image processing、database query、file access 或 API call。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 工具是有明确边界的外部能力，例如 calculator、search、code execution、image processing、database query、file access 或 API call。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：工具是有明确边界的外部能力，例如 calculator、search、code execution、image processing、database query、file access 或 API call。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 4 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：工具是有明确边界的外部能力，例如 calculator、search、code execution、image processing、database query、file access 或 API call。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 4 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 5 页：The model proposes; your system disposes

![PDF page 5](../assets/l12/pages/page_005.png)

### 原文 / Original Text
```text
The model proposes; your system disposes
A tool call in the model's 
output is a proposal, not an 
execution.
The model reads the tool definitions and 
produces only a name and arguments.
Your system validates, decides, 
executes or refuses, and reports what 
happened.
Provider documentation agrees that the 
application executes the call, so 
accountability sits there.
Lecture 12 · Tools, Connectors and the Boundary
```

### 完整中文翻译
模型提出，系统决定。模型读取工具定义并输出名称和参数，这只是 proposal；你的系统负责校验、授权、执行或拒绝，并报告实际发生的结果，因此责任位于应用层。

### 中文释义
本页的核心是：模型提出，系统决定。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 模型提出，系统决定。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：模型提出，系统决定。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 5 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：模型提出，系统决定。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 5 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 6 页：The function-calling loop

![PDF page 6](../assets/l12/pages/page_006.png)

### 原文 / Original Text
```text
The function-calling loop
The function-calling loop has 
five steps, and four of them are 
your code.
You send the request with tool 
definitions; the model returns a proposed 
call.
Your code executes the call, which is the 
only step that changes the world.
You return the result, treated as 
untrusted text; the model answers or 
calls again.
Lecture 12 · Tools, Connectors and the Boundary
```

### 完整中文翻译
function-calling loop 的五步中四步是应用代码：发送带 tool definitions 的请求；模型提出 call；代码执行唯一会改变世界的动作；把结果作为不可信文本返回；模型再回答或继续调用。

### 中文释义
本页的核心是：function-calling loop 的五步中四步是应用代码：发送带 tool definitions 的请求；模型提出 call；代码执行唯一会改变世界的动作；把结果作为不可信文本返回；模型再回答或继续调用。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: function-calling loop 的五步中四步是应用代码：发送带 tool definitions 的请求；模型提出 call；代码执行唯一会改变世界的动作；把结果作为不可信文本返回；模型再回答或继续调用。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：function-calling loop 的五步中四步是应用代码：发送带 tool definitions 的请求；模型提出 call；代码执行唯一会改变世界的动作；把结果作为不可信文本返回；模型再回答或继续调用。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 6 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：function-calling loop 的五步中四步是应用代码：发送带 tool definitions 的请求；模型提出 call；代码执行唯一会改变世界的动作；把结果作为不可信文本返回；模型再回答或继续调用。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 6 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 7 页：The schema is the contract

![PDF page 7](../assets/l12/pages/page_007.png)

### 原文 / Original Text
```text
The schema is the contract
The tool definition is a contract, 
and the model reads its 
description.
It names the capability, declares the 
arguments and states limits in plain 
language.
Your code validates the proposed call; the 
model cannot enforce its own contract.
A signature says “what to do, not how to 
prompt”; unparsed calls are caught errors.
Lecture 12 · Tools, Connectors and the Boundary
```

### 完整中文翻译
tool definition 的 schema 是契约：命名能力、声明参数并写清限制。你的代码必须验证调用；模型不能强制执行自己的契约。签名说明做什么，不说明如何写 prompt；无法解析的调用必须被捕获。

### 中文释义
本页的核心是：tool definition 的 schema 是契约：命名能力、声明参数并写清限制。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: tool definition 的 schema 是契约：命名能力、声明参数并写清限制。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：tool definition 的 schema 是契约：命名能力、声明参数并写清限制。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 7 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：tool definition 的 schema 是契约：命名能力、声明参数并写清限制。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 7 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 8 页：Five checks, and the failures they catch

![PDF page 8](../assets/l12/pages/page_008.png)

### 原文 / Original Text
```text
Five checks, and the failures they catch
Five checks run before any 
action, and each catches a 
specific failure.
Shape catches the malformed call; 
permission catches the unsafe call.
Precondition catches the stale action, 
such as cancelling an already 
cancelled meeting.
Confirmation catches wrong arguments 
in time; idempotency makes a 
repeated call harmless.
Lecture 12 · Tools, Connectors and the Boundary
```

### 完整中文翻译
执行前至少做五项检查：shape 检查格式错误；permission 检查不安全调用；precondition 检查过期状态；confirmation 及时暴露错误参数；idempotency 让重复调用无害。

### 中文释义
本页的核心是：执行前至少做五项检查：shape 检查格式错误；permission 检查不安全调用；precondition 检查过期状态；confirmation 及时暴露错误参数；idempotency 让重复调用无害。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 执行前至少做五项检查：shape 检查格式错误；permission 检查不安全调用；precondition 检查过期状态；confirmation 及时暴露错误参数；idempotency 让重复调用无害。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：执行前至少做五项检查：shape 检查格式错误；permission 检查不安全调用；precondition 检查过期状态；confirmation 及时暴露错误参数；idempotency 让重复调用无害。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 8 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：执行前至少做五项检查：shape 检查格式错误；permission 检查不安全调用；precondition 检查过期状态；confirmation 及时暴露错误参数；idempotency 让重复调用无害。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 8 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 9 页：From one function to a connector

![PDF page 9](../assets/l12/pages/page_009.png)

### 原文 / Original Text
```text
From one function to a connector
A connector is a set of 
operations defined and 
maintained by somebody 
else.
A tool is one stateless operation that 
you wrote, so you know its limits.
A connector has many operations, 
state, authentication and scopes that 
set the limit.
New risk: its definitions can change 
without any change in your code.
Lecture 12 · Tools, Connectors and the Boundary
```

### 完整中文翻译
connector 是由别人维护的一组 operations。单个 tool 通常是你写的无状态操作；connector 还涉及状态、认证和 scopes，且定义可能在你的代码不变时改变，因此风险更高。

### 中文释义
本页的核心是：connector 是由别人维护的一组 operations。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: connector 是由别人维护的一组 operations。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：connector 是由别人维护的一组 operations。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 9 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：connector 是由别人维护的一组 operations。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 9 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 10 页：MCP, in one picture

![PDF page 10](../assets/l12/pages/page_010.png)

### 原文 / Original Text
```text
MCP, in one picture
MCP is one standard way to 
connect tools and data to an AI 
application.
A host runs one client per server, over a single 
JSON-RPC protocol.
Servers expose three primitives: tools, 
resources and prompts; tools perform actions.
Connection is dynamic, so available 
capabilities can change at run time.
Lecture 12 · Tools, Connectors and the Boundary
```

### 完整中文翻译
MCP 是把 tools 和 data 连接到 AI application 的标准方式。host 为每个 server 运行 client，通过 JSON-RPC 通信；server 暴露 tools、resources、prompts 三种 primitive；连接是动态的，能力可在运行时变化。

### 中文释义
本页的核心是：MCP 是把 tools 和 data 连接到 AI application 的标准方式。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: MCP 是把 tools 和 data 连接到 AI application 的标准方式。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：MCP 是把 tools 和 data 连接到 AI application 的标准方式。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 10 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：MCP 是把 tools 和 data 连接到 AI application 的标准方式。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 10 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 11 页：The calendar assistant: the proposed call

![PDF page 11](../assets/l12/pages/page_011.png)

### 原文 / Original Text
```text
The calendar assistant: the proposed call
A well-formed call can 
silently make three decisions 
for the user.
The call passes the schema check 
and would execute without error.
It chose one of two Thursday meetings 
and read ‘morning’ as 09:00.
It set notify to true, a side effect that 
nobody requested.
Lecture 12 · Tools, Connectors and the Boundary
```

### 完整中文翻译
日历助手的 well-formed call 仍可能替用户做三个隐含决定：从两个周四会议中选一个，把 morning 解释成 09:00，并把 notify 设为 true，产生用户没有明确要求的副作用。

### 中文释义
本页的核心是：日历助手的 well-formed call 仍可能替用户做三个隐含决定：从两个周四会议中选一个，把 morning 解释成 09:00，并把 notify 设为 true，产生用户没有明确要求的副作用。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 日历助手的 well-formed call 仍可能替用户做三个隐含决定：从两个周四会议中选一个，把 morning 解释成 09:00，并把 notify 设为 true，产生用户没有明确要求的副作用。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：日历助手的 well-formed call 仍可能替用户做三个隐含决定：从两个周四会议中选一个，把 morning 解释成 09:00，并把 notify 设为 true，产生用户没有明确要求的副作用。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 11 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：日历助手的 well-formed call 仍可能替用户做三个隐含决定：从两个周四会议中选一个，把 morning 解释成 09:00，并把 notify 设为 true，产生用户没有明确要求的副作用。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 11 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 12 页：What the person sees before it runs

![PDF page 12](../assets/l12/pages/page_012.png)

### 原文 / Original Text
```text
What the person sees before it runs
A confirmation shows the model's 
decisions to the person before the 
action runs.
Name the object: ‘Project review’, six attendees, 
not ‘the meeting’.
Show from and to; surface the added side effect 
and leave it unticked.
Offer the other reading, and make cancelling as 
easy as confirming.
Lecture 12 · Tools, Connectors and the Boundary
```

### 完整中文翻译
执行前的确认界面应显示具体对象，例如 Project review、六位参与者，而不是‘the meeting’；显示起止时间；突出新增副作用；提供另一种解释，并让取消和确认一样容易。

### 中文释义
本页的核心是：执行前的确认界面应显示具体对象，例如 Project review、六位参与者，而不是‘the meeting’；显示起止时间；突出新增副作用；提供另一种解释，并让取消和确认一样容易。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 执行前的确认界面应显示具体对象，例如 Project review、六位参与者，而不是‘the meeting’；显示起止时间；突出新增副作用；提供另一种解释，并让取消和确认一样容易。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：执行前的确认界面应显示具体对象，例如 Project review、六位参与者，而不是‘the meeting’；显示起止时间；突出新增副作用；提供另一种解释，并让取消和确认一样容易。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 12 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：执行前的确认界面应显示具体对象，例如 Project review、六位参与者，而不是‘the meeting’；显示起止时间；突出新增副作用；提供另一种解释，并让取消和确认一样容易。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 12 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 13 页：What came back, and what the screen says

![PDF page 13](../assets/l12/pages/page_013.png)

### 原文 / Original Text
```text
What came back, and what the screen says
The return value is a fact; the 
model's summary is a claim.
The return value shows that nobody 
was emailed and that the move created 
a clash.
Build the on-screen report from the 
return value, not from the model's 
summary.
Two similar sentences differ in kind: one is 
generated, the other observed.
Lecture 12 · Tools, Connectors and the Boundary
```

### 完整中文翻译
return value 是事实，model summary 是 claim。界面报告应根据 return value 构建：例如无人收到邮件且移动造成冲突。生成的句子和观察到的结果属于不同证据等级。

### 中文释义
本页的核心是：return value 是事实，model summary 是 claim。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: return value 是事实，model summary 是 claim。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：return value 是事实，model summary 是 claim。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 13 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：return value 是事实，model summary 是 claim。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 13 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 14 页：‘Done’ is a claim until the tool says so

![PDF page 14](../assets/l12/pages/page_014.png)

### 原文 / Original Text
```text
‘Done’ is a claim until the tool says so
A process hallucination is a 
model reporting an action it 
never took.
The tool call crosses the gulf of 
execution; its return value closes the 
gulf of evaluation.
Report from the return value, and name 
the object that changed.
State what did not happen, and offer undo 
where it exists.
Lecture 12 · Tools, Connectors and the Boundary
```

### 完整中文翻译
process hallucination 是模型报告自己没有执行的行动。tool call 跨过 execution gulf，return value 关闭 evaluation gulf。报告应来自返回值，说明哪个对象改变、什么没有发生，并在可能时提供 undo。

### 中文释义
本页的核心是：process hallucination 是模型报告自己没有执行的行动。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: process hallucination 是模型报告自己没有执行的行动。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：process hallucination 是模型报告自己没有执行的行动。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 14 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：process hallucination 是模型报告自己没有执行的行动。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 14 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 15 页：Your turn: which ones need a confirmation?

![PDF page 15](../assets/l12/pages/page_015.png)

### 原文 / Original Text
```text
Your turn: which ones need a confirmation?
For each action, decide: just do 
it, confirm first, or never 
automate.
A: look up opening hours. B: draft a reply. 
C: send the reply.
D: add a calendar slot. E: cancel a 
meeting and tell six people.
F: delete the file just created. Take three 
minutes to decide.
Lecture 12 · Tools, Connectors and the Boundary
```

### 完整中文翻译
练习：A 查询营业时间，B 起草回复，C 发送回复，D 新增日历时间，E 取消会议并通知六人，F 删除刚创建的文件。决定每项是直接做、先确认还是永不自动化。

### 中文释义
本页的核心是：练习：A 查询营业时间，B 起草回复，C 发送回复，D 新增日历时间，E 取消会议并通知六人，F 删除刚创建的文件。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 练习：A 查询营业时间，B 起草回复，C 发送回复，D 新增日历时间，E 取消会议并通知六人，F 删除刚创建的文件。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：练习：A 查询营业时间，B 起草回复，C 发送回复，D 新增日历时间，E 取消会议并通知六人，F 删除刚创建的文件。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 15 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：练习：A 查询营业时间，B 起草回复，C 发送回复，D 新增日历时间，E 取消会议并通知六人，F 删除刚创建的文件。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 15 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 16 页：Where to draw the line: two questions

![PDF page 16](../assets/l12/pages/page_016.png)

### 原文 / Original Text
```text
Where to draw the line: two questions
Two questions decide it: can it be 
undone, and will the person 
notice?
Reversible and visible: do it and show it. 
Reversible but invisible: do it and report.
Irreversible but visible: confirm, with the 
arguments shown.
Irreversible and invisible: confirm, and 
consider not automating the action at all.
Lecture 12 · Tools, Connectors and the Boundary
```

### 完整中文翻译
画边界要问两个问题：行动能否撤销，用户是否会看见。可撤销且可见可执行后展示；可撤销但不可见要执行并报告；不可撤销且可见要在显示参数后确认；不可撤销且不可见应确认并考虑不自动化。

### 中文释义
本页的核心是：画边界要问两个问题：行动能否撤销，用户是否会看见。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 画边界要问两个问题：行动能否撤销，用户是否会看见。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：画边界要问两个问题：行动能否撤销，用户是否会看见。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 16 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：画边界要问两个问题：行动能否撤销，用户是否会看见。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 16 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 17 页：Text in the window can now ask for actions

![PDF page 17](../assets/l12/pages/page_017.png)

### 原文 / Original Text
```text
Text in the window can now ask for actions
Text in the context window can now 
request actions, not only mislead 
answers.
Lecture 11's contaminated document becomes a 
risk once tools are attached.
Least privilege: the narrowest scope, so a 
successful injection can do little.
The decision to act is never the model's or the 
document's. Phase 1: list tools, permissions and 
confirmations.
Lecture 12 · Tools, Connectors and the Boundary
```

### 完整中文翻译
上下文中的文字不只会误导答案，也可能请求行动。第 11 讲中被污染的文档一旦接入工具就成为风险。应采用 least privilege，使用最窄权限；决定行动的永远不能是模型或文档。Phase 1 要列出 tools、permissions、confirmations。

### 中文释义
本页的核心是：上下文中的文字不只会误导答案，也可能请求行动。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 上下文中的文字不只会误导答案，也可能请求行动。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：上下文中的文字不只会误导答案，也可能请求行动。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 17 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：上下文中的文字不只会误导答案，也可能请求行动。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 17 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 18 页：What you can now do

![PDF page 18](../assets/l12/pages/page_018.png)

### 原文 / Original Text
```text
What you can now do
Lecture 12 · Tools, Connectors and the Boundary
Course-own diagram. The four outcomes, and where each was answered.
```

### 完整中文翻译
本讲结果：你应能区分 proposal 与 execution、为工具调用设计验证和确认、解释 MCP 的边界，并让界面报告真实 return value 而不是模型的‘完成’陈述。

### 中文释义
本页的核心是：本讲结果：你应能区分 proposal 与 execution、为工具调用设计验证和确认、解释 MCP 的边界，并让界面报告真实 return value 而不是模型的‘完成’陈述。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 本讲结果：你应能区分 proposal 与 execution、为工具调用设计验证和确认、解释 MCP 的边界，并让界面报告真实 return value 而不是模型的‘完成’陈述。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：本讲结果：你应能区分 proposal 与 execution、为工具调用设计验证和确认、解释 MCP 的边界，并让界面报告真实 return value 而不是模型的‘完成’陈述。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 18 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：本讲结果：你应能区分 proposal 与 execution、为工具调用设计验证和确认、解释 MCP 的边界，并让界面报告真实 return value 而不是模型的‘完成’陈述。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 18 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.

## 第 19 页：References and further reading

![PDF page 19](../assets/l12/pages/page_019.png)

### 原文 / Original Text
```text
References and further reading
Schick, T., Dwivedi-Yu, J., Dessì, R., et al. (2023).
Toolformer: Language Models Can Teach Themselves to Use Tools.
Advances in Neural Information Processing Systems, 36.
→ Tool use by language models; deciding when and how to call external APIs. NeurIPS Proceedings
OpenAI. (current documentation).
Function Calling / Tool Calling Guide.
→ The model proposes a tool call; the application executes it and returns the result. This directly supports your 
five-step function-calling loop. OpenAI Developers
Model Context Protocol. (current specification).
MCP Specification: Tools, Resources and Prompts.
→ Standard client–server architecture for exposing tools and context to AI applications. GitHub
Saltzer, J. H., & Schroeder, M. D. (1975).
The Protection of Information in Computer Systems.
Proceedings of the IEEE, 63(9), 1278–1308.
→ Foundational security principles, especially least privilege and complete mediation. Massachusetts 
Institute of Technology
Greshake, K., Abdelnabi, S., Mishra, S., et al. (2023).
Not What You’ve Signed Up For: Compromising Real-World LLM-Integrated Applications with Indirect Prompt 
Injection.
Lecture 12 · Tools, Connectors and the Boundary
```

### 完整中文翻译
参考文献包括 Toolformer、OpenAI function/tool calling 文档、MCP specification、Saltzer 与 Schroeder 的 least privilege，以及 indirect prompt injection 研究。

### 中文释义
本页的核心是：参考文献包括 Toolformer、OpenAI function/tool calling 文档、MCP specification、Saltzer 与 Schroeder 的 least privilege，以及 indirect prompt injection 研究。重点是把它落实为可检查的系统行为，而不是只记住术语。

### English Explanation
The page's core point is: 参考文献包括 Toolformer、OpenAI function/tool calling 文档、MCP specification、Saltzer 与 Schroeder 的 least privilege，以及 indirect prompt injection 研究。重点是把它落实为可检查的系统行为，而不是只记住术语。

### 概念解析与拓展
- **Tools, Connectors And The Model-System Boundary**：参考文献包括 Toolformer、OpenAI function/tool calling 文档、MCP specification、Saltzer 与 Schroeder 的 least privilege，以及 indirect prompt injection 研究。
- **Tool call / 工具调用**：模型提出、应用校验并执行或拒绝的结构化行动请求。
- **Least privilege / 最小权限**：只授予完成任务所需的最窄权限范围。

### 自测问题 / Self-check
- 中文问题：第 19 页如何帮助理解 tools, connectors and the model-system boundary？
  - 答案：参考文献包括 Toolformer、OpenAI function/tool calling 文档、MCP specification、Saltzer 与 Schroeder 的 least privilege，以及 indirect prompt injection 研究。重点是把它落实为可检查的系统行为，而不是只记住术语。
- English question: How does page 19 help explain tools, connectors and the model-system boundary?
  - Answer: It turns the concept into a checkable system behaviour rather than a label to memorise.
