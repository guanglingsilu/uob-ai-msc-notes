# 来源：1. Datalake and lakehouse architecture_Lecture_Notes-1.pdf

<!-- SOURCE: 1. Datalake and lakehouse architecture_Lecture_Notes-1.pdf -->

<!-- PDF 页 1 -->

Data warehouse, data lake, lakehouse

Prof. Paolo Missier
School of Computer Science
University of Birmingham, UK

Data-intensive AI
2026/27 Sem 1

<!-- PDF 页 2 -->

In this lecture

Data warehouses: ACID-compliant storage optimised for analytics from the ‘80s
Data lakes: storage for structured, semi-structured, and unstructured data

open table formats (Delta Lake, Iceberg, Hudi)

The Medallion architecture: from raw data to an ML-ready training set

Introducing the NYC Taxi dataset

Dataset integration: table unions, joins. What can go wrong?

<!-- PDF 页 3 -->

Data Warehouses

Persistent storage for structured data, processed to optimize data analytics workloads

- Structured data (tables)
- Data flow from operational systems to decision support
- On premise or cloud-hosted

Image Credit: https://gem-corp.tech/big-data/etl-in-data-warehouse-the-definitive-guide/

<!-- PDF 页 4 -->

Data Warehouses: Features and Players

Feature

What does it mean?

Query performance

Columnar storage, pre-computed aggregations, materialised views, cost-based query 
optimisation

ACID transactions

Full atomicity, consistency, isolation, and durability guarantees on all operations

Data quality enforcement

Schema constraints (NOT NULL, CHECK, FOREIGN KEY) enforced at load time

SQL compatibility

Mature, standardised query interface; wide tooling support

Governance and lineage

Centralised metadata catalogue; clear provenance from source to report

Concurrent access

Multi-version concurrency control (MVCC) supports many simultaneous readers and 
writers

Major commercial players:
Snowflake, Google BigQuery, Amazon Redshift

<!-- PDF 页 5 -->

ACID transactions. -- look it up!

Try: “basics of ACID transaction management”

• Atomicity
• Consistency
• Isolation
• Durability

https://www.datacamp.com/blog/acid-transactions
https://www.databricks.com/blog/what-are-acid-transactions

Classic examples:
- Reserving a seat
- Transferring funds between bank accounts

<!-- PDF 页 6 -->

Data warehouse: limitations

1. Schema rigidity:

Schema-on-write makes it difficult to accommodate schema evolution. 

Upgrading schema and ETL pipeline is expensive

2. Data type restriction. Cannot store semi-structured and unstructured data natively

3. Coupling of storage and compute. Expensive to scale up

4. Data is stored in proprietary formats with an SQL access path

Accessing data with non-SQL tools requires expensive data transformation

5. Batch updates. New data not immediately available

6. Processed data unsuitable for ML/AI applications

pre-aggregated “OLAP cubes” are good for analytics but not as training sets

<!-- PDF 页 7 -->

Data Lakes

Format heterogeneity. Data stored in native format
•
structured (CSV, Parquet), semi-structured (JSON)
• unstructured (text, images, video, sensor streams)

Schema-on-read
• Structure not known at ingestion time. 
• Discovered at query time by the application

Decoupled storage and compute —
- storage layer independent of the compute layer. They can scale independently

HDFS, Amazon S3. -->  Spark, Hive 

Read-only: processed data is not stored back into a data lake

<!-- PDF 页 8 -->

The Data and AI maturity curve

<!-- PDF 页 9 -->

Key Design Principles of a Data Lake

1.

Immutability of raw data
•
•

Raw files are written once and never overwritten.
If a cleaning step is found to be wrong later, you reprocess from the raw zone

2. Partitioning for query efficiency
Files are organised in a directory hierarchy that maps 
to the most common query predicates:

<!-- PDF 页 10 -->

Key Design Principles of a Data Lake

3. Open file formats
• Parquet (columnar, compressed), Delta Lake

• Data becomes portable across implementations

https://www.databricks.com/blog/what-is-parquet

4. Columnar storage
• Only the columns needed by a query are read (column pruning)
• Optimises aggregation over all values in a column allows Spark to read only the columns 

needed by a query

• Using pre-computed column statistics (min/max per row group), row groups that cannot 

satisfy a filter can be skipped (predicate pushdown)

5. Compression (Snappy, Zstandard) reduces both storage cost and network transfer time when 
data moves between storage and executors

<!-- PDF 页 11 -->

Columnar data storage: efficient aggregation

Sales:

id

region product

amount

Row-oriented layout (CSV, or a row-store database)

1

2

3

4

5

6

EU

US

EU

US

EU

US

A

B

A

C

B

A

10

20

30

40

50

60

[1,EU,A,10] [2,US,B,20] [3,EU,A,30] [4,US,C,40] [5,EU,B,50] [6,US,A,60]

Columnar layout (Parquet)
id: 
region: 
product:  [A, B, A, C, B, A]
amount:  [10, 20, 30, 40, 50, 60]

[1, 2, 3, 4, 5, 6]
[EU, US, EU, US, EU, US]

Query: SELECT SUM(amount) FROM sales

How do you compute the result given each of the two layouts?

1. Row layout: 

Scan each row / retrieve amount / add  --> read 6x4 values, 
used 6.  75% of the reads are never used

2. Column layout: 

Scan amount column / add  --> read 6 values, used 6

<!-- PDF 页 12 -->

Columnar data storage: efficient filtering 

id region product

amount

1

EU

2 US

3

EU

4 US

5

EU

6 US

A

B

A

C

B

A

10

20

30

40

50

60

Group stats
amount

- Parquet splits the data into row groups
- Stores min/max statistics per column chunk in the file 

footer

min max

10

40

30

60

Query: SELECT * FROM sales WHERE amount > 35

How do you compute the result given each of the two layouts?

1. Row layout: 

Scan each row / if amount > 35, add to result

2. Column layout: 

Consult group stats for amount / Select group 2 (rows 4-6)
Add all rows in group to result

<!-- PDF 页 13 -->

Columnar data storage: combined benefits

Query:  SELECT SUM(amount) FROM sales WHERE amount > 35

id

region product

amount

1

2

3

4

5

6

EU

US

EU

US

EU

US

A

B

A

C

B

A

10

20

30

40

50

60

Group stats
amount

min max

10

40

30

60

Exercise:
show how this combined query is executed on a columnar store

<!-- PDF 页 14 -->

Key Design Principles of a Data Lake

5. Metadata and governance
• A data lake without a catalogue is a data swamp
• Data lakes use a metastore (Apache Hive Metastore, AWS Glue Data Catalog, Unity Catalog) 

to record:

•

tables, their schema, their partition layout

6. Separation of compute and storage
• Compute cluster can be shut down between jobs 

without losing data
(Spark) workers have no persistent state

•

<!-- PDF 页 15 -->

Data Lakes: Summary of Features and Strengths

Feature

Elastic scale

Cost efficiency

What it means

Storage (S3, ADLS) scales to exabytes; compute (Spark clusters) 
scales independently

Object store pricing (~$0.02/GB/month) is orders of magnitude 
cheaper than warehouse storage

ML and AI workload support

columnar Parquet files are natively consumed by Machine Learning 
libraries

Preservation of raw data

The original data is preserved, enabling re-processing when required

Open formats

Same files can be queried by Spark and other processors — no 
vendor lock-in

<!-- PDF 页 16 -->

Data Lakes: Limitations and Risks

Risk

Data swamp

Schema drift

Small-file problem

Description
Files accumulate with no schema 
documentation or ownership

Mitigation
Mandatory metadata registration 
at ingest

A source system changes a column name or 
type; downstream jobs silently break or 
produce wrong results
Errors are only detected late – at query time

Many tiny files (e.g., one Parquet per hour) 
degrade Spark read performance 
catastrophically

Schema-on-read validation

Periodic compaction jobs; target 
128 MB–1 GB per file

Read amplification

Unpartitioned tables force full scans even for 
highly selective queries

Design partition keys around the 
most frequent query patterns

<!-- PDF 页 17 -->

Data Lakes: Limitations

Risk

No ACID 
transaction support

No update or 
delete semantics

What it means
• Concurrent writers to the same dataset can produce partially written, 

inconsistent states. 
•
There is no native mechanism to roll back a failed multi-file write
• Object stores are optimised for append and full-object overwrite.
•

Implementing GDPR-mandated deletion of a specific user's records requires 
rewriting entire Parquet files

<!-- PDF 页 18 -->

Data warehouses vs data lakes

Property

Data Warehouse

Data Lake

Schema

Schema-on-write (defined before ingest)

Data format

Normalised tables (SQL)

Schema-on-read (defined at query 
time)

Files: Parquet, JSON, CSV, images, 
logs

Who uses it

BI analysts, fixed dashboards

Data scientists, ML engineers

Flexibility

Low — changing schema is expensive

Risk

Low — data is validated at ingest

High — raw data is always 
preserved

High — "data swamp" if 
ungoverned

References:
[1] (data lakehouse book)
https://learn.microsoft.com/en-us/azure/databricks/lakehouse/

<!-- PDF 页 19 -->

Databricks’ “Medallion” reference architecture

A medallion architecture is a data design pattern used to logically organize data in a lakehouse, with the goal 
of incrementally and progressively improving the structure and quality of data as it flows through each layer of 
the architecture (from Bronze ⇒ Silver ⇒ Gold layer tables).

Ref: https://www.databricks.com/blog/what-is-medallion-architecture

<!-- PDF 页 20 -->

Example: the NYC TLC Taxi dataset

https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page

Zone

Lake Role

NYC Taxi Artefact

Landing

Transient raw files, exactly as received from the source

Raw .parquet files downloaded from TLC 
CDN

Bronze

Immutable raw copy
read into Spark but never modified

yellow_raw, green_raw, zones
- Delta Table --> files / DataFrames

Silver

Cleaned, integrated (union, join)

Gold

ML-ready, balanced, etc 
fully quality-controlled feature matrix

trips_integrated
- Delta Table --> files / DataFrames

- Delta Table --> files / DataFrames

<!-- PDF 页 21 -->

Data lake + data warehouse = “Lakehouse”

Enable transactional data management features directly on top of object store files

Key insight:
store a transaction log alongside 
data files in the object store itself

Ref: Armbrust, M. et al. (2021). Lakehouse: A new generation of open platforms that unify data warehousing and advanced analytics.CIDR.

<!-- PDF 页 22 -->

Addressing the limitations: Lakehouse capabilities

Warehouse and Data 
Lake Limitation

Schema rigidity

Addressed by Lakehouse Capability…

Unity Catalog provides lineage, tagging, access control, search
Schema declared in log; violations rejected at commit time
Controlled column additions/renames recorded in log without rewriting data files

Proprietary formats

Delta/Iceberg/Hudi are open-source; any engine can read the Parquet files

No ACID transactions

Optimistic concurrency control on the Delta transaction log

Poor query performance

Data skipping via per-file statistics; Z-ordering; liquid clustering
Per-file min/max statistics in log allow the query engine to skip files that cannot contain 
qualifying rows

Cost at scale

Object store pricing; compute clusters spun up/down on demand

No ML support

Row-level Parquet files directly consumed by ML frameworks; no export step needed

<!-- PDF 页 23 -->

Delta Lake and Delta Tables

Delta Lake is Databrick’s implementation of a lakehouse
Delta Lake is an open-source storage framework
- originally developed by Databricks and donated to the Linux Foundation in 2019
-

It is a transactional metadata layer on top of standard Apache Parquet files stored in an object store

A Delta table is a table whose data is stored as 
a collection of Parquet files managed by a 
Delta Lake transaction log

From the user's perspective it behaves identically to a standard SQL table
- it has a schema, supports SELECT, INSERT, UPDATE, DELETE, and MERGE

<!-- PDF 页 24 -->

Delta Lake architecture in Databricks

In Databricks every table is a Delta table by default.
- The Medallion architecture (Bronze → Silver → Gold) is implemented as three sets of 

Delta tables at progressively higher quality levels

- The transaction log provides the audit trail across all transformations

<!-- PDF 页 25 -->

Delta Table: Data Skipping and Z-Ordering

When Delta Lake writes data files, it records column-level statistics for the first 32 columns in every Parquet 
file:

minimum value, maximum value, null count

At query time, files whose min/max ranges cannot contain any rows satisfying the WHERE predicate are 
skipped entirely — without being opened or decompressed.

Z-Ordering (multi-dimensional clustering) physically co-locates rows with similar values of multiple 
columns in the same files:

Z-ordering on (pickup_month, pickup_borough) means that a query filtering on both columns will skip 
the vast majority of files — the query touches only the files that could contain matching rows.

<!-- PDF 页 26 -->

Exercise

- Assume a uniform distribution of records for both pickup_month, 

pickup_borough

- Write a query to select rides for a specific time window (months) and a specific set of 

boroughs

- Estimate how many of the files will be read to answer the query

(hint: consider the number of months and the number of boroughs)

<!-- PDF 页 27 -->

Summary

• Data warehouses
• Datalakes

• Their convergence: the lakehouse

• Open specs, open format
• DeltaLake, Delta Tables: Databricks’ implementation

• Used in our labs
