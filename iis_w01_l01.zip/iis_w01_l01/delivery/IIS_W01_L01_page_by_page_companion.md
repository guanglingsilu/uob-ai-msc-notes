# IIS Week 1 Lecture 1 - Page-by-page Companion

本笔记基于 learn-from-materials 抽取结果重做，覆盖 PDF 27 页。每页包含截图、原文、完整中文翻译、中文释义、English explanation、概念解析与双语自测答案。

## 目录
- [第 1 页：From Calculators to Copilots: A History of Intelligent Interaction](#第-1-页from-calculators-to-copilots:-a-history-of-intelligent-interaction)
- [第 2 页：What we usually mean by 'intelligence'](#第-2-页what-we-usually-mean-by-'intelligence')
- [第 3 页：Intelligence as goal-directed navigation](#第-3-页intelligence-as-goal-directed-navigation)
- [第 4 页：Different spaces, different intelligences](#第-4-页different-spaces,-different-intelligences)
- [第 5 页：Two conversations, fifty-nine years apart](#第-5-页two-conversations,-fifty-nine-years-apart)
- [第 6 页：What changed for the person, each time?](#第-6-页what-changed-for-the-person,-each-time?)
- [第 7 页：The idea most of us arrive with](#第-7-页the-idea-most-of-us-arrive-with)
- [第 8 页：Five capability shifts, 1950 to today](#第-8-页five-capability-shifts,-1950-to-today)
- [第 9 页：Shift 1: symbolic rules and ELIZA (1966)](#第-9-页shift-1:-symbolic-rules-and-eliza-(1966))
- [第 10 页：Shift 2: direct manipulation and the GUI](#第-10-页shift-2:-direct-manipulation-and-the-gui)
- [第 11 页：Shift 3: learning and recommendation](#第-11-页shift-3:-learning-and-recommendation)
- [第 12 页：Shift 4: deep learning and perception](#第-12-页shift-4:-deep-learning-and-perception)
- [第 13 页：Shift 5: large language models and agents](#第-13-页shift-5:-large-language-models-and-agents)
- [第 14 页：The reading frame: four interaction variables](#第-14-页the-reading-frame:-four-interaction-variables)
- [第 15 页：Five shifts scored on four variables](#第-15-页five-shifts-scored-on-four-variables)
- [第 16 页：1) the predictive keyboard](#第-16-页1)-the-predictive-keyboard)
- [第 17 页：2) navigation that reroutes](#第-17-页2)-navigation-that-reroutes)
- [第 18 页：3) a coding copilot](#第-18-页3)-a-coding-copilot)
- [第 19 页：Your turn: score the automatic captions](#第-19-页your-turn:-score-the-automatic-captions)
- [第 20 页：ELIZA and a copilot, side by side](#第-20-页eliza-and-a-copilot,-side-by-side)
- [第 21 页：The ELIZA effect](#第-21-页the-eliza-effect)
- [第 22 页：Turing's question versus the design question](#第-22-页turing's-question-versus-the-design-question)
- [第 23 页：You bring the last generation's model with you](#第-23-页you-bring-the-last-generation's-model-with-you)
- [第 24 页：One question, four areas, eleven weeks](#第-24-页one-question,-four-areas,-eleven-weeks)
- [第 25 页：Phase 1 begins now: choose an area by its shift](#第-25-页phase-1-begins-now:-choose-an-area-by-its-shift)
- [第 26 页：What changed each time](#第-26-页what-changed-each-time)
- [第 27 页：References and further reading](#第-27-页references-and-further-reading)

## 第 1 页：From Calculators to Copilots: A History of Intelligent Interaction

Source ID: `src-ba38b47b419c-pdf_page-00001`

![PDF page 1](../assets/pages/page_001.png)

### 原文 / Original Text

```text
From Calculators to 
Copilots: A History of 
Intelligent Interaction

Intelligent Interactive Systems  ·  Week 1  ·  Lecture 01
University of Birmingham
```

### 完整中文翻译

从计算器到副驾驶：智能交互的历史。

智能交互系统 - 第 1 周 - 第 1 讲。

伯明翰大学。

### 中文释义

这一页给出整讲课的核心范围：不是单纯讲 AI 技术史，而是讲技术能力如何改变人与系统的互动方式。标题里的 calculators 指早期可计算、可自动化的机器形象；copilots 指现代能建议、生成、执行和协作的智能系统。课程关心的是从“工具帮我算”到“系统和我一起做，甚至替我行动”的转变。

### English Explanation

This opening slide frames the lecture as a history of interaction, not just a history of AI models. The movement from calculators to copilots signals a shift from computational tools to systems that participate in work, make suggestions, and sometimes act.

### 概念解析与拓展

- **Intelligent interaction / 智能交互**：人与具备推断、学习、推荐、感知或生成能力的系统共同完成任务的互动过程。重点不是机器有多聪明，而是互动结构如何改变。
- **Copilot / 副驾驶式系统**：一种协作型智能系统隐喻：系统不是完全自动驾驶，而是在人的任务中提供建议、补全、执行或纠错。

拓展：复习时把这门课和传统 AI 课区分开：传统 AI 常问模型准确率、算法结构、训练数据；IIS 更常问用户能否理解、控制、纠错、信任系统。

### 自测问题 / Self-check

**Q1 中文：** 这讲课的中心对象是 AI 技术本身，还是人与智能系统的互动？

**中文答案：** 中心对象是互动。技术史只是背景，真正要看的是系统能力如何改变人的可见性、主动权和可撤销性。

**Q1 English:** Is the lecture mainly about AI technology itself or interaction between people and intelligent systems?

**English answer:** It is mainly about interaction. The technology history matters because it changes what people can see, control, and undo.

**Q2 中文：** 为什么标题用 calculators 到 copilots？

**中文答案：** 它压缩了从“机器执行明确计算”到“系统参与复杂任务并提出行动”的历史变化。

**Q2 English:** Why does the title move from calculators to copilots?

**English answer:** It compresses the move from machines that compute explicit operations to systems that participate in complex tasks and propose actions.


## 第 2 页：What we usually mean by 'intelligence'

Source ID: `src-ba38b47b419c-pdf_page-00002`

![PDF page 2](../assets/pages/page_002.png)

### 原文 / Original Text

```text
What we usually mean by 'intelligence'

Lecture 01 · Framing

Ask a room to define intelligence and you get the 
same list every time — and two hidden assumptions 
come with it.

The list is usually reasoning, problem solving, flexibility, 
intuition and learning, and it is the one most of us arrive 
with.

The first assumption is anthropocentric: humans at the top 
of a single scale, everything else measured by how close it 
gets to us.

The second is brain-centric: that intelligence has to live in a 
brain. Both will shape how you judge every system in this 
module.
```

### 完整中文翻译

我们通常所说的“智能”。

第 1 讲 - 框架。

让一个房间里的人定义智能，你每次都会得到同一组清单，而且这组清单背后还带着两个隐藏假设。

这组清单通常包括推理、问题解决、灵活性、直觉和学习，这也是我们大多数人带着进入这门课的理解。

第一个假设是以人类为中心：人类位于单一尺度的顶端，其他一切都按它们与人类有多接近来衡量。

第二个假设是以大脑为中心：智能必须存在于大脑中。这两个假设都会影响你在本模块中判断每一个系统的方式。

### 中文释义

这一页先拆掉两个直觉包袱。我们往往把智能想成“越像人越智能”，还默认智能必须装在大脑里。课程提醒你：如果带着这两个假设看系统，你会过早把注意力放在类人程度，而不是放在系统在具体任务空间里做了什么、对用户造成了什么影响。

### English Explanation

The slide exposes two default assumptions: that intelligence is measured by similarity to humans and that it must reside in a brain. The module asks students to suspend those assumptions so that interaction can be evaluated across non-human and non-brain systems.

### 概念解析与拓展

- **Anthropocentric / 以人类为中心**：把人类当作智能的标准和顶点，容易忽略动物、细胞、组织、机器或集体系统中的不同能力。
- **Brain-centric / 以大脑为中心**：认为智能必须由大脑产生。IIS 课程会把智能看作更广泛的目标导向能力。
- **Reasoning, problem solving, flexibility, intuition, learning / 推理、问题解决、灵活性、直觉、学习**：常见智能清单，但它们不是唯一入口，也不一定都能直接指导交互设计。

拓展：考试或项目里遇到“智能”定义时，不要只写类人能力。可以补一句：本课更关心智能能力进入互动后如何改变人的行动条件。

### 自测问题 / Self-check

**Q1 中文：** 这一页指出的两个隐藏假设是什么？

**中文答案：** 以人类为中心和以大脑为中心。前者把人类当单一尺度顶点，后者假定智能必须在大脑中。

**Q1 English:** What are the two hidden assumptions on this slide?

**English answer:** Anthropocentrism and brain-centrism: treating humans as the top of one scale and assuming intelligence must live in a brain.

**Q2 中文：** 为什么这些假设会影响交互设计？

**中文答案：** 因为它们会让设计者只看系统是否像人，而忽略用户能否看见、控制和撤销系统行为。

**Q2 English:** Why do these assumptions matter for interaction design?

**English answer:** They can make designers focus on human-likeness instead of whether users can see, control, and undo system behavior.


## 第 3 页：Intelligence as goal-directed navigation

Source ID: `src-ba38b47b419c-pdf_page-00003`

![PDF page 3](../assets/pages/page_003.png)

### 原文 / Original Text

```text
Intelligence as goal-directed navigation

Lecture 01 · Framing

A definition that mentions neither brains nor humans: 
holding a goal fixed while varying the means of 
reaching it.

William James (1890) called it the pursuit of 'fixed ends with 
varying means'. Block one route and an intelligent system 
finds another.

Levin (2022) generalises this to competency at navigating 
a space toward desirable regions — a definition that fits a 
cell as well as a person.

So the question changes. Instead of 'how intelligent is it?', we 
ask which space is it navigating, and how well?
```

### 完整中文翻译

作为目标导向导航的智能。

第 1 讲 - 框架。

一个既不提大脑也不提人类的定义：在保持目标不变的同时，改变达到目标的手段。

William James（1890）把它称为追求“固定终点，但采用变化的手段”。如果一条路径被堵住，一个智能系统会找到另一条路径。

Levin（2022）把这个观点推广为：朝着理想区域在某个空间中导航的能力。这个定义既适用于细胞，也适用于人。

所以问题发生了变化。我们不再问“它有多智能？”，而是问：它正在导航的是哪个空间？它导航得有多好？

### 中文释义

这一页给出本讲最重要的替代定义。智能不是固定等于像人思考，而是“为了目标，在某个空间中调整路径”。这里的空间可以是物理空间、概念空间、社会空间、身体形态空间，也可以是数字任务空间。这个定义让我们能比较细胞、动物、人和软件系统。

### English Explanation

The lecture reframes intelligence as competence in navigating a space toward a desired region. This avoids requiring humans or brains and shifts evaluation toward the goal, the space, and the quality of navigation.

### 概念解析与拓展

- **Goal-directed navigation / 目标导向导航**：系统保留目标，同时调整达到目标的路径或手段。
- **Fixed ends with varying means / 固定终点、变化手段**：William James 的表达，强调智能体遇到阻碍后可以换方法。
- **Problem space / 问题空间**：系统行动、搜索、推断或适应发生的空间。评价智能时要先问空间是什么。

拓展：在 HCI/IIS 中，这个定义很有用，因为交互系统经常不是“独立智能体”，而是在用户任务空间中辅助导航。比如推荐系统导航偏好空间，地图导航交通空间，Copilot 导航代码空间。

### 自测问题 / Self-check

**Q1 中文：** 本页建议把“它有多智能”换成哪两个问题？

**中文答案：** 它在导航哪个空间？它导航得有多好？

**Q1 English:** Which two questions replace 'how intelligent is it?'

**English answer:** Which space is it navigating, and how well is it navigating it?

**Q2 中文：** 为什么这个定义能用于细胞？

**中文答案：** 因为它不要求大脑，只要求系统能朝理想区域调整行为或状态。

**Q2 English:** Why can this definition apply to a cell?

**English answer:** Because it does not require a brain; it only requires competence in moving states toward desirable regions.


## 第 4 页：Different spaces, different intelligences

Source ID: `src-ba38b47b419c-pdf_page-00004`

![PDF page 4](../assets/pages/page_004.png)

### 原文 / Original Text

```text
Different spaces, different intelligences

Lecture 01 · Framing

Once intelligence means navigating a space, you can 
see it working at scales that have nothing to do with 
thinking.

Cells navigate anatomical (morphogenetic) space and 
organs navigate physiological space: a salamander regrows 
a limb and stops when the shape is right.

Some animals outperform us inside a narrow space: a 
young chimpanzee beat untrained adults at numeral recall 
(2007), but practised humans matched him (2009).

Humans range across physical, conceptual and social 
space. Your systems navigate a digital one, alongside a 
person.
```

### 完整中文翻译

不同的空间，不同的智能。

第 1 讲 - 框架。

一旦智能意味着在某个空间中导航，你就能看到它在与“思考”无关的尺度上运作。

细胞在解剖学的，也就是形态发生的空间中导航；器官在生理空间中导航：蝾螈会重新长出肢体，并在形状正确时停止。

有些动物会在狭窄空间内胜过我们：一只年轻黑猩猩在数字回忆任务中击败未训练的成年人（2007），但经过练习的人类在 2009 年达到了同等水平。

人类跨越物理、概念和社会空间。你的系统则在数字空间中导航，并且是与一个人一起导航。

### 中文释义

这一页把第 3 页的定义展开为多尺度例子。细胞、器官、动物、人和数字系统都可以被看作在不同空间中追求目标。关键不是谁“更高级”，而是谁在自己的空间里更擅长。对交互系统来说，系统导航的是数字空间，但它旁边总有用户，所以设计要看人机共同活动。

### English Explanation

The slide broadens intelligence across scales. Cells, organs, animals, humans, and digital systems each navigate different spaces. Intelligent interactive systems are important because their digital navigation happens alongside a person.

### 概念解析与拓展

- **Morphogenetic space / 形态发生空间**：生物体形成形状和结构的空间，例如肢体再生中细胞如何达到正确形态。
- **Physiological space / 生理空间**：器官维持内部状态和功能的空间，例如调节血糖、温度或组织修复。
- **Narrow intelligence / 狭窄智能**：在特定任务空间中表现很强，但不代表在所有空间都强。黑猩猩数字记忆例子体现这一点。

拓展：这页能帮助你避免“通用智能崇拜”。项目分析时可以写：系统能力必须放回具体空间和任务中评价，例如医疗分诊系统不是“像医生”，而是在症状、风险和流程空间中导航。

### 自测问题 / Self-check

**Q1 中文：** 蝾螈再生例子说明什么？

**中文答案：** 智能可被理解为在形态发生空间中朝正确身体形状导航，不一定涉及人类式思考。

**Q1 English:** What does the salamander example show?

**English answer:** It shows intelligence as navigation in morphogenetic space toward a correct bodily form, not necessarily human-like thought.

**Q2 中文：** 人的系统和数字系统的关系是什么？

**中文答案：** 人跨越物理、概念、社会空间；系统在数字空间中导航，并与人共同完成任务。

**Q2 English:** How do human and digital-system spaces relate?

**English answer:** Humans span physical, conceptual, and social spaces; systems navigate digital spaces alongside a person.


## 第 5 页：Two conversations, fifty-nine years apart

Source ID: `src-ba38b47b419c-pdf_page-00005`

![PDF page 5](../assets/pages/page_005.png)

### 原文 / Original Text

```text
Two conversations, fifty-nine years apart

Lecture 01 · Hook (Interaction 1)

Two typed conversations that look almost identical on 
screen, and could hardly differ more in what they can 
do to you.

1966: ELIZA answers a troubled user by turning their 
sentence back into a question. It understands nothing; it 
matches keywords.

2025: a coding assistant proposes a change, runs it, and 
offers to commit it to your repository.

The typed surface is the same. The consequences are not
— and that gap is what this lecture is about.
```

### 完整中文翻译

相隔五十九年的两段对话。

第 1 讲 - 引入（互动 1）。

两段打字对话在屏幕上看起来几乎完全相同，但它们能对你造成的影响却几乎完全不同。

1966 年：ELIZA 通过把一个困扰中的用户的话改写成问题来回应。它什么都不理解；它只是匹配关键词。

2025 年：一个编码助手提出修改，运行修改，并主动提出把它提交到你的代码仓库。

打字界面是一样的。后果却不是一样的。本讲课讨论的正是这个差距。

### 中文释义

这一页用 ELIZA 和现代 coding assistant 做强对比。两者都是文本交互，但能力和风险完全不同：ELIZA 只是语言表面改写；现代助手能修改、运行、提交代码。课件想让你意识到：不能只看界面形式，要看系统行为后果。

### English Explanation

The hook contrasts similar-looking typed interfaces with very different consequences. ELIZA only transforms text; a modern coding assistant can alter a repository. The lecture uses this gap to motivate interaction-focused analysis.

### 概念解析与拓展

- **ELIZA**：1966 年 Weizenbaum 的早期聊天程序，使用关键词匹配和模板改写，常被用来说明人会把流畅回应误读为理解。
- **Surface similarity / 表面相似性**：界面看起来相似不代表交互后果相似。文本框可以承载完全不同的系统能力。
- **Consequential action / 有后果的行动**：系统行为会改变外部状态，例如修改代码、提交仓库或触发真实流程。

拓展：交互分析中常犯错是“界面同形就风险同形”。实际设计要问：系统能否行动？行动范围多大？失败成本由谁承担？

### 自测问题 / Self-check

**Q1 中文：** ELIZA 和 2025 编码助手的关键差别是什么？

**中文答案：** ELIZA 只回复文本；编码助手可以提出、运行并提交代码修改，因此错误后果更大。

**Q1 English:** What is the key difference between ELIZA and a 2025 coding assistant?

**English answer:** ELIZA only replies with text; the coding assistant can propose, run, and commit code changes.

**Q2 中文：** 为什么屏幕上看起来相似仍然不够？

**中文答案：** 因为交互评价要看系统能力和后果，而不只是看输入输出形式。

**Q2 English:** Why is visual similarity on screen not enough?

**English answer:** Because interaction evaluation must consider system capability and consequences, not only input-output format.


## 第 6 页：What changed for the person, each time?

Source ID: `src-ba38b47b419c-pdf_page-00006`

![PDF page 6](../assets/pages/page_006.png)

### 原文 / Original Text

```text
What changed for the person, each time?

Lecture 01 · Central question

This module never asks how intelligent the machine 
is. It asks what the interaction did to the person.

'How intelligent is the machine?' is the wrong question here, 
because no design decision follows from the answer.

Ours is: who starts the turn, what does the system infer, 
what can the person see, and what can be undone?

Those four questions are a reading frame we reuse every 
week. Today we read five capability shifts through it.
```

### 完整中文翻译

每一次变化，对人来说改变了什么？

第 1 讲 - 中心问题。

本模块从不问机器有多智能。它问的是：这种互动对人产生了什么影响。

“机器有多智能？”在这里是错误的问题，因为这个问题的答案不会直接带来任何设计决策。

我们的问题是：谁开启这一轮互动？系统推断了什么？人能看见什么？什么可以被撤销？

这四个问题是我们每周都会重复使用的阅读框架。今天我们会用它来阅读五次能力迁移。

### 中文释义

这一页是整门课的工具页。四个问题分别对应 initiative、inference、visibility、reversibility。它们把抽象的“智能程度”变成可以设计、评估和批判的交互变量。之后每个系统都可以用这四项打分。

### English Explanation

This slide establishes the recurring analytic frame. Instead of asking for a machine intelligence score, the module asks how initiative, inference, visibility, and reversibility shape the user's position.

### 概念解析与拓展

- **Initiative / 主动权**：谁先发起下一步互动，是人要求系统做事，还是系统主动打断、建议、补全或行动。
- **Inference / 推断**：系统从用户输入、环境、历史或他人行为中得出什么额外结论。
- **Visibility / 可见性**：用户能看见多少系统状态、理由、证据或置信度。
- **Reversibility / 可撤销性**：系统造成的结果能否撤销，以及撤销成本有多高。

拓展：这四个变量可直接用于论文阅读、项目选题和实验分析。写作时可以把它们当作统一小标题，比较不同智能系统。

### 自测问题 / Self-check

**Q1 中文：** 本模块为什么不以“机器有多智能”为中心？

**中文答案：** 因为它不能直接推出设计决策；设计更需要知道互动如何影响人的行动、理解和控制。

**Q1 English:** Why does the module avoid centering 'how intelligent is the machine?'

**English answer:** Because that answer does not directly imply design decisions; design needs to know how interaction affects people.

**Q2 中文：** 四个阅读变量是什么？

**中文答案：** 主动权、推断、可见性、可撤销性。

**Q2 English:** What are the four reading variables?

**English answer:** Initiative, inference, visibility, and reversibility.


## 第 7 页：The idea most of us arrive with

Source ID: `src-ba38b47b419c-pdf_page-00007`

![PDF page 7](../assets/pages/page_007.png)

### 原文 / Original Text

```text
The idea most of us arrive with

Lecture 01 · Why history

Most people picture AI as a chat box — but almost 
none of the intelligence you used today had one.

The mental image is a box that answers questions, 
because that is the form that became famous in 2022.

In practice you met suggestions, reroutes, rankings, scene 
detection, hand tracking and text completion, none of 
which involve a conversation.

History widens the picture before we define anything, so 
our definition is not accidentally a definition of chatbots.
```

### 完整中文翻译

我们大多数人带来的想法。

第 1 讲 - 为什么要讲历史。

大多数人把 AI 想象成一个聊天框，但你今天使用过的智能功能几乎都没有聊天框。

这种心理图像是一个会回答问题的方框，因为这种形式在 2022 年变得非常有名。

实际上，你遇到的是建议、路线重规划、排序、场景检测、手部追踪和文本补全，它们都不涉及一段对话。

历史会在我们定义任何东西之前拓宽图像，这样我们的定义才不会不小心变成聊天机器人的定义。

### 中文释义

这一页解释为什么课程从历史开始：如果只从 ChatGPT 的聊天界面出发，我们会把 AI 误定义为“会聊天的盒子”。但智能交互已经存在于键盘建议、地图、搜索排序、视觉识别、手势输入等大量非聊天场景中。

### English Explanation

The slide warns against equating AI with chat. Many intelligent systems are embedded in suggestions, rankings, perception, and prediction. History prevents the definition of AI interaction from collapsing into chatbot interaction.

### 概念解析与拓展

- **Chat box bias / 聊天框偏见**：把 AI 误认为主要是问答聊天，从而忽视嵌入式、预测式、感知式智能。
- **Embedded intelligence / 嵌入式智能**：智能功能嵌入在普通界面流程中，不一定以对话形式出现。
- **Text completion / 文本补全**：系统根据上下文预测接下来可能输入的文本，是常见的非聊天智能交互。

拓展：项目选题不要局限于 chatbot。推荐、搜索、自动字幕、相机识别、智能家居、医疗分诊、代码补全都可以是 IIS 主题。

### 自测问题 / Self-check

**Q1 中文：** 为什么聊天框不是 AI 交互的全部？

**中文答案：** 因为很多智能功能以建议、排序、检测、追踪和补全的形式出现，不需要对话界面。

**Q1 English:** Why is a chat box not the whole of AI interaction?

**English answer:** Because many intelligent functions appear as suggestions, rankings, detection, tracking, and completion without dialogue.

**Q2 中文：** 历史在这里有什么作用？

**中文答案：** 历史拓宽定义，避免把 AI 交互误定义成聊天机器人交互。

**Q2 English:** What is the role of history here?

**English answer:** History widens the definition so AI interaction is not accidentally defined as chatbot interaction.


## 第 8 页：Five capability shifts, 1950 to today

Source ID: `src-ba38b47b419c-pdf_page-00008`

![PDF page 8](../assets/pages/page_008.png)

### 原文 / Original Text

```text
Five capability shifts, 1950 to today

Lecture 01 · Timeline

Five moments where a new capability arrived and the interaction changed shape with it.

Each shift added a capability to the machine and moved something in the interaction; the boundaries between them are interpretive, not facts.

As we go, read the last line of each band: it says what changed for the person, not what changed in the technology.
```

### 完整中文翻译

从 1950 年到今天的五次能力迁移。

第 1 讲 - 时间线。

有五个时刻，一种新能力出现，并且互动形态也随之改变。

每一次迁移都给机器增加了一种能力，并移动了互动中的某些东西；这些迁移之间的边界是解释性的，而不是事实本身。

接下来阅读时，请看每一条带状区域的最后一行：它说的是对人来说改变了什么，而不是技术本身改变了什么。

### 中文释义

这一页预告后面五个 shift。重要的是边界是 interpretive：不是自然界固定分期，而是为了帮助我们看清交互变化而做的解释框架。读每一段技术史时，都要把注意力放回“对用户改变了什么”。

### English Explanation

The timeline is an interpretive structure rather than a fixed historical taxonomy. Each shift adds machine capability and changes the user's interactional position.

### 概念解析与拓展

- **Capability shift / 能力迁移**：机器获得新能力后，互动结构发生变化的历史节点。
- **Interpretive boundary / 解释性边界**：分期边界是为了分析而划定，不是客观世界中绝对存在的线。
- **User-centered historical reading / 以用户为中心的历史阅读**：读技术史时关注技术让人能做什么、看见什么、撤销什么。

拓展：论文写作中可以借用这种方式：不要只列技术发展，而要解释每个发展如何改变用户任务、责任、风险或信任。

### 自测问题 / Self-check

**Q1 中文：** 五次迁移的边界为什么不是事实本身？

**中文答案：** 因为它们是为分析交互变化而划分的解释性框架。

**Q1 English:** Why are the boundaries between shifts not facts themselves?

**English answer:** They are interpretive boundaries used to analyze interactional change.

**Q2 中文：** 阅读每次迁移时应看什么？

**中文答案：** 看它对人改变了什么，而不只是看技术新增了什么。

**Q2 English:** What should we read for in each shift?

**English answer:** What changed for the person, not only what changed in the technology.


## 第 9 页：Shift 1: symbolic rules and ELIZA (1966)

Source ID: `src-ba38b47b419c-pdf_page-00009`

![PDF page 9](../assets/pages/page_009.png)

### 原文 / Original Text

```text
Shift 1: symbolic rules and ELIZA (1966)

Lecture 01 · Shift 1

The first shift gave the machine a turn in the 
conversation — and nothing else.

ELIZA works by keyword spotting, decomposition and 
reassembly rules: it finds a pattern in your sentence and 
rebuilds it as a question.

The machine takes a turn, but the person supplies all the 
meaning. Nothing is inferred about the world, only about the 
shape of the sentence.

In frame terms: initiative moved a little; inference and 
visibility barely moved at all.
```

### 完整中文翻译

迁移 1：符号规则与 ELIZA（1966）。

第 1 讲 - 迁移 1。

第一次迁移让机器在对话中获得了发言轮次，仅此而已。

ELIZA 的工作方式是关键词发现、分解和重组规则：它在你的句子中找到一个模式，然后把它重新构造成一个问题。

机器获得了一个回合，但所有意义都由人来提供。它并没有推断世界，只是推断了句子的形状。

用本课框架来说：主动权稍微移动了一点；推断和可见性几乎没有移动。

### 中文释义

ELIZA 是早期聊天式互动的代表，但它的“智能”很浅。它会接话，但不理解语义、世界或用户处境。它体现的是交互形式上的第一步：机器可以轮到自己说话了。

### English Explanation

ELIZA gave the machine a conversational turn without substantive understanding. Its rules transformed sentence patterns, so initiative moved slightly while inference and visibility remained minimal.

### 概念解析与拓展

- **Symbolic rules / 符号规则**：用明确规则和模式来处理输入，而不是从数据中学习隐含表示。
- **Keyword spotting / 关键词发现**：在输入中寻找触发词，用它选择回应模板。
- **Decomposition and reassembly / 分解与重组**：把用户句子拆成部分，再按模板重组为系统回应。

拓展：ELIZA 对今天的启发不是“早期 AI 很弱”，而是“很弱的机制也能制造强交互错觉”。这直接连到第 21 页的 ELIZA effect。

### 自测问题 / Self-check

**Q1 中文：** ELIZA 实际推断了什么？

**中文答案：** 它只推断句子形状和关键词模式，没有推断真实世界或用户心理。

**Q1 English:** What did ELIZA actually infer?

**English answer:** It inferred sentence shape and keyword patterns, not the world or the user's mind.

**Q2 中文：** 四变量中哪一项稍微移动了？

**中文答案：** 主动权稍微移动，因为机器获得了对话回合。

**Q2 English:** Which variable moved slightly?

**English answer:** Initiative moved slightly because the machine gained a conversational turn.


## 第 10 页：Shift 2: direct manipulation and the GUI

Source ID: `src-ba38b47b419c-pdf_page-00010`

![PDF page 10](../assets/pages/page_010.png)

### 原文 / Original Text

```text
Shift 2: direct manipulation and the GUI

Lecture 01 · Shift 2

The second shift made the system's state visible and 
its actions reversible — and both were deliberate 
design choices.

Sketchpad (1963) and Sutherland's Ultimate Display (1965)
imagined it; the Alto (1973), Star (1981), Lisa (1983) and 
Macintosh (1984) delivered it.

Shneiderman named the principle in 1983 as Direct 
Manipulation: continuous representation, physical actions 
rather than commands, and reversible operations.

This is the one shift where visibility and reversibility were 
designed in on purpose. Notice that it never happens again 
by accident.

Xerox Star (1981)

Xerox Alto (1973)

Photos: Alto and Star, source and licence to be confirmed; Lisa, © Auction Team Breker.

Apple Lisa (1983)
```

### 完整中文翻译

迁移 2：直接操控与图形用户界面。

第 1 讲 - 迁移 2。

第二次迁移让系统状态变得可见，并让系统行动变得可撤销，而且这两者都是有意的设计选择。

Sketchpad（1963）和 Sutherland 的 Ultimate Display（1965）想象了这种未来；Alto（1973）、Star（1981）、Lisa（1983）和 Macintosh（1984）把它实现了出来。

Shneiderman 在 1983 年把这一原则命名为 Direct Manipulation，即直接操控：连续的表示、用物理动作而不是命令来操作，以及可撤销的操作。

这是唯一一次可见性和可撤销性被有意设计进去的迁移。请注意，它之后再也不会自动发生。

Xerox Star（1981）。

Xerox Alto（1973）。

照片：Alto 和 Star 的来源及许可待确认；Lisa，© Auction Team Breker。

Apple Lisa（1983）。

### 中文释义

GUI 和直接操控是本讲中最“设计导向”的迁移。系统状态通过图形界面持续显示，用户通过鼠标、拖拽、选择等动作直接操作对象，并且能撤销。这一页强调：可见性和可撤销性不是技术进步自然带来的，而是设计者主动加入的。

### English Explanation

Direct manipulation and the GUI made system state visible and actions reversible by design. This is the lecture's key counterexample to the idea that technological progress automatically improves interaction control.

### 概念解析与拓展

- **Direct Manipulation / 直接操控**：Shneiderman 提出的交互原则：对象持续可见，用户通过物理化动作操作对象，操作可以撤销。
- **Continuous representation / 连续表示**：系统对象和状态持续显示，用户无需记住隐藏命令或内部状态。
- **Reversible operations / 可撤销操作**：用户可以恢复先前状态，降低探索和错误成本。
- **GUI / 图形用户界面**：通过窗口、图标、菜单、指针等视觉对象组织交互。

拓展：今天设计 AI 系统时，要把 GUI 的教训带回来：即使模型很复杂，也应尽量显示状态、来源、置信度、操作范围和撤销路径。

### 自测问题 / Self-check

**Q1 中文：** 直接操控的三个特征是什么？

**中文答案：** 连续表示、用物理动作替代命令、可撤销操作。

**Q1 English:** What are the three features of direct manipulation?

**English answer:** Continuous representation, physical actions rather than commands, and reversible operations.

**Q2 中文：** 为什么 GUI 迁移很特殊？

**中文答案：** 因为可见性和可撤销性在这里被有意设计进去，之后的智能迁移没有自动保持它们。

**Q2 English:** Why is the GUI shift special?

**English answer:** Visibility and reversibility were deliberately designed in, and later intelligent shifts did not automatically preserve them.


## 第 11 页：Shift 3: learning and recommendation

Source ID: `src-ba38b47b419c-pdf_page-00011`

![PDF page 11](../assets/pages/page_011.png)

### 原文 / Original Text

```text
Shift 3: learning and recommendation

Lecture 01 · Shift 3

The third shift let systems infer what you want from 
what other people did — and the reasoning left the 
screen.

GroupLens (Resnick et al., 1994) predicted what you would 
like from people who rated things the way you do: 
Collaborative Filtering.

Amazon's item-to-item filtering (Linden et al., 2003) scaled 
that to millions of items and made it ordinary.

The system now infers preferences you never stated. 
Initiative moved towards the system, and visibility went 
down.
```

### 完整中文翻译

迁移 3：学习与推荐。

第 1 讲 - 迁移 3。

第三次迁移让系统能从其他人的行为中推断你想要什么，而且这种推理离开了屏幕。

GroupLens（Resnick 等，1994）根据与你评分方式相似的人来预测你会喜欢什么：这就是协同过滤。

Amazon 的 item-to-item filtering，也就是物品到物品过滤（Linden 等，2003），把它扩展到数百万件商品，并让它变得日常化。

现在系统会推断你从未明确说出的偏好。主动权向系统移动，可见性下降。

### 中文释义

推荐系统改变了互动：用户不一定先问，系统会根据数据主动排序和建议。它能推断偏好，但理由通常不可见。你看到的是推荐结果，不一定看到模型如何利用相似用户、历史行为或物品关系。

### English Explanation

Learning and recommendation systems infer preferences from patterns in data. They increase system initiative and inference while making reasoning less visible to the user.

### 概念解析与拓展

- **Collaborative Filtering / 协同过滤**：根据相似用户或相似物品的行为来预测用户偏好。
- **Item-to-item filtering / 物品到物品过滤**：Amazon 推广的推荐方法，基于物品之间的相似关系进行大规模推荐。
- **Preference inference / 偏好推断**：系统从行为数据中推测用户可能喜欢什么，即使用户没有明说。

拓展：推荐系统的设计难题包括解释性、过滤泡泡、公平性、用户自主性和反馈循环。IIS 角度特别关心：用户是否知道自己为什么看到这些内容。

### 自测问题 / Self-check

**Q1 中文：** 推荐系统让哪两个变量上升或移动？

**中文答案：** 推断增强，主动权向系统移动。

**Q1 English:** Which variables increase or move in recommendation systems?

**English answer:** Inference increases and initiative moves toward the system.

**Q2 中文：** 为什么可见性下降？

**中文答案：** 因为用户通常只能看到推荐结果，而看不到背后的相似用户、物品关系和权重。

**Q2 English:** Why does visibility go down?

**English answer:** Users usually see the recommendation output, not the evidence, similar users, item relations, or weights behind it.


## 第 12 页：Shift 4: deep learning and perception

Source ID: `src-ba38b47b419c-pdf_page-00012`

![PDF page 12](../assets/pages/page_012.png)

### 原文 / Original Text

```text
Shift 4: deep learning and perception

Lecture 01 · Shift 4

The fourth shift let inference reach past the keyboard 
and into the world.

In 2012 Krizhevsky, Sutskever and Hinton showed learned 
features beat hand-built ones on ImageNet: 15.3% top-5 
error against 26.2%.

Within a few years speech, faces, scenes and gestures 
became usable inputs to ordinary interfaces.

The consequence for interaction: the system now infers 
things about the world, not only about what you typed.
```

### 完整中文翻译

迁移 4：深度学习与感知。

第 1 讲 - 迁移 4。

第四次迁移让推断越过键盘，进入世界。

2012 年，Krizhevsky、Sutskever 和 Hinton 证明，在 ImageNet 上，学习得到的特征胜过人工构造的特征：top-5 错误率为 15.3%，而对照为 26.2%。

几年之内，语音、人脸、场景和手势都变成了普通界面可用的输入。

对交互的后果是：系统现在会推断关于世界的事情，而不仅仅是推断你输入了什么。

### 中文释义

深度学习把交互输入从键盘和鼠标扩展到真实世界信号。系统不只处理文本，而是识别声音、脸、图像场景和身体动作。它让界面能感知世界，但也让误识别、隐私和不可见推断变得重要。

### English Explanation

Deep learning expanded inference into perception. Interfaces began using speech, faces, scenes, and gestures as inputs, so systems inferred properties of the world rather than only text or clicks.

### 概念解析与拓展

- **Deep learning / 深度学习**：通过多层模型从数据中学习特征表示，减少对人工特征工程的依赖。
- **ImageNet**：大型图像识别数据集和竞赛，2012 年 AlexNet 的表现成为深度学习视觉突破的标志。
- **Top-5 error / 前五错误率**：正确标签不在模型前五个预测中的比例，是图像分类常用指标。
- **Perception as input / 感知作为输入**：语音、图像、人脸、场景、手势等成为交互输入。

拓展：感知型界面常见设计问题：误识别如何纠正？用户是否知道自己被识别了什么？系统是否显示置信度？数据采集是否被用户理解和同意？

### 自测问题 / Self-check

**Q1 中文：** 2012 年 ImageNet 例子说明了什么？

**中文答案：** 学习得到的特征在视觉识别中胜过人工构造特征，推动感知能力进入普通界面。

**Q1 English:** What does the 2012 ImageNet example show?

**English answer:** Learned features outperformed hand-built features in vision, helping perception enter ordinary interfaces.

**Q2 中文：** 这次迁移对交互的后果是什么？

**中文答案：** 系统开始推断世界中的语音、人脸、场景和手势，而不只是用户输入的文字。

**Q2 English:** What was the interactional consequence?

**English answer:** Systems began inferring speech, faces, scenes, and gestures in the world, not only typed text.


## 第 13 页：Shift 5: large language models and agents

Source ID: `src-ba38b47b419c-pdf_page-00013`

![PDF page 13](../assets/pages/page_013.png)

### 原文 / Original Text

```text
Shift 5: large language models and agents

Lecture 01 · Shift 5

The fifth shift made systems fluent in any typed task 
— and then let them act, which is where reversibility 
broke.

Transformers (Vaswani et al., 2017) and GPT-3 (Brown et 
al., 2020) led to Copilot and ChatGPT in 2022.

They also generalise: a few examples in the prompt are 
enough for a new task (Brown et al., 2020).

Put them in agentic loops with tools and they act rather 
than only answer — and reversing a real action is now 
the open design problem.
```

### 完整中文翻译

迁移 5：大型语言模型与智能体。

第 1 讲 - 迁移 5。

第五次迁移让系统能流畅处理任何打字任务，随后又让它们可以行动，而这正是可撤销性崩坏的地方。

Transformers（Vaswani 等，2017）和 GPT-3（Brown 等，2020）引向了 2022 年的 Copilot 和 ChatGPT。

它们还具有泛化能力：提示词中的几个例子就足以让系统执行一项新任务（Brown 等，2020）。

把它们放进带工具的智能体循环中，它们就不再只是回答，而是会行动。此时，撤销一个真实行动就成了开放的设计问题。

### 中文释义

LLM 迁移有两层：先是语言流畅和跨任务泛化，再是工具使用和 agentic loops 带来的真实行动。风险也随之升级：文本错了可以改，但系统如果发邮件、改代码、下单、删文件，可撤销性就复杂得多。

### English Explanation

LLMs add fluent general-purpose typed interaction, and agents add tool-mediated action. The design challenge is no longer only answer quality; it is how to make real actions visible, controllable, and reversible.

### 概念解析与拓展

- **Transformer**：2017 年提出的神经网络架构，使用 attention 机制，成为现代 LLM 的核心基础。
- **Few-shot prompting / 少样本提示**：在提示词中给少量示例，模型就能迁移到新任务。
- **Agentic loop / 智能体循环**：模型观察状态、计划、调用工具、检查结果并继续行动的循环。
- **Tool use / 工具使用**：模型通过外部工具读写文件、运行代码、浏览网页或操作应用。

拓展：设计 agent 时常用防线包括权限分级、预览、确认、日志、沙盒、回滚、速率限制和人类批准。它们本质上都在重建可见性和可撤销性。

### 自测问题 / Self-check

**Q1 中文：** 为什么 LLM 加工具会让可撤销性变成开放问题？

**中文答案：** 因为系统不只是生成文本，还可能改变外部世界或用户资产，撤销成本不再固定。

**Q1 English:** Why do LLMs with tools make reversibility an open problem?

**English answer:** Because they may change external state or user assets, so undo costs are no longer simple or fixed.

**Q2 中文：** Few-shot prompting 是什么？

**中文答案：** 在提示中给几个示例，让模型在没有专门训练的情况下执行新任务。

**Q2 English:** What is few-shot prompting?

**English answer:** Giving a few examples in the prompt so the model can perform a new task without task-specific training.


## 第 14 页：The reading frame: four interaction variables

Source ID: `src-ba38b47b419c-pdf_page-00014`

![PDF page 14](../assets/pages/page_014.png)

### 原文 / Original Text

```text
The reading frame: four interaction variables

Lecture 01 · The frame

Four questions you can ask of any intelligent system, 
and will ask of your own project.

Initiative — who starts the turn, the person or the system?  
Inference — what does the system conclude beyond your 
words or clicks?

Visibility — how much of the system's state and reasoning 
can the person actually see?

Reversibility — can a consequence be undone, and how 
easily?
```

### 完整中文翻译

阅读框架：四个交互变量。

第 1 讲 - 框架。

你可以对任何智能系统提出四个问题，也会对自己的项目提出这四个问题。

主动权：谁开启这一轮互动，是人还是系统？

推断：系统在你的文字或点击之外得出了什么结论？

可见性：人实际能看见多少系统状态和推理？

可撤销性：后果能否被撤销？撤销有多容易？

### 中文释义

这一页是可背诵页。四个变量可以作为评估任何 IIS 的统一框架。注意每个变量都不是纯技术指标，而是人与系统之间的关系指标。

### English Explanation

This is the portable evaluation frame for the module. Each variable describes the user's relation to the system, not merely a technical property of the system.

### 概念解析与拓展

- **Turn / 互动轮次**：一次系统或用户发起并推进任务的行动单位。
- **System state / 系统状态**：系统当前知道、判断、准备做或已经做了什么。
- **Reasoning visibility / 推理可见性**：用户能否看到系统为什么得出某个建议或行动。
- **Undo cost / 撤销成本**：恢复原状所需时间、努力、风险和是否完全可恢复。

拓展：写项目 proposal 时可以把研究问题改写成：我的系统在哪些变量上改变了用户体验？我如何测量这种改变？

### 自测问题 / Self-check

**Q1 中文：** 可见性问的是什么？

**中文答案：** 人能看见多少系统状态和推理。

**Q1 English:** What does visibility ask?

**English answer:** How much of the system's state and reasoning the person can actually see.

**Q2 中文：** 可撤销性只问有没有 undo 按钮吗？

**中文答案：** 不是，还要问后果是否真的能恢复，以及撤销成本有多高。

**Q2 English:** Is reversibility only about having an undo button?

**English answer:** No. It asks whether the consequence can really be undone and how costly undoing is.


## 第 15 页：Five shifts scored on four variables

Source ID: `src-ba38b47b419c-pdf_page-00015`

![PDF page 15](../assets/pages/page_015.png)

### 原文 / Original Text

```text
Five shifts scored on four variables

Lecture 01 · The pattern

Initiative and inference moved to the system; visibility and 
reversibility peaked with the GUI and have fallen since.

Systems started more turns and inferred more at each 
shift — except under direct manipulation, where the 
person held the initiative.

Visibility and reversibility peaked with the GUI, where 
they were designed in, and fell at each later shift.

The distance between what a system can do and what 
a person can see or undo is the design problem we 
keep returning to.
```

### 完整中文翻译

用四个变量给五次迁移评分。

第 1 讲 - 模式。

主动权和推断转移到了系统；可见性和可撤销性在 GUI 时达到顶峰，之后一直下降。

每次迁移中，系统开启更多互动并推断更多事情。直接操控是例外，在那里主动权仍由人掌握。

可见性和可撤销性在 GUI 时达到顶峰，因为它们被设计了进去，而在之后每一次迁移中都下降。

系统能够做什么，与人能够看见或撤销什么之间的距离，就是我们会不断回到的设计问题。

### 中文释义

这一页给出全讲主线：能力越强，不代表交互越好。推荐、感知、LLM 和 agent 都让系统更主动、更会推断，但同时常常让用户更难看见理由、更难撤销后果。设计任务就是缩短能力与可控性之间的距离。

### English Explanation

The central pattern is that initiative and inference move toward systems while visibility and reversibility decline after the GUI. The design problem is the gap between system capability and user observability/control.

### 概念解析与拓展

- **Capability-control gap / 能力-控制差距**：系统能做的事情越来越多，但用户能看见、理解和撤销的部分没有同步增长。
- **Peak visibility/reversibility / 可见性与可撤销性峰值**：GUI 时代因设计选择达到高点，之后的智能系统未自然继承。

拓展：这页可以作为论文论证句：AI interaction design is not just about increasing capability; it is about restoring visibility and reversibility as capability rises.

### 自测问题 / Self-check

**Q1 中文：** 本页总结的总体模式是什么？

**中文答案：** 主动权和推断向系统移动；可见性和可撤销性在 GUI 达峰后下降。

**Q1 English:** What is the overall pattern?

**English answer:** Initiative and inference move toward the system; visibility and reversibility peak with the GUI and then decline.

**Q2 中文：** 核心设计问题是什么？

**中文答案：** 系统能做什么与用户能看见或撤销什么之间的距离。

**Q2 English:** What is the core design problem?

**English answer:** The distance between what the system can do and what the person can see or undo.


## 第 16 页：1) the predictive keyboard

Source ID: `src-ba38b47b419c-pdf_page-00016`

![PDF page 16](../assets/pages/page_016.png)

### 原文 / Original Text

```text
1) the predictive keyboard

Lecture 01 · Three systems

An intelligent system most of you used before 
breakfast, with no chat box anywhere.

Initiative: the system proposes a word before you have 
finished typing it.

Inference: your next word, predicted from general language 
patterns and your own typing history.

Visibility and reversibility: you see three candidates and 
no reasons, and correcting takes one tap — unless 
autocorrect already acted.
```

### 完整中文翻译

1）预测键盘。

第 1 讲 - 三个系统。

这是一个你们大多数人在早饭前就用过的智能系统，而且完全没有聊天框。

主动权：系统在你还没有打完之前就提出一个词。

推断：它根据一般语言模式和你自己的输入历史预测你的下一个词。

可见性和可撤销性：你看见三个候选词，但看不见理由；纠正只需要点一下，除非自动更正已经执行了操作。

### 中文释义

预测键盘是低风险、日常化的智能交互例子。它主动建议、根据模式推断、只显示候选不显示理由。可撤销性通常还不错，但 autocorrect 一旦替你行动，就可能产生误发、误写等小型后果。

### English Explanation

The predictive keyboard shows intelligent interaction without chat. The system initiates suggestions and infers likely words, while giving limited visibility and usually low-cost reversibility.

### 概念解析与拓展

- **Predictive keyboard / 预测键盘**：根据上下文和用户历史预测下一个词或短语。
- **Autocorrect / 自动更正**：系统不只建议，而是直接替换文本，主动权和后果都更强。
- **Candidate visibility / 候选可见性**：用户看到若干结果，但看不到模型理由或证据。

拓展：同一个系统里“建议”和“自动执行”差别很大。设计上，suggestion 通常比 automatic action 更容易撤销、更少打断用户。

### 自测问题 / Self-check

**Q1 中文：** 预测键盘的主动权体现在哪里？

**中文答案：** 它在用户未完成输入前主动提出候选词。

**Q1 English:** Where is initiative in a predictive keyboard?

**English answer:** It proposes candidate words before the user has finished typing.

**Q2 中文：** 为什么 autocorrect 比候选词风险更高？

**中文答案：** 因为它已经替用户执行替换，用户可能在注意到之前把错误发出去。

**Q2 English:** Why is autocorrect riskier than word candidates?

**English answer:** It has already acted on the user's text, so the user may send the wrong replacement before noticing.


## 第 17 页：2) navigation that reroutes

Source ID: `src-ba38b47b419c-pdf_page-00017`

![PDF page 17](../assets/pages/page_017.png)

### 原文 / Original Text

```text
2) navigation that reroutes

Lecture 01 · Three systems

Here the system interrupts you mid-task, using 
evidence you cannot inspect.

Initiative: the map interrupts your journey to offer a faster 
route.

Inference: congestion ahead, estimated from the 
movement of many other phones.

Visibility and reversibility: you are shown a time saving, 
not the evidence behind it, and you have seconds to accept 
or dismiss.
```

### 完整中文翻译

2）会重新规划路线的导航。

第 1 讲 - 三个系统。

在这里，系统会在任务中途打断你，并使用你无法检查的证据。

主动权：地图打断你的行程，提供一条更快路线。

推断：前方拥堵，这个判断来自许多其他手机的移动情况估计。

可见性和可撤销性：你看到的是节省时间，而不是背后的证据，而且你只有几秒钟决定接受还是忽略。

### 中文释义

地图重规划比预测键盘更强，因为它在你执行任务时打断并改变计划。它的推断基于群体移动数据，用户通常看不到证据。设计难点是：在驾驶压力下如何让用户迅速但合理地信任或拒绝建议。

### English Explanation

Rerouting navigation interrupts an ongoing task based on hidden evidence. It increases system initiative and inference while compressing the user's time to inspect and decide.

### 概念解析与拓展

- **Rerouting / 路线重规划**：系统根据新的交通信息改变建议路径。
- **Interruptive initiative / 打断式主动权**：系统在用户任务进行中主动介入。
- **Evidence opacity / 证据不透明**：系统显示结论或收益，但不显示足够证据让用户判断。

拓展：地图类系统可以通过显示拥堵来源、时间估计不确定性、路线差异和撤回方式来增强可见性与可控性。

### 自测问题 / Self-check

**Q1 中文：** 导航重规划用什么证据推断拥堵？

**中文答案：** 许多其他手机的移动情况。

**Q1 English:** What evidence is used to infer congestion?

**English answer:** The movement of many other phones.

**Q2 中文：** 用户看到什么，又看不到什么？

**中文答案：** 看到节省时间，看不到背后证据的细节。

**Q2 English:** What does the user see and not see?

**English answer:** They see a time saving, not the detailed evidence behind it.


## 第 18 页：3) a coding copilot

Source ID: `src-ba38b47b419c-pdf_page-00018`

![PDF page 18](../assets/pages/page_018.png)

### 原文 / Original Text

```text
3) a coding copilot

Lecture 01 · Three systems

The same pattern again, but now the consequences 
land in your own work.

Initiative: ghost text appears as you type, unasked.

Inference: what it thinks you meant, read from your code, 
your comments and your naming.

Visibility and reversibility: the suggestion is shown but the 
reasoning is not, and once you press Tab the edits are 
yours.
```

### 完整中文翻译

3）一个编码副驾驶。

第 1 讲 - 三个系统。

同样的模式再次出现，但这一次后果落在你自己的工作中。

主动权：你打字时，幽灵文本会在没有请求的情况下出现。

推断：它从你的代码、注释和命名中读取它认为你想表达的意思。

可见性和可撤销性：建议会显示出来，但推理不会显示；一旦你按下 Tab，这些编辑就是你的了。

### 中文释义

编码 Copilot 是本讲与学生项目最相关的例子。系统主动提供 ghost text，从局部上下文推断意图。用户能看到代码建议，但看不到推断过程、训练来源或风险。接受后，责任和后果转移到用户代码库中。

### English Explanation

A coding copilot repeats the same pattern in a higher-stakes work context. It displays suggestions but hides reasoning, and accepted edits become the user's responsibility.

### 概念解析与拓展

- **Ghost text / 幽灵文本**：编辑器中半透明或灰色显示的预测补全，等待用户接受。
- **Intent inference / 意图推断**：系统根据代码、注释、命名和上下文猜测用户想做什么。
- **Ownership transfer / 责任转移**：用户接受建议后，代码成为用户工作的一部分，错误也由用户承担。

拓展：评估 Copilot 不只看节省时间，还要看错误检测、可解释性、测试覆盖、许可证风险和用户是否过度依赖。

### 自测问题 / Self-check

**Q1 中文：** Copilot 从哪些线索推断用户意图？

**中文答案：** 代码、注释和命名。

**Q1 English:** What clues does a copilot use to infer intent?

**English answer:** Code, comments, and naming.

**Q2 中文：** 为什么按 Tab 后风险改变？

**中文答案：** 因为建议变成实际编辑，进入用户自己的工作成果和责任范围。

**Q2 English:** Why does risk change after pressing Tab?

**English answer:** The suggestion becomes an actual edit within the user's work and responsibility.


## 第 19 页：Your turn: score the automatic captions

Source ID: `src-ba38b47b419c-pdf_page-00019`

![PDF page 19](../assets/pages/page_019.png)

### 原文 / Original Text

```text
Your turn: score the automatic captions

Lecture 01 · Interaction 2

Lecture capture is writing captions while I speak. 
Score it.

Score all four variables — initiative, inference, visibility 
and reversibility — from low to high.

Then name one thing you would need to be able to see in 
order to trust it.

Two minutes, then three answers from the room.
```

### 完整中文翻译

轮到你：给自动字幕评分。

第 1 讲 - 互动 2。

课堂录制正在我讲话时写出字幕。请给它评分。

对四个变量都评分：主动权、推断、可见性和可撤销性，从低到高。

然后说出一件你需要能够看见的东西，才能信任它。

两分钟，然后听取课堂上的三个答案。

### 中文释义

这是课堂练习页。自动字幕是感知型智能系统：它从语音推断文本，通常主动生成结果。你要用四变量分析它，而不是只说“准不准”。信任需要可见证据，例如置信度、可回放音频、时间戳、谁说话、可编辑记录等。

### English Explanation

This activity applies the four-variable frame to automatic captions. It asks students to score the system and identify what evidence would make the output trustworthy.

### 概念解析与拓展

- **Automatic captions / 自动字幕**：系统把语音实时或近实时转写成文字。
- **Trust evidence / 信任证据**：用户判断是否相信系统输出所需的信息，如置信度、原音频、时间戳或可编辑性。
- **Scoring frame / 评分框架**：用同一组变量比较不同系统，而不是只凭直觉评价。

拓展：自动字幕的设计可以加入低置信高亮、可回放片段、说话人分离、术语词典和人工修订流程，以提升可见性和可撤销性。

### 自测问题 / Self-check

**Q1 中文：** 自动字幕应从哪四个变量评分？

**中文答案：** 主动权、推断、可见性和可撤销性。

**Q1 English:** Which four variables should automatic captions be scored on?

**English answer:** Initiative, inference, visibility, and reversibility.

**Q2 中文：** 举一个你需要看见才会信任字幕的东西。

**中文答案：** 例如置信度、对应音频片段、时间戳或可编辑修订历史。

**Q2 English:** Name one thing you might need to see to trust captions.

**English answer:** For example confidence, the matching audio segment, timestamps, or editable revision history.


## 第 20 页：ELIZA and a copilot, side by side

Source ID: `src-ba38b47b419c-pdf_page-00020`

![PDF page 20](../assets/pages/page_020.png)

### 原文 / Original Text

```text
ELIZA and a copilot, side by side

Lecture 01 · Worked example

Two systems that take typed turns, separated by what 
happens when they are wrong.

Both exchange turns in typed language, and on screen 
they look alike.

But one infers the shape of a sentence; the other infers a 
plan — and then carries it out.

ELIZA can only reply. A copilot can edit, run and commit.
One mistake costs a strange question; the other can cost a 
codebase.
```

### 完整中文翻译

ELIZA 与副驾驶并排比较。

第 1 讲 - worked example。

两个系统都会进行打字轮次，但它们的差别在于出错时会发生什么。

两者都以打字语言交换轮次，在屏幕上看起来相似。

但一个推断句子的形状；另一个推断计划，并随后把计划执行出来。

ELIZA 只能回复。副驾驶可以编辑、运行和提交。一个错误只会造成一个奇怪的问题；另一个错误可能让一个代码库付出代价。

### 中文释义

这页把第 5 页的对比讲透：同样是 typed turns，系统推断对象和行动能力完全不同。ELIZA 错了只是回答怪；Copilot 错了可能改变代码库。出错成本是评价智能交互的重要维度。

### English Explanation

The worked example highlights the cost of error. Similar typed turns hide different inference targets and action scopes: sentence shape versus plan execution.

### 概念解析与拓展

- **Inference target / 推断对象**：系统到底在推断什么：句法模式、用户偏好、世界状态、任务计划等。
- **Action scope / 行动范围**：系统能影响的外部范围，例如只回复文本，或能编辑和提交代码。
- **Error cost / 错误成本**：系统判断错误后造成的损失、修复难度和责任影响。

拓展：设计评估时可以把系统按 action scope 分层：只显示、建议但不执行、执行可撤销操作、执行难撤销操作。层级越高，越需要可见性和确认机制。

### 自测问题 / Self-check

**Q1 中文：** ELIZA 和 Copilot 都像在哪里？

**中文答案：** 都使用打字语言交换轮次，屏幕表面相似。

**Q1 English:** Where do ELIZA and Copilot look similar?

**English answer:** Both exchange typed language turns and look similar on screen.

**Q2 中文：** 它们出错成本为何不同？

**中文答案：** ELIZA 只能产生奇怪回复；Copilot 能编辑、运行、提交，可能损害代码库。

**Q2 English:** Why are their error costs different?

**English answer:** ELIZA can only produce a strange reply; Copilot can edit, run, and commit, potentially damaging a codebase.


## 第 21 页：The ELIZA effect

Source ID: `src-ba38b47b419c-pdf_page-00021`

![PDF page 21](../assets/pages/page_021.png)

### 原文 / Original Text

```text
The ELIZA effect

Lecture 01 · The ELIZA effect

People read fluency as understanding — and they did 
it with a keyword matcher in 1966.

Weizenbaum's own users confided in ELIZA, knowing it 
was a program. Hofstadter (1995) popularised the name 
ELIZA effect.

The mechanism is simple: fluency is read as 
understanding, and the reader supplies the rest.

It scales with fluency, which has never been higher. The 
design consequence is blunt: show what the system 
actually did, not just what it said.

Source: Wikimedia Commons, 'ELIZA conversation' (2005 re-implementation by N. Landsteiner), 
public domain.
```

### 完整中文翻译

ELIZA 效应。

第 1 讲 - ELIZA 效应。

人们会把流畅性解读为理解，而且他们在 1966 年就已经对一个关键词匹配器这样做了。

Weizenbaum 自己的用户在明知 ELIZA 是程序的情况下，仍向它倾诉。Hofstadter（1995）推广了 ELIZA effect 这个名称。

机制很简单：流畅性被读作理解，读者会补上其余部分。

它会随着流畅性一起放大，而现在的流畅性从未如此之高。设计后果非常直接：展示系统实际做了什么，而不只是展示它说了什么。

来源：Wikimedia Commons，“ELIZA conversation”（N. Landsteiner 于 2005 年重新实现），公有领域。

### 中文释义

ELIZA effect 是理解现代 LLM 的核心心理机制。人会自然把语言流畅等同于理解、意图或能力。系统越会说，用户越可能高估它。设计上的回应不是禁止流畅，而是显示行动、证据、限制和真实能力。

### English Explanation

The ELIZA effect describes how people read fluency as understanding. With modern fluent systems, the effect scales up, making it crucial to show what the system actually did, not only what it said.

### 概念解析与拓展

- **ELIZA effect / ELIZA 效应**：用户把系统的语言流畅性误读为理解、同理心或能力。
- **Fluency / 流畅性**：输出看起来连贯自然，但不等于真实理解、正确性或可靠性。
- **Attribution / 归因**：用户把意义、意图或知识归给系统的心理过程。

拓展：LLM 产品常见风险是“语气可信但事实错误”。缓解方式包括来源引用、过程日志、可验证输出、明确不确定性、任务边界和人工确认。

### 自测问题 / Self-check

**Q1 中文：** ELIZA effect 的机制是什么？

**中文答案：** 人把语言流畅性读作理解，并由自己补足其余意义。

**Q1 English:** What is the mechanism of the ELIZA effect?

**English answer:** People read fluency as understanding and supply the rest themselves.

**Q2 中文：** 设计上的直接后果是什么？

**中文答案：** 要展示系统实际做了什么，而不只是展示它说了什么。

**Q2 English:** What is the direct design consequence?

**English answer:** Show what the system actually did, not just what it said.


## 第 22 页：Turing's question versus the design question

Source ID: `src-ba38b47b419c-pdf_page-00022`

![PDF page 22](../assets/pages/page_022.png)

### 原文 / Original Text

```text
Turing's question versus the design question

Lecture 01 · Reframing

Turing's question is about the machine. Ours is about 
the person — and that changes what counts as 
success.

Turing (1950) replaced 'can machines think?' with an 
imitation game, because the original question was not 
answerable.

But the game judges the machine and says nothing about 
the person's task. A system can pass it and still be useless 
to work with.

Our question is what the interaction lets a person do, see 
and undo — the reframing Shneiderman (2022, ch. 1)
builds human-centred AI on.
```

### 完整中文翻译

图灵的问题与设计问题。

第 1 讲 - 重新框定。

图灵的问题关乎机器。我们的问题关乎人，而这会改变什么算作成功。

Turing（1950）用模仿游戏替代了“机器能思考吗？”这个问题，因为原问题无法回答。

但是这个游戏评价的是机器，却没有说明人的任务。一个系统可以通过它，但仍然非常难用。

我们的问题是：这种互动让一个人能够做什么、看见什么、撤销什么。这正是 Shneiderman（2022，第 1 章）建立以人为中心 AI 的重新框定。

### 中文释义

本页把 AI 哲学问题转成设计问题。Turing Test 问机器是否能表现得像人；IIS 问系统是否让人的任务变好。一个会骗过人的系统不一定有用、安全或可控。因此课程采用 human-centered AI 的视角。

### English Explanation

The slide contrasts a machine-centered imitation question with a human-centered design question. Passing as intelligent is not the same as helping a person work effectively.

### 概念解析与拓展

- **Turing Test / 图灵测试**：通过模仿游戏判断机器是否能在对话中表现得像人。
- **Design question / 设计问题**：互动让人能做什么、看见什么、撤销什么。
- **Human-centered AI / 以人为中心的 AI**：把人的能力、控制、理解、责任和社会影响放在 AI 系统设计中心。

拓展：在项目评估中，不要只问模型是否像人或准确率是否高，还要测量任务完成、错误恢复、用户理解、信任校准和工作流整合。

### 自测问题 / Self-check

**Q1 中文：** Turing 的问题和本课问题分别关注什么？

**中文答案：** Turing 关注机器；本课关注人和人的任务。

**Q1 English:** What do Turing's question and this module's question focus on?

**English answer:** Turing's focuses on the machine; this module's focuses on the person and their task.

**Q2 中文：** 为什么通过图灵测试不等于好用？

**中文答案：** 因为它不说明系统是否支持用户任务、是否可见、可控、可撤销。

**Q2 English:** Why does passing the Turing Test not mean a system is useful?

**English answer:** It says nothing about whether the system supports the user's task or is visible, controllable, and reversible.


## 第 23 页：You bring the last generation's model with you

Source ID: `src-ba38b47b419c-pdf_page-00023`

![PDF page 23](../assets/pages/page_023.png)

### 原文 / Original Text

```text
You bring the last generation's model with you

Lecture 01 · Psychology, informally

Every one of you is running an out-of-date model of 
what these systems are — and so are your users.

People type search-engine keywords into a chat, and aim 
conversational requests at a database.

More dangerously, they carry undo expectations from 
documents into systems that take real actions.

This is your first, informal meeting with the idea of a mental 
model. No theory today — just notice it in yourself this 
week.
```

### 完整中文翻译

你会把上一代系统的模型带到现在。

第 1 讲 - 非正式心理学。

你们每个人都在运行一个关于这些系统是什么的过时模型，你们的用户也是如此。

人们会把搜索引擎关键词输入聊天系统，也会把对话式请求投向数据库。

更危险的是，他们会把文档中的撤销期待带入那些会采取真实行动的系统。

这是你第一次以非正式方式接触 mental model，也就是心理模型这个概念。今天不讲理论，只请你这周在自己身上注意它。

### 中文释义

心理模型是用户对系统如何工作的内在理解。新系统出现时，用户会带着旧系统经验来使用它：把 chat 当 search，用自然语言问数据库，或以为所有系统都像文档编辑器一样能撤销。错配的心理模型会导致误用和过度信任。

### English Explanation

Users carry mental models from older systems into newer ones. Misapplied expectations, especially about undo and system action, create interaction risks.

### 概念解析与拓展

- **Mental model / 心理模型**：用户心中关于系统是什么、如何工作、会产生什么后果的内在模型。
- **Model mismatch / 模型错配**：用户用旧系统规则理解新系统，导致错误操作或错误期待。
- **Undo expectation / 撤销期待**：用户默认操作可以像文档编辑一样撤销，但真实行动系统未必如此。

拓展：设计新智能系统时，需要通过界面信号、反馈、确认和教育帮助用户建立正确心理模型，而不是假设用户自然理解系统边界。

### 自测问题 / Self-check

**Q1 中文：** 什么是心理模型？

**中文答案：** 用户对系统如何工作、能做什么、结果如何产生的内在理解。

**Q1 English:** What is a mental model?

**English answer:** A user's internal understanding of how a system works, what it can do, and how consequences happen.

**Q2 中文：** 为什么从文档带来的撤销期待危险？

**中文答案：** 因为会采取真实行动的系统可能无法像文档编辑一样轻松撤销。

**Q2 English:** Why are undo expectations from documents dangerous?

**English answer:** Systems that take real actions may not be undoable like document edits.


## 第 24 页：One question, four areas, eleven weeks

Source ID: `src-ba38b47b419c-pdf_page-00024`

![PDF page 24](../assets/pages/page_024.png)

### 原文 / Original Text

```text
One question, four areas, eleven weeks

Lecture 01 · The module map

One question runs through the module: how do we 
design, build and evaluate interactive systems in 
which intelligent capabilities meaningfully take part in 
interaction with people?

Area I (Weeks 1–3): humans and intelligent interaction —
what intelligence is, and who is on the other side of it.

Area II (Weeks 4–5 and 7): engineering intelligent systems 
— context, models, knowledge, tools, agents and sensing.

Areas III and IV (Weeks 8–9, then 10–11): bodies and 
space; then agency, reliance, evaluation and deployment. 
Week 6 is reading week; Week 11 is review and project 
submission.
```

### 完整中文翻译

一个问题，四个领域，十一周。

第 1 讲 - 模块地图。

整个模块贯穿一个问题：我们如何设计、构建和评估交互系统，使智能能力能够有意义地参与人与系统的互动？

领域 I（第 1-3 周）：人类与智能交互 - 智能是什么，以及另一端是谁。

领域 II（第 4-5 周和第 7 周）：工程化智能系统 - 语境、模型、知识、工具、智能体和感知。

领域 III 和 IV（第 8-9 周，然后第 10-11 周）：身体与空间；随后是能动性、依赖、评估和部署。第 6 周是阅读周；第 11 周是复习和项目提交。

### 中文释义

这一页给模块结构。第 1-3 周建立人和智能交互的概念基础；第 4-7 周转向工程与系统构建；第 8-11 周看身体、空间、能动性、依赖、评估和部署。中心问题始终是智能能力如何有意义地参与互动。

### English Explanation

The module map organizes the course around one question: how to design, build, and evaluate interactive systems where intelligent capabilities meaningfully participate in human interaction.

### 概念解析与拓展

- **Module map / 模块地图**：课程主题与周次的结构化安排。
- **Meaningful participation / 有意义参与**：智能能力不是装饰，而是在互动中实际改变任务、决策或体验。
- **Evaluation and deployment / 评估与部署**：后期关注系统是否有效、可靠、可被依赖并适合真实环境。

拓展：复习时可把每周内容放回主问题：这周帮助我回答 design、build 还是 evaluate？它处理的是人、工程、身体空间，还是部署责任？

### 自测问题 / Self-check

**Q1 中文：** 贯穿模块的中心问题是什么？

**中文答案：** 如何设计、构建和评估让智能能力有意义参与人机互动的交互系统。

**Q1 English:** What is the central module question?

**English answer:** How to design, build, and evaluate interactive systems in which intelligent capabilities meaningfully participate in interaction with people.

**Q2 中文：** 第 6 周和第 11 周分别是什么？

**中文答案：** 第 6 周是阅读周；第 11 周是复习和项目提交。

**Q2 English:** What are Weeks 6 and 11?

**English answer:** Week 6 is reading week; Week 11 is review and project submission.


## 第 25 页：Phase 1 begins now: choose an area by its shift

Source ID: `src-ba38b47b419c-pdf_page-00025`

![PDF page 25](../assets/pages/page_025.png)

### 原文 / Original Text

```text
Phase 1 begins now: choose an area by its shift

Lecture 01 · Project connection

Pick your project area by asking which capability shift 
your problem actually depends on.

Ask: which of the five shifts does my problem rely on?
That answer points at your area.

The shift also tells you what evidence you will need, 
which is why choosing early saves you weeks later.

Phase 1 (Weeks 1–4) is problem, literature, gap and 
contribution — and Lab 1 this week starts the literature 
search with AI tools.
```

### 完整中文翻译

阶段 1 现在开始：根据迁移选择一个领域。

第 1 讲 - 项目连接。

通过询问你的问题实际上依赖哪一次能力迁移，来选择你的项目领域。

问：我的问题依赖五次迁移中的哪一次？这个答案会指向你的领域。

这次迁移也会告诉你需要什么证据，因此早一点选择会在之后帮你节省数周时间。

阶段 1（第 1-4 周）是问题、文献、空白和贡献；本周的实验 1 会从使用 AI 工具进行文献搜索开始。

### 中文释义

这一页把课程框架接到项目。选题不要先想“做什么应用”，而要问它依赖哪类智能能力：规则对话、GUI/直接操控、推荐学习、感知深度学习、LLM/agents。不同 shift 会决定文献、评估指标和证据类型。

### English Explanation

The project guidance asks students to choose an area by identifying which capability shift their problem depends on. This clarifies the evidence, literature, gap, and contribution needed in Phase 1.

### 概念解析与拓展

- **Phase 1 / 阶段 1**：第 1-4 周的项目阶段，聚焦问题、文献、研究空白和贡献。
- **Research gap / 研究空白**：现有文献或系统尚未充分解决的问题。
- **Contribution / 贡献**：你的项目相对已有工作的新增价值，可以是设计、实现、评估或实证发现。

拓展：写 proposal 时建议用一句话定位：My project depends primarily on Shift X because... Then evidence should include... 这样能把技术、交互变量和文献类型连起来。

### 自测问题 / Self-check

**Q1 中文：** 项目选区应先问什么？

**中文答案：** 我的问题依赖五次能力迁移中的哪一次。

**Q1 English:** What should you ask first when choosing a project area?

**English answer:** Which of the five capability shifts the problem depends on.

**Q2 中文：** Phase 1 包括哪些内容？

**中文答案：** 问题、文献、空白和贡献。

**Q2 English:** What does Phase 1 include?

**English answer:** Problem, literature, gap, and contribution.


## 第 26 页：What changed each time

Source ID: `src-ba38b47b419c-pdf_page-00026`

![PDF page 26](../assets/pages/page_026.png)

### 原文 / Original Text

```text
What changed each time

Lecture 01 · Synthesis

Initiative and inference moved to the system; visibility 
and reversibility were high only where somebody 
designed them.

From recommendation onward, what the system starts and 
what it infers kept rising. Direct manipulation was the 
exception: it handed both back to the person.

Visibility and reversibility are design choices, not gifts of 
progress — they peaked with the GUI, where they were 
deliberately built in (Shneiderman, 1983).

Since then they have fallen as capability rose. Designing 
them back in is the job, and it is what this module trains you 
to do.
```

### 完整中文翻译

每一次到底改变了什么。

第 1 讲 - 综合。

主动权和推断转移到了系统；可见性和可撤销性只有在人们设计它们时才会高。

从推荐开始，系统开启的事情和系统推断的事情持续上升。直接操控是例外：它把两者都交还给了人。

可见性和可撤销性是设计选择，而不是技术进步的礼物。它们在 GUI 中达到顶峰，因为它们被有意建构进去（Shneiderman，1983）。

此后，随着能力上升，它们下降了。把它们重新设计回来，就是这项工作，也是本模块训练你去做的事情。

### 中文释义

这是总结页，也是最该记住的一页。AI 系统越强，越要主动设计用户的可见性和可撤销性。课程不是反对系统推断或主动行动，而是要求在能力上升时重新设计控制、解释、确认和恢复机制。

### English Explanation

The synthesis states the module's design agenda: as system initiative and inference grow, designers must deliberately rebuild visibility and reversibility.

### 概念解析与拓展

- **Design choice / 设计选择**：某种交互品质不是技术自然产物，而是设计者通过界面、流程、反馈和约束主动实现的。
- **Designing back in / 重新设计回来**：在现代智能系统中重新引入 GUI 时代强调的可见性和可撤销性。
- **Human control / 人的控制**：用户理解、批准、修正、撤销和监督系统行动的能力。

拓展：这一页可变成项目评价准则：我的系统增加了哪些推断和主动权？我怎样把可见性和可撤销性设计回来？

### 自测问题 / Self-check

**Q1 中文：** 可见性和可撤销性为什么不是进步的礼物？

**中文答案：** 因为技术能力上升不会自动带来它们；GUI 中它们高，是因为被有意设计进去。

**Q1 English:** Why are visibility and reversibility not gifts of progress?

**English answer:** Because technological capability does not automatically produce them; they were high in the GUI because they were deliberately designed in.

**Q2 中文：** 本模块训练你做什么？

**中文答案：** 在智能能力上升时，把可见性和可撤销性重新设计回来。

**Q2 English:** What does the module train you to do?

**English answer:** To design visibility and reversibility back in as intelligent capability rises.


## 第 27 页：References and further reading

Source ID: `src-ba38b47b419c-pdf_page-00027`

![PDF page 27](../assets/pages/page_027.png)

### 原文 / Original Text

```text
References and further reading

Lecture 01 · References

James, W. (1890). The Principles of Psychology. Henry Holt.

Turing, A. M. (1950). Computing Machinery and Intelligence. Mind, 59(236), 433–460.

Weizenbaum, J. (1966). ELIZA — A Computer Program for the Study of Natural Language 
Communication between Man and Machine. Communications of the ACM, 9(1), 36–45.

Weizenbaum, J. (1976). Computer Power and Human Reason. W. H. Freeman.

Sutherland, I. E. (1965). The Ultimate Display. Proceedings of IFIP Congress, 506–508.

Shneiderman, B. (1983). Direct Manipulation: A Step Beyond Programming Languages. IEEE 
Computer, 16(8), 57–69.

Resnick, P., Iacovou, N., Suchak, M., Bergstrom, P., & Riedl, J. (1994). GroupLens: An Open 
Architecture for Collaborative Filtering of Netnews. CSCW 1994.

Linden, G., Smith, B., & York, J. (2003). Amazon.com Recommendations: Item-to-Item 
Collaborative Filtering. IEEE Internet Computing, 7(1), 76–80.
Inoue, S., & Matsuzawa, T. (2007). Working memory of numerals in chimpanzees. Current 
Biology, 17(23), R1004–R1005.
Silberberg, A., & Kearns, D. (2009). Memory for the order of briefly presented numerals in 
humans as a function of practice. Animal Cognition, 12(2), 405–407.
Krizhevsky, A., Sutskever, I., & Hinton, G. E. (2012). ImageNet Classification with Deep 
Convolutional Neural Networks. NeurIPS 25.
Hinton, G. et al. (2012). Deep Neural Networks for Acoustic Modeling in Speech Recognition. 
IEEE Signal Processing Magazine, 29(6), 82–97.
Vaswani, A. et al. (2017). Attention Is All You Need. NeurIPS 30.   ·   Brown, T. et al. (2020). 
Language Models are Few-Shot Learners. NeurIPS 33.
Hofstadter, D. R. (1995). Fluid Concepts and Creative Analogies. Basic Books (preface: the 
'ELIZA effect').
Levin, M. (2022). Technological Approach to Mind Everywhere: An Experimentally-Grounded 
Framework for Understanding Diverse Bodies and Minds. Frontiers in Systems Neuroscience, 
16, 768201.
Shneiderman, B. (2022). Human-Centered AI. Oxford University Press. Start with Part 1, ch. 1.
```

### 完整中文翻译

参考文献与延伸阅读。

第 1 讲 - 参考文献。

James, W.（1890）。《心理学原理》。Henry Holt。

Turing, A. M.（1950）。《计算机器与智能》。Mind，59(236)，433-460。

Weizenbaum, J.（1966）。《ELIZA：一个用于研究人与机器之间自然语言交流的计算机程序》。Communications of the ACM，9(1)，36-45。

Weizenbaum, J.（1976）。《计算机力量与人类理性》。W. H. Freeman。

Sutherland, I. E.（1965）。《终极显示》。IFIP Congress 论文集，506-508。

Shneiderman, B.（1983）。《直接操控：超越编程语言的一步》。IEEE Computer，16(8)，57-69。

Resnick, P., Iacovou, N., Suchak, M., Bergstrom, P., & Riedl, J.（1994）。《GroupLens：用于 Netnews 协同过滤的开放架构》。CSCW 1994。

Linden, G., Smith, B., & York, J.（2003）。《Amazon.com 推荐：物品到物品协同过滤》。IEEE Internet Computing，7(1)，76-80。

Inoue, S., & Matsuzawa, T.（2007）。《黑猩猩对数字的工作记忆》。Current Biology，17(23)，R1004-R1005。

Silberberg, A., & Kearns, D.（2009）。《人类对短暂呈现数字顺序的记忆如何随练习而变化》。Animal Cognition，12(2)，405-407。

Krizhevsky, A., Sutskever, I., & Hinton, G. E.（2012）。《使用深度卷积神经网络进行 ImageNet 分类》。NeurIPS 25。

Hinton, G. 等（2012）。《用于语音识别声学建模的深度神经网络》。IEEE Signal Processing Magazine，29(6)，82-97。

Vaswani, A. 等（2017）。《Attention Is All You Need》。NeurIPS 30。Brown, T. 等（2020）。《语言模型是少样本学习者》。NeurIPS 33。

Hofstadter, D. R.（1995）。《流动概念与创造性类比》。Basic Books（前言：“ELIZA effect”）。

Levin, M.（2022）。《通向无处不在心智的技术路径：一个以实验为基础、用于理解多样身体与心智的框架》。Frontiers in Systems Neuroscience，16，768201。

Shneiderman, B.（2022）。《以人为中心的 AI》。Oxford University Press。建议从第 1 部分第 1 章开始。

### 中文释义

这一页给整讲的学术出处。它把本讲的几条线索连起来：James 和 Levin 支持广义智能定义；Turing 和 Weizenbaum 支持早期 AI 与交互讨论；Sutherland、Shneiderman 支持直接操控与 human-centered AI；GroupLens、Amazon、ImageNet、Transformers、GPT-3 支持五次能力迁移中的技术节点。

### English Explanation

The references anchor the lecture's intellectual lineage: broad definitions of intelligence, early AI and interaction, direct manipulation, recommendation, deep learning, LLMs, the ELIZA effect, and human-centered AI.

### 概念解析与拓展

- **Primary source / 一手来源**：概念或技术首次提出或经典发表的文献，例如 Turing 1950、Weizenbaum 1966、Shneiderman 1983。
- **Further reading / 延伸阅读**：用于加深理解但不一定在课件正文详讲的文献。
- **Citation lineage / 引文脉络**：一讲课中概念、案例和理论的来源网络。

拓展：优先精读 Shneiderman 1983、Shneiderman 2022 第 1 章、Weizenbaum 1966/1976、Brown 2020 和 Levin 2022。做项目时，再按自己的 shift 选择 GroupLens/Amazon、ImageNet 或 Transformer/LLM 方向。

### 自测问题 / Self-check

**Q1 中文：** 哪篇文献对应 Direct Manipulation？

**中文答案：** Shneiderman, B. (1983), Direct Manipulation: A Step Beyond Programming Languages.

**Q1 English:** Which reference corresponds to Direct Manipulation?

**English answer:** Shneiderman, B. (1983), Direct Manipulation: A Step Beyond Programming Languages.

**Q2 中文：** 如果项目偏 LLM 和 agents，参考页上哪些文献最直接相关？

**中文答案：** Vaswani 等 2017 的 Transformer 与 Brown 等 2020 的 GPT-3/few-shot learning。

**Q2 English:** If a project focuses on LLMs and agents, which references are most directly relevant?

**English answer:** Vaswani et al. 2017 on Transformers and Brown et al. 2020 on GPT-3 and few-shot learning.
