from __future__ import annotations

import html
import json
import re
import shutil
import subprocess
from datetime import datetime
from pathlib import Path


ROOT = Path(r"E:\UOB Artificial Intelligence")
WORK_ROOT = ROOT / "Codex Workspace" / "learn_from_materials"
POPPLER = r"C:\Users\小巷派暗黑打油诗人\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe"


LECTURES = {
    "iis_w02_l04": {
        "pdf": ROOT / "Intelligent Interactive Systems" / "Week 2" / "W02_L04_Perception_Attention_and_Feedback.pdf",
        "out": "IIS_W02_L04_page_by_page_companion",
        "title": "Perception, Attention and Feedback",
        "pages": {
            1: ("Perception, Attention and Feedback", "感知、注意力与反馈。\n\n智能交互系统 - 第 2 周 - 第 4 讲。伯明翰大学。\n\n只有当人能够注意到并解释反馈时，反馈才真正起作用。\n\n- 我们会考察感知和注意力如何塑造人在智能系统沟通时会注意到什么。\n- 我们会使用信号检测、线索整合和反馈时机来选择线索、通道和回应。\n\n课程自绘图：五个线索竞争同一个人的注意。", "本讲把“系统给了反馈”拆成“人是否注意到、是否能解释、是否及时收到”。智能系统沟通不是把消息放到界面上就结束，而要匹配人的任务、感官通道和注意资源。", "This lecture asks whether feedback actually reaches and can be interpreted by a person who is already doing something.", [["Feedback / 反馈", "系统向用户传达状态、结果或确认的信号；只有被注意并解释后才有效。"]]),
            2: ("Watch the video", "观看视频。\n\n观看时跟随计数任务。\n\n- 计算白衣队伍传球的次数。\n- 在视频结束前先不要说出答案，然后跟随讲师讨论。", "这一页设置了经典注意力实验。任务要求你专注于计数，为后面解释“可见事件也可能被错过”做铺垫。", "The video primes students for inattentional blindness by giving them a counting task that consumes attention.", [["Counting task / 计数任务", "用一个明确目标占用注意力，从而显示未被关注事件如何被漏看。"]]),
            3: ("Count the passes", "数传球次数。\n\n第 4 讲 - 引入。\n\n当注意力在别处时，一个可见事件也可能被错过。\n\n- 在 Simons 和 Chabris（1999）中，观察者一边数传球，一边发生意外事件。研究多个条件下大约一半人错过了它。\n- 这就是持续性非注意盲视：在执行另一个任务时，一个意外且可见的事件可能逃过注意。\n- 互动 1：预测司机在繁忙路口注意到仪表盘图标的比例。写下一个数字，五分钟后再回看。\n\n根据 Simons 和 Chabris（1999）。原始影片帧保留版权；旁边示意图为课程自制。", "关键概念是 inattentional blindness：看见不等于注意到。对设计来说，静态图标或颜色变化即使“在屏幕上”，也可能在高负荷任务中完全失败。", "A visible event can still be missed when attention is committed elsewhere; this creates a design risk for passive cues.", [["Inattentional blindness / 非注意盲视", "人在专注于一个任务时，可能漏掉明显可见但未被期待的事件。"]]),
            4: ("The feedback arrow, taken seriously", "认真对待反馈箭头。\n\n第 4 讲 - 中心问题。\n\n反馈箭头必须到达一个已经在做事的人。\n\n- 第 2 讲的反馈箭头把系统消息连接到人。今天我们问：什么让这条消息真正抵达？\n- 问这个线索是否会被注意到、是否与当前任务竞争、是否可能错误，以及它如何与其他感官结合。\n- 然后问人能多快、多精确地感知它，以及何时、如何确认人的行动。\n\n课程自绘图：简化循环和本讲回答的六个问题。", "这页给出本讲总问题：反馈不是一条抽象箭头，而要穿过注意、竞争、不确定性、感官整合、速度和确认机制。", "The central question is what makes a system message arrive, compete appropriately, and support action acknowledgement.", [["Feedback arrow / 反馈箭头", "从系统消息到人的感知和解释之间的设计路径。"]]),
            5: ("Selective attention: one narrow channel", "选择性注意：一条狭窄通道。\n\n第 4 讲 - 注意力。\n\n选择性注意限制哪些输入能得到持续处理。\n\n- 选择性注意意味着优先处理某些输入而不是另一些。Broadbent 的过滤模型（1958）把许多输入想象成竞争一条狭窄处理通道。\n- 后续研究修正了该模型：一些未被注意的信息仍然能被处理，因此过滤器只是教学简化。\n- 对设计来说，要问线索是否到达人的当前注意，或者是否以可接受的打断成本捕获注意。\n\n课程自绘图，基于 Broadbent（1958）。", "选择性注意告诉我们：人的处理能力有限，线索必须进入注意通道。强行捕获注意可能有效，但代价是打断当前任务。", "Selective attention limits sustained processing, so designers must decide whether a cue fits current attention or justifiably interrupts it.", [["Selective attention / 选择性注意", "人在多个输入中优先处理某些输入的机制。"]]),
            6: ("Inattentional blindness as a design problem", "非注意盲视作为设计问题。\n\n第 4 讲 - 注意力。\n\n要为人的当前任务设计，而不是只为可见性设计。\n\n- 非注意盲视帮助解释为什么静态仪表盘图标或外围颜色变化会在高要求工作中被错过。\n- 突然出现、运动、被关注通道中的变化和有意义线索能吸引注意，但它们也会打断任务。\n- 回看你的预测：声音也可能与语音竞争。把这个图标当作设计风险，而不是已经测量出的检测率。\n\n课程自制表格：回到引入中的预测。", "这页把心理学实验转成设计判断：线索是否会被注意取决于任务环境。设计师要权衡注意捕获与打断成本。", "Visibility alone is not enough. A cue must be designed for the person's current task and disruption tolerance.", [["Disruption cost / 打断成本", "线索捕获注意时对当前任务造成的干扰。"]]),
            7: ("Multiple resources: use a free channel", "多资源理论：使用空闲通道。\n\n第 4 讲 - 注意力。\n\n当任务使用不同资源时，干扰较少。\n\n- 多资源理论区分模态、编码和处理阶段（Wickens，2002）。通俗地说，任务会竞争不同类型的注意力。\n- 驾驶和仪表盘地图都要求视觉和空间资源。语音导航使用听觉和语言资源，因此能减少干扰。\n- 不同通道仍有成本：写代码和听语音可能都会竞争语言资源。\n\n根据 Wickens（2002）的简化教学模型。", "如果当前任务占用视觉空间资源，就不要再用视觉地图塞给用户；可以考虑听觉语言。但通道不同不等于零成本。", "Multiple-resource theory helps choose a less competing channel, while reminding us that every channel still has costs.", [["Multiple-resource theory / 多资源理论", "不同任务会占用不同模态、编码和处理阶段资源；资源重叠越多，干扰越大。"]]),
            8: ("Three perceptual limits every system runs into", "每个系统都会遇到的三种感知限制。\n\n第 4 讲 - 感知限制。\n\n感知限制为界面设计创造具体约束。\n\n- 延迟是动作和可见效果之间的间隔。短延迟在头戴显示器中特别重要（LaValle，2017）。\n- 分辨率会从中央凹向外下降；中央凹是清晰中央视觉的小区域。细节和微妙颜色差异在周边更难看见。\n- 变化盲视意味着人在视觉中断期间漏掉变化，flicker paradigm 展示了这一点（Rensink、O'Regan 和 Clark，1997）。", "三条设计约束：反馈要快；细节要放在用户看得到的地方；变化不能只靠用户自己发现。XR 和智能界面尤其受延迟影响。", "Latency, foveal resolution, and change blindness create concrete constraints for feedback and interface design.", [["Latency / 延迟", "用户动作和系统反馈之间的时间差。"], ["Change blindness / 变化盲视", "人在视觉中断或注意不足时漏掉变化。"]]),
            9: ("Change blindness", "变化盲视。\n\n仔细观察房间，看有什么发生变化。\n\n- 列出你发现的每一个变化；\n- 先不要说出来。\n\n之后，你漏掉的内容就是变化盲视（Rensink 等，1997）。", "这是课堂活动页，用来让学生亲身体验变化盲视。设计含义是：如果系统状态变化很重要，就不要只依赖细微视觉变化。", "This activity makes change blindness experiential: students list noticed changes and then compare with what they missed.", [["Flicker paradigm / 闪烁范式", "通过视觉中断展示人对变化的感知依赖注意力。"]]),
            10: ("Signal detection: four outcomes, two quantities", "信号检测：四种结果，两个量。\n\n第 4 讲 - 信号检测。\n\n把证据质量和是否发出警告的决定分开。\n\n- 信号检测理论区分命中、漏报、误报和正确拒绝：把警告决策与危险是否真实存在进行比较（Green 和 Swets，1966）。\n- 敏感度 d' 描述证据区分危险与非危险的能力。传感器和模型性能会影响这种分离。\n- 判据是决策阈值。在敏感度固定时，移动阈值是在漏报与误报之间权衡，而不是同时减少二者。\n\n课程自绘图，基于 Green 和 Swets（1966）。", "这一页非常重要：模型证据质量和报警阈值是两件事。调低阈值可以减少漏报，但会增加误报；不是免费提升。", "Signal detection separates evidence quality from warning criterion, making error trade-offs explicit.", [["Signal detection theory / 信号检测理论", "分析系统在信号存在/不存在时做出警告/不警告决定的框架。"], ["Criterion / 判据", "决定证据是否足够触发警告的阈值。"]]),
            11: ("The same evidence, two criteria", "同样的证据，两种判据。\n\n第 4 讲 - 信号检测。\n\n改变判据会改变错误，而不是改变底层证据。\n\n- 两个图中都有相同的危险和非危险重叠分布。形状是示意，不是实测。\n- 谨慎判据会产生更少误报但更多漏报。积极判据会产生更少漏报但更多误报。\n- 改善传感器或模型能改善敏感度。只移动决策线不能把分布分开。\n\n课程自绘示意图；曲线为示意，不是实测。", "这页防止一个常见误解：阈值调节不能让模型更懂世界，只能改变错误类型。真正提高证据质量要改善传感器或模型。", "Moving the criterion changes the balance of misses and false alarms; improving sensitivity requires better evidence.", [["Sensitivity / 敏感度", "证据区分有危险与无危险的能力。"]]),
            12: ("A collision warning at three criteria", "三个判据下的碰撞警告。\n\n第 4 讲 - worked example。\n\n更高命中率可能带来代价高昂的误报增加。\n\n- 这些虚构教学数字使用同一个传感器，在谨慎、平衡和积极三个判据下比较。它们不是实际警告系统观测数据。\n- 从谨慎到积极，每 100 个危险多得到 18 次命中，但误报从每 100 小时驾驶 2 次上升到 60 次，增加 30 倍。\n- 要同时判断两种错误成本：频繁误报会降低司机响应意愿，从而减少警告的实际收益。\n\n虚构教学数据；行为解释是假设，不是实测结果。", "碰撞警告不能只追求 hit rate。误报过多会使用户习惯性忽略警告，最终损害系统有效性。", "Higher hit rates can come with many more false alarms, which may reduce practical benefit by changing user response.", [["False alarm cost / 误报成本", "不该警告时警告造成的打扰、信任下降或行为疲劳。"]]),
            13: ("Cry wolf: what false alarms do over time", "狼来了：误报随时间造成什么。\n\n第 4 讲 - worked example。\n\n重复误报会削弱人们对后续警告的反应。\n\n- cry-wolf effect 描述当警报被证明不可靠时，人们响应性下降（Breznitz，1984）。人会学习一个警告值不值得注意。\n- 两条曲线显示定性趋势，不是实测数据，也不是每次误报后必然下降的规律。\n- 评估系统时，要把命中率和人随时间的反应一起看。一次误报会影响未来警告的有用性。\n\n根据 Breznitz（1984）。定性示意图，不是数据或确定性反应规律。", "误报是长期交互问题，不只是一次错误。它会改变用户对未来警告的信任和响应。", "False alarms can train people to ignore later warnings, so evaluation must include responses over time.", [["Cry-wolf effect / 狼来了效应", "警报频繁不可靠后，用户对后续警报响应降低。"]]),
            14: ("Every threshold is a criterion", "每个阈值都是一个判据。\n\n第 4 讲 - 应用。\n\n阈值会做出决策，而这些错误具有人的成本。\n\n- 唤醒词、分类器置信度截断和检索分数都决定证据是否足以触发回应。\n- 规划/行动层加入行动、询问或等待；反馈层加入警告或保持安静。在命名漏报或误报前，先定义被检测的事件。\n- 对每个阈值，都要区分敏感度和判据，并解释谁的成本证明这个设置合理。", "阈值不只是技术参数，而是人机互动决策。必须先定义要检测什么，再讨论 miss/false alarm，并说明成本由谁承担。", "Every threshold is a criterion with human costs, whether in wake words, classifiers, retrieval, planning, or feedback.", [["Threshold / 阈值", "系统把连续证据转化为行动或不行动的决策边界。"]]),
            15: ("Your turn: set the criterion for three systems", "轮到你：为三个系统设置判据。\n\n第 4 讲 - 互动 2。\n\n通过比较两种错误成本来设置每个判据。\n\n- A 是学生厨房里的烟雾报警器，比较漏掉火灾与烦人警报及其后果。\n- B 是拼写建议，比较未被注意的拼写错误与不必要下划线。C 是智能体在发送高风险邮件前询问“你确定吗？”。\n- 用两分钟把 A、B、C 放到谨慎到积极的尺度上。每个系统写一句话解释两种成本。\n\n课程自制 worksheet。", "练习要求你把 criterion 变成设计论证。不同系统错误成本不同，所以阈值也应该不同。", "The activity asks students to justify criteria by comparing the cost of misses and false alarms.", [["Cost-based criterion setting / 基于成本的判据设置", "根据漏报和误报的相对代价选择阈值。"]]),
            16: ("Cue integration: weighting by reliability", "线索整合：按可靠性加权。\n\n第 4 讲 - 线索整合。\n\n在线索整合中，更可靠的证据可以获得更高权重。\n\n- 线索整合意味着合并感官估计。Ernst 和 Banks（2002）发现，人们在使用视觉和触觉判断凸起高度时接近最优加权。\n- 在他们的实验中，更可靠的线索获得更多权重，合并估计比任一单独线索更精确。\n- 这连接到传感器融合。把这个想法应用到对警告的信任是一种设计类比，不是该实验确立的通用公式。\n\n根据 Ernst 和 Banks（2002）。警告信任扩展是类比。", "人会综合多个线索，并倾向依赖更可靠的线索。设计中可以借用这个思想，但不要把实验结果直接当作所有信任判断公式。", "Cue integration combines estimates and can weight more reliable cues more heavily; applying it to trust is an analogy.", [["Cue integration / 线索整合", "把多个感官或信息线索组合成一个估计。"], ["Sensor fusion / 传感器融合", "将多个传感器来源组合以获得更可靠估计。"]]),
            17: ("Slide 16 comment", "第 16 页批注。\n\nEO1：你可以提到我们的许多触觉研究，其中视觉输入被用来修改触觉渲染。\n\nEyal Ofek，2026-09-23。", "这是课件批注，不是正式知识点。它提示 cue integration 与触觉研究有关，尤其是视觉如何改变触觉渲染。", "This is a review comment noting that haptics research can illustrate visual influence on haptic rendering.", [["Haptic rendering / 触觉渲染", "通过设备生成触觉反馈，让用户感到接触、纹理或力。"]]),
            18: ("Feedback timing: three thresholds", "反馈时机：三个阈值。\n\n第 4 讲 - 反馈。\n\n在慢响应让人不确定之前，先确认动作已被接收。\n\n- 约 0.1 秒、1 秒和 10 秒指南分别描述即时响应、持续流畅和持续注意的上限（Miller，1968；Nielsen，1993）。\n- 如果模型调用需要更久，在最终答案前显示“正在处理”、输入指示器或部分结果。\n- 反馈告诉人们他们的行动造成了什么（Norman，2013）。沉默或迟到确认会让人不确定，或把注意力转向别处。\n\n响应时间指南：Miller（1968）；Nielsen（1993）。反馈：Norman（2013）。", "速度本身就是反馈设计。即使最终结果很慢，也要先让用户知道系统听到了、正在做、下一步是什么。", "Prompt acknowledgement prevents uncertainty while slower processing continues.", [["Response-time thresholds / 响应时间阈值", "0.1s、1s、10s 等大致时间界限，用于判断反馈是否及时。"]]),
            19: ("Feedback modality: which channel?", "反馈模态：哪个通道？\n\n第 4 讲 - 反馈。\n\n选择适合任务和人的反馈模态。\n\n- 中央视觉反馈能在人正在看的地方承载细节。周边变化能吸引注意，但小型静态线索更容易漏掉。\n- 非语音声音能快速确认，但会与其他声音竞争。语音承载意义，也会与语言任务竞争。\n- 触觉反馈在设备接触身体时能离散确认。把通道选择与错误成本和及时反馈结合起来（Norman，2013）。\n\n课程自制表格：多资源、信号检测和时机共同决定通道选择。", "反馈通道要根据任务资源选择：视觉适合细节，声音适合快速提醒，触觉适合低调确认。但每个通道都有竞争成本。", "Modality choice combines attention resources, error costs, and timing requirements.", [["Feedback modality / 反馈模态", "视觉、声音、语音、触觉等反馈通道。"]]),
            20: ("The cost of a late or missing acknowledgement", "迟到或缺失确认的成本。\n\n第 4 讲 - 反馈。\n\n及时确认能减少不确定性和重复请求。\n\n- 在假想收据归档例子中，一条路径在一秒内确认；另一条沉默六秒。\n- 沉默期间，用户会想“它听到了吗？”，重复请求，结果产生重复归档。模型答案本身不是原因。\n- 早期确认可以降低这种风险。但它本身不能保证系统阻止每一次重复操作。\n\n假想时间线。原始绘图位置与文字时间冲突；替换版本遵循叙述。", "这页说明很多错误不是模型错，而是反馈晚造成用户重复行动。确认消息能减少不确定性。", "Late acknowledgement can cause repeated requests and duplicate actions even when the model's final answer is fine.", [["Acknowledgement / 确认反馈", "系统及时告知用户行动已被接收或正在处理。"]]),
            21: ("Phase 1: your channel and the cost of a miss", "阶段 1：你的通道和漏报成本。\n\n第 4 讲 - 项目连接。\n\n指定一个重要线索，并说明它如何到达用户。\n\n- 写六行：命名消息和通道，然后描述人的当前任务以及它使用的资源。\n- 描述漏报成本和误报成本。然后选择谨慎、平衡或积极，并解释原因。\n- 花十分钟完成这个不计分任务，并带到实验 2。它会发展阶段 1 的“用户体验”部分和你的反馈层。\n\n六行不计分任务，目标十分钟。把完成的 worksheet 带到 Lab 2。", "项目任务把本讲工具落地：你必须为一个 cue 说明通道、用户当前任务、资源竞争、漏报/误报成本和判据选择。", "The project task asks students to justify one cue and channel using current task resources and error costs.", [["Cue-channel justification / 线索-通道论证", "说明某个消息为什么通过某个通道传达，并如何权衡错误成本。"]]),
            22: ("What a person can notice, and how fast", "人能注意到什么，以及多快。\n\n第 4 讲 - 综合与过渡。\n\n有用线索必须到达注意力、支持判断，并及时抵达。\n\n- 注意力和资源决定线索是否被注意到，以及它与当前任务竞争多少。\n- 检测和整合把错误成本与可用证据的可靠性连接起来。重复误报会改变反应。\n- 及时给出反馈，然后问人能在脑中保持什么。第 5 讲会接着讲工作记忆、认知负荷和心理模型。\n\n五条原则，随后进入第 5 讲。", "总结页把本讲三个部分连起来：注意力决定能否注意，信号检测决定何时警告，反馈时机决定是否及时解除不确定。", "The synthesis links attention, detection, integration, false alarms over time, and timely feedback.", [["Attention-resource-feedback chain / 注意-资源-反馈链", "线索设计必须同时考虑注意、资源竞争、证据可靠性和反馈时机。"]]),
            23: ("References and further reading", "参考文献与延伸阅读。\n\n第 4 讲 - 参考文献。\n\nBroadbent（1958）《Perception and Communication》。\n\nSimons 与 Chabris（1999）《Gorillas in our midst: sustained inattentional blindness for dynamic events》。Perception, 28(9), 1059-1074。\n\nWickens（2002）《Multiple resources and performance prediction》。Theoretical Issues in Ergonomics Science, 3(2), 159-177。\n\nGreen 与 Swets（1966）《Signal Detection Theory and Psychophysics》。Wiley。\n\nBreznitz（1984）《Cry Wolf: The Psychology of False Alarms》。Lawrence Erlbaum。\n\nErnst 与 Banks（2002）《Humans integrate visual and haptic information in a statistically optimal fashion》。Nature, 415, 429-433。\n\nRensink、O'Regan 与 Clark（1997）《To see or not to see: the need for attention to perceive changes in scenes》。Psychological Science, 8(5), 368-373。\n\nMiller（1968）《Response time in man-computer conversational transactions》。AFIPS Fall Joint Computer Conference, 267-277。Nielsen（1993）《Usability Engineering》。Academic Press。\n\nNorman（2013）《The Design of Everyday Things》第 2 章。LaValle（2017）《Virtual Reality》第 5-6 章预告。\n\n完整列表与核验注释：W02_L04_references.md。\n\n课程自绘图：来源按支持内容分组。使用一手来源检查每条设计规则背后的机制。", "参考页把本讲机制对应到来源：注意力、非注意盲视、多资源、信号检测、误报心理、线索整合、变化盲视、反馈时机和 Norman 反馈理论。", "The references anchor the mechanisms behind the design rules: attention, signal detection, cue integration, timing, and feedback.", [["Primary mechanism source / 机制一手来源", "用于追溯设计原则背后心理或感知机制的原始研究。"]]),
        },
    },
}


def add_l05_l06() -> None:
    """Populate compact page notes for L05 and L06."""
    LECTURES["iis_w02_l05"] = {
        "pdf": ROOT / "Intelligent Interactive Systems" / "Week 2" / "W02_L05_Memory_Mental_Models_and_Cognitive_Load.pdf",
        "out": "IIS_W02_L05_page_by_page_companion",
        "title": "Memory, Mental Models and Cognitive Load",
        "pages": {
            1: ("Memory, Mental Models and Cognitive Load", "记忆、心理模型与认知负荷。\n\n智能交互系统 - 第 2 周 - 第 5 讲。伯明翰大学。\n\n课程自绘图：头脑中的四个组块，以及旁边的系统模型。", "本讲接在反馈之后：即使线索已经到达，人还要能记住、理解并形成正确系统模型。", "This lecture asks what happens after a cue arrives: what the person can hold and what model they form.", [["Working memory / 工作记忆", "短时间保持和操作信息的有限心理资源。"]]),
            2: ("A phone number read aloud", "被大声读出的电话号码。\n\n第 5 讲 - 引入。\n\n工作记忆是短暂存储：听一次 11 位数字后，如果没有复述，多数人只能保留少数几位。\n\n写下前，预测十秒后你能按顺序复现多少位；这个练习让限制变得可见。\n\n分组会改变结果，因为熟悉组块比孤立数字更容易保留下来。\n\n课程自绘图：号码是示意，不是真实号码。", "这个练习展示工作记忆容量和时间都有限。chunking 能把多个项目压缩成少量有意义单位。", "The phone-number exercise makes working-memory limits and the value of chunking visible.", [["Chunking / 组块化", "把多个信息项组织成一个熟悉单位，以减少工作记忆负担。"]]),
            3: ("After the cue arrives: two questions", "线索到达之后：两个问题。\n\n第 5 讲 - 中心问题。\n\n第 4 讲确定线索已被注意到；现在我们问它到达后发生什么。\n\n工作记忆、识别和认知负荷解释人能保持什么；心理模型和解释解释人相信什么。\n\n这些过程相互作用：负荷会产生更弱的模型，错误模型会创造更多检查工作。", "中心问题分成两个：用户能保持多少信息？用户形成了什么系统理解？负荷和心理模型会互相影响。", "After attention, design must support both memory capacity and model formation.", [["Cognitive load / 认知负荷", "任务和界面消耗工作记忆资源的程度。"], ["Mental model / 心理模型", "用户对系统如何工作及会产生什么结果的理解。"]]),
            4: ("Working memory: a small, fragile store", "工作记忆：小而脆弱的存储。\n\n第 5 讲 - 工作记忆。\n\nBaddeley 和 Hitch（1974）的模型把工作记忆看作中央执行系统协调语音环路和视觉空间画板；Baddeley（2000）后来加入情景缓冲。\n\nMiller（1956）推广了“七加减二”；Cowan（2001）后来认为，在控制分组和复述后，限制更接近四个组块，所以设计时按大约四个来设计。\n\n通俗地说，信息会在几秒内衰退，因此系统应承担状态，而不是要求人记住它。\n\n课程自绘图，基于 Baddeley 和 Hitch（1974）及 Baddeley（2000）。", "设计含义很直接：不要让用户记住很多状态、参数或步骤。系统应该显示状态、保留上下文，并减少记忆负担。", "Working memory is small and fragile; systems should carry state instead of asking users to remember it.", [["Four chunks / 四个组块", "课程采用的实用设计近似：工作记忆大约容纳四个有意义单位。"]]),
            5: ("Slide 4 comment", "第 4 页批注。\n\nEO1：谁？7？4？\n\nEyal Ofek，2026-09-23。", "这是课件批注，指出幻灯片中“七”和“四”的指代需要更清楚。正式知识点仍是：现代设计更保守地按约四个组块处理。", "This review comment asks for clearer wording around the seven-versus-four memory limit.", [["Clarification comment / 澄清批注", "课件制作反馈，不是正式课程内容。"]]),
            6: ("Gone in seconds: why waiting costs", "几秒内消失：为什么等待有成本。\n\n第 5 讲 - 工作记忆。\n\nPeterson 和 Peterson（1959）在阻止复述的情况下，让参与者延迟回忆三个字母。\n\n回忆在前 10 到 15 秒急剧下降；图中显示研究形状，不是精确数据。\n\n与第 4 讲的联系很实际：六秒沉默可能已经超过请求在工作记忆中的保留时间，所以要快速确认。\n\n课程自绘示意图，基于 Peterson 和 Peterson（1959）；曲线显示结果形状，不是数据。", "等待会消耗记忆。系统沉默太久，用户可能忘记自己刚刚要求了什么，或者重复请求。", "Waiting costs because unrehearsed information decays within seconds.", [["Memory decay / 记忆衰退", "没有复述或外部提示时，短时信息很快消失。"]]),
            7: ("Chunking: the same eleven digits, three ways", "组块化：同样 11 位数字，三种方式。\n\n第 5 讲 - 工作记忆。\n\n组块是人可以当作一个东西处理的单位；11 个孤立数字会溢出约四个组块的存储。\n\n三个分组更容易装下，熟悉组块如伯明翰区号 0121 可以作为一个组块被检索。\n\n通俗地说，利用已有知识组织信息；如果超过约四个项目，就显示出来，而不是让人保持在脑中。\n\n课程自绘图。", "设计时要把信息按用户熟悉结构分组。列表太长就放到界面上，而不是要求用户记忆。", "Chunking uses existing knowledge to reduce working-memory load.", [["Familiar chunk / 熟悉组块", "用户已知的模式或单位，可以被当成一个信息项处理。"]]),
            8: ("Recognition beats recall", "识别胜过回忆。\n\n第 5 讲 - 识别与回忆。\n\n回忆要求人在没有环境线索的情况下产生命令；识别让人辨认已经可见的选项。\n\nNorman（2013）把它描述为“头脑中的知识”与“世界中的知识”。\n\n通俗地说，菜单支持新手识别；当专家已经知道命令时，他们可能更喜欢命令行。\n\n课程自绘图，基于 Norman（2013）第 3 章。", "界面越能把选项放到世界中，用户越不必从记忆中召回。菜单、按钮、建议 chips 都是在支持识别。", "Recognition is easier than recall because visible cues reduce memory demand.", [["Knowledge in the world / 世界中的知识", "界面中可见的提示、选项和状态，帮助用户识别而非回忆。"]]),
            9: ("The blank chat box is a command line", "空白聊天框就是命令行。\n\n第 5 讲 - 识别与回忆。\n\n“问我任何事”呈现的是一个空命令行：人必须回忆界面从未显示过的能力和状态。\n\n建议 chips、显示来源和最近行动把这些线索移到世界中，支持识别。\n\n通俗地说，每一次不必要回忆都会消耗工作记忆容量，所以显示应优于记忆。", "这页很适合批判 AI 聊天界面。空白输入框让用户自己猜系统能力；建议、来源、最近行动能减少 recall burden。", "A blank chat box forces recall of capabilities; visible suggestions and state support recognition.", [["Blank-box recall burden / 空白框回忆负担", "空输入框要求用户自己记住系统能做什么和当前状态。"]]),
            10: ("Cognitive load: three kinds, one budget", "认知负荷：三种类型，一个预算。\n\n第 5 讲 - 认知负荷。\n\n认知负荷理论区分来自任务的内在负荷、来自建构 schema 的 germane load，以及来自设计的外在负荷（Sweller，1988；Sweller、van Merrienboer 和 Paas，1998）。\n\n三者都竞争有限工作记忆容量，但外在负荷是设计者可以移除的部分。\n\n通俗地说，让任务复杂性可见，但不要增加任务本来不需要的界面工作。\n\n课程自绘图，基于 Sweller 等。", "认知负荷不是全部都坏。任务本身复杂无法完全消除，但界面额外制造的外在负荷应该减少。", "Cognitive load has one limited budget; designers can especially reduce extraneous load.", [["Extraneous load / 外在负荷", "由界面或教学设计额外制造、不是任务本身必须的负担。"]]),
            11: ("The same request, two designs", "同一个请求，两种设计。\n\n第 5 讲 - worked example。\n\n设计 A 大声读出 8 个航班，并让人记住每个航班的四个字段；设计 B 显示同样信息。\n\n任务和底层模型不变，但设计 B 把提取信息从记忆转移到识别。\n\n通俗地说，语音只呈现少数项目，或者显示完整集合让人比较。\n\n课程自制 mock-up；结果为示意并已标注。", "同样模型可以因为界面不同而负荷差异巨大。显示可比较信息通常比逐条读出更适合复杂选择。", "The model is unchanged, but visual presentation shifts work from memory to recognition.", [["Memory-to-recognition shift / 从记忆转向识别", "通过显示选项和状态，减少用户必须记住的信息。"]]),
            12: ("The same request under two load conditions", "同一个请求在两种负荷条件下。\n\n第 5 讲 - worked example。\n\n内在负荷会随情境改变：坐在桌前可能低负荷，而驾驶时同一请求会变成高风险。\n\n纯语音交互会与驾驶任务竞争，屏幕也不能安全查看。\n\n通俗地说，最多提供少量项目，然后问“更多吗？”；正确设计取决于人现在正在做什么。\n\n课程自制表格；单元格为示意，方向依据记忆文献。", "情境会改变设计。桌面上能显示长列表，驾驶时则要限制项目数并避免视觉检查。", "The right design depends on current task context; driving changes the load and safety profile.", [["Context-dependent load / 情境依赖负荷", "同一界面在不同用户任务下可能带来不同认知负荷。"]]),
            13: ("Your turn: recall, recognition, load", "轮到你：回忆、识别、负荷。\n\n第 5 讲 - 互动 2。\n\n把五个界面时刻分类为回忆或识别，然后评价每个时刻增加的外在负荷。\n\n重新设计一个时刻，让相关线索可见，而不是要求人检索。\n\n用两分钟完成，然后为最后一个判断辩护，因为情境会改变成本。\n\n课程自制 worksheet。", "练习训练你识别界面是否要求 recall，以及如何把信息搬到世界中来降低外在负荷。", "The activity asks students to classify recall/recognition moments and redesign one cue to be visible.", [["Recall vs recognition audit / 回忆-识别审计", "检查界面是否不必要地要求用户从记忆中取回信息。"]]),
            14: ("Mental models: Different representations", "心理模型：不同表示。\n\n每个参与者都会建立同一请求的不同模型，而且它们都可能不符合用户真正想要的东西。\n\n1973 年 tree-swing 漫画跟随一个秋千，从赞助方提案、规格说明、分析师设计、程序员、安装一路变化。\n\n通俗地说，每一格都是一个心理模型；下一页展示设计师模型如何只能通过系统形象到达用户。\n\nThe O.G. Tire Swing Cartoon，原始漫画 1973。", "秋千漫画说明：不同角色对同一需求的理解会分叉。系统最终呈现出来的样子会塑造用户模型。", "The tree-swing cartoon shows that different stakeholders form different models of the same request.", [["System image / 系统形象", "用户实际看到和接触到的系统表现，是设计师模型传递给用户的媒介。"]]),
            15: ("Mental models: the runnable theory in the head", "心理模型：头脑中的可运行理论。\n\n第 5 讲 - 心理模型。\n\n心理模型是一种可运行理论：设计师模型、系统形象和用户模型通过一个可见通道相遇。\n\nJohnson-Laird（1983）认为，人通过构建和运行小型内部模型来推理。\n\nNorman（2013）强调，用户模型不必技术上准确，但必须支持有用预测；线索和反馈会建立它。\n\n课程自绘图，基于 Norman（2013）第 1 章和 Johnson-Laird（1983）。", "心理模型的标准不是工程准确，而是能否帮助用户预测系统。设计要通过线索和反馈塑造可用模型。", "A mental model is a runnable internal theory that supports prediction, even if it is not technically exact.", [["Runnable theory / 可运行理论", "用户可以在脑中运行的系统理解，用来预测行动后果。"]]),
            16: ("A model built from cues", "由线索建立的模型。\n\n第 5 讲 - 心理模型。\n\n一句问候可能暗示“它知道我是谁”，提到昨天可能暗示“它记得一切”。\n\n如果系统忘记了用户说过的偏好，却不解释它保存什么，用户模型会在两个极端之间摇摆。\n\n通俗地说，可见且可编辑的记忆能给人关于系统边界的证据，并保持模型校准。\n\n课程自绘图。", "AI 系统的小线索会造成大期待。记忆必须可见可编辑，否则用户不知道系统到底记住什么。", "Cues such as greetings and references to yesterday shape assumptions about identity and memory.", [["Visible memory / 可见记忆", "用户能查看、编辑和理解系统保存内容的设计。"]]),
            17: ("Explanation dosage: what is just right?", "解释剂量：什么才刚刚好？\n\n第 5 讲 - 解释。\n\nKulesza 等（2013）改变推荐系统解释的 soundness 和 completeness。\n\n完整性对准确心理模型最重要；不完整或不可靠解释会产生自信但错误的模型。\n\n最完整解释也会消耗努力，所以要提供足够证据来塑造预测，而不要压垮用户。\n\n课程自绘示意图：Kulesza 等（2013）的两个维度；图不是研究数据。", "解释不是越多越好，也不是越少越好。目标是让用户形成能预测系统行为的模型。", "Explanation dosage must balance completeness, soundness, and cognitive effort.", [["Soundness and completeness / 可靠性与完整性", "解释是否真实反映系统，以及是否覆盖形成正确模型所需信息。"]]),
            18: ("Three dosages of one explanation", "一个解释的三种剂量。\n\n第 5 讲 - 解释。\n\n太少：“为你推荐”会让人形成“它在猜”的模型。\n\n刚刚好：说明它使用了什么、没有使用什么，以及人如何改变结果。\n\n太多：例如 39 个特征权重，远超人能保持的四个组块；剂量取决于什么会塑造下一次预测。\n\n课程自制 mock-up：推荐器解释的三种剂量。", "好解释要说清输入、边界和控制路径。过少会让用户瞎猜，过多会制造外在负荷。", "A just-right explanation states what was used, what was not used, and how the user can change the result.", [["Explanation dosage / 解释剂量", "解释信息量的设计，需要足以校准模型但不过载。"]]),
            19: ("Slide 17 comment", "第 17 页批注。\n\nEO1：39 是什么意思？只是一个很大的数字吗？\n\nEyal Ofek，2026-09-23。", "这是课件批注，指出“39 个权重”应解释为大量特征的例子，而不是一个特殊数字。", "This review comment asks whether 39 has a specific meaning or simply means too many features.", [["Example magnitude / 示例数量", "用来表达过载的数量示例，需避免被误解为固定指标。"]]),
            20: ("Human memory is not computer memory", "人类记忆不是计算机记忆。\n\n第 5 讲 - 类比。\n\n人类记忆会重构要点；计算机可以返回存储副本，所以两者不会以同样方式失败。\n\n人类遗忘和基于线索的检索不同于机器删除策略、键、搜索和相似性匹配。\n\n通俗地说，要谨慎使用记忆术语，并说明智能系统保存、遗忘和检索什么。\n\n课程自绘表格。", "不要把 AI memory 拟人化。人的记忆是重构性的，机器记忆是存储和检索策略；界面必须说明系统到底记住什么。", "Human and computer memory fail differently, so memory terminology must be precise.", [["Machine memory / 机器记忆", "系统按存储策略、键、搜索或相似性检索保留信息，不等同人类记忆。"]]),
            21: ("Phase 1: the model you want users to form", "阶段 1：你希望用户形成的模型。\n\n第 5 讲 - 项目连接。\n\n写一句话说明系统感知什么、记住什么、决定什么，以及何时行动。\n\n列出系统形象中建立该心理模型的三个线索，然后说出用户可能带来的错误模型，以及修正它的线索。\n\n定义用户已经形成模型的证据：他们不用询问就能预测或做什么。\n\n课程自制 worksheet。", "项目中不能只说“用户会理解”。你要明确想让用户形成什么模型、用哪些线索塑造它、如何证明他们形成了。", "The project task asks students to specify the intended user model, cues that build it, likely wrong models, and evidence of success.", [["Evidence of model formation / 模型形成证据", "用户能预测或正确操作系统，说明他们形成了目标心理模型。"]]),
            22: ("What they hold, and what model they form", "他们能保持什么，以及形成什么模型。\n\n第 5 讲 - 综合与过渡。\n\n工作记忆只能在几秒内保持大约四个组块，所以系统要承担状态，并显示本来可能被遗忘的内容。\n\n外在负荷是设计成本；心理模型来自线索和反馈，而解释必须完整、可靠，并按可用容量调整大小。\n\n通俗地说，人无法形成模型的系统，就是他们无法使用的系统；人类记忆不是机器记忆。\n\n课程自绘图：关于人能保持什么和形成什么模型的六条规则。", "总结页将本讲变成设计原则：少让用户记，减少外在负荷，显示状态，设计解释剂量，谨慎处理记忆隐喻。", "The synthesis links working memory limits, extraneous load, mental models, explanations, and memory terminology.", [["State carried by system / 系统承担状态", "系统显示和保存必要上下文，而不是让用户在脑中保留。"]]),
            23: ("References and further reading", "参考文献与延伸阅读。\n\n第 5 讲 - 参考文献。\n\nMiller（1956）《神奇数字 7 加减 2》。Psychological Review, 63(2), 81-97。\n\nBaddeley 与 Hitch（1974）《Working memory》；Baddeley（2000）《The episodic buffer》。\n\nCowan（2001）《The magical number 4 in short-term memory》。Behavioral and Brain Sciences, 24(1), 87-114。\n\nPeterson 与 Peterson（1959）《Short-term retention of individual verbal items》。Journal of Experimental Psychology, 58(3), 193-198。\n\nSweller（1988）和 Sweller、van Merrienboer 与 Paas（1998）关于认知负荷。\n\nJohnson-Laird（1983）《Mental Models》。Harvard University Press。\n\nKulesza 等（2013）《Too much, too little, or just right? Ways explanations impact end users' mental models》。IEEE VL/HCC 2013。\n\nNorman（2013）《The Design of Everyday Things》第 1-3 章；Shneiderman（2022）关于 explainability。完整核验列表：W02_L05_references.md。", "参考页覆盖工作记忆、短时遗忘、认知负荷、心理模型、解释剂量和 Norman 的设计理论。", "The references anchor memory capacity, decay, cognitive load, mental models, explanation dosage, and design theory.", [["Reference cluster / 参考文献群", "按概念分组的一组来源，用来支撑本讲机制。"]]),
            24: ("Optional viewing: Her (2013)", "可选观看：《Her》（2013）。\n\n跟踪人与系统之间的互动。\n\n心理模型：Theodore 起初认为这个新 OS 能做什么？\n系统形象：界面给了他关于智能、人格、记忆和自主性的哪些线索？\n识别与回忆：onboarding 展示选择，还是要求 Theodore 知道该问什么？\n认知负荷：注意 Theodore 需要理解的技术配置很少；互动把复杂系统压缩成短对话。\n用户建模/记忆：设置过程询问私人问题并立即使用答案。Theodore 现在会假设什么会被记住？\n解释剂量：系统几乎不解释技术过程。这是优雅简化，还是制造了不准确心理模型？\n人类与机器记忆：拟人化声音是否鼓励 Theodore 假设 Samantha 像人一样记得并理解？\n期待形成：在 Samantha 做很多事之前，她的声音和对话流畅性已经建立了关于她是什么实体的期待。\n\n截图：《Her》（2013），YouTube 链接。", "可选观看把本讲所有概念放进一个电影交互案例：心理模型、系统形象、记忆、解释剂量、拟人化和期待形成。", "The optional viewing applies the lecture concepts to a human-like conversational OS.", [["Anthropomorphic cue / 拟人化线索", "声音、人格和对话流畅性等让用户把系统理解成人一样的线索。"]]),
        },
    }
    LECTURES["iis_w02_l06"] = {
        "pdf": ROOT / "Intelligent Interactive Systems" / "Week 2" / "W02_L06_Action_Error_Agency_and_Decision.pdf",
        "out": "IIS_W02_L06_page_by_page_companion",
        "title": "Action, Error, Agency and Decision",
        "pages": {
            1: ("Action, Error, Agency and Decision", "行动、错误、能动性与决策。\n\n智能交互系统 - 第 2 周 - 第 6 讲。伯明翰大学。\n\n课程自绘图：一个会学习的恒温器，以及本讲的五个概念。", "本讲把前两讲的注意、记忆和心理模型连接到行动：用户如何知道能做什么，为什么会错，系统替人行动时能动性感如何改变。", "This lecture connects cues and mental models to action, error, agency, and decision-making.", [["Agency / 能动性感", "人感觉“是我在行动并造成结果”的主观体验。"]]),
            2: ("A door that needs a sign", "一扇需要标识的门。\n\n第 6 讲 - 引入。\n\n一块板说“推”，一个把手说“拉”；signifier 告诉我们哪个 affordance 可用。\n\n互动 1：用一个词说出板子邀请什么，用一个词说出把手邀请什么。\n\n一个能发邮件却没有标识的助手有同样设计问题：有能力但没有可见 signifier；一个没有可见原因就改变的恒温器甚至把把手也移除了。", "门的例子说明 affordance 和 signifier 的区别。智能系统也需要把能力显示出来，否则用户不知道如何行动或如何控制。", "The door example introduces affordance and signifier, then maps them onto intelligent systems that hide capability or control.", [["Affordance / 可供性", "对象或系统允许某个人做的事情。"], ["Signifier / 能指", "可感知的线索，告诉用户可供性存在。"]]),
            3: ("Acting through a system, and being acted for", "通过系统行动，以及被系统代为行动。\n\n第 6 讲 - 中心问题。\n\n第 4 讲问线索是否到达；第 5 讲问人保持什么、形成什么模型。\n\n今天问人如何行动、为什么出错，以及当系统代表他们行动时发生什么变化。\n\n我们通过人由线索建立的行动模型，把 signifier、鸿沟、错误、能动性、决策和自动化连接起来。", "中心问题是行动结构：用户不只是接收反馈，还要通过系统行动；当系统替人行动时，责任和控制会变复杂。", "The lecture asks how people act through systems and what changes when systems act on their behalf.", [["Action model / 行动模型", "用户基于线索形成的关于如何行动、会发生什么的理解。"]]),
            4: ("Affordance, signifier, mapping", "可供性、能指、映射。\n\n第 6 讲 - 行动。\n\n可供性是一个对象或系统允许这个人做什么，无论它是否可见。\n\n能指是传达可供性的可感知线索；这是设计可以控制的部分。\n\n映射把控制与效果连接起来：Norman 的炉灶之所以有效，是因为旋钮位置映射炉头位置，所以不需要标签。\n\n课程自绘图，基于 Norman（2013）第 1 章。", "三概念是行动设计基础：系统能做什么、如何显示能做什么、控制和效果是否自然对应。", "Affordance, signifier, and mapping explain how users discover and perform actions.", [["Mapping / 映射", "控制项与系统效果之间的对应关系。"]]),
            5: ("What tells you what a system can do?", "是什么告诉你系统能做什么？\n\n第 6 讲 - 行动。\n\n麦克风图标表示可以说话，但它没有说明系统支持哪些短语或能力。\n\n建议 chips 是强 signifier，因为它们暴露了人可以识别的能力。\n\n“问我任何事”是假的 signifier：一个学习型恒温器如果静默覆盖旋钮，也在发出一个它并不遵守的控制信号。\n\n课程自制六个 signifier mock-up；没有一个是真实截图。", "AI 系统常有“能力不明”的问题。建议 chips 比空白输入框更强，因为它把可做事项放到世界中。", "A cue must indicate not just input mode but supported capability; suggestion chips are stronger signifiers than blank prompts.", [["False signifier / 假能指", "界面暗示某种能力或控制存在，但系统实际上不支持或不遵守。"]]),
            6: ("The two gulfs", "两个鸿沟。\n\n第 6 讲 - 行动。\n\nNorman 的七阶段从目标、计划和指定，到执行，再到感知、解释和比较。\n\n执行鸿沟问如何行动；评价鸿沟问发生了什么，以及它是否符合目标。\n\nSignifier 缩小执行鸿沟；反馈和可运行心理模型缩小评价鸿沟。\n\n课程自绘图，基于 Norman（1986；2013 第 2 章）。", "两个鸿沟是用户行动理论核心。用户要先知道怎么做，再知道做了之后发生了什么。AI 系统常同时扩大两者。", "The gulf of execution concerns how to act; the gulf of evaluation concerns understanding what happened.", [["Gulf of execution / 执行鸿沟", "用户目标与可执行操作之间的距离。"], ["Gulf of evaluation / 评价鸿沟", "系统结果与用户理解/目标比较之间的距离。"]]),
            7: ("A thermostat that learns", "一个会学习的恒温器。\n\n第 6 讲 - worked example。\n\n你设置 21 度，但恒温器在晚上十点降到 19 度，并在周四再次升温；系统基于推断模式采取了行动。\n\n舒适度提高，账单下降，但人和系统都没有让原因可见。\n\n当评价鸿沟扩大时，人会更难说“是我行动了”。", "恒温器案例说明：系统可能带来好结果，但如果原因不可见，用户会失去控制感和能动性感。", "A learning thermostat may improve outcomes while widening the gulf of evaluation and weakening agency.", [["Learning thermostat / 学习型恒温器", "通过推断用户日程和偏好自动改变温度的系统。"]]),
            8: ("Where the gulfs sit on the spine", "鸿沟位于概念脊柱的哪里。\n\n第 6 讲 - 应用。\n\n提示可以缩小执行鸿沟，同时打开一个新问题：系统理解我了吗？\n\n智能体会扩大评价鸿沟，因为许多隐藏步骤把请求与可见结果分开。\n\n可观察性通过显示发生了什么、为什么发生、接下来会怎样来再次缩小评价鸿沟；辅助和具身也会塑造能动性。\n\n课程自绘图：第 2 讲脊柱标出两个鸿沟和后续四讲。", "这页把 Norman 的鸿沟放回 L02 脊柱。agent 的问题在于隐藏步骤太多；observability 是缩小评价鸿沟的关键。", "Observability narrows the gulf of evaluation by showing what happened, why, and what comes next.", [["Observability / 可观察性", "用户能看见系统内部状态、行动轨迹和后续计划的程度。"]]),
            9: ("Slips versus mistakes", "失误与错误判断。\n\n第 6 讲 - 错误。\n\nSlip 保留正确意图但执行了错误动作；mistake 从错误意图、规则或猜测开始（Reason，1990）。\n\nSlip 需要约束、确认或撤销；mistake 需要更好的模型和更清楚的反馈。\n\n先诊断错误再重新设计，因为错误补救会惹恼用户或无效。\n\n课程自绘图，基于 Reason（1990）和 Norman（2013）第 5 章。", "错误类型不同，修复也不同。把 mistake 当 slip 加确认，可能只是增加负担；把 slip 当 mistake 加解释，也解决不了误触。", "Slips and mistakes need different remedies, so diagnosis comes before redesign.", [["Slip / 失手", "意图正确但执行动作错。"], ["Mistake / 错误判断", "意图、规则或理解本身错。"]]),
            10: ("Three kinds of error in one voice assistant", "一个语音助手中的三类错误。\n\n第 6 讲 - 错误。\n\n“Call Sam”拨给 Samantha 是系统识别错误：系统推断了错误目标。\n\n当你其实想发短信却说“Call Sam”是用户 slip；设置闹钟并以为它每天重复是用户 mistake。\n\n每一种都需要不同补救：显示听到了什么、确认高风险行动、暴露系统模型。\n\n课程自制表格；助手为泛化示例。", "同一表面问题可能是系统识别错、用户失手或用户误解。修复要匹配根因。", "A voice-assistant failure can be system inference, user slip, or user mistake, each needing a different remedy.", [["System recognition error / 系统识别错误", "系统把输入或目标推断错。"]]),
            11: ("Your turn: slip, mistake, or system inference?", "轮到你：slip、mistake，还是系统推断？\n\n第 6 讲 - 互动 2。\n\n把五个失败分类：错窗口发送、车道助手、照片标签、两个监听器和删除智能体，分为 slip、mistake 或系统推断。\n\n用三个词命名补救措施，并标记需要两个标签的情况，因为人类错误和系统错误会相互作用。\n\n用两分钟完成，然后为 agent 案例辩护。", "练习强调复合错误：人和系统可能同时贡献错误。删除 agent 这类高后果场景尤其需要双标签分析和恢复设计。", "The activity trains error diagnosis, including cases where human and system errors interact.", [["Compound error / 复合错误", "人类错误和系统推断错误共同造成失败。"]]),
            12: ("The sense of agency", "能动性感。\n\n第 6 讲 - 能动性。\n\n能动性感是一种计算出来的感觉，由意图、行动、预测结果和比较构成（Haggard，2017）。\n\n当意图行动后迅速出现预测结果时，它最强。\n\n延迟、不匹配结果和非本人行动会削弱能动性感；感知到的控制会在更长时间上延伸这种感觉。\n\n课程自绘图，基于 Haggard（2017）。", "能动性感不是抽象哲学，而是交互体验：我想做、我做了、结果如预期出现。智能系统替人行动会打断这个链条。", "Agency is strongest when intended action is promptly followed by predicted outcome.", [["Sense of agency / 能动性感", "人感觉自己是行动和结果来源的体验。"]]),
            13: ("The thermostat, redesigned for agency", "为能动性感重新设计恒温器。\n\n第 6 讲 - 能动性。\n\n“由你设置为 21 度，18:40”和“由日程降低，22:00”让每次变化的原因可见。\n\n覆盖设置应一直保持到用户释放它，并且界面应说明这一点。\n\n“我学到了你这一周的什么”应该可编辑，并在变化发生前宣布；学习可以保留，同时恢复能动性感。", "设计不必取消学习功能，而是让原因、覆盖、学习内容和即将发生的改变可见可控。", "Agency can be restored by making causes visible, overrides persistent, and learned patterns editable.", [["Override / 覆盖设置", "用户临时或明确覆盖自动化行为的控制。"]]),
            14: ("Who feels they acted?", "谁感觉是自己行动了？\n\n第 6 讲 - 能动性。\n\n在简单助手中，人行动，系统提出建议，所以能动性仍然清楚。\n\n在智能体系统中，人启动多步骤过程，系统行动；能动性变成共享且可能不清晰。\n\n当系统在没有人意图的情况下决策时，人变成观察者；共同能动性需要启动和可见否决权。\n\n课程自绘图：第 2 讲自主性尺度加上能动性注释。", "自主性越高，越要设计 who acted 的可见性。共同能动性不是系统任意行动，而是人启动、系统执行、人能否决。", "As autonomy rises, agency becomes shared and needs visible initiation and veto.", [["Co-agency / 共同能动性", "人和系统共同推进任务，但人的启动、监督和否决仍清楚可见。"]]),
            15: ("Bounded rationality: people satisfice", "有限理性：人会满足化。\n\n第 6 讲 - 决策。\n\nSimon（1955）描述有限理性：人在注意、记忆和时间限制下搜索，直到某个选项足够好。\n\nJoachims 等（2005）交换搜索结果前两名后发现，人们仍然点击第一项。\n\n系统排在第一位的东西就成了代表人做出的决策，无论它是否被标记为决策。", "排序本身就是影响决策。用户不会无限比较，而会满足化，所以系统默认和排名具有行动力量。", "Rankings shape decisions because people satisfice under attention, memory, and time constraints.", [["Bounded rationality / 有限理性", "人在有限注意、记忆和时间下寻找足够好的选项，而非最优选项。"], ["Satisficing / 满足化", "找到足够好选项就停止搜索。"]]),
            16: ("Heuristics and biases: anchoring", "启发式与偏差：锚定。\n\n第 6 讲 - 决策。\n\n在锚定演示中，一个随机轮盘停在 10 或 65，会把中位估计移动到 25 或 45（Tversky 和 Kahneman，1974）。\n\n锚定、可得性和代表性是有限心智做决策时使用的启发式。\n\n助手的第一稿会锚定编辑，因此生成草稿本身已经是一种决策。", "LLM 草稿不是中立起点。它会锚定用户后续编辑方向，所以“只是生成初稿”也在影响决策。", "An assistant's first draft anchors later edits, so draft generation is already a decision.", [["Anchoring / 锚定", "初始数值或建议影响后续判断。"]]),
            17: ("Automation bias: introduced and parked", "自动化偏差：介绍并暂放。\n\n第 6 讲 - 决策。\n\nParasuraman 和 Riley（1997）区分自动化的使用、误用、不用和滥用。\n\n一个通常正确但偶尔错误的辅助系统会导致人产生 omission 和 commission errors（Skitka 等，1999）。\n\n“暂放”意味着现在介绍但不在已排定讲座中回访；可选材料会扩展它，因此 agent 永远不会在不讲人类成本的情况下被教授。\n\n课程自绘图，基于 Parasuraman 和 Riley（1997）以及 Skitka、Mosier 和 Burdick（1999）。", "自动化偏差提醒我们：人可能过度依赖或错误拒绝自动化。通常正确的系统反而会诱导更危险的忽视。", "Automation bias covers misuse and disuse; usually-right aids can create omission and commission errors.", [["Automation bias / 自动化偏差", "人因自动化建议而过度依赖、忽略或错误行动的倾向。"]]),
            18: ("Slide 17 comment", "第 17 页批注。\n\nEO1：不清楚。什么被暂放？你会在第 10 周回到它吗？\n\nEyal Ofek，2026-09-23。", "这是课件批注，指出“parked”的含义需要更清晰。当前课件解释为：介绍但不在排定讲座中回访。", "This review comment asks for clarification of what 'parked' means.", [["Terminology clarity / 术语清晰度", "课件中暂放、预告等词需要明确范围，避免学生误解。"]]),
            19: ("Phase 1: mark your storyboard", "阶段 1：标注你的 storyboard。\n\n第 6 讲 - 项目连接。\n\n为阶段 1 项目，标注五个 storyboard frame：目标、人的行动、系统推断和行动、结果、恢复。\n\n对每一帧记录谁行动（P、S 或 both）、涉及哪个鸿沟，以及显示了哪个 signifier。\n\n如果某一帧是 S 且没有可见原因，就是恒温器问题；把标注好的 storyboard 带到 Lab 2。\n\n课程自制 worksheet。阶段 2 storyboard 会计分；这个草稿不计分。", "项目任务要求你把行动、系统推断、结果和恢复画出来，并标注谁在行动。这样能暴露“系统行动但原因不可见”的问题。", "The project task maps storyboards to actor, gulf, signifier, and recovery.", [["Storyboard audit / 故事板审计", "逐帧标注人/系统行动、鸿沟、signifier 和恢复路径。"]]),
            20: ("Slide 18 comment", "第 18 页批注。\n\nEO1：这是项目部分的开始吗？也许需要一个标题和一页幻灯片来宣布它？\n\nEyal Ofek，2026-09-23。", "这是课件批注，提醒项目连接部分可能需要更明显的过渡。", "This review comment suggests making the project section transition clearer.", [["Section transition / 章节过渡", "用标题或提示明确从理论转到项目任务。"]]),
            21: ("The week's theories, and where each returns", "本周理论，以及它们在哪里回归。\n\n第 6 讲 - 综合与过渡。\n\n第 4 讲提供了注意力、检测、整合、限制和反馈时机；第 5 讲加入工作记忆、识别、负荷、心理模型和解释。\n\n今天加入 signifier、两个鸿沟、slip 与 mistake、能动性、决策和自动化。\n\n为 Lab 2，用 storyboard 表达你的问题，并用今天的概念标注每一帧。", "这页把 Week 2 全部理论汇总成项目工具箱。Lab 2 的核心是把 storyboard 逐帧概念化。", "The synthesis gathers Week 2 concepts and directs students to apply them to Lab 2 storyboards.", [["Week 2 theory toolkit / 第二周理论工具箱", "注意、记忆、心理模型、行动、错误、能动性和决策等用于分析交互的概念集合。"]]),
            22: ("References and further reading", "参考文献与延伸阅读。\n\n第 6 讲 - 参考文献。\n\nNorman（2013）《The Design of Everyday Things》修订扩展版，第 1-2 章和第 5 章。\n\nNorman（1986）《Cognitive engineering》，见 User Centered System Design，31-61。\n\nReason（1990）《Human Error》。Cambridge University Press。\n\nHaggard（2017）《Sense of agency in the human brain》。Nature Reviews Neuroscience, 18(4), 196-207。\n\nSimon（1955）《A behavioral model of rational choice》。Quarterly Journal of Economics, 69(1), 99-118。\n\nTversky 与 Kahneman（1974）《Judgment under uncertainty: heuristics and biases》。Science, 185(4157), 1124-1131。\n\nJoachims 等（2005）《Accurately interpreting clickthrough data as implicit feedback》。SIGIR 2005, 154-161。\n\nParasuraman 与 Riley（1997）《Humans and automation: use, misuse, disuse, abuse》。Human Factors, 39(2), 230-253。\n\nSkitka、Mosier 与 Burdick（1999）《Does automation bias decision-making?》。IJHCS, 51(5), 991-1006。\n\nShneiderman（2022）《Human-Centered AI》；控制中心设计隐喻预告。完整核验注释：W02_L06_references.md。", "参考页覆盖 Norman 行动理论、Reason 错误分类、Haggard 能动性、Simon 有限理性、Tversky/Kahneman 启发式、自动化偏差等。", "The references anchor action theory, error, agency, bounded rationality, heuristics, ranking effects, and automation bias.", [["Action-theory sources / 行动理论来源", "支撑 affordance、鸿沟、错误、能动性和自动化决策的文献。"]]),
            23: ("Watch the first 90 seconds clip of Wargames (1983)", "观看《WarGames》（1983）前 90 秒片段。\n\n评价鸿沟：人能看到导弹轨迹，但无法判断轨迹对应真实导弹还是模拟。\n\n心理模型/signifier 问题：界面呈现信息的方式完全像真实情况；基本没有 signifier 区分模拟和现实。\n\n系统推断/错误：从操作员角度看，显示状态是错误的，但它带着强权威到达：“confidence is high”。\n\n自动化偏差：因为系统通常被信任，人们开始依据其输出行动，而不是独立核查世界。\n\n有限理性：在极端时间压力下，操作员无法检查一切；他们依据第一个看似可信的解释行动。\n\n能动性：有趣问题变成到底是谁在做决策？将军技术上做决定，但计算机框定了情境并建议行动。\n\n排序/默认效应：WOPR 建议全面报复性打击。这个建议本身成为人类决策的强锚点。\n\n错误诊断：这是人类 mistake、系统推断问题，还是界面/反馈失败？实际上是组合问题，因此非常适合讨论。\n\nYouTube 链接见课件。", "可选片段把本讲所有概念放入高风险决策场景：评价鸿沟、signifier、自动化偏差、有限理性、能动性、锚定和复合错误。", "The WarGames clip is a compact case for gulf of evaluation, signifier failure, automation bias, bounded rationality, agency, anchoring, and compound error.", [["High-stakes automation / 高风险自动化", "系统输出会影响重大决策，要求更强可见性、核查和人类控制。"]]),
        },
    }


add_l05_l06()


def esc(text: str) -> str:
    return html.escape(text, quote=True)


def parse_pages(kb: Path) -> dict[int, str]:
    text = (kb / "full_text.md").read_text(encoding="utf-8")
    parts = re.split(r"<!-- PDF 页 (\d+) -->", text)
    return {int(parts[i]): parts[i + 1].strip() for i in range(1, len(parts), 2)}


def source_index(kb: Path) -> dict[int, dict]:
    return {int(x["pdf_page"]): x for x in json.loads((kb / "source_map.json").read_text(encoding="utf-8"))}


def render_images(pdf: Path, assets: Path, count: int) -> None:
    assets.mkdir(parents=True, exist_ok=True)
    if len(list(assets.glob("page_*.png"))) >= count:
        return
    pdftoppm = shutil.which("pdftoppm") or POPPLER
    subprocess.run([pdftoppm, "-png", "-r", "120", str(pdf), str(assets / "render")], check=True)
    for path in assets.glob("render-*.png"):
        match = re.search(r"render-(\d+)\.png$", path.name)
        if match:
            path.rename(assets / f"page_{int(match.group(1)):03d}.png")


def qa(page: int, note: tuple) -> list[tuple[str, str, str, str]]:
    concept, desc = note[4][0]
    return [
        (f"第 {page} 页的核心复习点是什么？", note[2], f"What is the key revision point on page {page}?", note[3]),
        (f"解释本页概念：{concept}", desc, f"Explain this concept: {concept}", desc),
    ]


def write_kb(kb: Path, title: str, pdf: Path, pages: dict[int, tuple], sources: dict[int, dict]) -> None:
    (kb / "units").mkdir(exist_ok=True)
    page_nums = sorted(pages)
    chunks = [page_nums[i:i + 6] for i in range(0, len(page_nums), 6)]
    coverage = []
    index = [f"# {title} 知识库索引", "", f"来源材料：{pdf.name}", ""]
    for idx, group in enumerate(chunks, 1):
        uid = f"u{idx:02d}-pages-{group[0]:02d}-{group[-1]:02d}"
        index.append(f"- [第 {group[0]}-{group[-1]} 页](units/{uid}.md)")
        lines = [f"# 第 {group[0]}-{group[-1]} 页", "", "## Page-by-page Notes", ""]
        for p in group:
            note = pages[p]
            lines += [f"### 第 {p} 页：{note[0]}", "", f"Source ID: `{sources[p]['source_id']}`", "", note[2], "", "#### Concepts"]
            for name, desc in note[4]:
                lines.append(f"- **{name}**：{desc}")
            lines.append("")
            coverage.append({"pdf_page": p, "source_id": sources[p]["source_id"], "unit_id": uid, "status": "covered"})
        (kb / "units" / f"{uid}.md").write_text("\n".join(lines), encoding="utf-8")
    (kb / "INDEX.md").write_text("\n".join(index), encoding="utf-8")
    glossary = ["# 术语表", ""]
    seen = set()
    for note in pages.values():
        for name, desc in note[4]:
            if name not in seen:
                seen.add(name)
                glossary.append(f"- **{name}**：{desc}")
    (kb / "glossary.md").write_text("\n".join(glossary), encoding="utf-8")
    q_items, practice = [], ["# 自测题", ""]
    for p, note in pages.items():
        practice.append(f"## 第 {p} 页：{note[0]}")
        for i, (qzh, azh, qen, aen) in enumerate(qa(p, note), 1):
            qid = f"p{p:03d}-q{i}"
            q_items.append({"id": qid, "page": p, "source_id": sources[p]["source_id"], "question_zh": qzh, "answer_zh": azh, "question_en": qen, "answer_en": aen})
            practice += [f"- {qid} 中文：{qzh}", f"  - 答案：{azh}", f"  - English: {qen}", f"  - Answer: {aen}"]
    (kb / "practice.md").write_text("\n".join(practice), encoding="utf-8")
    (kb / "question-bank.json").write_text(json.dumps({"detection": "generated_from_pages", "items": q_items}, ensure_ascii=False, indent=2), encoding="utf-8")
    (kb / "coverage-audit.json").write_text(json.dumps({"learningDepth": "systematic", "items": coverage}, ensure_ascii=False, indent=2), encoding="utf-8")
    (kb / "coverage-audit.md").write_text("# 覆盖审计\n\n" + "\n".join(f"- PDF 页 {x['pdf_page']}：covered - {x['source_id']}" for x in coverage), encoding="utf-8")
    (kb / "summary-ledger.json").write_text(json.dumps({"claims": coverage}, ensure_ascii=False, indent=2), encoding="utf-8")
    (kb / "reverse-coverage-report.json").write_text(json.dumps({"status": "complete", "pages_checked": len(pages), "unmapped_pages": []}, ensure_ascii=False, indent=2), encoding="utf-8")
    (kb / "methods.json").write_text(json.dumps({"methods": [{"id": "page-by-page-systematic-review", "name": "逐页系统复习法", "source_pages": page_nums, "steps": ["阅读原页", "核对完整中文翻译", "提炼设计概念", "用双语自测检查理解"]}]}, ensure_ascii=False, indent=2), encoding="utf-8")
    (kb / "patterns.md").write_text("# 方法卡\n\n## 逐页系统复习法\n\n阅读原页，核对完整中文翻译，提炼设计概念，并用双语自测检查理解。\n", encoding="utf-8")
    (kb / "methodology.json").write_text(json.dumps({"status": "supported", "central_problem": f"如何系统复习 {title} 的每一页并保持来源可追溯。", "nodes": [{"id": "n1", "title": "逐页翻译"}, {"id": "n2", "title": "概念解析"}, {"id": "n3", "title": "双语自测"}], "edges": [{"from": "n1", "to": "n2"}, {"from": "n2", "to": "n3"}]}, ensure_ascii=False, indent=2), encoding="utf-8")
    (kb / "methodology.md").write_text(f"# 整体方法论\n\n对 {title} 逐页保留原文、翻译、解释、概念和自测，并绑定 PDF 页来源。\n", encoding="utf-8")


CSS = """body{margin:0;font-family:"Segoe UI",Arial,"Microsoft YaHei",sans-serif;background:#f6f8fb;color:#172033;line-height:1.65}.layout{display:grid;grid-template-columns:310px 1fr}aside{position:sticky;top:0;height:100vh;overflow:auto;background:#fff;border-right:1px solid #d8dee9;padding:20px 16px}aside h1{font-size:18px;margin:0 0 8px}aside p{font-size:13px;color:#667085}nav a{display:grid;grid-template-columns:36px 1fr;gap:10px;padding:9px 8px;border-radius:6px;color:#172033;text-decoration:none;font-size:13px;line-height:1.35}nav a:hover{background:#eef7f5}nav span{color:#0f766e;font-weight:700}main{padding:32px min(4vw,48px) 80px}.hero{border-bottom:1px solid #d8dee9;margin-bottom:28px;padding-bottom:20px}.hero h2{font-size:42px;line-height:1.15;margin:0 0 12px}.page{background:#fff;border:1px solid #d8dee9;border-radius:8px;padding:24px;margin-bottom:24px;box-shadow:0 8px 24px rgba(15,23,42,.05)}.kicker{color:#0f766e;font-size:13px;font-weight:700}h2{font-size:26px;line-height:1.25}h3{font-size:17px;margin:18px 0 8px}.grid{display:grid;grid-template-columns:minmax(300px,.95fr) minmax(320px,1.05fr);gap:22px;align-items:start}img{width:100%;border:1px solid #d8dee9;border-radius:6px}figcaption{font-size:12px;color:#667085}pre{white-space:pre-wrap;word-wrap:break-word;background:#f8fafc;border:1px solid #d8dee9;border-radius:6px;padding:14px;font:13px/1.55 Consolas,monospace}.translation{background:#fff7ed;border-left:4px solid #b45309;padding:12px 14px;border-radius:6px}.explain{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:18px}article,details{border:1px solid #d8dee9;border-radius:6px;background:#fbfcfe;padding:10px 12px}.concepts li{margin:8px 0}.concepts span{display:block;color:#344054}details{margin:8px 0}summary{font-weight:700;cursor:pointer}@media(max-width:980px){.layout{grid-template-columns:1fr}aside{position:static;height:auto;max-height:46vh;border-right:0;border-bottom:1px solid #d8dee9}.grid,.explain{grid-template-columns:1fr}main{padding:24px 16px 60px}}"""


def build_html(slug: str, conf: dict, original: dict[int, str], sources: dict[int, dict]) -> str:
    pages = conf["pages"]
    toc = "\n".join(f'<a href="#page-{p}"><span>{p:02d}</span>{esc(pages[p][0])}</a>' for p in pages)
    sections = []
    for p, note in pages.items():
        concepts = "".join(f"<li><strong>{esc(name)}</strong><span>{esc(desc)}</span></li>" for name, desc in note[4])
        qas = "".join(f"<details><summary>Q{i}. {esc(qzh)} / {esc(qen)}</summary><p><strong>中文答案：</strong>{esc(azh)}</p><p><strong>English answer:</strong> {esc(aen)}</p></details>" for i, (qzh, azh, qen, aen) in enumerate(qa(p, note), 1))
        sections.append(f'<section class="page" id="page-{p}"><p class="kicker">PDF page {p:02d} · {esc(sources[p]["source_id"])}</p><h2>{p}. {esc(note[0])}</h2><div class="grid"><figure><img src="../assets/pages/page_{p:03d}.png" alt="PDF page {p}"><figcaption>原始 PDF 第 {p} 页截图</figcaption></figure><div><h3>原文 / Original Text</h3><pre>{esc(original[p])}</pre><h3>完整中文翻译</h3><div class="translation">{esc(note[1]).replace(chr(10), "<br>")}</div></div></div><div class="explain"><article><h3>中文释义</h3><p>{esc(note[2])}</p></article><article><h3>English Explanation</h3><p>{esc(note[3])}</p></article></div><h3>概念解析</h3><ul class="concepts">{concepts}</ul><h3>自测问题 / Self-check</h3>{qas}</section>')
    return f'<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>{esc(conf["title"])} - Page-by-page Companion</title><style>{CSS}</style></head><body><div class="layout"><aside><h1>{slug} 逐页复习</h1><p>完整中文翻译 · 中英文释义 · 概念拓展 · 自测答案</p><nav>{toc}</nav></aside><main><section class="hero"><h2>{esc(conf["title"])}</h2><p>基于 learn-from-materials 抽取结果重做。覆盖 {len(pages)} 页，保留页面截图、原文、完整中文翻译、概念解析与双语自测。</p><p>生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M")}</p></section>{"".join(sections)}</main></div></body></html>'


def build_md(conf: dict, original: dict[int, str], sources: dict[int, dict]) -> str:
    out = [f"# {conf['title']}", "", "逐页完整翻译与复习笔记。", ""]
    for p, note in conf["pages"].items():
        out += [f"## 第 {p} 页：{note[0]}", "", f"Source ID: `{sources[p]['source_id']}`", "", f"![PDF page {p}](../assets/pages/page_{p:03d}.png)", "", "### 原文", "```text", original[p], "```", "", "### 完整中文翻译", note[1], "", "### 中文释义", note[2], "", "### English Explanation", note[3], "", "### 概念解析"]
        for name, desc in note[4]:
            out.append(f"- **{name}**：{desc}")
        out += ["", "### 自测问题"]
        for i, (qzh, azh, qen, aen) in enumerate(qa(p, note), 1):
            out += [f"**Q{i} 中文：** {qzh}", f"**答：** {azh}", f"**Q{i} English:** {qen}", f"**Answer:** {aen}", ""]
    return "\n".join(out)


def build_one(slug: str, conf: dict) -> dict:
    work = WORK_ROOT / slug
    kb = work / f"{slug}.learnkb"
    assets = work / "assets" / "pages"
    delivery = work / "delivery"
    delivery.mkdir(parents=True, exist_ok=True)
    original = parse_pages(kb)
    sources = source_index(kb)
    render_images(conf["pdf"], assets, len(conf["pages"]))
    write_kb(kb, conf["title"], conf["pdf"], conf["pages"], sources)
    html_path = delivery / f"{conf['out']}.html"
    md_path = delivery / f"{conf['out']}.md"
    html_path.write_text(build_html(slug, conf, original, sources), encoding="utf-8")
    md_path.write_text(build_md(conf, original, sources), encoding="utf-8")
    (work / "index.html").write_text(f'<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="0; url=delivery/{html_path.name}"><a href="delivery/{html_path.name}">Open</a>', encoding="utf-8")
    tools = work / "tools"
    tools.mkdir(exist_ok=True)
    shutil.copy2(Path(__file__), tools / Path(__file__).name)
    return {"slug": slug, "html": str(html_path), "markdown": str(md_path), "pages": len(conf["pages"]), "images": len(list(assets.glob("page_*.png")))}


def write_week2_index(results: list[dict]) -> Path:
    out = WORK_ROOT / "iis_week2_index.html"
    cards = []
    for result in results:
        conf = LECTURES[result["slug"]]
        rel = Path(result["html"]).relative_to(WORK_ROOT).as_posix()
        cards.append(f'<a class="item" href="{rel}"><strong>{esc(result["slug"].upper())}</strong><span>{esc(conf["title"])}</span><em>{result["pages"]} pages</em></a>')
    out.write_text(f'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>IIS Week 2 Revision Index</title><style>body{{font-family:"Segoe UI",Arial,"Microsoft YaHei",sans-serif;background:#f6f8fb;color:#172033;margin:0;padding:48px}}main{{max-width:900px;margin:auto}}h1{{font-size:40px;margin:0 0 8px}}p{{color:#667085}}.item{{display:block;background:#fff;border:1px solid #d8dee9;border-radius:8px;padding:18px 20px;margin:12px 0;text-decoration:none;color:#172033;box-shadow:0 8px 24px rgba(15,23,42,.05)}}.item:hover{{border-color:#0f766e}}strong{{display:block;color:#0f766e}}span{{display:block;margin-top:4px}}em{{display:block;color:#667085;margin-top:4px}}</style><main><h1>IIS Week 2 逐页复习资料</h1><p>learn-from-materials 模板：逐页截图、原文、完整中文翻译、中英文释义、概念解析与双语自测答案。</p>{''.join(cards)}</main></html>''', encoding="utf-8")
    return out


def main() -> None:
    results = [build_one(slug, conf) for slug, conf in LECTURES.items()]
    index = write_week2_index(results)
    print(json.dumps({"results": results, "index": str(index)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
