# 自测题

## 第 1 页：Memory, Mental Models and Cognitive Load
- p001-q1 中文：第 1 页的核心复习点是什么？
  - 答案：本讲接在反馈之后：即使线索已经到达，人还要能记住、理解并形成正确系统模型。
  - English: What is the key revision point on page 1?
  - Answer: This lecture asks what happens after a cue arrives: what the person can hold and what model they form.
- p001-q2 中文：解释本页概念：Working memory / 工作记忆
  - 答案：短时间保持和操作信息的有限心理资源。
  - English: Explain this concept: Working memory / 工作记忆
  - Answer: 短时间保持和操作信息的有限心理资源。
## 第 2 页：A phone number read aloud
- p002-q1 中文：第 2 页的核心复习点是什么？
  - 答案：这个练习展示工作记忆容量和时间都有限。chunking 能把多个项目压缩成少量有意义单位。
  - English: What is the key revision point on page 2?
  - Answer: The phone-number exercise makes working-memory limits and the value of chunking visible.
- p002-q2 中文：解释本页概念：Chunking / 组块化
  - 答案：把多个信息项组织成一个熟悉单位，以减少工作记忆负担。
  - English: Explain this concept: Chunking / 组块化
  - Answer: 把多个信息项组织成一个熟悉单位，以减少工作记忆负担。
## 第 3 页：After the cue arrives: two questions
- p003-q1 中文：第 3 页的核心复习点是什么？
  - 答案：中心问题分成两个：用户能保持多少信息？用户形成了什么系统理解？负荷和心理模型会互相影响。
  - English: What is the key revision point on page 3?
  - Answer: After attention, design must support both memory capacity and model formation.
- p003-q2 中文：解释本页概念：Cognitive load / 认知负荷
  - 答案：任务和界面消耗工作记忆资源的程度。
  - English: Explain this concept: Cognitive load / 认知负荷
  - Answer: 任务和界面消耗工作记忆资源的程度。
## 第 4 页：Working memory: a small, fragile store
- p004-q1 中文：第 4 页的核心复习点是什么？
  - 答案：设计含义很直接：不要让用户记住很多状态、参数或步骤。系统应该显示状态、保留上下文，并减少记忆负担。
  - English: What is the key revision point on page 4?
  - Answer: Working memory is small and fragile; systems should carry state instead of asking users to remember it.
- p004-q2 中文：解释本页概念：Four chunks / 四个组块
  - 答案：课程采用的实用设计近似：工作记忆大约容纳四个有意义单位。
  - English: Explain this concept: Four chunks / 四个组块
  - Answer: 课程采用的实用设计近似：工作记忆大约容纳四个有意义单位。
## 第 5 页：Slide 4 comment
- p005-q1 中文：第 5 页的核心复习点是什么？
  - 答案：这是课件批注，指出幻灯片中“七”和“四”的指代需要更清楚。正式知识点仍是：现代设计更保守地按约四个组块处理。
  - English: What is the key revision point on page 5?
  - Answer: This review comment asks for clearer wording around the seven-versus-four memory limit.
- p005-q2 中文：解释本页概念：Clarification comment / 澄清批注
  - 答案：课件制作反馈，不是正式课程内容。
  - English: Explain this concept: Clarification comment / 澄清批注
  - Answer: 课件制作反馈，不是正式课程内容。
## 第 6 页：Gone in seconds: why waiting costs
- p006-q1 中文：第 6 页的核心复习点是什么？
  - 答案：等待会消耗记忆。系统沉默太久，用户可能忘记自己刚刚要求了什么，或者重复请求。
  - English: What is the key revision point on page 6?
  - Answer: Waiting costs because unrehearsed information decays within seconds.
- p006-q2 中文：解释本页概念：Memory decay / 记忆衰退
  - 答案：没有复述或外部提示时，短时信息很快消失。
  - English: Explain this concept: Memory decay / 记忆衰退
  - Answer: 没有复述或外部提示时，短时信息很快消失。
## 第 7 页：Chunking: the same eleven digits, three ways
- p007-q1 中文：第 7 页的核心复习点是什么？
  - 答案：设计时要把信息按用户熟悉结构分组。列表太长就放到界面上，而不是要求用户记忆。
  - English: What is the key revision point on page 7?
  - Answer: Chunking uses existing knowledge to reduce working-memory load.
- p007-q2 中文：解释本页概念：Familiar chunk / 熟悉组块
  - 答案：用户已知的模式或单位，可以被当成一个信息项处理。
  - English: Explain this concept: Familiar chunk / 熟悉组块
  - Answer: 用户已知的模式或单位，可以被当成一个信息项处理。
## 第 8 页：Recognition beats recall
- p008-q1 中文：第 8 页的核心复习点是什么？
  - 答案：界面越能把选项放到世界中，用户越不必从记忆中召回。菜单、按钮、建议 chips 都是在支持识别。
  - English: What is the key revision point on page 8?
  - Answer: Recognition is easier than recall because visible cues reduce memory demand.
- p008-q2 中文：解释本页概念：Knowledge in the world / 世界中的知识
  - 答案：界面中可见的提示、选项和状态，帮助用户识别而非回忆。
  - English: Explain this concept: Knowledge in the world / 世界中的知识
  - Answer: 界面中可见的提示、选项和状态，帮助用户识别而非回忆。
## 第 9 页：The blank chat box is a command line
- p009-q1 中文：第 9 页的核心复习点是什么？
  - 答案：这页很适合批判 AI 聊天界面。空白输入框让用户自己猜系统能力；建议、来源、最近行动能减少 recall burden。
  - English: What is the key revision point on page 9?
  - Answer: A blank chat box forces recall of capabilities; visible suggestions and state support recognition.
- p009-q2 中文：解释本页概念：Blank-box recall burden / 空白框回忆负担
  - 答案：空输入框要求用户自己记住系统能做什么和当前状态。
  - English: Explain this concept: Blank-box recall burden / 空白框回忆负担
  - Answer: 空输入框要求用户自己记住系统能做什么和当前状态。
## 第 10 页：Cognitive load: three kinds, one budget
- p010-q1 中文：第 10 页的核心复习点是什么？
  - 答案：认知负荷不是全部都坏。任务本身复杂无法完全消除，但界面额外制造的外在负荷应该减少。
  - English: What is the key revision point on page 10?
  - Answer: Cognitive load has one limited budget; designers can especially reduce extraneous load.
- p010-q2 中文：解释本页概念：Extraneous load / 外在负荷
  - 答案：由界面或教学设计额外制造、不是任务本身必须的负担。
  - English: Explain this concept: Extraneous load / 外在负荷
  - Answer: 由界面或教学设计额外制造、不是任务本身必须的负担。
## 第 11 页：The same request, two designs
- p011-q1 中文：第 11 页的核心复习点是什么？
  - 答案：同样模型可以因为界面不同而负荷差异巨大。显示可比较信息通常比逐条读出更适合复杂选择。
  - English: What is the key revision point on page 11?
  - Answer: The model is unchanged, but visual presentation shifts work from memory to recognition.
- p011-q2 中文：解释本页概念：Memory-to-recognition shift / 从记忆转向识别
  - 答案：通过显示选项和状态，减少用户必须记住的信息。
  - English: Explain this concept: Memory-to-recognition shift / 从记忆转向识别
  - Answer: 通过显示选项和状态，减少用户必须记住的信息。
## 第 12 页：The same request under two load conditions
- p012-q1 中文：第 12 页的核心复习点是什么？
  - 答案：情境会改变设计。桌面上能显示长列表，驾驶时则要限制项目数并避免视觉检查。
  - English: What is the key revision point on page 12?
  - Answer: The right design depends on current task context; driving changes the load and safety profile.
- p012-q2 中文：解释本页概念：Context-dependent load / 情境依赖负荷
  - 答案：同一界面在不同用户任务下可能带来不同认知负荷。
  - English: Explain this concept: Context-dependent load / 情境依赖负荷
  - Answer: 同一界面在不同用户任务下可能带来不同认知负荷。
## 第 13 页：Your turn: recall, recognition, load
- p013-q1 中文：第 13 页的核心复习点是什么？
  - 答案：练习训练你识别界面是否要求 recall，以及如何把信息搬到世界中来降低外在负荷。
  - English: What is the key revision point on page 13?
  - Answer: The activity asks students to classify recall/recognition moments and redesign one cue to be visible.
- p013-q2 中文：解释本页概念：Recall vs recognition audit / 回忆-识别审计
  - 答案：检查界面是否不必要地要求用户从记忆中取回信息。
  - English: Explain this concept: Recall vs recognition audit / 回忆-识别审计
  - Answer: 检查界面是否不必要地要求用户从记忆中取回信息。
## 第 14 页：Mental models: Different representations
- p014-q1 中文：第 14 页的核心复习点是什么？
  - 答案：秋千漫画说明：不同角色对同一需求的理解会分叉。系统最终呈现出来的样子会塑造用户模型。
  - English: What is the key revision point on page 14?
  - Answer: The tree-swing cartoon shows that different stakeholders form different models of the same request.
- p014-q2 中文：解释本页概念：System image / 系统形象
  - 答案：用户实际看到和接触到的系统表现，是设计师模型传递给用户的媒介。
  - English: Explain this concept: System image / 系统形象
  - Answer: 用户实际看到和接触到的系统表现，是设计师模型传递给用户的媒介。
## 第 15 页：Mental models: the runnable theory in the head
- p015-q1 中文：第 15 页的核心复习点是什么？
  - 答案：心理模型的标准不是工程准确，而是能否帮助用户预测系统。设计要通过线索和反馈塑造可用模型。
  - English: What is the key revision point on page 15?
  - Answer: A mental model is a runnable internal theory that supports prediction, even if it is not technically exact.
- p015-q2 中文：解释本页概念：Runnable theory / 可运行理论
  - 答案：用户可以在脑中运行的系统理解，用来预测行动后果。
  - English: Explain this concept: Runnable theory / 可运行理论
  - Answer: 用户可以在脑中运行的系统理解，用来预测行动后果。
## 第 16 页：A model built from cues
- p016-q1 中文：第 16 页的核心复习点是什么？
  - 答案：AI 系统的小线索会造成大期待。记忆必须可见可编辑，否则用户不知道系统到底记住什么。
  - English: What is the key revision point on page 16?
  - Answer: Cues such as greetings and references to yesterday shape assumptions about identity and memory.
- p016-q2 中文：解释本页概念：Visible memory / 可见记忆
  - 答案：用户能查看、编辑和理解系统保存内容的设计。
  - English: Explain this concept: Visible memory / 可见记忆
  - Answer: 用户能查看、编辑和理解系统保存内容的设计。
## 第 17 页：Explanation dosage: what is just right?
- p017-q1 中文：第 17 页的核心复习点是什么？
  - 答案：解释不是越多越好，也不是越少越好。目标是让用户形成能预测系统行为的模型。
  - English: What is the key revision point on page 17?
  - Answer: Explanation dosage must balance completeness, soundness, and cognitive effort.
- p017-q2 中文：解释本页概念：Soundness and completeness / 可靠性与完整性
  - 答案：解释是否真实反映系统，以及是否覆盖形成正确模型所需信息。
  - English: Explain this concept: Soundness and completeness / 可靠性与完整性
  - Answer: 解释是否真实反映系统，以及是否覆盖形成正确模型所需信息。
## 第 18 页：Three dosages of one explanation
- p018-q1 中文：第 18 页的核心复习点是什么？
  - 答案：好解释要说清输入、边界和控制路径。过少会让用户瞎猜，过多会制造外在负荷。
  - English: What is the key revision point on page 18?
  - Answer: A just-right explanation states what was used, what was not used, and how the user can change the result.
- p018-q2 中文：解释本页概念：Explanation dosage / 解释剂量
  - 答案：解释信息量的设计，需要足以校准模型但不过载。
  - English: Explain this concept: Explanation dosage / 解释剂量
  - Answer: 解释信息量的设计，需要足以校准模型但不过载。
## 第 19 页：Slide 17 comment
- p019-q1 中文：第 19 页的核心复习点是什么？
  - 答案：这是课件批注，指出“39 个权重”应解释为大量特征的例子，而不是一个特殊数字。
  - English: What is the key revision point on page 19?
  - Answer: This review comment asks whether 39 has a specific meaning or simply means too many features.
- p019-q2 中文：解释本页概念：Example magnitude / 示例数量
  - 答案：用来表达过载的数量示例，需避免被误解为固定指标。
  - English: Explain this concept: Example magnitude / 示例数量
  - Answer: 用来表达过载的数量示例，需避免被误解为固定指标。
## 第 20 页：Human memory is not computer memory
- p020-q1 中文：第 20 页的核心复习点是什么？
  - 答案：不要把 AI memory 拟人化。人的记忆是重构性的，机器记忆是存储和检索策略；界面必须说明系统到底记住什么。
  - English: What is the key revision point on page 20?
  - Answer: Human and computer memory fail differently, so memory terminology must be precise.
- p020-q2 中文：解释本页概念：Machine memory / 机器记忆
  - 答案：系统按存储策略、键、搜索或相似性检索保留信息，不等同人类记忆。
  - English: Explain this concept: Machine memory / 机器记忆
  - Answer: 系统按存储策略、键、搜索或相似性检索保留信息，不等同人类记忆。
## 第 21 页：Phase 1: the model you want users to form
- p021-q1 中文：第 21 页的核心复习点是什么？
  - 答案：项目中不能只说“用户会理解”。你要明确想让用户形成什么模型、用哪些线索塑造它、如何证明他们形成了。
  - English: What is the key revision point on page 21?
  - Answer: The project task asks students to specify the intended user model, cues that build it, likely wrong models, and evidence of success.
- p021-q2 中文：解释本页概念：Evidence of model formation / 模型形成证据
  - 答案：用户能预测或正确操作系统，说明他们形成了目标心理模型。
  - English: Explain this concept: Evidence of model formation / 模型形成证据
  - Answer: 用户能预测或正确操作系统，说明他们形成了目标心理模型。
## 第 22 页：What they hold, and what model they form
- p022-q1 中文：第 22 页的核心复习点是什么？
  - 答案：总结页将本讲变成设计原则：少让用户记，减少外在负荷，显示状态，设计解释剂量，谨慎处理记忆隐喻。
  - English: What is the key revision point on page 22?
  - Answer: The synthesis links working memory limits, extraneous load, mental models, explanations, and memory terminology.
- p022-q2 中文：解释本页概念：State carried by system / 系统承担状态
  - 答案：系统显示和保存必要上下文，而不是让用户在脑中保留。
  - English: Explain this concept: State carried by system / 系统承担状态
  - Answer: 系统显示和保存必要上下文，而不是让用户在脑中保留。
## 第 23 页：References and further reading
- p023-q1 中文：第 23 页的核心复习点是什么？
  - 答案：参考页覆盖工作记忆、短时遗忘、认知负荷、心理模型、解释剂量和 Norman 的设计理论。
  - English: What is the key revision point on page 23?
  - Answer: The references anchor memory capacity, decay, cognitive load, mental models, explanation dosage, and design theory.
- p023-q2 中文：解释本页概念：Reference cluster / 参考文献群
  - 答案：按概念分组的一组来源，用来支撑本讲机制。
  - English: Explain this concept: Reference cluster / 参考文献群
  - Answer: 按概念分组的一组来源，用来支撑本讲机制。
## 第 24 页：Optional viewing: Her (2013)
- p024-q1 中文：第 24 页的核心复习点是什么？
  - 答案：可选观看把本讲所有概念放进一个电影交互案例：心理模型、系统形象、记忆、解释剂量、拟人化和期待形成。
  - English: What is the key revision point on page 24?
  - Answer: The optional viewing applies the lecture concepts to a human-like conversational OS.
- p024-q2 中文：解释本页概念：Anthropomorphic cue / 拟人化线索
  - 答案：声音、人格和对话流畅性等让用户把系统理解成人一样的线索。
  - English: Explain this concept: Anthropomorphic cue / 拟人化线索
  - Answer: 声音、人格和对话流畅性等让用户把系统理解成人一样的线索。