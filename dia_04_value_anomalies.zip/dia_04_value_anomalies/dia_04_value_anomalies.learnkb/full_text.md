# 来源：4. Data Quality II - value anomalies - Lecture Notes.pdf

<!-- SOURCE: 4. Data Quality II - value anomalies - Lecture Notes.pdf -->

<!-- PDF 页 1 -->

Data Quality II:
Anomaly Detection

Prof. Paolo Missier
School of Computer Science
University of Birmingham, UK

Data-intensive AI
2026/27 Sem 1

<!-- PDF 页 2 -->

Detecting Univariate outliers: Z-score

Given a set 𝐱 = 𝑥1 … 𝑥𝑛  of points, the z-score 𝑧𝑖 of 𝑥𝑖 is defined as:

Rule of thumb:  Flag 𝑥𝑖 a point as anomalous when |𝑧𝑖 > 𝜏

This heuristics for detecting anomalies works well
when 𝒙 is approximately normally distributed

In this case, 𝜏 = 3 is a reasonable choice, because only about only ≈0.3% of points have |𝑧𝑖 >
3

<!-- PDF 页 3 -->

Z-score: limitations

The average is not a robust estimator for the true mean of the distribution

Example:

Consider 𝐱 = 6.27,6.34,6.25,6.31,6.28

Suppose a single point is entered incorrectly:
𝐱’ = 6.27,6.34,6.25,63.1,6.28

Why is this point not flagged as 
outlier”?

the outlier inflates both the mean and the std
This drags the outlier's own score back down toward "normal."

x

6.27

6.34

6.25

6.31

6.28

x

6.27

6.34

6.25

63.1

6.28

Z

−0.566

+1.414

−1.131

+0.566

−0.283

Z

−0.448

−0.445

−0.449

+1.789

−0.447

mean = 6.29
std = 0.035

No outliers

mean = 17.6480
std = 25.4085

<!-- PDF 页 4 -->

Z-score in Code: trip_distance

dist_stats = trips.agg(

F.mean("trip_distance").alias("mean_dist"),

F.stddev("trip_distance").alias("std_dist"),

).collect()[0]

trips = trips.withColumn(

"distance_zscore",
(F.col("trip_distance") - mean_dist) / std_dist

).withColumn(

"distance_anomaly_z",

F.when(F.abs(F.col("distance_zscore")) > 3, 1).otherwise(0)

)

• One Spark job computes mean_dist and std_dist as two driver-side scalars.

• Every row's distance_zscore and the boolean distance_anomaly_z flag are then computed 

column-wise, in parallel, with no further driver round-trip.

<!-- PDF 页 5 -->

MAD: A more robust estimator

Median: the mid value when the data points are sorted

MAD: Median of all Absolute Deviations from the median:

(1.483 is a correction factor that makes the MAD unbiased)

Note that for the two example sets of data points, both median and MAD are the same:

X = {6.25, 6.27, 6.28, 6.31, 6.34}

X’ = {6.25, 6.27, 6.28, 6.34, 63.1}

median = 6.28, MAD = 0.044

<!-- PDF 页 6 -->

Replacing z-score with MAD

If we replace average with median and standard deviation with MAD in the z-score equation:

The new scores for X’ = {6.27, 6.34, 6.25, 63.1, 6.28} become:  

−0.22, 1.35, −0.67, 1277.5, 0.0 

where now the outlier is clearly identified 

•
The median and MAD stay stable even if up to half the data is extreme
• A few very large values can't drag the median the way they drag the mean

<!-- PDF 页 7 -->

MAD in Code: fare_amount

fare_median = trips.approxQuantile("fare_amount", [0.5], 0.001)[0]

trips = trips.withColumn("fare_abs_dev",

F.abs(F.col("fare_amount") - fare_median))

mad = trips.approxQuantile("fare_abs_dev", [0.5], 0.001)[0]

MODIFIED_Z_THRESHOLD = 3.5
trips = trips.withColumn(

"fare_modified_z",
F.lit(0.6745) * (F.col("fare_amount") - fare_median) / F.lit(mad)

).withColumn(

"fare_anomaly_mad",

F.when(F.abs(F.col("fare_modified_z")) > MODIFIED_Z_THRESHOLD, 1).otherwise(0))

Two lightweight Spark scans: one approxQuantile() call for the median of fare_amount, a second for 
the median of the absolute deviations

Both stay on the workers; only two scalars return to the driver.

<!-- PDF 页 8 -->

Anomaly Detection: Isolation Forest

How it Works

Key Advantage: Multivariate

• Builds an ensemble of random binary trees

• Catches implausible combinations of features, not just extreme single values

• At each node, a random feature and split value are chosen

• Anomalies sit in sparse regions of feature space, so they get isolated (reach a 

leaf) after very few splits

score = 2^(−mean path length / c(n))

score → 1: likely anomaly.  score → 0.5: normal.

• Example: 0.5-mile trip + $40 fare + 90-minute duration — each figure is 

individually plausible, but the combination is anomalous (e.g. metered while 
stuck in traffic, or fraud)

• Z-score and MAD would never flag this, since each column looks normal on its 

own

Limitation: scikit-learn's IsolationForest does not run natively on Spark workers — it needs the train → broadcast → score pattern shown on the next slide.

<!-- PDF 页 9 -->

Isolation Forest

build a random tree, where
- at each node, a random feature and split 

value are chosen

Repeat until we have a forest of random trees

The average path length to a leaf is used as a 
measure of normality

Insight: Anomalies sit in sparse regions of 
feature space, so they reach a leaf after very 
few splits 
- use the length of a path to a sample to flag 
likely outliers

Key reference: F. T. Liu, K. M. Ting and Z. Zhou, "Isolation Forest," 2008 Eighth IEEE International Conference on 
Data Mining, 2008, pp. 413-422, doi: 10.1109/ICDM.2008.17.
