from __future__ import annotations

import html, json, re, shutil, subprocess
from datetime import datetime
from pathlib import Path

PDF = Path(r"E:\UOB Artificial Intelligence\Intelligent Interactive Systems\Week 1\W01_L03_Human_Centred_Intelligent_Interaction_and_the_Shape_of_the_Module_v5_novideo.pdf")
SLUG = "iis_w01_l03"
TITLE = "Human-Centred Intelligent Interaction and the Shape of the Module"
WORK = Path(r"E:\UOB Artificial Intelligence\Codex Workspace\learn_from_materials") / SLUG
KB = WORK / f"{SLUG}.learnkb"
ASSETS = WORK / "assets" / "pages"
DELIVERY = WORK / "delivery"
OUT_HTML = DELIVERY / "IIS_W01_L03_page_by_page_companion.html"
OUT_MD = DELIVERY / "IIS_W01_L03_page_by_page_companion.md"

PAGES = {
1: ("Human-Centred Intelligent Interaction and the Shape of the Module", "以人为中心的智能交互与模块形状。\n\n智能交互系统 - 第 1 周 - 第 3 讲。伯明翰大学。\n\n以人为中心的设计给了我们判断智能交互的标准。\n\n- 我们会把 human-centred 转化为三个可以用来测试设计的承诺。\n- 我们会把二维框架、十八条指南、混合主动权和期待鸿沟连接到你的项目。\n\n根据 Shneiderman（2022）。", "本讲把“以人为中心”从口号变成可检验标准：用户是否保留控制、系统是否清楚地表达能力与边界、主动权规则是否可说明。", "The lecture turns human-centred design into testable commitments for intelligent systems.", [["Human-centred design / 以人为中心设计", "把人的活动、控制、理解、恢复和责任放在系统设计中心。"]]),
2: ("Two inbox assistants, one tagline", "两个收件箱助手，一个宣传语。\n\n第 3 讲 - 引入。\n\n差别在于人保留了多少控制。\n\n- 两个假想助手都说“围绕你而设计”，也节省相同时间，但 A 在你离开时行动，事后报告。\n- B 先提出建议，由你决定；每个被接受的改动都可以撤销。\n- 互动 1：写一句话说明哪个是以人为中心的，并准确说出差别在哪里。\n\n假想收件箱助手。", "这一页说明 human-centred 不是看宣传语，而是看控制结构。B 更接近以人为中心，因为它保留了审批和撤销。", "The difference between the two assistants is not productivity but retained human control.", [["Human control / 人类控制", "人在系统行动前后保留审核、批准、撤销和纠错能力。"]]),
3: ("'Human-centred' as three commitments", "“以人为中心”作为三个承诺。\n\n第 3 讲 - 中心问题。\n\n以人为中心设计提出三个可测试承诺。\n\n- 问责：当一个人无法成功使用系统时，检查设计（Norman，2013）。\n- 两个维度：自动化和人类控制是分开的；要设计两者都高的系统（Shneiderman，2022）。\n- 主动权：谁接下来行动是一条明确、可测试的规则（Horvitz，1999；Amershi 等，2019）。\n- 中心问题：这个系统为谁而设计？当它能推断和行动时，“以人为中心”要求我们承担什么？", "三个承诺是本讲骨架：错误先问设计责任；自动化不必牺牲控制；系统何时行动必须有规则。", "The three commitments are accountability, two independent dimensions, and explicit initiative rules.", [["Accountability / 问责", "用户失败时先检查设计，而不是把责任推给用户。"], ["Initiative rule / 主动权规则", "说明在什么条件下人或系统采取下一步行动。"]]),
4: ("Shneiderman's two-dimensional framework", "Shneiderman 的二维框架。\n\n第 3 讲 - 框架。\n\n一个设计可以同时提高自动化和人类控制。\n\n- Shneiderman（2022）的二维框架把计算机自动化放在一条轴上，把人类控制放在另一条轴上；两者形成一个平面。\n- 目标是在两者上都高：系统可靠、安全、可信，能做有用工作，同时人仍保留控制。\n- 过度自动化会移除监督；过度控制会让人承担机器本可完成的工作。图中位置是讲师示例。", "核心误区是把自动化和控制当成此消彼长。Shneiderman 框架要求我们寻找“高自动化 + 高控制”的设计。", "Shneiderman's framework separates automation from human control so a design can aim to be high on both.", [["Two-dimensional HCAI framework / 二维 HCAI 框架", "用自动化和人类控制两条独立轴评估系统，而不是只问自动化高低。"]]),
5: ("Moving a design on the plane", "在平面上移动一个设计。\n\n第 3 讲 - 框架。\n\n提议、审查和撤销可以在不改变模型的情况下增加控制。\n\n- 在这个例子中，助手 A 和 B 使用同一个模型，自动化水平也相同。\n- B 增加提议步骤、审查和可撤销性，使设计沿人类控制轴向上移动。\n- 设计挑战是避免过度自动化和过度控制：保留有用自动化，同时给人一种可执行的监督方式。", "这页很实用：你不一定要换模型才能改善人本性。只要加 proposal、review、undo，就能增加控制。", "A design can gain human control through proposal, review, and undo without changing the underlying model.", [["Proposal-review-undo / 提议-审查-撤销", "让系统先建议，人再批准，并提供撤销路径的控制模式。"]]),
6: ("Eighteen guidelines in four phases", "四个阶段中的十八条指南。\n\n第 3 讲 - 指南。\n\n十八条指南覆盖互动的四个阶段。\n\n- 在互动开始和互动过程中，要处理能力、可靠性、时机、相关性、社会规范和偏见。\n- 当系统出错以及随着时间推移，要支持恢复、解释、谨慎学习、反馈、可见后果、控制和变更通知。\n\nAmershi 等（2019）。", "Amershi 指南把人机 AI 互动拆成生命周期：开始、过程中、出错时、长期使用中。每个阶段都有不同设计责任。", "The eighteen guidelines cover the lifecycle of human-AI interaction: initially, during interaction, when wrong, and over time.", [["Guidelines for Human-AI Interaction / 人机 AI 交互指南", "Amershi 等提出的 18 条设计指南，用于改善 AI 系统可理解、可控和可恢复性。"]]),
7: ("Initially and during: G1 to G6", "开始时和互动中：G1 到 G6。\n\n第 3 讲 - 指南。\n\nG1-G6 让系统限制和情境变得可见。\n\n- G1-G2 显示 capability envelope，也就是系统能做什么，以及可靠性；G3-G4 加入时机和相关性。\n- G5-G6 处理社会规范和偏见：匹配预期语气，并跨口音、姓名和方言测试。", "前六条关心用户一开始如何理解系统：它能做什么、做得多可靠、什么时候出现、是否相关、是否符合社会场景且不带偏见。", "G1-G6 make capability, reliability, timing, relevance, social norms, and bias visible.", [["Capability envelope / 能力边界", "系统能可靠完成和不能完成的范围。"]]),
8: ("When wrong and over time: G7 to G18", "出错时和长期使用中：G7 到 G18。\n\n第 3 讲 - 指南。\n\n出错是一个正常阶段，界面必须支持它。\n\n- G7-G11 让调用、忽略和纠正更高效；在不确定时缩小范围并解释行动。\n- G12-G18 支持记忆、谨慎学习、细粒度反馈、可见后果、全局控制和变更通知。", "后十二条承认 AI 会错，所以要设计恢复和长期学习控制。重点不是让系统永不出错，而是错了之后人能看见、理解和修正。", "G7-G18 address invocation, dismissal, correction, scoped uncertainty, explanation, memory, cautious learning, feedback, consequences, controls, and change notifications.", [["Cautious learning / 谨慎学习", "系统从用户行为中学习时不要过度推广，应让用户知道并能控制。"]]),
9: ("Who moves next is a design decision", "谁下一步行动，是一个设计决策。\n\n第 3 讲 - 混合主动权。\n\n混合主动权把下一步行动变成共享的设计决策。\n\n- 在手动例子中，人创建会议；在自动例子中，系统在人审查之前创建会议。\n- 在混合主动权中，系统提出会议，人来决定。双方都能推进任务。\n- Horvitz（1999）把这个决定连接到不确定性、注意力和错误猜测的成本，并用对话解决重要不确定性。", "Mixed initiative 的本质是分配下一步行动权：人做、系统做，还是系统建议人决定。选择取决于置信度、注意力和错误成本。", "Mixed initiative treats the next move as a shared design decision based on uncertainty, attention, and cost.", [["Mixed initiative / 混合主动权", "人和系统都可以推动任务，但谁行动由明确规则决定。"]]),
10: ("Act, ask or wait", "行动、询问或等待。\n\n第 3 讲 - 混合主动权。\n\n根据后果选择行动、询问或等待。\n\n- 同时考虑系统对人想要该行动的置信度和出错成本。\n- 在这个定性规则中，置信度高且错误成本低时行动；不确定或成本值得关注时询问；否则等待。\n- 注意力会改变决策：08:10 合适的行动，在会议中可能变成打扰。记录、测试并为规则辩护。", "这是主动权规则的简洁公式。系统何时自动行动不应凭感觉，而要把置信度、错误成本和用户注意状态写成可测试规则。", "Act, ask, or wait should be chosen by considering confidence, error cost, and attention.", [["Act-ask-wait rule / 行动-询问-等待规则", "高置信低成本就行动；有不确定或成本就询问；否则等待。"]]),
11: ("The gulf between expectation and experience", "期待与体验之间的鸿沟。\n\n第 3 讲 - 期待鸿沟。\n\n期待鸿沟关心人们期待系统理解什么。\n\n- 本讲把“像有一个私人助理”与 Luger 和 Sellen（2016）的研究题目“像有一个非常糟糕的私人助理”进行对比。\n- 受访者报告了简单任务可靠性、无法解释的失败和能力不清，随后发展出变通办法或更少使用系统。\n- 设计解释是期待与体验不匹配：呈现方式塑造人们相信助手能做什么。", "宣传和界面会塑造用户期待。如果系统看起来像真人助理，用户会期待它理解更多；实际能力不足就形成 expectation gulf。", "The expectation gulf is a mismatch between what people expect an assistant to understand and what it reliably does.", [["Expectation gulf / 期待鸿沟", "系统呈现出的能力形象与真实体验之间的差距。"]]),
12: ("The gulf is a mental-model mismatch", "这个鸿沟是一种心理模型错配。\n\n第 3 讲 - 期待鸿沟。\n\n让系统限制可见，使人能修正自己的心理模型。\n\n- 心理模型是人对系统如何工作的理解，由过去经验和助手如何呈现自己共同塑造。\n- 当能力边界保持隐藏时，这种理解无法根据系统实际可靠行为得到纠正。\n- 说明它能做什么以及做得多好（G1、G2）传达能力和可靠性；在不确定时限定范围并解释原因（G10、G11）缩小不确定服务并解释行为。这些设计动作会减少错配。", "期待鸿沟不是单纯用户误会，而是系统没有给足证据让用户校准心理模型。能力边界、可靠性、范围限定和解释都是校准工具。", "The gulf can be reduced by making limits, reliability, uncertainty, and explanations visible so users can revise their mental models.", [["Mental-model mismatch / 心理模型错配", "用户以为系统怎样工作，与系统实际可靠能力不一致。"]]),
13: ("Your turn: name the guideline, then the fix", "轮到你：说出指南，再提出修复。\n\n第 3 讲 - 互动 2。\n\n诊断被破坏的指南，再提出具体修复。\n\n- A 连续四次重复“抱歉，我没听懂”然后停止。B 因一次误触拇指滑动就发送智能回复，且无法召回。\n- C 在别人用你的手机播放一下午儿童歌曲后，悄悄重写音乐档案。\n- 用两分钟说出指南、修复，以及被破坏的承诺：问责、两个维度，或明确主动权规则。", "练习要求你不要只说“体验差”，而要把问题映射到具体指南和三个承诺。例如误触发送破坏主动权与可撤销性，静默改档案破坏谨慎学习与通知。", "The activity trains diagnosis: name the broken guideline, propose a repair, and link it to one of the commitments.", [["Guideline diagnosis / 指南诊断", "把交互失败映射到具体人机 AI 指南，再提出修复。"]]),
14: ("The recommender, initially", "推荐器：初始阶段。\n\n第 3 讲 - worked example。\n\n解释推荐器使用什么，以及在哪里可能不可靠。\n\n- 说明它能做什么（G1）：它根据你播放和保存的内容推荐；它绝不会购买、分享或发布。\n- 说明它做得多好（G2）：熟悉类型上更好，新类型上较弱，并标注低置信推荐。\n- 显示关于你的模型在哪里以及如何检查。缺少这些解释会让后来的推荐更难理解和信任。", "推荐系统一开始就要亮明能力边界、可靠性和用户模型位置。这样用户才知道推荐来自哪里，也知道它不会越权。", "The recommender should initially reveal capability, reliability, confidence, and where the user model can be inspected.", [["User model / 用户模型", "系统保存的关于用户偏好、历史和推断的表示。"]]),
15: ("The recommender, during interaction", "推荐器：互动过程中。\n\n第 3 讲 - worked example。\n\n时机、相关性和理由让推荐可检查。\n\n- 时机（G3）：工作日 08:10 的通勤歌单，在通话中保持安静。\n- 相关性（G4）：三个符合当前情境的卡片，让用户看到为什么现在重要。\n- 解释原因（G11）：“因为你昨天保存了 Night Drive”。用户可以挑战这个推断，并了解系统使用了什么信息。", "推荐不是只给结果，还要让用户检查“为什么现在推荐这个”。时机、情境相关性和简短理由能增强可见性。", "During interaction, timing, relevance, and reasons make recommendations checkable.", [["Reason-giving / 给出理由", "用简短证据说明推荐为何出现，帮助用户挑战或校准系统推断。"]]),
16: ("The recommender, when wrong", "推荐器：出错时。\n\n第 3 讲 - worked example。\n\n纠正应该处理错误的档案更新，而不只是隐藏卡片。\n\n- 有人借你的手机一下午后，首页变成儿歌。轻松忽略（G8）只能隐藏卡片；轻松纠正（G9）允许“那是别人”修复原因。\n- 不确定时缩小范围（G10）把异常一天视为不确定，并限制系统改变的内容。\n- 静默更新还破坏谨慎适应（G14）、通知用户变化（G18）和全局控制（G17）。", "真正修复推荐错误要改原因，而不是只删结果。系统需要识别异常行为、暂停学习或让用户标记“不是我”。", "When a recommender is wrong, correction should address the mistaken profile update, not only dismiss the visible tile.", [["Cause-level correction / 原因层修正", "修正导致错误输出的用户模型或学习记录，而不是只隐藏表面结果。"]]),
17: ("Slide 16 comments", "第 16 页评论。\n\nEO1：这些是指向未来讲座的引用吗？如果是，没人会记得。也许最好把它们关联到一个概念，而不是一个数字。\n\nDG1：它们是论文中的点。\n\nEyal Ofek，2026-09-23；Daniele Giunchi，2026-09-24。", "这一页是课件批注，不是正式授课内容。它提醒我们：引用或编号如果不自明，会增加理解负担；更好的做法是把引用连接到概念。", "This page contains review comments rather than lecture content. It highlights that references should be concept-linked rather than opaque numbers.", [["Review comment / 课件批注", "课件制作过程中的反馈，不应和正式课程主张混淆。"]]),
18: ("The recommender, over time: the fix", "推荐器：长期使用中的修复。\n\n第 3 讲 - worked example。\n\n让档案变化谨慎、可见、可控。\n\n- 谨慎适应（G14）：根据多日重复行为更新档案，并把异常日期单独保留以供审查。\n- 变化通知（G18）：解释“你的推荐发生变化，因为……”并显示证据和选择。\n- 全局控制（G17）：访客会话、暂停学习、重置，以及查看使用了什么。推荐器保留准确性，人获得控制。", "这页给出推荐器长期学习的好设计：不要因为一天异常就改用户模型；要通知变化、显示证据，并提供全局控制。", "The fix is cautious, visible, controllable adaptation: repeated evidence, change notifications, and global controls.", [["Guest session / 访客会话", "允许他人使用设备而不污染主用户模型的模式。"]]),
19: ("The project is a compact research paper", "项目是一篇紧凑的研究论文。\n\n第 3 讲 - 项目连接。\n\n项目要发展一个问题、一个系统和关于它的证据。\n\n- 阶段 1，第 1-4 周（5%）：建立问题、相关工作、空白、问题和贡献，提交约 700 字图文文档和约 5 分钟视频。\n- 阶段 2，第 5-9 周（10%）：开发原型并记录 AI 使用；第 6 周是阅读周。\n- 阶段 3，第 10-11 周（5%）：呈现证据和海报。项目是连续评估，占模块 20%；期末考试占 80%。", "项目不是单纯做 demo，而是小型研究：问题、文献、空白、贡献、原型和证据必须连起来。", "The project is framed as a compact research paper: question, system, evidence, and contribution.", [["Research contribution / 研究贡献", "项目相对已有工作的新增价值，可以体现在问题、设计、实现或评估证据上。"]]),
20: ("Eleven weeks, three phases, one final exam", "十一周，三个阶段，一场期末考试。\n\n第 3 讲 - 项目连接。\n\n三个项目阶段构成模块 20%；期末考试构成 80%。\n\n- 项目（20%）：阶段 1 占 5%，第 1-4 周；阶段 2 占 10%，第 5-9 周；阶段 3 占 5%，第 10-11 周。\n- 期末考试（80%）在考试期进行。每周 Canvas quizzes 是 formative，也就是形成性练习，不计分。\n\n提交日期发布在 Canvas。", "这页是 assessment 结构。重要的是项目三阶段持续推进，Canvas quiz 用于练习，不计入成绩。", "The assessment structure is 20% project across three phases and 80% final exam; weekly quizzes are formative.", [["Formative assessment / 形成性评估", "用于学习反馈但不计入最终成绩的练习。"]]),
21: ("Three books, and how the module reads them", "三本书，以及模块如何阅读它们。\n\n第 3 讲 - 书目。\n\n带着每讲的设计问题阅读对应章节锚点。\n\n- Shneiderman《Human-Centered AI》（2022）支持设计立场、人类控制和治理。\n- Norman《The Design of Everyday Things》（2013）解释行动、错误、反馈和心理模型：人如何理解并操作系统。\n- LaValle《Virtual Reality》（2017）覆盖扩展现实（XR）的感知、渲染和评估。阅读指定章节锚点，而不是一次读完整本书。", "这页告诉你如何用书：不是泛读，而是按 lecture anchor 读。每本书支撑不同部分：HCAI、日常设计心理学、XR。", "The module uses three books as chapter anchors, not as whole-book reading assignments.", [["Chapter anchor / 章节锚点", "每讲指定的阅读定位，用于支撑当前设计问题。"]]),
22: ("Who is it for, and what does that commit us to?", "它是为谁而设计？这要求我们承担什么？\n\n第 3 讲 - 综合与过渡。\n\n以人为中心的系统在人推断和行动时仍让人保持控制。\n\n- 为活动被改变的人设计，目标是同时获得高自动化和高人类控制。\n- 使用十八条指南和明确的主动权规则；这个立场会在第 7、13 和 28 讲（第 11 周自我审计）回归。\n- 在实验 1 中，使用 AI 工具搜索文献并验证五个来源；你会得到一句话笔记、prompt log 和第一句 gap sentence。", "总结页把本讲压缩成项目原则：先问为谁设计，再用指南和主动权规则保证人在系统推断与行动中仍保留控制。", "The synthesis connects human-centred commitments to project work and later module checkpoints.", [["Gap sentence / 研究空白句", "用一句话说明现有工作没有解决什么，以及你的项目切入点。"]]),
23: ("References and further reading", "参考文献与延伸阅读。\n\n第 3 讲 - 参考文献。\n\n按设计主张阅读来源。\n\nShneiderman（2022）《Human-Centered AI》：第 1 部分第 3-4 章，以及第 2 部分的二维 HCAI 框架和设计指南。\n\nNorman（2013）《The Design of Everyday Things》修订扩展版：第 1 章，The Psychopathology of Everyday Things。\n\nAmershi 等（2019）《Guidelines for Human-AI Interaction》。CHI 2019, Paper 3。\n\nHorvitz（1999）《Principles of Mixed-Initiative User Interfaces》。CHI 1999，159-166。\n\nLuger 与 Sellen（2016）《Like Having a Really Bad PA: The Gulf between User Expectation and Experience of Conversational Agents》。CHI 2016，5286-5297。\n\nLaValle（2017）《Virtual Reality》。Cambridge University Press；可在 lavalle.pl/vr 免费在线阅读。今天点名，主要用于第 7-9 周。\n\n评估细节和提交日期见 module handbook 与 Canvas。\n\n- Shneiderman 和 Norman 建立设计立场；Amershi 等与 Horvitz 支持指南和主动权决策。\n- Luger 与 Sellen 研究期待鸿沟；LaValle 支持 XR 周内容。", "参考页把每个概念的学术来源对应起来。复习时按主题读：HCAI 看 Shneiderman，日常设计看 Norman，指南看 Amershi，主动权看 Horvitz，期待鸿沟看 Luger & Sellen。", "The references map each design claim to its supporting literature.", [["Citation mapping / 引文映射", "把课程概念与支撑文献一一对应，便于复习和项目引用。"]]),
}

def parse_pages():
    text=(KB/"full_text.md").read_text(encoding="utf-8")
    parts=re.split(r"<!-- PDF 页 (\d+) -->",text)
    return {int(parts[i]):parts[i+1].strip() for i in range(1,len(parts),2)}
def sources():
    return {int(x["pdf_page"]):x for x in json.loads((KB/"source_map.json").read_text(encoding="utf-8"))}
def render():
    ASSETS.mkdir(parents=True,exist_ok=True)
    if len(list(ASSETS.glob("page_*.png")))>=len(PAGES): return
    pdftoppm=shutil.which("pdftoppm") or r"C:\Users\小巷派暗黑打油诗人\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin\pdftoppm.exe"
    subprocess.run([pdftoppm,"-png","-r","120",str(PDF),str(ASSETS/"render")],check=True)
    for f in ASSETS.glob("render-*.png"):
        m=re.search(r"render-(\d+)\.png$",f.name)
        if m: f.rename(ASSETS/f"page_{int(m.group(1)):03d}.png")
def esc(s): return html.escape(s,quote=True)
def qa(p,n):
    name,desc=n[4][0]
    return [(f"第 {p} 页最重要的设计判断是什么？", n[2], f"What is the key design judgement on page {p}?", n[3]), (f"解释本页概念：{name}", desc, f"Explain this concept: {name}", desc)]
def write_kb(orig,src):
    (KB/"units").mkdir(exist_ok=True)
    units=[("u01-commitments","人本设计三承诺",range(1,6)),("u02-guidelines-initiative","18 条指南与混合主动权",range(6,14)),("u03-recommender-project","推荐器案例与项目结构",range(14,21)),("u04-books-synthesis","书目、综合与参考",range(21,24))]
    cov=[]; idx=["# IIS W01 L03 知识库索引","",f"来源材料：{PDF.name}",""]
    for uid,title,pages in units:
        idx.append(f"- [{title}](units/{uid}.md)")
        lines=[f"# {title}","","## Page-by-page Notes",""]
        for p in pages:
            n=PAGES[p]; lines += [f"### 第 {p} 页：{n[0]}","",f"Source ID: `{src[p]['source_id']}`","",n[2],"","#### Concepts"]
            for nm,d in n[4]: lines.append(f"- **{nm}**：{d}")
            lines.append(""); cov.append({"pdf_page":p,"source_id":src[p]["source_id"],"unit_id":uid,"status":"covered"})
        (KB/"units"/f"{uid}.md").write_text("\n".join(lines),encoding="utf-8")
    (KB/"INDEX.md").write_text("\n".join(idx),encoding="utf-8")
    glossary=["# 术语表",""]; seen=set()
    for n in PAGES.values():
        for nm,d in n[4]:
            if nm not in seen: seen.add(nm); glossary.append(f"- **{nm}**：{d}")
    (KB/"glossary.md").write_text("\n".join(glossary),encoding="utf-8")
    qitems=[]; practice=["# 自测题",""]
    for p,n in PAGES.items():
        practice.append(f"## 第 {p} 页：{n[0]}")
        for i,(qz,az,qe,ae) in enumerate(qa(p,n),1):
            qid=f"p{p:03d}-q{i}"; qitems.append({"id":qid,"page":p,"source_id":src[p]["source_id"],"question_zh":qz,"answer_zh":az,"question_en":qe,"answer_en":ae})
            practice += [f"- {qid} 中文：{qz}",f"  - 答案：{az}",f"  - English: {qe}",f"  - Answer: {ae}"]
    (KB/"practice.md").write_text("\n".join(practice),encoding="utf-8")
    (KB/"question-bank.json").write_text(json.dumps({"detection":"generated_from_pages","items":qitems},ensure_ascii=False,indent=2),encoding="utf-8")
    for fn,data in {"coverage-audit.json":{"learningDepth":"systematic","items":cov},"summary-ledger.json":{"claims":cov},"reverse-coverage-report.json":{"status":"complete","pages_checked":len(PAGES),"unmapped_pages":[]},"methods.json":{"methods":[{"id":"human-centred-commitment-check","name":"人本设计承诺检查法","source_pages":[3,4,5,9,10],"steps":["检查问责","检查自动化与人类控制是否都高","检查主动权规则是否明确"]}]},"methodology.json":{"status":"supported","central_problem":"智能系统推断和行动时，如何保持人类控制与可校准期待。"}}.items():
        (KB/fn).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    (KB/"coverage-audit.md").write_text("# 覆盖审计\n\n"+"\n".join(f"- PDF 页 {x['pdf_page']}：covered - {x['source_id']}" for x in cov),encoding="utf-8")
    (KB/"patterns.md").write_text("# 方法卡\n\n## 人本设计承诺检查法\n\n检查问责、二维自动化/控制、主动权规则。\n",encoding="utf-8")
    (KB/"methodology.md").write_text("# 整体方法论\n\n把 human-centred 转为可测试承诺，并用指南、主动权规则与期待鸿沟分析系统。\n",encoding="utf-8")
def build_html(orig,src):
    toc="\n".join(f'<a href="#page-{p}"><span>{p:02d}</span>{esc(PAGES[p][0])}</a>' for p in PAGES)
    secs=[]
    for p,n in PAGES.items():
        concepts="".join(f"<li><strong>{esc(nm)}</strong><span>{esc(d)}</span></li>" for nm,d in n[4])
        qas="".join(f"<details><summary>Q{i}. {esc(qz)} / {esc(qe)}</summary><p><strong>中文答案：</strong>{esc(az)}</p><p><strong>English answer:</strong> {esc(ae)}</p></details>" for i,(qz,az,qe,ae) in enumerate(qa(p,n),1))
        secs.append(f'<section class="page" id="page-{p}"><p class="kicker">PDF page {p:02d} · {esc(src[p]["source_id"])}</p><h2>{p}. {esc(n[0])}</h2><div class="grid"><figure><img src="../assets/pages/page_{p:03d}.png" alt="PDF page {p}"><figcaption>原始 PDF 第 {p} 页截图</figcaption></figure><div><h3>原文 / Original Text</h3><pre>{esc(orig[p])}</pre><h3>完整中文翻译</h3><div class="translation">{esc(n[1]).replace(chr(10),"<br>")}</div></div></div><div class="explain"><article><h3>中文释义</h3><p>{esc(n[2])}</p></article><article><h3>English Explanation</h3><p>{esc(n[3])}</p></article></div><h3>概念解析</h3><ul class="concepts">{concepts}</ul><h3>自测问题 / Self-check</h3>{qas}</section>')
    css='body{margin:0;font-family:"Segoe UI",Arial,"Microsoft YaHei",sans-serif;background:#f6f8fb;color:#172033;line-height:1.65}.layout{display:grid;grid-template-columns:310px 1fr}aside{position:sticky;top:0;height:100vh;overflow:auto;background:#fff;border-right:1px solid #d8dee9;padding:20px 16px}aside h1{font-size:18px;margin:0 0 8px}aside p{font-size:13px;color:#667085}nav a{display:grid;grid-template-columns:36px 1fr;gap:10px;padding:9px 8px;border-radius:6px;color:#172033;text-decoration:none;font-size:13px;line-height:1.35}nav a:hover{background:#eef7f5}nav span{color:#0f766e;font-weight:700}main{padding:32px min(4vw,48px) 80px}.hero{border-bottom:1px solid #d8dee9;margin-bottom:28px;padding-bottom:20px}.hero h2{font-size:42px;line-height:1.15;margin:0 0 12px}.page{background:#fff;border:1px solid #d8dee9;border-radius:8px;padding:24px;margin-bottom:24px;box-shadow:0 8px 24px rgba(15,23,42,.05)}.kicker{color:#0f766e;font-size:13px;font-weight:700}h2{font-size:26px;line-height:1.25}h3{font-size:17px;margin:18px 0 8px}.grid{display:grid;grid-template-columns:minmax(300px,.95fr) minmax(320px,1.05fr);gap:22px;align-items:start}img{width:100%;border:1px solid #d8dee9;border-radius:6px}figcaption{font-size:12px;color:#667085}pre{white-space:pre-wrap;word-wrap:break-word;background:#f8fafc;border:1px solid #d8dee9;border-radius:6px;padding:14px;font:13px/1.55 Consolas,monospace}.translation{background:#fff7ed;border-left:4px solid #b45309;padding:12px 14px;border-radius:6px}.explain{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:18px}article,details{border:1px solid #d8dee9;border-radius:6px;background:#fbfcfe;padding:10px 12px}.concepts li{margin:8px 0}.concepts span{display:block;color:#344054}details{margin:8px 0}summary{font-weight:700;cursor:pointer}@media(max-width:980px){.layout{grid-template-columns:1fr}aside{position:static;height:auto;max-height:46vh;border-right:0;border-bottom:1px solid #d8dee9}.grid,.explain{grid-template-columns:1fr}main{padding:24px 16px 60px}}'
    return f'<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>IIS W01 L03 Page-by-page Companion</title><style>{css}</style></head><body><div class="layout"><aside><h1>IIS W01 L03 逐页复习</h1><p>完整中文翻译 · 中英文释义 · 概念拓展 · 自测答案</p><nav>{toc}</nav></aside><main><section class="hero"><h2>{TITLE}</h2><p>基于 learn-from-materials 抽取结果重做。覆盖 23 页，保留页面截图、原文、完整中文翻译、概念解析与双语自测。</p><p>生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M")}</p></section>{"".join(secs)}</main></div></body></html>'
def build_md(orig,src):
    out=[f"# IIS W01 L03 - {TITLE}","","逐页完整翻译与复习笔记。",""]
    for p,n in PAGES.items():
        out += [f"## 第 {p} 页：{n[0]}","",f"Source ID: `{src[p]['source_id']}`","",f"![PDF page {p}](../assets/pages/page_{p:03d}.png)","","### 原文","```text",orig[p],"```","","### 完整中文翻译",n[1],"","### 中文释义",n[2],"","### English Explanation",n[3],"","### 概念解析"]
        for nm,d in n[4]: out.append(f"- **{nm}**：{d}")
        out += ["","### 自测问题"]
        for i,(qz,az,qe,ae) in enumerate(qa(p,n),1): out += [f"**Q{i} 中文：** {qz}",f"**答：** {az}",f"**Q{i} English:** {qe}",f"**Answer:** {ae}",""]
    return "\n".join(out)
def main():
    orig=parse_pages(); src=sources(); render(); DELIVERY.mkdir(parents=True,exist_ok=True); write_kb(orig,src)
    OUT_HTML.write_text(build_html(orig,src),encoding="utf-8"); OUT_MD.write_text(build_md(orig,src),encoding="utf-8")
    (WORK/"index.html").write_text(f'<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="0; url=delivery/{OUT_HTML.name}"><a href="delivery/{OUT_HTML.name}">Open</a>',encoding="utf-8")
    print(json.dumps({"html":str(OUT_HTML),"markdown":str(OUT_MD),"pages":len(PAGES),"images":len(list(ASSETS.glob("page_*.png")))},ensure_ascii=False,indent=2))
if __name__=="__main__": main()
