# IIS W01 L03 知识库索引

来源材料：W01_L03_Human_Centred_Intelligent_Interaction_and_the_Shape_of_the_Module_v5_novideo.pdf

- [人本设计三承诺](units/u01-commitments.md)
- [18 条指南与混合主动权](units/u02-guidelines-initiative.md)
- [推荐器案例与项目结构](units/u03-recommender-project.md)
- [书目、综合与参考](units/u04-books-synthesis.md)