# 自测题

## 第 1 页：Action, Error, Agency and Decision
- p001-q1 中文：第 1 页的核心复习点是什么？
  - 答案：本讲把前两讲的注意、记忆和心理模型连接到行动：用户如何知道能做什么，为什么会错，系统替人行动时能动性感如何改变。
  - English: What is the key revision point on page 1?
  - Answer: This lecture connects cues and mental models to action, error, agency, and decision-making.
- p001-q2 中文：解释本页概念：Agency / 能动性感
  - 答案：人感觉“是我在行动并造成结果”的主观体验。
  - English: Explain this concept: Agency / 能动性感
  - Answer: 人感觉“是我在行动并造成结果”的主观体验。
## 第 2 页：A door that needs a sign
- p002-q1 中文：第 2 页的核心复习点是什么？
  - 答案：门的例子说明 affordance 和 signifier 的区别。智能系统也需要把能力显示出来，否则用户不知道如何行动或如何控制。
  - English: What is the key revision point on page 2?
  - Answer: The door example introduces affordance and signifier, then maps them onto intelligent systems that hide capability or control.
- p002-q2 中文：解释本页概念：Affordance / 可供性
  - 答案：对象或系统允许某个人做的事情。
  - English: Explain this concept: Affordance / 可供性
  - Answer: 对象或系统允许某个人做的事情。
## 第 3 页：Acting through a system, and being acted for
- p003-q1 中文：第 3 页的核心复习点是什么？
  - 答案：中心问题是行动结构：用户不只是接收反馈，还要通过系统行动；当系统替人行动时，责任和控制会变复杂。
  - English: What is the key revision point on page 3?
  - Answer: The lecture asks how people act through systems and what changes when systems act on their behalf.
- p003-q2 中文：解释本页概念：Action model / 行动模型
  - 答案：用户基于线索形成的关于如何行动、会发生什么的理解。
  - English: Explain this concept: Action model / 行动模型
  - Answer: 用户基于线索形成的关于如何行动、会发生什么的理解。
## 第 4 页：Affordance, signifier, mapping
- p004-q1 中文：第 4 页的核心复习点是什么？
  - 答案：三概念是行动设计基础：系统能做什么、如何显示能做什么、控制和效果是否自然对应。
  - English: What is the key revision point on page 4?
  - Answer: Affordance, signifier, and mapping explain how users discover and perform actions.
- p004-q2 中文：解释本页概念：Mapping / 映射
  - 答案：控制项与系统效果之间的对应关系。
  - English: Explain this concept: Mapping / 映射
  - Answer: 控制项与系统效果之间的对应关系。
## 第 5 页：What tells you what a system can do?
- p005-q1 中文：第 5 页的核心复习点是什么？
  - 答案：AI 系统常有“能力不明”的问题。建议 chips 比空白输入框更强，因为它把可做事项放到世界中。
  - English: What is the key revision point on page 5?
  - Answer: A cue must indicate not just input mode but supported capability; suggestion chips are stronger signifiers than blank prompts.
- p005-q2 中文：解释本页概念：False signifier / 假能指
  - 答案：界面暗示某种能力或控制存在，但系统实际上不支持或不遵守。
  - English: Explain this concept: False signifier / 假能指
  - Answer: 界面暗示某种能力或控制存在，但系统实际上不支持或不遵守。
## 第 6 页：The two gulfs
- p006-q1 中文：第 6 页的核心复习点是什么？
  - 答案：两个鸿沟是用户行动理论核心。用户要先知道怎么做，再知道做了之后发生了什么。AI 系统常同时扩大两者。
  - English: What is the key revision point on page 6?
  - Answer: The gulf of execution concerns how to act; the gulf of evaluation concerns understanding what happened.
- p006-q2 中文：解释本页概念：Gulf of execution / 执行鸿沟
  - 答案：用户目标与可执行操作之间的距离。
  - English: Explain this concept: Gulf of execution / 执行鸿沟
  - Answer: 用户目标与可执行操作之间的距离。
## 第 7 页：A thermostat that learns
- p007-q1 中文：第 7 页的核心复习点是什么？
  - 答案：恒温器案例说明：系统可能带来好结果，但如果原因不可见，用户会失去控制感和能动性感。
  - English: What is the key revision point on page 7?
  - Answer: A learning thermostat may improve outcomes while widening the gulf of evaluation and weakening agency.
- p007-q2 中文：解释本页概念：Learning thermostat / 学习型恒温器
  - 答案：通过推断用户日程和偏好自动改变温度的系统。
  - English: Explain this concept: Learning thermostat / 学习型恒温器
  - Answer: 通过推断用户日程和偏好自动改变温度的系统。
## 第 8 页：Where the gulfs sit on the spine
- p008-q1 中文：第 8 页的核心复习点是什么？
  - 答案：这页把 Norman 的鸿沟放回 L02 脊柱。agent 的问题在于隐藏步骤太多；observability 是缩小评价鸿沟的关键。
  - English: What is the key revision point on page 8?
  - Answer: Observability narrows the gulf of evaluation by showing what happened, why, and what comes next.
- p008-q2 中文：解释本页概念：Observability / 可观察性
  - 答案：用户能看见系统内部状态、行动轨迹和后续计划的程度。
  - English: Explain this concept: Observability / 可观察性
  - Answer: 用户能看见系统内部状态、行动轨迹和后续计划的程度。
## 第 9 页：Slips versus mistakes
- p009-q1 中文：第 9 页的核心复习点是什么？
  - 答案：错误类型不同，修复也不同。把 mistake 当 slip 加确认，可能只是增加负担；把 slip 当 mistake 加解释，也解决不了误触。
  - English: What is the key revision point on page 9?
  - Answer: Slips and mistakes need different remedies, so diagnosis comes before redesign.
- p009-q2 中文：解释本页概念：Slip / 失手
  - 答案：意图正确但执行动作错。
  - English: Explain this concept: Slip / 失手
  - Answer: 意图正确但执行动作错。
## 第 10 页：Three kinds of error in one voice assistant
- p010-q1 中文：第 10 页的核心复习点是什么？
  - 答案：同一表面问题可能是系统识别错、用户失手或用户误解。修复要匹配根因。
  - English: What is the key revision point on page 10?
  - Answer: A voice-assistant failure can be system inference, user slip, or user mistake, each needing a different remedy.
- p010-q2 中文：解释本页概念：System recognition error / 系统识别错误
  - 答案：系统把输入或目标推断错。
  - English: Explain this concept: System recognition error / 系统识别错误
  - Answer: 系统把输入或目标推断错。
## 第 11 页：Your turn: slip, mistake, or system inference?
- p011-q1 中文：第 11 页的核心复习点是什么？
  - 答案：练习强调复合错误：人和系统可能同时贡献错误。删除 agent 这类高后果场景尤其需要双标签分析和恢复设计。
  - English: What is the key revision point on page 11?
  - Answer: The activity trains error diagnosis, including cases where human and system errors interact.
- p011-q2 中文：解释本页概念：Compound error / 复合错误
  - 答案：人类错误和系统推断错误共同造成失败。
  - English: Explain this concept: Compound error / 复合错误
  - Answer: 人类错误和系统推断错误共同造成失败。
## 第 12 页：The sense of agency
- p012-q1 中文：第 12 页的核心复习点是什么？
  - 答案：能动性感不是抽象哲学，而是交互体验：我想做、我做了、结果如预期出现。智能系统替人行动会打断这个链条。
  - English: What is the key revision point on page 12?
  - Answer: Agency is strongest when intended action is promptly followed by predicted outcome.
- p012-q2 中文：解释本页概念：Sense of agency / 能动性感
  - 答案：人感觉自己是行动和结果来源的体验。
  - English: Explain this concept: Sense of agency / 能动性感
  - Answer: 人感觉自己是行动和结果来源的体验。
## 第 13 页：The thermostat, redesigned for agency
- p013-q1 中文：第 13 页的核心复习点是什么？
  - 答案：设计不必取消学习功能，而是让原因、覆盖、学习内容和即将发生的改变可见可控。
  - English: What is the key revision point on page 13?
  - Answer: Agency can be restored by making causes visible, overrides persistent, and learned patterns editable.
- p013-q2 中文：解释本页概念：Override / 覆盖设置
  - 答案：用户临时或明确覆盖自动化行为的控制。
  - English: Explain this concept: Override / 覆盖设置
  - Answer: 用户临时或明确覆盖自动化行为的控制。
## 第 14 页：Who feels they acted?
- p014-q1 中文：第 14 页的核心复习点是什么？
  - 答案：自主性越高，越要设计 who acted 的可见性。共同能动性不是系统任意行动，而是人启动、系统执行、人能否决。
  - English: What is the key revision point on page 14?
  - Answer: As autonomy rises, agency becomes shared and needs visible initiation and veto.
- p014-q2 中文：解释本页概念：Co-agency / 共同能动性
  - 答案：人和系统共同推进任务，但人的启动、监督和否决仍清楚可见。
  - English: Explain this concept: Co-agency / 共同能动性
  - Answer: 人和系统共同推进任务，但人的启动、监督和否决仍清楚可见。
## 第 15 页：Bounded rationality: people satisfice
- p015-q1 中文：第 15 页的核心复习点是什么？
  - 答案：排序本身就是影响决策。用户不会无限比较，而会满足化，所以系统默认和排名具有行动力量。
  - English: What is the key revision point on page 15?
  - Answer: Rankings shape decisions because people satisfice under attention, memory, and time constraints.
- p015-q2 中文：解释本页概念：Bounded rationality / 有限理性
  - 答案：人在有限注意、记忆和时间下寻找足够好的选项，而非最优选项。
  - English: Explain this concept: Bounded rationality / 有限理性
  - Answer: 人在有限注意、记忆和时间下寻找足够好的选项，而非最优选项。
## 第 16 页：Heuristics and biases: anchoring
- p016-q1 中文：第 16 页的核心复习点是什么？
  - 答案：LLM 草稿不是中立起点。它会锚定用户后续编辑方向，所以“只是生成初稿”也在影响决策。
  - English: What is the key revision point on page 16?
  - Answer: An assistant's first draft anchors later edits, so draft generation is already a decision.
- p016-q2 中文：解释本页概念：Anchoring / 锚定
  - 答案：初始数值或建议影响后续判断。
  - English: Explain this concept: Anchoring / 锚定
  - Answer: 初始数值或建议影响后续判断。
## 第 17 页：Automation bias: introduced and parked
- p017-q1 中文：第 17 页的核心复习点是什么？
  - 答案：自动化偏差提醒我们：人可能过度依赖或错误拒绝自动化。通常正确的系统反而会诱导更危险的忽视。
  - English: What is the key revision point on page 17?
  - Answer: Automation bias covers misuse and disuse; usually-right aids can create omission and commission errors.
- p017-q2 中文：解释本页概念：Automation bias / 自动化偏差
  - 答案：人因自动化建议而过度依赖、忽略或错误行动的倾向。
  - English: Explain this concept: Automation bias / 自动化偏差
  - Answer: 人因自动化建议而过度依赖、忽略或错误行动的倾向。
## 第 18 页：Slide 17 comment
- p018-q1 中文：第 18 页的核心复习点是什么？
  - 答案：这是课件批注，指出“parked”的含义需要更清晰。当前课件解释为：介绍但不在排定讲座中回访。
  - English: What is the key revision point on page 18?
  - Answer: This review comment asks for clarification of what 'parked' means.
- p018-q2 中文：解释本页概念：Terminology clarity / 术语清晰度
  - 答案：课件中暂放、预告等词需要明确范围，避免学生误解。
  - English: Explain this concept: Terminology clarity / 术语清晰度
  - Answer: 课件中暂放、预告等词需要明确范围，避免学生误解。
## 第 19 页：Phase 1: mark your storyboard
- p019-q1 中文：第 19 页的核心复习点是什么？
  - 答案：项目任务要求你把行动、系统推断、结果和恢复画出来，并标注谁在行动。这样能暴露“系统行动但原因不可见”的问题。
  - English: What is the key revision point on page 19?
  - Answer: The project task maps storyboards to actor, gulf, signifier, and recovery.
- p019-q2 中文：解释本页概念：Storyboard audit / 故事板审计
  - 答案：逐帧标注人/系统行动、鸿沟、signifier 和恢复路径。
  - English: Explain this concept: Storyboard audit / 故事板审计
  - Answer: 逐帧标注人/系统行动、鸿沟、signifier 和恢复路径。
## 第 20 页：Slide 18 comment
- p020-q1 中文：第 20 页的核心复习点是什么？
  - 答案：这是课件批注，提醒项目连接部分可能需要更明显的过渡。
  - English: What is the key revision point on page 20?
  - Answer: This review comment suggests making the project section transition clearer.
- p020-q2 中文：解释本页概念：Section transition / 章节过渡
  - 答案：用标题或提示明确从理论转到项目任务。
  - English: Explain this concept: Section transition / 章节过渡
  - Answer: 用标题或提示明确从理论转到项目任务。
## 第 21 页：The week's theories, and where each returns
- p021-q1 中文：第 21 页的核心复习点是什么？
  - 答案：这页把 Week 2 全部理论汇总成项目工具箱。Lab 2 的核心是把 storyboard 逐帧概念化。
  - English: What is the key revision point on page 21?
  - Answer: The synthesis gathers Week 2 concepts and directs students to apply them to Lab 2 storyboards.
- p021-q2 中文：解释本页概念：Week 2 theory toolkit / 第二周理论工具箱
  - 答案：注意、记忆、心理模型、行动、错误、能动性和决策等用于分析交互的概念集合。
  - English: Explain this concept: Week 2 theory toolkit / 第二周理论工具箱
  - Answer: 注意、记忆、心理模型、行动、错误、能动性和决策等用于分析交互的概念集合。
## 第 22 页：References and further reading
- p022-q1 中文：第 22 页的核心复习点是什么？
  - 答案：参考页覆盖 Norman 行动理论、Reason 错误分类、Haggard 能动性、Simon 有限理性、Tversky/Kahneman 启发式、自动化偏差等。
  - English: What is the key revision point on page 22?
  - Answer: The references anchor action theory, error, agency, bounded rationality, heuristics, ranking effects, and automation bias.
- p022-q2 中文：解释本页概念：Action-theory sources / 行动理论来源
  - 答案：支撑 affordance、鸿沟、错误、能动性和自动化决策的文献。
  - English: Explain this concept: Action-theory sources / 行动理论来源
  - Answer: 支撑 affordance、鸿沟、错误、能动性和自动化决策的文献。
## 第 23 页：Watch the first 90 seconds clip of Wargames (1983)
- p023-q1 中文：第 23 页的核心复习点是什么？
  - 答案：可选片段把本讲所有概念放入高风险决策场景：评价鸿沟、signifier、自动化偏差、有限理性、能动性、锚定和复合错误。
  - English: What is the key revision point on page 23?
  - Answer: The WarGames clip is a compact case for gulf of evaluation, signifier failure, automation bias, bounded rationality, agency, anchoring, and compound error.
- p023-q2 中文：解释本页概念：High-stakes automation / 高风险自动化
  - 答案：系统输出会影响重大决策，要求更强可见性、核查和人类控制。
  - English: Explain this concept: High-stakes automation / 高风险自动化
  - Answer: 系统输出会影响重大决策，要求更强可见性、核查和人类控制。